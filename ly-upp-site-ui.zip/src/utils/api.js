﻿/*
 * @Description: 系统api接口
 * @Author: xuqiuting
 * @Date: 2019-06-12 10:06:06
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-02-28 15:01:22
 */
import axios from 'axios'
import { message, Modal } from 'antd'
// import createHistory from 'history/createHashHistory'
import store from 'redux/store/configureStore'
import { hex_md5 } from './MD5'
import { AUTH } from 'app/config/names'
import { userLogout } from './service'
// const history = createHistory()

function getAuth() {
  return (
    store &&
    store.getState() &&
    store.getState().login &&
    store.getState().login.data &&
    store.getState().login.data.authorization
  )
}

let base_uppcard = '/api/uppcard'
let base_excard = '/api/uppexcard'
let base = ''
let base_upp = '/api/upp'
let base_upload = '/zuul/docrepo' //上传
let base_downLoad = '/zuul/docrepo' //下载
let base_weather = '/weather' // 天气

axios.defaults.withCredentials = true
axios.defaults.headers.get['X-Requested-With'] = 'XMLHttpRequest' //Ajax get请求标识
axios.defaults.headers.post['X-Requested-With'] = 'XMLHttpRequest' //Ajax post请求标识
axios.defaults.headers.post['Content-Type'] =
  'application/x-www-form-urlencoded;charset=utf-8' //POST请求参数获取不到的问题
axios.defaults.headers.put['X-Requested-With'] = 'XMLHttpRequest' //Ajax put请求标识
axios.defaults.headers.delete['X-Requested-With'] = 'XMLHttpRequest' //Ajax delete请求标识

axios.interceptors.response.use(
  function(response) {
    return response
  },
  function(error) {
    // 弹出信息配置
    message.config({
      top: 100,
      duration: 2,
      maxCount: 1
    })
    if (error.response != null) {
      if (error.response.status == 302) {
        message.error(error.response.statusText)
        // 如果开启单点，跳转到验证平台
        // if (window.casStatus) {
        //   window.location =
        //     'auth?service=' +
        //     encodeURIComponent(
        //       window.location.origin + window.location.pathname + '#/index'
        //     )
        // } else {
        //   history.push('/login')
        // }
        userLogout()
      } else if (
        error.response.status == 401 ||
        error.response.status == 404 ||
        error.response.status == 500
      ) {
        if (!error.response.data || typeof error.response.data != 'object') {
          error.response.data = {
            data: null,
            meta: {
              success: false,
              message: error.response.statusText
            }
          }
        }
        return error.response
      } else if (error.response.status == 504) {
        if (!error.response.data || typeof error.response.data != 'object') {
          error.response.data = {
            data: null,
            meta: {
              success: false,
              message: error.response.statusText
            }
          }
        }
        return error.response
      }
    }
  }
)

axios.interceptors.request.use(function(config) {
  let user = JSON.parse(window.sessionStorage.getItem('userLogin'))
  let userCode = JSON.parse(window.sessionStorage.getItem('userCode'))

  //设置网关加密串
  try {
    let timestemp = new Date().valueOf()
    let csrfToken = hex_md5(
      'timestamp=' + timestemp + ',key=' + AUTH.GATEWAY_KEY
    )
    config.headers.get['csrfToken'] = csrfToken
    config.headers.post['csrfToken'] = csrfToken
    config.headers.get['csrfTimestamp'] = timestemp
    config.headers.post['csrfTimestamp'] = timestemp
  } catch (e) {}

  if (user) {
    config.headers.get['loginUserId'] = user.userId
    config.headers.post['loginUserId'] = user.userId
    config.headers.get['loginUserOrgId'] = user.orgId
    config.headers.post['loginUserOrgId'] = user.orgId
    // 如果是后台跳转过来，实现用户浏览功能，当前登录的账号应该是要被浏览的用户
    if (userCode && userCode.ts) {
      config.headers.get['lyupp_encode'] = userCode.s
      config.headers.post['lyupp_encode'] = userCode.s
      config.headers.get['lyupp_userId'] = user.userId
      config.headers.post['lyupp_userId'] = user.userId
      config.headers.get['lyupp_tiems'] = userCode.ts
      config.headers.post['lyupp_tiems'] = userCode.ts
    }
  }

  if (config.method == 'get') {
    config.params = {
      _t: Date.parse(new Date()) / 1000,
      ...config.params
    }
  }
  return config
})

// formdata
axios.form = obj => {
  const formData = new FormData()
  Object.keys(obj)
    .filter(
      key => Boolean(obj[key]) || (obj[key] !== null && +obj[key] === -obj[key])
    )
    .forEach(key =>
      formData.append(key, obj[key] === undefined ? '' : obj[key])
    )
  return formData
}

//将POST请求参数转换请求字符串
var querystring = require('querystring')

// 上传附件
export const uploadApi = `${base_upload}/upload`
// 上传图片
export const uploadImg = `${base_upp}/attachmentManagement/upload`
// 上传图片封装
export const reqUploadImg = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_attachmentManagement_upload')) {
    Modal.error({ title: '提示', content: '您没有权限上传图标！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(uploadImg, axios.form(params))
  }
}
// 下载
export const downloadApi = `${base_downLoad}/download`
// 获取语言
export const reqLanguage = () => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_locale_queryPage')) {
    Modal.error({ title: '提示', content: '您没有权限获取语言！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/locale`)
  }
}
// 获取登录logo
export const reqGetLoginLogo = params => {
  return axios.get(`${base}/api/uap/unauthorize/attachment/getAttachmentId`, {
    params: params
  })
}
//尝试登录
export const reqGetCasLogin = Authorization => {
  return axios.post(
    `${base}/tryLoginUserInfo`,
    null,
    Authorization && {
      headers: { Authorization }
    }
  )
}
//登录
export const reqGetLogin = params => {
  return axios.post(`${base}/login`, querystring.stringify(params))
}
// 退出
export const reqGetLogout = params => {
  return axios.get(`${base}/logout`, { params: params })
}
// 获取是否第一次登录/使用过新手指引
export const reqFirstLogin = () => {
  return axios.get(`${base_upp}/userControl/getLoginInfo`)
}
// 记录使用过新手指引
export const reqGuideHasUsed = () => {
  return axios.post(`${base_upp}/userControl/guideHasUsed`)
}
// 天气
export const reqGetWeather = params => {
  return axios.get(`${base_weather}/weather_mini`, { params: params })
}
// 获取系统配置
export const reqGetSystemConfig = params => {
  return axios.get(`${base_upp}/Unauthorize/systemConfig/type`, { params })
}
// 验证用户浏览和编辑主题的接口
export const reqCheckBrowseUser = params => {
  return axios.post(`${base_upp}/Unauthorize/checkBrowseUser`, params)
}
// 验证编辑页面的接口
export const reqCheckEditPage = params => {
  return axios.post(`${base_upp}/Unauthorize/checkPageBrowseUser`, params)
}
// 登录添加在线用户记录
export const reqAddOnlineUsersRecord = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_onlineUsers_add')) {
    Modal.error({ title: '提示', content: '您没有权限登录添加在线用户记录！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/onlineUsers/add`, params)
  }
}
// 根据编号删除附件(bh)
export const reqDeleteAttachment = attachmentId => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_attachmentManagement_delete')) {
    Modal.error({ title: '提示', content: '您没有权限删除附件！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/attachmentManagement/${attachmentId}/delete`)
  }
}
// 获取附件列表
export const reqGetAttachmentList = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-mgr-svc_attachmentManagement_queryPage')
  ) {
    Modal.error({ title: '提示', content: '您没有权限获取附件列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/attachmentManagement`, { params: params })
  }
}
// 根据页面id获取页面内容
export const reqGetPageContent = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_layout_getPageContent')) {
    Modal.error({ title: '提示', content: '您没有权限获取页面内容！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/layout/getPageContent`, { params: params })
  }
}
// 根据主题id获取页面内容
export const reqGetThemeContent = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_getPageByThemeId')) {
    Modal.error({ title: '提示', content: '您没有权限获取页面内容！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/theme/getPageByThemeId`, { params: params })
  }
}
// 获取全部的主题信息
export const reqGetAllTheme = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_getPageThemeList')) {
    Modal.error({ title: '提示', content: '您没有权限获取全部的主题信息！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/theme/getPageThemeList`, { params: params })
  }
}
// 保存页面内容
export const reqSavePageContent = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_layout_savePage')) {
    Modal.error({ title: '提示', content: '您没有权限保存页面内容！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/layout/savePage`, params)
  }
}
// 保存主题时保存页面
export const reqSaveThemeContent = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_saveTheme')) {
    Modal.error({ title: '提示', content: '您没有权限保存页面！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/theme/savePage`, params)
  }
}
//根据页面id获取页面配置
export const reqGetPageConf = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_pages_getPageConfByUser')) {
    Modal.error({ title: '提示', content: '您没有权限获取页面配置！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/pages/getPageConf`, { params: params })
  }
}
// 获取页面列表
export const reqGetPath = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_pages_getPage')) {
    Modal.error({ title: '提示', content: '您没有权限获取页面列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/pages/getPage`, { params: params })
  }
}
// 保存|修改页面
export const reqSavePath = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_pages_savePage')) {
    Modal.error({ title: '提示', content: '您没有权限保存|修改页面！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/pages/savePage`, params)
  }
}
// 保存主题
export const reqSaveTheme = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_saveTheme')) {
    Modal.error({ title: '提示', content: '您没有权限保存主题！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/theme/saveTheme`, params)
  }
}
// 获取主题列表
export const reqGetThemeList = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_getThemeData')) {
    Modal.error({ title: '提示', content: '您没有权限获取主题列表数据！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/theme/getThemeData`, { params: params })
  }
}
// 获取我的主题
export const reqGetMyTheme = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_getMyThemeData')) {
    Modal.error({ title: '提示', content: '您没有权限获取我的主题列表数据！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/theme/getMyThemeData`, { params: params })
  }
}
// 删除页面
export const reqDeletePage = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_pages_delPage')) {
    Modal.error({ title: '提示', content: '您没有权限删除页面！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/pages/delPage`, params)
  }
}
// 页面排序
export const reqSortPage = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_pages_updatePageSort')) {
    Modal.error({ title: '提示', content: '您没有权限页面排序！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/pages/updatePageSort`, params)
  }
}
// 页面默认路径
export const reqPagePath = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_pages_selectIndexUrl')) {
    Modal.error({ title: '提示', content: '您没有权限获得自动生成路径！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/pages/selectIndexUrl`, { params })
  }
}
// 根据页面路径获取页面配置
export const reqPageConfigByPagePath = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_pages_getPageByUserAndUrl')) {
    Modal.error({ title: '提示', content: '您没有权限获取页面配置！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/pages/getPageByUserAndUrl`, { params })
  }
}
// 保存系统页面并还原修改过的内容
export const reqSavePageAndRestore = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_layout_savePageAndRestore')) {
    Modal.error({ title: '提示', content: '您没有权限保存系统页面！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/layout/savePageAndRestore`, params)
  }
}
// 编辑页面高级样式
export const reqEditPageCss = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_pages_editPageCss')) {
    Modal.error({ title: '提示', content: '您没有权限编辑页面高级样式！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/pages/editPageCss`, params)
  }
}
// 卡片查询列表
export const reqGetCardList = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-mgr-svc_useCardManage_selectUseCardList')
  ) {
    Modal.error({ title: '提示', content: '您没有权限查询卡片列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/useCardManage`, { params: params })
  }
}
// 卡片信息
export const reqGetCardProps = params => {
  // if (
  //   !getAuth().hasOwnProperty('')
  // ) {
  //   Modal.error({ title: '提示', content: '您没有权限查询卡片信息！' })
  //   return new Promise((resolve, reject) => {
  //     reject()
  //   })
  // } else {
  return axios.get(`${base_upp}/layout/getCardProps`, { params: params })
  // }
}
// 添加卡片搜索记录
export const addSearchLog = searchName => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_useCardManage_addSearchLog')) {
    Modal.error({ title: '提示', content: '您没有权限添加卡片搜素历史！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/useCardManage/addSearchLog/${searchName}`)
  }
}
// 最近查询列表
export const reqGetCardSearchList = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_useCardManage_latelySearch')) {
    Modal.error({ title: '提示', content: '您没有权限获取最近查询列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/useCardManage/latelySearch`, {
      params: params
    })
  }
}
// 删除主题
export const reqDeleteTheme = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_delMyTheme')) {
    Modal.error({ title: '提示', content: '您没有权限删除主题！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/theme/delMyTheme`, params)
  }
}
// 保存主题描述
export const reqSaveThemeDec = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_editTheme')) {
    Modal.error({ title: '提示', content: '您没有权限编辑主题描述！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/theme/editTheme`, params)
  }
}
// 保存主题高级样式
export const reqSaveThemeAdvanceStyle = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_editThemeSaveCss')) {
    Modal.error({ title: '提示', content: '您没有权限保存高级样式！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/theme/editThemeSaveCss`, params)
  }
}
// 主题分享
export const reqSaveThemeShare = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_sharedTheme')) {
    Modal.error({ title: '提示', content: '您没有权限分享|取消分享主题！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/theme/sharedTheme`, params)
  }
}
// 获取国际化
export const reqGetLocale = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_layout_getLocale')) {
    Modal.error({ title: '提示', content: '您没有权限获取国际化！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/layout/getLocale`, { params: params })
  }
}
// 保存国际化
export const reqSaveLocale = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_layout_updateLocale')) {
    Modal.error({ title: '提示', content: '您没有权限设置国际化参数！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/layout/updateLocale`, params)
  }
}
// 编辑主题
export const reqUpdateTheme = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_theme_updateTheme')) {
    Modal.error({ title: '提示', content: '您没有权限修改主题！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/theme/updateTheme`, params)
  }
}

// 第一次登录插入默认订阅数据
export const reqDefalutAppList = params => {
  // if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_queryPage')) {
  //   Modal.error({ title: '提示', content: '您没有权限访问应用中心！' })
  //   return new Promise((resolve, reject) => {
  //     reject()
  //   })
  // } else {
  return axios.get(`${base_upp}/appStore/setDefSubsApp`, { params })
  // }
}
// 应用中心列表
export const reqGetAppList = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_queryPage')) {
    Modal.error({ title: '提示', content: '您没有权限访问应用中心！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/appStore/queryApp`, { params })
  }
}
// 获取标签列表
export const reqAppSelectList = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_selectList')) {
    Modal.error({ title: '提示', content: '您没有权限获取标签列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/appStore/selectList`, params)
  }
}
// 获取类型列表
export const reqAppTypeList = () => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_selectList')) {
    Modal.error({ title: '提示', content: '您没有权限获取类型列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/appStore/selectAppType`)
  }
}
// 查询应用分类列表
export const reqAppFilterList = () => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_selectList')) {
    Modal.error({ title: '提示', content: '您没有权限获取应用分类列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/appStore/queryClassifyList`)
  }
}
// 收藏应用
export const reqCollectApp = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_storeApp')) {
    Modal.error({ title: '提示', content: '您没有权限收藏应用！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/appStore/storeApp`, params)
  }
}
// 我的收藏列表
export const reqMyAppList = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_queryMyStore')) {
    Modal.error({ title: '提示', content: '您没有权限查看我的收藏！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/appStore/queryMyStore`, { params })
  }
}
// 根据id获取应用详情
export const reqAppDetail = appId => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_get')) {
    Modal.error({ title: '提示', content: '您没有权限获取应用详情！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/appStore/${appId}/queryPersonalApp`)
  }
}
// 获取应用图表列表
export const reqAppIconList = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-mgr-svc_attachmentManagement_queryPage')
  ) {
    Modal.error({ title: '提示', content: '您没有权限获取应用图标列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/attachmentManagement`, { params })
  }
}
// 编辑应用
export const reqEditApp = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_updatePersonalApp')) {
    Modal.error({ title: '提示', content: '您没有权限编辑应用！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/appStore/updatePersonalApp`, params)
  }
}
// 新增应用
export const reqAddApp = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_add')) {
    Modal.error({ title: '提示', content: '您没有权限新增应用！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/appStore/addPersonalApp`, params)
  }
}
// 删除应用
export const reqDeleteApp = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_delete')) {
    Modal.error({ title: '提示', content: '您没有权限删除应用！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/appStore/${params.appId}/delete`, params)
  }
}
// 拖动操作
export const reqDragApp = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_AppSort')) {
    Modal.error({ title: '提示', content: '您没有权限对应用进行排序！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/appStore/AppSort`, params)
  }
}
// 置顶&置底
export const reqAppToTopOrBottom = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_appToTopOrBott')) {
    Modal.error({ title: '提示', content: '您没有权限进行置顶/置底操作！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(`${base_upp}/appStore/appToTopOrBott`, params)
  }
}
// // 置顶&取消置顶
// export const reqAppToTop = params => {
//   return axios.post(`${base_upp}/appStore/AppToTop`, params);
// };
// // 置底&取消置底
// export const reqAppToBottom = params => {
//   return axios.post(`${base_upp}/appStore/AppToBottom`, params);
// };
// 生成应用使用日志
export const reqAppLog = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-mgr-svc_appStore_frontAppOperateLogs')
  ) {
    Modal.error({ title: '提示', content: '您没有权限生成应用使用日志！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios({
      url: `${base_upp}/appStore/frontAppOperateLogs`,
      method: 'post',
      params
    })
  }
}
//服务展示页面数据接口
export const queryforHTML = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_contentDisplay_get')) {
    Modal.error({
      title: '提示',
      content: '您没有权限查询单个卡片对应服务展示！'
    })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/contentDisplay/${params}`)
  }
}
//根据条件查询数据接口
export const getCardInterface = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_cardInterface_queryPage')) {
    Modal.error({ title: '提示', content: '您没有权限查询数据接口！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/cardInterface/queryCardInterface`, { params })
  }
}
//对接服务中心查询数据
export const getSrviceCenter = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-mgr-svc_cardInterface_getServiceCenter')
  ) {
    Modal.error({
      title: '提示',
      content: '您没有权限通过服务中心获取接口数据信息！'
    })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/cardInterface/serviceCenter`, { params })
  }
}
//邮箱测试数据接口
export const mailtest = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-base-card-svc_emailCardConfig_getmailImf')
  ) {
    Modal.error({ title: '提示', content: '您没有权限测试邮箱数据接口！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_uppcard}/emailCardConfig/getmailImf`, { params })
  }
}
//服务展示完整页面请求接口
export const searchforCardId = params => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_cardManage_queryPage')) {
    Modal.error({ title: '提示', content: '您没有权限请求服务展示完整页面！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/cardManage`, { params })
  }
}
//邮箱绑定页面接口
export const emailBinding = params => {
  if (
    !getAuth().hasOwnProperty(
      'ly-upp-base-card-svc_emailCardConfig_emailBinding'
    )
  ) {
    Modal.error({ title: '提示', content: '您没有权限绑定邮箱！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_uppcard}/emailCardConfig/emailBinding`, { params })
  }
}
//邮箱注册页面接口
export const emailRegister = params => {
  if (
    !getAuth().hasOwnProperty(
      'ly-upp-base-card-svc_emailCardConfig_emailRegister'
    )
  ) {
    Modal.error({ title: '提示', content: '您没有权限注册邮箱！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_uppcard}/emailCardConfig/emailRegister`, {
      params
    })
  }
}
//根据id查询卡片模板接口
export const getCardTemplateById = id => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_cardTemplate_get')) {
    Modal.error({ title: '提示', content: '您没有权限查询卡片模板！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/cardTemplate/` + id)
  }
}
//获取图表数据
export const queryEchart = params => {
  if (!getAuth().hasOwnProperty('ly-upp-base-card-svc_chart_queryEchart')) {
    Modal.error({ title: '提示', content: '您没有权限获取图表数据！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_uppcard}/chart/queryEchart`, { params })
  }
}

export const queryforTotalPage = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-mgr-svc_contentDisplay_queryForTotalPage')
  ) {
    Modal.error({
      title: '提示',
      content: '您没有权限获取前端服务展示完整页面！'
    })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/contentDisplay/queryAppointCard/${params}`)
  }
}
// 查询服务卡片应用列表
export const queryServiceTypeList = params => {
  if (
    !getAuth().hasOwnProperty(
      'ly-upp-base-card-svc_serviceTypeShow_selectAppByCardId'
    )
  ) {
    Modal.error({ title: '提示', content: '您没有权限查询服务卡片应用列表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_uppcard}/serviceTypeShow/selectAppByCardId`, {
      params
    })
  }
}
// 更改服务卡片应用列表配置
export const editServiceTypeConfig = params => {
  if (
    !getAuth().hasOwnProperty(
      'ly-upp-base-card-svc_userServiceTypeShow_insertOrUpdateServiceTypeShow'
    )
  ) {
    Modal.error({
      title: '提示',
      content: '您没有权限更改服务卡片应用列表配置！'
    })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.post(
      `${base_uppcard}/userServiceTypeShow/insertOrUpdate`,
      params
    )
  }
}
// 用户查询服务卡片配置
export const queryServiceTypeConfig = params => {
  if (
    !getAuth().hasOwnProperty(
      'ly-upp-base-card-svc_userServiceTypeShow_selectByUrerIdAndCardId'
    )
  ) {
    Modal.error({ title: '提示', content: '您没有权限查询服务卡片配置！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios({
      url: `${base_uppcard}/userServiceTypeShow/selectByUrerIdAndCardId`,
      method: 'post',
      params
    })
  }
}
// 搜索卡片
export const searchThemeCard = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-mgr-svc_useCardManage_themeCardListA')
  ) {
    Modal.error({ title: '提示', content: '您没有权限搜索卡片！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/useCardManage/themeCardListA`, { params })
  }
}
// 卡片帮助
export const getCardHelp = id => {
  if (!getAuth().hasOwnProperty('ly-upp-mgr-svc_useCardManage_get')) {
    Modal.error({ title: '提示', content: '您没有权限查询卡片说明！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/useCardManage/findKpsm/` + id)
  }
}
// 查询周课表
export const queryWeekSchedule = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-base-card-svc_kbsz_queryAWeekSchedule')
  ) {
    Modal.error({ title: '提示', content: '您没有权限查询周课表！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_uppcard}/kbsz/queryAWeekSchedule`, { params })
  }
}

/**
 * ******************************************************主题专用接口******************************************************
 */

//一卡通数据详情数据接口
export const getIpassDetail = () => {
  if (!getAuth().hasOwnProperty('ly-upp-ext-card-svc_iPass_getIpassDetail')) {
    Modal.error({
      title: '提示',
      content: '您没有权限查看一卡通数据详情数据！'
    })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_excard}/iPass/getIpassDetail/`)
  }
}

//图书借阅数据接口
export const getBookBorrow = () => {
  if (
    !getAuth().hasOwnProperty('ly-upp-ext-card-svc_bookBorrow_getBookBorrow')
  ) {
    Modal.error({ title: '提示', content: '您没有权限查看图书借阅数据！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_excard}/bookBorrow/getBookBorrow/`)
  }
}

//工资信息数据接口
export const getSalary = () => {
  if (!getAuth().hasOwnProperty('ly-upp-ext-card-svc_salary_getSalary')) {
    Modal.error({ title: '提示', content: '您没有权限查看工资信息数据！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_excard}/salary/getSalary/`)
  }
}

//图书详情数据接口
export const getBookBorrowDetails = () => {
  return axios.get(`${base_excard}/bookBorrow/getBooks/`)
}
//一卡通数据接口
export const getIPassDailyCustom = () => {
  return axios.get(`${base_excard}/iPass/getIPassDailyCustom/`)
}

//[固定]选项卡数据接口
export const getSelectCard = params => {
  if (
    !getAuth().hasOwnProperty('ly-upp-base-card-svc_emailCardConfig_getmailImf')
  ) {
    Modal.error({ title: '提示', content: '您没有选项卡数据接口权限！' })
    return new Promise((resolve, reject) => {
      reject()
    })
  } else {
    return axios.get(`${base_upp}/useCardManage/getSelData/` + params)
  }
}
