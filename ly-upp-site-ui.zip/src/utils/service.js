/*
 * @Description: 公共服务
 * @Author: xuqiuting
 * @Date: 2019-10-14 11:07:10
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-05 14:58:38
 */
import axios from 'axios'
import { AUTH } from 'src/app/config/names'
import { message } from 'antd'
import { getKeyPair, setMaxDigits } from 'utils/rsa'
import {
  styleInject,
  getDpi,
  getBrowser,
  getOS,
  getDevice,
  getHashParam,
  getCookie,
  deleteCookie
} from 'utils/util'
import {
  reqAddOnlineUsersRecord,
  reqDefalutAppList,
  reqFirstLogin
} from 'utils/api'
import { themeList } from 'utils/themeData'
import {
  reqGetPath,
  reqGetPageContent,
  reqSaveThemeContent,
  reqSavePageContent,
  reqSaveTheme,
  reqGetThemeContent,
  reqGetLogin,
  reqGetLocale,
  reqGetLogout,
  reqGetSystemConfig,
  downloadApi
} from 'utils/api'
import {
  setPage,
  setSystem,
  setCurrentPage,
  setFirstMenu,
  setEditPage,
  setOpenSider,
  setSkinDisable,
  setLayoutDisable,
  setThemeDisable,
  setSaveASDisable,
  setCardDisable,
  setLoading
} from 'redux/actions/page'
import {
  setLocale,
  setSystemConfig,
  setLocaleJson,
  clearUserInfo,
  receiveUserInfo,
  getMenus,
  receiveDefaultPageColor,
  setGuideUsed
} from 'redux/actions/login'
import { changeTopFive } from 'redux/actions/app'
import store from 'redux/store/configureStore'
import createHistory from 'history/createHashHistory'
import { async } from 'rxjs/internal/scheduler/async'
const history = createHistory()

function getDefaultColor() {
  return (
    store &&
    store.getState() &&
    store.getState().login &&
    store.getState().login.defaultPageColor
  )
}

//post请求会有post参数也可能有get参数
export function Post(url, datas, params) {
  return new Promise((resolve, reject) => {
    axios
      .post(url, datas, { params: params })
      .then(res => {
        resolve(res.data)
      })
      .catch(err => {
        reject(err.data)
      })
  })
}

// 登录
export const userLogin = (userName, password, dispatch) => {
  // 清除redux信息
  dispatch(clearUserInfo())
  // 验证登录信息
  // let timestamp = new Date().getTime();
  setMaxDigits(131)
  let key = getKeyPair(AUTH.public_exponent, '', AUTH.modulus)
  // let encrptPass = encryptedString(key, AUTH.TAG + timestamp);
  let params = {
    username: userName,
    password: password
  }
  reqGetLogin(params).then(async res => {
    let { meta, data } = res.data
    if (meta.success) {
      sessionStorage.setItem('userLogin', JSON.stringify(data))
      dispatch(receiveUserInfo(data))
      // 获取登录情况：1.是否第一次登录 2.是否已使用新手指引
      reqFirstLogin().then(res => {
        const { data, meta } = res.data
        console.log('reqFirstLogin', data)
        if (!meta.success) console.log('reqFirstLogin error')
        if (data.guideUsed === '0') {
          dispatch(setGuideUsed(false))
        }
        if (data.firLogin === '1') {
          // 第一次登录插入默认订阅数据
          reqDefalutAppList().then(() => {
            dispatch(changeTopFive(true))
          })
        }
      })
      //登录添加在线用户记录
      const params = {
        userName: data.userName,
        operaCategory: data.userType,
        nickName: data.userNickname,
        ip: data.host,
        email: data.email,
        departmentId: data.departmentId,
        browser: getBrowser(), // 浏览器
        screenSize: getDpi(), // 屏幕分辨率
        loginCategory: getDevice(), // 手机端还是pc端
        operation: getOS() // 操作系统
      }
      reqAddOnlineUsersRecord(params).then(res => {
        const { meta } = res.data
        if (!meta.success) return message.error(meta.message)
        reqGetSystemConfig().then(res => {
          if (res.data.meta) {
            dispatch(
              receiveDefaultPageColor(
                res.data.data &&
                  res.data.data.filter(
                    item => item.configKey == 'uppFrontColor'
                  ).length
                  ? res.data.data.filter(
                      item => item.configKey == 'uppFrontColor'
                    )[0].configValue
                  : ''
              )
            )
          }
        })
      })
      // 获取菜单
      await getPage(dispatch, 'firstlogin')
      // 获取国际语言
      await getLocale(dispatch)
      await history.push('/')
      //记录登录日志成功操作
      // getLoginLog(userName, "1", encrptPass);
    } else {
      //记录登录日志失败操作
      // getLoginLog(userName, "0", encrptPass);
      message.error(meta.message)
    }
  })
}

// 获取登录日志
export const getLoginLog = (userName, status, encrptPass) => {
  axios
    .post(
      'api/upp/audit/login/log',
      {
        name: userName,
        loginType: '-1',
        loginStatus: status
      },
      {
        headers: {
          loginUserId: userName,
          token: encrptPass
        }
      }
    )
    .then(res => {})
}

// 退出
export const userLogout = dispatch => {
  reqGetLogout().then(res => {
    let { meta } = res.data
    if (meta.success) {
      sessionStorage.removeItem('userLogin')
      sessionStorage.removeItem('element')
      sessionStorage.removeItem('locale')
      sessionStorage.removeItem('localeJson')
      sessionStorage.removeItem('menus')
      sessionStorage.removeItem('firstMenu')
      sessionStorage.removeItem('systemConfig')
      sessionStorage.removeItem('currentPage')
      if (dispatch) {
        dispatch(setPage({}))
        dispatch(getMenus([]))
        dispatch(setFirstMenu(null))
        dispatch(setLocale('zh_CN')) //设置语言
        dispatch(setLocaleJson({})) //设置语言配置
        //dispatch(clearUserInfo())
        dispatch(setCurrentPage(null))
        dispatch(setEditPage(false))
        dispatch(setOpenSider(false))
        dispatch(setGuideUsed(true))
      }
      if (window.casStatus) {
        if (getCookie('session')) {
          deleteCookie('session')
        }
        setTimeout(() => {
          if (dispatch) {
            window.location.href = window.casLogoutUrl
          } else {
            window.location.reload()
          }
        }, 500)
      } else {
        if (dispatch) {
          history.push('/login')
        } else {
          window.location.reload()
        }
      }
    } else {
      message.error(meta.message)
    }
  })
}

// 获取设置的语言
export const getLocale = dispatch => {
  reqGetLocale().then(res => {
    const { data, meta } = res.data
    if (meta.success) {
      let localeData = window.locale[data.localeType]
      dispatch(setLocale(data.localeType)) //设置语言
      dispatch(setLocaleJson(localeData)) //设置语言配置
      sessionStorage.setItem('locale', data.localeType)
      sessionStorage.setItem('localeJson', JSON.stringify(localeData))
    } else {
      message.error(meta.message)
    }
  })
}

// 获取系统配置
export const getSystemConfig = props => {
  let { dispatch, login } = props
  reqGetSystemConfig().then(res => {
    const { data, meta } = res.data
    if (meta.success) {
      let config = {}
      data.map(item => {
        config[item.configKey] = item.configValue
        // 页头
        if (item.configKey == 'mgrTitle') {
          document.title =
            item.configValue && JSON.parse(item.configValue)[login.locale]
              ? JSON.parse(item.configValue)[login.locale]
              : '服务门户管理平台'
        } else if (item.configKey == 'casFootImage') {
          //ico
          let icoEle = document.getElementById('linkIco')
          icoEle.href = item.configValue
            ? downloadApi + '?attachmentId=' + item.configValue
            : 'favicon.ico'
        } else if (item.configKey == 'keyWord') {
          let keyEle = document.getElementById('keywordMeta')
          keyEle.content = item.configValue
        }
      })
      dispatch(setSystemConfig(config))
      // sessionStorage.setItem("systemConfig", JSON.stringify(config));
    } else {
      message.error(meta.message)
    }
  })
}

// 获取页面列表
export const getPage = (dispatch, type) => {
  reqGetPath().then(res => {
    const { data } = res
    if (data.meta.success) {
      let dataSource = data.data
        ? data.data.filter(item => item.isShow == '1')
        : []
      // console.log('请求的菜单',data.data)
      // 第一次登录进来
      if (type && dataSource[0]) {
        dispatch(setCurrentPage(dataSource[0].pagePath))
        sessionStorage.setItem('currentPage', dataSource[0].pagePath)
        history.push('/' + dataSource[0].pagePath)
      }
      if (dataSource[0]) {
        dispatch(setFirstMenu(dataSource[0].pagePath))
        sessionStorage.setItem('firstMenu', dataSource[0].pagePath)
      }
      // console.log('登录后设置menus前的menus', sessionStorage.getItem('menus'))
      dispatch(getMenus(dataSource))
      sessionStorage.setItem('menus', JSON.stringify(dataSource))
      // console.log('登录后设置了menus', dataSource)
    } else {
      if (type) {
        message.error('您没有权限访问该系统页面，请联系管理员')
      } else {
        message.error(data.meta.message)
      }
    }
  })
}

// 获取页面内容
export const getPageContent = (item, props) => {
  props.dispatch(setLoading(true))
  if (!item) {
    return
  }
  let params = {}
  let reqContentApi = null
  if (getHashParam('themeId')) {
    params.themeId = getHashParam('themeId')
    reqContentApi = reqGetThemeContent
  } else {
    params.pageId = item.pageId
    reqContentApi = reqGetPageContent
  }
  reqContentApi(params)
    .then(res => {
      const { data } = res
      if (data.meta.success) {
        // 系统总的页面布局
        let element = props.page.element
        let pageContent = data.data.pageContent || {}
        element = {
          ...element,
          [item.type]: pageContent
        }
        props.dispatch(setPage(element))
        sessionStorage.setItem('element', JSON.stringify(element))
        // 如果为编辑主题，需要自行加菜单
        if (item.type === 'editTheme') {
          let menuList = [
            {
              pageId: pageContent.pageId,
              pageName: pageContent.pageName,
              pagePath: 'editTheme',
              key: 'editTheme',
              type: 'editTheme',
              locales: pageContent.locale
            }
          ]
          props.dispatch(getMenus(menuList))
          sessionStorage.setItem('menus', JSON.stringify(menuList))
        }
        // 特殊主题处理
        let themeId = data.data.pageContent && data.data.pageContent.pageTheme
        handleSpecialTheme(themeId, props.dispatch, pageContent)
        // 设置系统配置
        props.dispatch(setSystem(pageContent))
        setPageStyle(pageContent)
        props.dispatch(setLoading(false))
      } else {
        props.dispatch(setLoading(false))
        message.error(data.meta.message)
      }
    })
    .catch(err => {
      props.dispatch(setLoading(false))
      throw new Error('获取页面内容失败')
    })
}

//获取配置设置样式
export const setPageStyle = (pageContent, Id) => {
  if (!pageContent) return
  let themeId = Id || pageContent.pageTheme
  let remark = false
  // 主题列表
  themeList.map(item => {
    if (themeId == item.themeName) {
      remark = true
      document.getElementsByTagName('body')[0].className = item.themeName
      if (pageContent.skin) {
        // 获取内容之后需要改变颜色
        setPageSystem(pageContent)
      } else {
        //设置皮肤
        setPageSkin('#0F0F3D')
        //设置自定义样式
        const myStyle =
          pageContent.pageMyCss ||
          '.app-layout-cardSet-index-box-3fFTC {border-radius: 16px;}'
        styleInject(myStyle, '1')
      }
    }
  })
  if (!remark) {
    document.getElementsByTagName('body')[0].className = ''
    // 获取内容之后需要改变颜色
    setPageSystem(pageContent)
  }
}

// 根据主题，获取页面内容
export const getThemeContent = (themeId, props) => {
  props.dispatch(setLoading(true))
  let params = {
    themeId: themeId
  }
  reqGetThemeContent(params).then(async res => {
    const { data, meta } = res.data
    if (meta.success) {
      // 系统总的页面布局
      let element = props.page.element
      if (!data.pageContent) {
        data.pageContent = {
          layout: 'horizontal',
          layoutName: '横向排列',
          pageColorName: '科技蓝',
          skin: '#1890ff',
          pageTheme: themeId,
          component: [{ componentArea: [] }]
        }
      } else {
        data.pageContent.pageTheme = themeId
      }
      // 切换主题需要保留之前的pageId、pagePath、pageName
      const { pageId, pagePath, pageName } = element[props.page.currentPage]
      element = {
        ...element,
        [props.page.currentPage]: {
          ...data.pageContent,
          pageId,
          pagePath,
          pageName
        }
      }
      // 特殊主题处理
      handleSpecialTheme(themeId, props.dispatch)
      await props.dispatch(setPage(element))
      await sessionStorage.setItem('element', JSON.stringify(element))
      // 获取内容之后需要改变颜色
      // setPageSystem(data.pageContent);
      setPageStyle(data.pageContent, themeId)
      // 设置系统配
      props.dispatch(setSystem(data.pageContent))
      props.dispatch(setLoading(false))
    } else {
      props.dispatch(setLoading(false))
    }
  })
}

// 特殊主题的处理
export const handleSpecialTheme = (themeId, dispatch, pageContent) => {
  // 侧边栏皮肤
  let skinDisable = false
  // 另存为主题
  let saveAsDisable = false
  // 侧边栏布局
  let layoutDisable = false
  // 侧边栏主题
  let themeDisable = false
  // 侧边栏添加卡片
  let cardDisable = false
  if (pageContent && pageContent.pageType && pageContent.pageType == '2') {
    saveAsDisable = true
    layoutDisable = true
    themeDisable = true
    cardDisable = true
  } else {
    themeList.map(item => {
      if (themeId == item.themeName) {
        // 皮肤
        if (item.skinDisable) {
          skinDisable = true
        }
        // 另存为主题
        if (item.saveAsDisable) {
          saveAsDisable = true
        }
        // 布局
        if (item.layoutDisable) {
          layoutDisable = true
        }
        // 布局
        if (item.themeDisable) {
          themeDisable = true
        }
      }
    })
  }

  dispatch(setSkinDisable(skinDisable))
  sessionStorage.setItem('skinDisable', skinDisable)
  dispatch(setSaveASDisable(saveAsDisable))
  sessionStorage.setItem('saveAsDisable', saveAsDisable)
  dispatch(setLayoutDisable(layoutDisable))
  sessionStorage.setItem('layoutDisable', layoutDisable)
  dispatch(setThemeDisable(themeDisable))
  sessionStorage.setItem('themeDisable', themeDisable)
  dispatch(setCardDisable(cardDisable))
  sessionStorage.setItem('cardDisable', cardDisable)
}

// 根据页面设置系统配置
export const setPageSystem = data => {
  if (data) {
    //设置皮肤
    // console.log(
    //   '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>' + getDefaultColor()
    // )
    setPageSkin(data.skin || getDefaultColor() || '#1890ff')
    //设置自定义样式
    const myStyle =
      data.pageMyCss ||
      '.app-layout-cardSet-index-box-3fFTC {border-radius: 16px;}'
    styleInject(myStyle, '1')
  }
}

// 设置颜色
export const setPageSkin = color => {
  let initialTheme = { '@primary-color': color }
  window.less
    .modifyVars(initialTheme)
    .then(() => {})
    .catch(error => {
      // message.error(`更新主题失败`);
    })
}

// 保存页面内容
export const savePageContent = async (props, value, _this) => {
  const { page, dispatch, login } = props
  let params = {}
  let pageId
  let componet = page.element[page.currentPage]
  let menus = JSON.parse(sessionStorage.getItem('menus')) || []
  for (let i = 0; i < menus.length; i++) {
    if (menus[i].pagePath == page.currentPage) {
      pageId = menus[i].pageId
    }
  }
  if (componet && pageId) {
    params = {
      pageId: pageId,
      ...componet
    }
    // 保存主题，先要保存页面内容
    if (value) {
      reqSaveThemeContent(params).then(res => {
        const { data } = res
        if (data.meta.success) {
          saveTheme(value, data.data, _this)
        } else {
          message.error(data.meta.message)
        }
      })
    } else {
      let isSuccess = false // 返回值用于判断是否执行成功
      await reqSavePageContent(params).then(res => {
        const { data } = res
        if (data.meta.success) {
          getPage(props.dispatch)
          message.success(login.localeJson.api_save_page_success)
          isSuccess = true
        } else {
          message.error(data.meta.message)
          isSuccess = false
        }
      })
      return isSuccess
    }
  } else {
    message.error(login.localeJson.refresh_the_page)
  }
}

// 保存主题
export const saveTheme = (value, pageId, _this) => {
  const { login } = _this.props
  let params = {
    ...value,
    pageId: pageId
  }
  reqSaveTheme(params).then(res => {
    const { data } = res
    if (data.meta.success) {
      message.success(login.localeJson.api_save_theme_success)
      if (_this) {
        _this.handleTheme()
      }
    } else {
      message.error(data.meta.message)
    }
  })
}

// 退出编辑状态时 先还原
export const exitEditPage = async props => {
  let pageItem
  let currentPage = props.page.currentPage
  let menus = JSON.parse(sessionStorage.getItem('menus')) || []
  // await props.dispatch(setEditPage(false))
  pageItem = await menus.find(item => item.pagePath == currentPage)
  getPageContent(pageItem, props)
}
