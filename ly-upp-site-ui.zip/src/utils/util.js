﻿/*
 * @Description: 系统公共方法
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-08 12:00:49
 */
import Tinycolor from 'tinycolor2'

// 获取css样式表里面的值
export const getCssStyle = (name, queryString) => {
  var reg = new RegExp('(^|;)' + name + ':([^;]*)(;|$)'),
    result = queryString.match(reg)
  return result ? decodeURIComponent(result[2]) : null
}

// 国际化名称取值
export const getLanguageTitle = (props, obj, type, typeName) => {
  // 参数分别是全局props,拿到的国际化对象，要实现国际化的字段，没有国际化时候的字段，第四个不是必传
  // 示例
  // getLanguageTitle(
  //   this.props,
  //   item.locales,
  //   "name",
  //   item.pageName
  // )
  let name
  const { login } = props
  const { systemConfig, locale } = login
  if (!obj) return window.locale.No_text
  // 没当前语言就显示系统默认语言的，没有就显示中文的，再没有就显示英文，还没有就显示有值的，都没有就显示absent
  if (obj[locale] && obj[locale][type]) {
    name = obj[locale][type]
  } else if (
    systemConfig &&
    systemConfig.language &&
    obj[systemConfig.language] &&
    obj[systemConfig.language][type]
  ) {
    name = obj[systemConfig.language][type]
  } else if (obj['zh_CN'] && obj['zh_CN'][type]) {
    name = obj['zh_CN'][type]
  } else if (obj['en_US'] && obj['en_US'][type]) {
    name = obj['en_US'][type]
  } else if (obj) {
    let remark = false
    for (let key in obj) {
      if (obj[key] && obj[key][type]) {
        remark = true
        name = obj[key][type]
      }
    }
    if (!remark) {
      if (typeName) {
        name = typeName
      } else {
        name = window.locale.No_text
      }
    }
  } else {
    if (typeName) {
      name = typeName
    } else {
      name = window.locale.No_text
    }
  }
  return name
}

// 获取随机ID，组件拖到预览视图后就会被设置个ID
export const guid = () => {
  const s4 = () => {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1)
  }
  return s4() + s4()
}

// 获取屏幕宽高
export const getSize = () => {
  let windowW, windowH, contentH, contentW, scrollT
  windowH = window.innerHeight
  windowW = window.innerWidth
  scrollT = document.documentElement.scrollTop || document.body.scrollTop
  contentH =
    document.documentElement.scrollHeight > document.body.scrollHeight
      ? document.documentElement.scrollHeight
      : document.body.scrollHeight
  contentW =
    document.documentElement.scrollWidth > document.body.scrollWidth
      ? document.documentElement.scrollWidth
      : document.body.scrollWidth
  return { windowW, windowH, contentH, contentW, scrollT }
}

export const decode = input => {
  let _keyStr =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
  let output = ''
  let chr1, chr2, chr3
  let enc1, enc2, enc3, enc4
  let i = 0
  input = input.replace(/[^A-Za-z0-9\+\/\=]/g, '')
  while (i < input.length) {
    enc1 = _keyStr.indexOf(input.charAt(i++))
    enc2 = _keyStr.indexOf(input.charAt(i++))
    enc3 = _keyStr.indexOf(input.charAt(i++))
    enc4 = _keyStr.indexOf(input.charAt(i++))
    chr1 = (enc1 << 2) | (enc2 >> 4)
    chr2 = ((enc2 & 15) << 4) | (enc3 >> 2)
    chr3 = ((enc3 & 3) << 6) | enc4
    output = output + String.fromCharCode(chr1)
    if (enc3 != 64) {
      output = output + String.fromCharCode(chr2)
    }
    if (enc4 != 64) {
      output = output + String.fromCharCode(chr3)
    }
  }
  output = _utf8_decode(output)
  return output
}

function _utf8_decode(utftext) {
  let string = ''
  let i = 0
  let c = 0
  let c1 = 0
  let c2 = 0
  let c3 = 0
  while (i < utftext.length) {
    c = utftext.charCodeAt(i)
    if (c < 128) {
      string += String.fromCharCode(c)
      i++
    } else if (c > 191 && c < 224) {
      c2 = utftext.charCodeAt(i + 1)
      string += String.fromCharCode(((c & 31) << 6) | (c2 & 63))
      i += 2
    } else {
      c2 = utftext.charCodeAt(i + 1)
      c3 = utftext.charCodeAt(i + 2)
      string += String.fromCharCode(
        ((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63)
      )
      i += 3
    }
  }
  return string
}

//添加key
export const DateUtil = {
  dateAddKey: function(date) {
    var localCounter = 1
    date.forEach(el => {
      el.key = localCounter++
    })
    return date
  },
  dataFormat: function(time) {
    //时间戳转时间 => yyyy-mm-dd hh:mm:ss
    let now = new Date(time)
    let year = now.getFullYear()
    let month =
      now.getMonth() + 1 >= 10 ? now.getMonth() + 1 : '0' + (now.getMonth() + 1)
    let date = now.getDate() >= 10 ? now.getDate() : '0' + now.getDate()
    let hour = now.getHours() >= 10 ? now.getHours() : '0' + now.getHours()
    let minute =
      now.getMinutes() >= 10 ? now.getMinutes() : '0' + now.getMinutes()
    let second =
      now.getSeconds() >= 10 ? now.getSeconds() : '0' + now.getSeconds()
    return (
      year + '-' + month + '-' + date + ' ' + hour + ':' + minute + ':' + second
    )
  }
}

// GBK字符集实际长度计算
export const getStrLength = str => {
  let realLength = 0
  let len = str.length
  let charCode = -1
  for (let i = 0; i < len; i++) {
    charCode = str.charCodeAt(i)
    if (charCode >= 0 && charCode <= 128) {
      realLength += 1
    } else {
      // 如果是中文则长度加2
      realLength += 2
    }
  }
  return realLength
}

export const transformDate = date => {
  var createAt = new Date(date)
  var time = new Date().getTime() - createAt.getTime() //现在的时间-传入的时间 = 相差的时间（单位 = 毫秒）
  if (time < 0) {
    return ''
  } else if (time / 1000 < 60) {
    return '刚刚'
  } else if (time / 60000 < 60) {
    return parseInt(time / 60000) + '分钟前'
  } else if (time / 3600000 < 24) {
    return parseInt(time / 3600000) + '小时前'
  } else if (time / 86400000 < 31) {
    return parseInt(time / 86400000) + '天前'
  } else if (time / 2592000000 < 12) {
    return parseInt(time / 2592000000) + '月前'
  } else {
    return parseInt(time / 31536000000) + '年前'
  }
}

// 拼接图片url
export const handleImageUrl = str => {
  return 'zuul/docrepo/download?attachmentId=' + str
}

// 图片文件转成base64（本地预览）
export const getBase64 = (img, callback) => {
  const reader = new FileReader()
  reader.addEventListener('load', () => callback(reader.result))
  reader.readAsDataURL(img)
}

// 移动数组
export const arrayMoveMutate = (array, from, to) => {
  array.splice(to < 0 ? array.length + to : to, 0, array.splice(from, 1)[0])
}

// 移动数组
export const arrayMove = (array, from, to) => {
  array = array.slice()
  arrayMoveMutate(array, from, to)
  return array
}

// 切割数组
export const splitArray = (arr, num) => {
  if (!num) return [arr]
  let result = []
  for (let i = 0; i < arr.length; i += num) {
    result.push(arr.slice(i, i + num))
  }
  return result
}

// 根据颜色类型获取颜色
export const getColor = (color, colorType) => {
  if (!color) return 'transparent'
  switch (colorType) {
    case 'hex':
      return color
    default:
      const newColor = Tinycolor.fromRatio(color).toRgb()
      return `rgba(${newColor.r}, ${newColor.g}, ${newColor.b}, ${newColor.a})`
  }
}

/**
 * 动态创建css
 *
 * @param {*} css style标签内容
 * @param {*} insertId style标签id
 * @param {boolean} [insertTop=false] style标签是否插入到最前
 * @param {string} [preId="inject-styles-"] style标签id的前缀
 */
export const styleInject = (
  css,
  insertId = '',
  insertTop = false,
  preId = 'inject-styles-'
) => {
  if (!css || typeof document === 'undefined') return

  const head = document.head || document.getElementsByTagName('head')[0]
  let style = document.createElement('style')
  style.type = 'text/css'

  // 如果存在id, 移除旧的style标签
  if (insertId) {
    const oldStyle = document.getElementById(preId + insertId)
    if (oldStyle) {
      head.removeChild(oldStyle)
    }
    style.id = preId + insertId
  }

  if (style.styleSheet) {
    //ie下
    style.styleSheet.cssText = css
  } else {
    style.innerHTML = css
  }

  // 是否插入到最前
  if (insertTop) {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild)
    } else {
      head.appendChild(style)
    }
  } else {
    head.appendChild(style)
  }
}

// 获取url参数
export const getHashParam = name => {
  var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)'),
    queryString = window.location.hash.split('?')[1] || '',
    result = queryString.match(reg)
  return result ? decodeURIComponent(result[2]) : null
}

// 获取当前时间
export const getCurrentTime = () => {
  let timeStr = new Date()
  let y = timeStr.getFullYear()
  let m = timeStr.getMonth() + 1
  let d = timeStr.getDate()
  if (m < 10) {
    m = '0' + m
  }
  if (d < 10) {
    d = '0' + d
  }
  return y + m + d
}

export function pwStrength(pwd) {
  var O_color = '#d9d9d9'
  var L_color = '#FF0000'
  var M_color = '#FF9900'
  var H_color = '#33CC00'
  let Lcolor = null
  let Mcolor = null
  let Hcolor = null
  if (pwd == null || pwd == '') {
    Lcolor = Mcolor = Hcolor = O_color
  } else {
    var S_level = checkStrong(pwd)
    switch (S_level) {
      case 0:
        Lcolor = Mcolor = Hcolor = O_color
      case 1:
        Lcolor = L_color
        Mcolor = Hcolor = O_color
        break
      case 2:
        Lcolor = Mcolor = M_color
        Hcolor = O_color
        break
      default:
        Lcolor = Mcolor = Hcolor = H_color
    }
  }
  return { Lcolor: Lcolor, Mcolor: Mcolor, Hcolor: Hcolor }
}
export function checkStrong(sPW) {
  if (sPW.length <= 4) return 0 //密码太短
  var Modes = 0
  for (var i = 0; i < sPW.length; i++) {
    //密码模式
    Modes |= CharMode(sPW.charCodeAt(i))
  }
  return bitTotal(Modes)
}

function CharMode(iN) {
  if (iN >= 48 && iN <= 57)
    //数字
    return 1
  if (iN >= 65 && iN <= 90)
    //大写
    return 2
  if (iN >= 97 && iN <= 122)
    //小写
    return 4
  else return 8
}
function bitTotal(num) {
  var modes = 0
  for (var i = 0; i < 4; i++) {
    if (num & 1) modes++
    num >>>= 1
  }
  return modes
}

export function debounce(func, delay = 500) {
  let timer
  return function(event) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      func.call(this, event)
    }, delay)
  }
}

// 获取用户屏幕分辨率
export const getDpi = () => {
  const { width, height } = window.screen
  return width + '×' + height
}

// 获取用户浏览器类型
export const getBrowser = () => {
  const userAgent = navigator.userAgent //取得浏览器的userAgent字符串
  const isOpera = userAgent.indexOf('Opera') > -1 //判断是否Opera浏览器
  const isIE =
    userAgent.indexOf('compatible') > -1 &&
    userAgent.indexOf('MSIE') > -1 &&
    !isOpera //判断是否IE浏览器
  const isIE11 = userAgent.toLowerCase().match(/rv:([\d.]+)\) like gecko/) //判断是否IE11浏览器
  const isEdge = userAgent.indexOf('Edge') > -1 //判断是否IE的Edge浏览器
  const isFF = userAgent.indexOf('Firefox') > -1 //判断是否Firefox浏览器
  const isSafari =
    userAgent.indexOf('Safari') > -1 && userAgent.indexOf('Chrome') == -1 //判断是否Safari浏览器
  const isChrome =
    userAgent.indexOf('Chrome') > -1 && userAgent.indexOf('Safari') > -1 //判断Chrome浏览器
  const is360 = _mime('type', 'application/vnd.chromium.remoting-viewer')
  if (isIE) {
    // const reIE = new RegExp("MSIE (\\d+\\.\\d+);")
    // reIE.test(userAgent)
    // const fIEVersion = parseFloat(RegExp["$1"])
    // if (fIEVersion == 7) {
    //     return "IE7"
    // } else if (fIEVersion == 8) {
    //     return "IE8"
    // } else if (fIEVersion == 9) {
    //     return "IE9"
    // } else if (fIEVersion == 10) {
    //     return "IE10"
    // } else if (fIEVersion == 11) {
    //     return "IE11"
    // } else {
    //     return "0"
    // }
    return 'IE'
  }
  if (isIE11) {
    return 'IE'
  }
  if (isOpera) {
    return 'Opera'
  }
  if (isEdge) {
    return 'Edge'
  }
  if (isFF) {
    return 'FireFox'
  }
  if (isSafari) {
    return 'Safari'
  }
  if (isChrome) {
    if (is360) {
      return '360'
    }
    return 'Chrome'
  }
  // 检查浏览器的mimeType(媒体类型) 用于区分360浏览器
  function _mime(option, value) {
    var mimeTypes = navigator.mimeTypes
    for (var mt in mimeTypes) {
      if (mimeTypes[mt][option] == value) {
        return true
      }
    }
    return false
  }
}

// 获取用户操作系统
export const getOS = () => {
  const sUserAgent = navigator.userAgent
  const isWin = navigator.platform == 'Win32' || navigator.platform == 'Windows'
  const isMac =
    navigator.platform == 'Mac68K' ||
    navigator.platform == 'MacPPC' ||
    navigator.platform == 'Macintosh' ||
    navigator.platform == 'MacIntel'
  if (isMac) return 'Mac'
  const isUnix = navigator.platform == 'X11' && !isWin && !isMac
  if (isUnix) return 'Unix'
  const isLinux = String(navigator.platform).indexOf('Linux') > -1
  if (isLinux) return 'Linux'
  if (isWin) {
    const isWin2K =
      sUserAgent.indexOf('Windows NT 5.0') > -1 ||
      sUserAgent.indexOf('Windows 2000') > -1
    if (isWin2K) return 'Win2000'
    const isWinXP =
      sUserAgent.indexOf('Windows NT 5.1') > -1 ||
      sUserAgent.indexOf('Windows XP') > -1
    if (isWinXP) return 'WinXP'
    const isWin2003 =
      sUserAgent.indexOf('Windows NT 5.2') > -1 ||
      sUserAgent.indexOf('Windows 2003') > -1
    if (isWin2003) return 'Win2003'
    const isWinVista =
      sUserAgent.indexOf('Windows NT 6.0') > -1 ||
      sUserAgent.indexOf('Windows Vista') > -1
    if (isWinVista) return 'WinVista'
    const isWin7 =
      sUserAgent.indexOf('Windows NT 6.1') > -1 ||
      sUserAgent.indexOf('Windows 7') > -1
    if (isWin7) return 'Win7'
    const isWin10 = sUserAgent.indexOf('Windows NT 10') != -1
    if (isWin10) return 'Win10'
  }
  return 'other'
}

export const IEVersion = () => {
  var userAgent = navigator.userAgent //取得浏览器的userAgent字符串
  var isIE =
    userAgent.indexOf('compatible') > -1 && userAgent.indexOf('MSIE') > -1 //判断是否IE<11浏览器
  var isEdge = userAgent.indexOf('Edge') > -1 && !isIE //判断是否IE的Edge浏览器
  var isIE11 =
    userAgent.indexOf('Trident') > -1 && userAgent.indexOf('rv:11.0') > -1
  if (isIE) {
    var reIE = new RegExp('MSIE (\\d+\\.\\d+);')
    reIE.test(userAgent)
    var fIEVersion = parseFloat(RegExp['$1'])
    if (fIEVersion == 7) {
      return 7
    } else if (fIEVersion == 8) {
      return 8
    } else if (fIEVersion == 9) {
      return 9
    } else if (fIEVersion == 10) {
      return 10
    } else {
      return 6 //IE版本<=7
    }
  } else if (isEdge) {
    return 'edge' //edge
  } else if (isIE11) {
    return 11 //IE11
  } else {
    return -1 //不是ie浏览器
  }
}

// 获取用户是PC端还是移动端
export const getDevice = () => {
  const sUserAgent = navigator.userAgent.toLowerCase()
  const bIsIpad = sUserAgent.match(/ipad/i) == 'ipad'
  const bIsIphoneOs = sUserAgent.match(/iphone os/i) == 'iphone os'
  const bIsMidp = sUserAgent.match(/midp/i) == 'midp'
  const bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == 'rv:1.2.3.4'
  const bIsUc = sUserAgent.match(/ucweb/i) == 'ucweb'
  const bIsAndroid = sUserAgent.match(/android/i) == 'android'
  const bIsCE = sUserAgent.match(/windows ce/i) == 'windows ce'
  const bIsWM = sUserAgent.match(/windows mobile/i) == 'windows mobile'
  // PC端
  if (
    !(
      bIsIpad ||
      bIsIphoneOs ||
      bIsMidp ||
      bIsUc7 ||
      bIsUc ||
      bIsAndroid ||
      bIsCE ||
      bIsWM
    )
  ) {
    return '1'
    // 移动端
  } else {
    return '2'
  }
}

//删除cookie
export function deleteCookie(name) {
  var date = new Date()
  date.setTime(date.getTime() - 10000)
  document.cookie = name + '=v; expires=' + date.toGMTString()
}

//获取cookie
export function getCookie(cname) {
  var name = cname + '='
  var ca = document.cookie.split(';')
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i].trim()
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length)
    }
  }
  return ''
}

// 判断浏览器是否支持
export const detectAvailableBrowser = () => {
  const userAgent = navigator.userAgent //取得浏览器的userAgent字符串
  // const isOpera = userAgent.indexOf('Opera') > -1 //判断是否Opera浏览器
  const isIE =
    userAgent.indexOf('compatible') > -1 &&
    userAgent.indexOf('MSIE') > -1 &&
    !isOpera //判断是否IE浏览器
  const isIE11 = userAgent.toLowerCase().match(/rv:([\d.]+)\) like gecko/) //判断是否IE11浏览器
  // const isEdge = userAgent.indexOf('Edge') > -1 //判断是否IE的Edge浏览器
  const isFF = userAgent.indexOf('Firefox') > -1 //判断是否Firefox浏览器
  const isSafari =
    userAgent.indexOf('Safari') > -1 && userAgent.indexOf('Chrome') == -1 //判断是否Safari浏览器
  const isChrome =
    userAgent.indexOf('Chrome') > -1 && userAgent.indexOf('Safari') > -1 //判断Chrome浏览器
  if (isIE) {
    const reIE = new RegExp("MSIE (\\d+\\.\\d+);")
    reIE.test(userAgent)
    const fIEVersion = parseFloat(RegExp["$1"])
    if (fIEVersion < 10) {
      return false
    }
  }
  if (isIE11 || isFF || isSafari || isChrome) {
    return true
  } else {
    return false
  }
}