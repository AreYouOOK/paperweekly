/* 表单校验
-------------------------- */

const Hanzi = msg => (rule, v, cb) => {
  const isHanzi = /^[\u4e00-\u9fa50-9]+$/
  if (isHanzi.test(v) || !v) {
    return cb()
  } else {
    return cb(new Error(msg))
  }
}

const letters = msg => (rule, v, cb) => {
  const isLetters = /^[a-zA-Z0-9]+$/
  if (isLetters.test(v) || !v) {
    return cb()
  } else {
    return cb(new Error(msg))
  }
}

const path = () => (rule, v, cb) => {
  const isPath = /^[//a-z0-9a-z]+$/
  if (isPath.test(v) || !v) {
    return cb()
  } else {
    return cb(new Error(`请输入正确的路径（只允许“/”，数字和英文字符）`))
  }
}

export default class CreateRules {
  constructor () {
    this.rules = []
  }

  need (msg = '必填') {
    this.rules.push({
      required: true,
      message: msg
    })
    return this
  }

  max (max = 50, msg = '字符数不得超过') {
    this.rules.push({
      max,
      message: msg + max
    })
    return this
  }

  url (message = '不是合法的链接') {
    this.rules.push({
      type: 'url',
      message
    })
    return this
  }

  path () {
    this.rules.push({
      validator: path()
    })
    return this
  }

  Hanzi (msg) {
    this.rules.push({
      validator: Hanzi(msg)
    })
    return this
  }

  letters (msg) {
    this.rules.push({
      validator: letters(msg)
    })
    return this
  }

  get () {
    const res = this.rules.slice(0)
    this.rules.length = 0
    return res
  }

}
