/*
 * @Description: 主题配置信息
 * @Author: xuqiuting
 * @Date: 2019-08-30 13:48:48
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-18 15:24:58
 */
import React from 'react'
import classnames from 'classnames'

// 特殊主题列表，一个主题有五个属性，themeName，skinDisable，saveAsDisable，layoutDisable，themeDisable现在有主题A和主题B
export const themeList = [
  {
    themeName: 'lyThemeA', // 主题名字
    skinDisable: true, //皮肤是否可以用
    saveAsDisable: true //另存为主题可不可以用
    // layoutDisable  //布局是否可以用
    // themeDisable   //主题是否可以用
  },
  {
    themeName: 'lyThemeB',
    skinDisable: true, //皮肤是否不可以用
    saveAsDisable: true //另存为主题可不可以用
    // layoutDisable:true,
  }
]

// 侧边栏ico
export const themeData = {
  default: [
    {
      name: '编辑',
      type: 'edit',
      img: 'iconbianji'
    },
    {
      name: '主题',
      type: 'theme',
      img: 'icontheme'
    },
    {
      name: '新增',
      type: 'add',
      img: 'icontianjia'
    },
    {
      name: '收藏',
      type: 'collect',
      img: 'iconcolllect'
    }
  ],
  lyThemeA: [
    {
      name: '编辑',
      type: 'edit',
      img: 'iconthemA_bianji'
    },
    {
      name: '主题',
      type: 'theme',
      img: 'iconthemA_zhuti'
    },
    {
      name: '新增',
      type: 'add',
      img: 'iconthemeA_tianjia'
    },
    {
      name: '收藏',
      type: 'collect',
      img: 'iconthemeA_app'
    }
  ],
  lyThemeB: [
    {
      name: '编辑',
      type: 'edit',
      img: 'iconbianji2'
    },
    {
      name: '主题',
      type: 'theme',
      img: 'iconzhuti'
    },
    {
      name: '新增',
      type: 'add',
      img: 'icontianjia1'
    },
    {
      name: '收藏',
      type: 'collect',
      img: 'iconyingyong'
    }
  ]
}

// 卡片默认间距
export const getThemeStyle = (componentName, props) => {
  // 是否是放在layout布局卡和tab中的
  const { wrapper } = props
  let style = `background: #fff; margin: 10px 5px; padding: 10px; border: none;border-radius:10px;min-height:100px;`
  // 是否是编辑程
  if (wrapper) {
    style = `background: #fff; margin: 10px; border: none;border-radius:10px;min-height:100px;`
  } else {
    let object = props.page.element[props.page.currentPage]
    // 主题A
    if (object && object.pageTheme == 'lyThemeA') {
      if (componentName == 'SearchCard') {
        style = `background: transparent; margin: 30px 10px 0 10px; padding: 10px; border:none;border-radius:none;`
      } else {
        style = `background: #fff; margin: 30px 15px; padding: 10px; border:none;border-radius:20px;min-height:100px;`
      }
    }
  }
  return style
}

// 主题编辑栏
export const generateEdit = (componentName, props) => {
  const { page, handleEdit, handleDelete, handleHelp, cardProps } = props
  const { hasExplain } = cardProps
  const { editPage } = page
  // 本菜单下的页面布局
  let object = props.page.element[props.page.currentPage]
  // 主题A
  if (object && object.pageTheme == 'lyThemeA') {
    // if (componentName == "SearchCard") {
    //   return null;
    // } else {
    return (
      <div className={classnames('floatBtn')}>
        {hasExplain && (
          <i
            className={`icon iconfont icontishi`}
            onClick={() => handleHelp(props) || (() => {})}
            style={{
              color: '#fff',
              display: handleEdit && editPage ? '' : 'none'
            }}
          />
        )}
        <i
          className={`icon iconfont iconbianji1`}
          style={{
            color: '#fff',
            display: handleEdit && editPage ? '' : 'none'
          }}
          onClick={() => handleEdit(props) || (() => {})}
        />
        <i
          className={`icon iconfont iconshanchumokuai`}
          style={{
            color: '#fff',
            display: handleEdit && editPage ? '' : 'none'
          }}
          onClick={() => handleDelete(props) || (() => {})}
        />
      </div>
    )
    //}
  } else {
    return (
      <div className={classnames('floatBtn')}>
        {hasExplain && (
          <i
            className={`icon iconfont icontishi`}
            onClick={() => handleHelp(props) || (() => {})}
            style={{
              color: '#fff',
              display: handleEdit && editPage ? '' : 'none'
            }}
          />
        )}
        <i
          className={`icon iconfont iconbianji1`}
          style={{
            color: '#fff',
            display: handleEdit && editPage ? '' : 'none'
          }}
          onClick={() => handleEdit(props) || (() => {})}
        />
        <i
          className={`icon iconfont iconshanchumokuai`}
          style={{
            color: '#fff',
            display: handleEdit && editPage ? '' : 'none'
          }}
          onClick={() => handleDelete(props) || (() => {})}
        />
      </div>
    )
  }
}
