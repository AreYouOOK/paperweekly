/*
 * @Description: 卡片基础配置信息
 * @Author: xuqiuting
 * @Date: 2019-08-17 14:16:52
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-16 14:35:01
 */
// 所有卡片共同拥有的系统内置卡片弹窗表单
export const cardFormList = [
  // {
  //   type: "Switch",
  //   label: "cardTransparent",
  //   name: "systemCardTransparent",
  //   show: true
  // },
  {
    type: 'Switch',
    label: 'cardShowTitle',
    name: 'systemTitleShow',
    show: true,
    authority: [
      'systemTitleLocale',
      'systemTitleFontfamily',
      'systemTitleFontsize',
      'systemTitleColor'
    ]
  },
  {
    type: 'LanguageInput',
    label: 'cardTitle',
    name: 'systemTitleLocale',
    maxlength: 25,
    show: {
      label: 'systemTitleShow',
      value: true
    }
  },
  {
    type: 'Select',
    label: 'cardFontfamily',
    name: 'systemTitleFontfamily',
    show: {
      label: 'systemTitleShow',
      value: true
    },
    items: [
      {
        value: 'SimSun',
        label: 'fontfamily_SimSun'
      },
      {
        value: 'SimHei',
        label: 'fontfamily_SimHei'
      },
      {
        value: 'FangSong',
        label: 'fontfamily_FangSong'
      },
      {
        value: 'KaiTi',
        label: 'fontfamily_KaiTi'
      },
      {
        value: 'Microsoft YaHei',
        label: 'fontfamily_MicrosoftYaHei'
      },
      {
        value: 'LiSu',
        label: 'fontfamily_LiSu'
      },
      {
        value: 'STHeiti',
        label: 'fontfamily_STHeiti'
      },
      {
        value: 'STKaiti',
        label: 'fontfamily_STKaiti'
      },
      {
        value: 'STSong',
        label: 'fontfamily_STSong'
      },
      {
        value: 'STFangsong',
        label: 'fontfamily_STFangsong'
      }
    ]
  },
  {
    type: 'Select',
    label: 'cardFontsize',
    name: 'systemTitleFontsize',
    show: {
      label: 'systemTitleShow',
      value: true
    },
    hideLanguage: true,
    items: [
      {
        value: '12px',
        label: '12px'
      },
      {
        value: '14px',
        label: '14px'
      },
      {
        value: '16px',
        label: '16px'
      },
      {
        value: '18px',
        label: '18px'
      },
      {
        value: '20px',
        label: '20px'
      },
      {
        value: '22px',
        label: '22px'
      }
    ]
  },
  {
    type: 'ColorBtn',
    label: 'cardFontcolor',
    name: 'systemTitleColor',
    colorType: 'hex',
    show: {
      label: 'systemTitleShow',
      value: true
    }
  },
  {
    type: 'CssEditor',
    label: 'cardStyle',
    name: 'systemCardStyle',
    show: true,
    extra: 'css_editor_extra'
  }
]
