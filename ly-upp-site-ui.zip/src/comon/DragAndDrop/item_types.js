export const ItemTypes = {
    DragMenu: 'DragMenu', // 卡片添加
    Element:"Element", // 元素拖曳
    Drop:['Element', 'DragMenu'],//放置
}
