/*
 * @Description: 拖曳组件Hover逻辑处理
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-24 16:48:48
 */
/************实现拖动的各个方法处理*************/
import { findDOMNode } from "react-dom";
import { guid } from "utils/util";
import antdUI from "assets/js/lib";
import systemCard from "comon/template/index";
import _ from "lodash";
import { message } from "antd";

// 国际化语言，为了报错弹出对应信息
let localeJson = JSON.parse(window.sessionStorage.getItem("localeJson"));
if (!localeJson) {
  let locale = window.sessionStorage.getItem("locale")
    ? window.sessionStorage.getItem("locale")
    : "zh_CN";
  localeJson = window.locale[locale];
}

// 菜单拖曳source
export const sourceSpec = {
  beginDrag(props) {
    // 返回需要注入的属性
    return {
      id: props.id,
      ...props
    };
  },
  canDrag(props) {
    if (props.cardProps.isSingleton == "1" && props.cardProps.isUse == "1") {
      return false;
    } else {
      return true;
    }
  },
  endDrag(props, monitor) {}
};

//既可以拖曳又可以放置的source
export const dropSourceSpec = {
  canDrag(props) {
    if (props.editPage) {
      return true;
    } else {
      return false;
    }
  },
  beginDrag(props) {
    // 返回需要注入的属性
    return {
      id: props.id,
      ...props
    };
  },
  endDrag(props, monitor) {}
};

// 布局放置目标,不包括选项卡放置组件,也不包括布局卡
export const targetSpec = {
  hover(props, monitor, component) {},
  drop(props, monitor) {
    if (monitor.didDrop()) return;
    let dragItem = monitor.getItem();
    let { dataSource, areaIndex } = props;
    let propsDatasource = _.cloneDeep(dataSource);
    let dropAim = propsDatasource[areaIndex].componentArea;

    // 给组件加上唯一的id,可以是从组件栏目拖进来的组件，也可以是从页面本来有，然后拖进不同的target
    let uid = dragItem.props && dragItem.props.id ? dragItem.props.id : guid();
    //新的属性
    let newprops = {
      // 用于渲染是什么组件
      componentName: dragItem.props
        ? dragItem.props.componentName
        : dragItem.componentName,
      // key值用来自由布局
      key: uid,
      // 用来标志是在那个target里面的
      parentid: props.id,
      // 默认id
      id: uid,
      // 自由布局必须要的
      dataGrid: dragItem.props
        ? dragItem.props["dataGrid"]
        : {
            i: uid.toString(),
            x: 0,
            y: 0,
            w: 3,
            h: 1,
            isDraggable: true,
            isResizable: true
          },
      // 组件是否只能添加一次
      isSingleton: dragItem.props
        ? dragItem.props.isSingleton
        : dragItem.isSingleton,
      cardProps: dragItem.props ? dragItem.props.cardProps : dragItem.cardProps,
      config: dragItem.props ? dragItem.props.config : dragItem.config
    };
    // 用于暂存数据
    let itemCopy = _.cloneDeep(dragItem.props);
    let allProps = {
      ...itemCopy,
      ...newprops
    };
    // 放置在普通布局，删除tabId和colId
    if (allProps.tabId) {
      delete allProps.tabId;
    }
    if (allProps.colId == 0 || allProps.colId) {
      delete allProps.colId;
    }

    // 判断是从菜单中拖拉出来的还是在组件存在的，有props表示组件存在的
    if (dragItem.props && dragItem.props.id) {
      // console.log(props, dragItem, "布局放置目标,不包括选项卡放置组件,也不包括布局卡");
      let fromAreaIndex = dragItem.areaIndex;
      let fromDataSource = propsDatasource[fromAreaIndex].componentArea;
      let dragCoordinate = dragItem.coordinate;
      let parentTablist = fromDataSource.filter(
        res => res.id == dragItem.props.parentid
      )[0];
     
      if (dragCoordinate[0] == "tab") {
		if (!parentTablist) {
			return;
		  }
        let fromtabContent = parentTablist.tabList.filter(
          res => res.id == dragItem.props.tabId
        )[0].content;
        fromtabContent.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            fromtabContent.splice(i, 1);
            return true;
          } else {
            return false;
          }
        });
      } else if (dragCoordinate[0] == "layout") {
		if (!parentTablist) {
			return;
		  }
        let parentArr = parentTablist.component[dragCoordinate[2]].subComponent;
        parentArr.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            parentArr.splice(i, 1);
            return true;
          } else {
            return false;
          }
        });
      } else {
        fromDataSource.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            fromDataSource.splice(i, 1);
            return true;
          } else {
            return false;
          }
        });
      }
      dropAim.push(allProps);
      dragItem.areaIndex = areaIndex;
      dragItem.parentid = props.id;
      dragItem.coordinate = ["mainArea", dropAim.length];
    } else {
      if (
        !systemCard[dragItem.commpentName] &&
        !antdUI[dragItem.commpentName]
      ) {
        message.error(localeJson.card_not_exist);
        return;
      }
      if (dragItem.componentName == "SelectCard") {
        allProps.defaultActiveKey = 0;
        allProps.tabList = [
          {
            title: "选项卡1",
            id: guid(),
            locale: {
              en_US: {
                name: "tab1"
              },
              zh_CN: {
                name: "选项卡1"
              }
            },
            content: []
          },
          {
            title: "选项卡2",
            id: guid(),
            locale: {
              en_US: {
                name: "tab2"
              },
              zh_CN: {
                name: "选项卡2"
              }
            },
            content: []
          },
          {
            title: "选项卡3",
            id: guid(),
            locale: {
              en_US: {
                name: "tab3"
              },
              zh_CN: {
                name: "选项卡3"
              }
            },
            content: []
          }
        ];
        allProps["dataGrid"] = {
          i: uid.toString(),
          x: 0,
          y: 0,
          w: 4,
          h: 2,
          isDraggable: true,
          isResizable: true
        };
      } else if (dragItem.componentName == "LayoutCard") {
        allProps.layout = "two_col_5_5";
        allProps.component = [
          {
            subComponent: []
          },
          {
            subComponent: []
          }
        ];
        allProps["dataGrid"] = {
          i: uid.toString(),
          x: 0,
          y: 0,
          w: 4,
          h: 2,
          isDraggable: true,
          isResizable: true
        };
      }
      dropAim.splice(dropAim.length, 0, allProps);
      dragItem.areaIndex = areaIndex;
      dragItem.parentid = props.id;
      dragItem.coordinate = ["mainArea", dropAim.length];
    }
    props.operationItem(propsDatasource, dragItem);

    return {
      ...props,
      id: props.id,
      isOver: monitor.isOver(),
      diffOffset: monitor.getDifferenceFromInitialOffset()
    };
  }
};

// 选项卡布局放置组件
export const tabTargetSpec = {
  hover(props, monitor, component) {},
  drop(props, monitor) {
    if (monitor.didDrop()) return;
    let dragItem = monitor.getItem();
    if (
      (dragItem.props && dragItem.props.componentName == "SelectCard") ||
      (dragItem.props && dragItem.props.componentName == "LayoutCard") ||
      (dragItem.props && dragItem.props.componentName == "SelectComponent") ||
      dragItem.componentName == "SelectCard" ||
      dragItem.componentName == "LayoutCard" ||
      dragItem.componentName == "SelectComponent"
    ) {
      return;
    }
    if (
      dragItem.props &&
      dragItem.props.parentid == props.id &&
      dragItem.props.tabId == props.tabId
    ) {
      return;
    }
    let { dataSource, areaIndex, tabId } = props;
    let propsDatasource = _.cloneDeep(dataSource);
    let tabAllContent = propsDatasource[areaIndex].componentArea.filter(
      res => res.id == props.id
    )[0].tabList;
    let dropAim = tabAllContent.filter(res => res.id == tabId)[0].content;

    // 给组件加上唯一的id,可以是从组件栏目拖进来的组件，也可以是从页面本来有，然后拖进不同的target
    let uid = dragItem.props && dragItem.props.id ? dragItem.props.id : guid();
    //新的属性
    let newprops = {
      // 用于渲染是什么组件
      componentName: dragItem.props
        ? dragItem.props.componentName
        : dragItem.componentName,
      // key值用来自由布局
      key: uid,
      // 用来标志是在那个target里面的
      parentid: props.id,
      // 默认id
      id: uid,
      tabId: tabId,
      // 自由布局必须要的
      ["dataGrid"]: dragItem.props
        ? dragItem.props["dataGrid"]
        : {
            i: uid.toString(),
            x: 0,
            y: 0,
            w: 3,
            h: 1,
            isDraggable: true,
            isResizable: true
          },
      config: dragItem.props ? dragItem.props.config : dragItem.config,
      isSingleton: dragItem.props
        ? dragItem.props.isSingleton
        : dragItem.isSingleton,
      cardProps: dragItem.props ? dragItem.props.cardProps : dragItem.cardProps
    };
    // console.log(props, dragItem, "选项卡布局放置目标")

    // tab卡片需要单独加一个默认属性，用于设置tab数以及名字,由于菜单拖进来的组件没有props属性
    let itemCopy = _.cloneDeep(dragItem.props);
    let allProps = {
      ...itemCopy,
      ...newprops
    };
    // 放置在tab卡片，删除colId
    if (allProps.colId == 0 || allProps.colId) {
      delete allProps.colId;
    }
    // 判断是从菜单中拖拉出来的还是在组件存在的，有props表示组件存在的
    if (dragItem.props && dragItem.props.id) {
      // console.log(dragItem,"dragItem","布局")
      let fromAreaIndex = dragItem.areaIndex;
      let fromDataSource = propsDatasource[fromAreaIndex].componentArea;
      let dragCoordinate = dragItem.coordinate;
      let parentTablist = fromDataSource.filter(
        res => res.id == dragItem.props.parentid
      )[0];

      if (dragCoordinate[0] == "tab") {
		if (!parentTablist) {
			return;
		  }
        // console.log(dataSource,propsDatasource,"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
        // console.log(parentTablist, "parentTablist")
        let fromtabContent = parentTablist.tabList.filter(
          res => res.id == dragItem.props.tabId
        )[0].content;
        fromtabContent.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            fromtabContent.splice(i, 1)[0];
            return true;
          } else {
            return false;
          }
        });
      } else if (dragCoordinate[0] == "layout") {
		if (!parentTablist) {
			return;
		  }
        let parentArr = parentTablist.component[dragCoordinate[2]].subComponent;
        parentArr.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            parentArr.splice(i, 1);
            return true;
          } else {
            return false;
          }
        });
      } else {
        fromDataSource.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            fromDataSource.splice(i, 1)[0];
            return true;
          } else {
            return false;
          }
        });
      }
      dropAim.push(allProps);
      dragItem.areaIndex = areaIndex;
      dragItem.parentid = props.id;
      dragItem.coordinate = ["tab", dropAim.length];
      dragItem.props = allProps;
    } else {
      if (
        !systemCard[dragItem.commpentName] &&
        !antdUI[dragItem.commpentName]
      ) {
        message.error(localeJson.card_not_exist);
        return;
      }
      dropAim.push(allProps);
      dragItem.areaIndex = areaIndex;
      dragItem.parentid = props.id;
      dragItem.coordinate = ["tab", dropAim.length];
      dragItem.props = allProps;
    }
    // console.log(propsDatasource,"选项卡布局放置组件")
    props.operationItem(propsDatasource, dragItem);
    return {
      ...props,
      id: props.id,
      isOver: monitor.isOver(),
      diffOffset: monitor.getDifferenceFromInitialOffset()
    };
  }
};

// 布局卡片放置组件
export const layoutTargetSpec = {
  hover(props, monitor, component) {},
  drop(props, monitor) {
    if (monitor.didDrop()) return;
    // console.log(props, "布局卡片放置组件")
    let dragItem = monitor.getItem();
    if (
      (dragItem.props && dragItem.props.componentName == "SelectCard") ||
      (dragItem.props && dragItem.props.componentName == "LayoutCard") ||
      dragItem.componentName == "SelectCard" ||
      dragItem.componentName == "LayoutCard"
    ) {
      return;
    }
    if (
      dragItem.props &&
      dragItem.props.parentid == props.id &&
      dragItem.props.colId == props.colId
    ) {
      return;
    }
    let { dataSource, areaIndex, colId } = props;
    let propsDatasource = _.cloneDeep(dataSource);
    let dropAim = propsDatasource[areaIndex].componentArea.filter(
      res => res.id == props.id
    )[0].component[colId].subComponent;

    // 给组件加上唯一的id,可以是从组件栏目拖进来的组件，也可以是从页面本来有，然后拖进不同的target
    let uid = dragItem.props && dragItem.props.id ? dragItem.props.id : guid();
    //新的属性
    let newprops = {
      // 用于渲染是什么组件
      componentName: dragItem.props
        ? dragItem.props.componentName
        : dragItem.componentName,
      // key值用来自由布局
      key: uid,
      // 用来标志是在那个target里面的
      parentid: props.id,
      // 默认id
      id: uid,
      colId: colId,
      // 自由布局必须要的
      ["dataGrid"]: dragItem.props
        ? dragItem.props["dataGrid"]
        : {
            i: uid.toString(),
            x: 0,
            y: 0,
            w: 3,
            h: 1,
            isDraggable: true,
            isResizable: true
          },
      config: dragItem.props ? dragItem.props.config : dragItem.config,
      isSingleton: dragItem.props
        ? dragItem.props.isSingleton
        : dragItem.isSingleton,
      cardProps: dragItem.props ? dragItem.props.cardProps : dragItem.cardProps
    };
    // console.log(props, dragItem, "布局卡片放置目标")

    // tab卡片需要单独加一个默认属性，用于设置tab数以及名字,由于菜单拖进来的组件没有props属性
    let itemCopy = _.cloneDeep(dragItem.props);
    let allProps = {
      ...itemCopy,
      ...newprops
    };
    // 放置在layout卡片，删除tabId
    if (allProps.tabId) {
      delete allProps.tabId;
	}

    // 判断是从菜单中拖拉出来的还是在组件存在的，有props表示组件存在的
    if (dragItem.props && dragItem.props.id) {
      // console.log(dragItem,"dragItem","布局")
      let fromAreaIndex = dragItem.areaIndex;
      let fromDataSource = propsDatasource[fromAreaIndex].componentArea;
      let dragCoordinate = dragItem.coordinate;
      let parentTablist = fromDataSource.filter(
        res => res.id == dragItem.props.parentid
	  )[0];
     
      if (dragCoordinate[0] == "tab") {
		if (!parentTablist) {
			return;
		  }
        // console.log(parentTablist, "parentTablist")
        let fromtabContent = parentTablist.tabList.filter(
          res => res.id == dragItem.props.tabId
        )[0].content;
        fromtabContent.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            fromtabContent.splice(i, 1);
            return true;
          } else {
            return false;
          }
        });
      } else if (dragCoordinate[0] == "layout") {
		if (!parentTablist) {
			return;
		  }
        let parentArr = parentTablist.component[dragCoordinate[2]].subComponent;
        parentArr.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            parentArr.splice(i, 1);
            return true;
          } else {
            return false;
          }
        });
      } else {
        fromDataSource.some(function(item, i) {
          if (item.id == dragItem.props.id) {
            fromDataSource.splice(i, 1);
            return true;
          } else {
            return false;
          }
        });
      }
      dropAim.push(allProps);
      dragItem.areaIndex = areaIndex;
      dragItem.parentid = props.id;
      dragItem.coordinate = ["layout", dropAim.length, colId];
      dragItem.props = allProps;
    } else {
      if (
        !systemCard[dragItem.commpentName] &&
        !antdUI[dragItem.commpentName]
      ) {
        message.error(localeJson.card_not_exist);
        return;
      }
      dropAim.push(allProps);
      dragItem.areaIndex = areaIndex;
      dragItem.parentid = props.id;
      dragItem.coordinate = ["layout", dropAim.length, colId];
      dragItem.props = allProps;
    }
    props.operationItem(propsDatasource, dragItem);
    return {
      ...props,
      id: props.id,
      isOver: monitor.isOver(),
      diffOffset: monitor.getDifferenceFromInitialOffset()
    };
  }
};

//既可以拖曳又可以放置的target
export const dropTargetSpec = {
  hover(props, monitor, component) {
    const dragItem = monitor.getItem();
    // 如果id一样就不要移动
    if (dragItem.props && props.props.id == dragItem.props.id) {
      return false;
    }
    if (!dragItem.props && dragItem.id) {
      return false;
    }
    if (
      (props.props && props.props.componentName == "SelectCard") ||
      (props.props && props.props.componentName == "LayoutCard") ||
      props.componentName == "SelectCard" ||
      props.componentName == "LayoutCard"
    ) {
      return;
    }
    // console.log(dragItem, props, "dragItem,props既可以拖曳又可以放置的target")

    const hoverBoundingRect = findDOMNode(component).getBoundingClientRect();
    const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
    const clientOffset = monitor.getClientOffset();
    const hoverClientY = clientOffset.y - hoverBoundingRect.top;

    let toAreaIndex = props.areaIndex;
    let propsDatasource = _.cloneDeep(props.dataSource);
    let toDataSource = propsDatasource[toAreaIndex].componentArea;
    let hoverIndex = props.coordinate[1];
    // 不是从菜单拖出来的
    if (dragItem.props) {
      let itemCopy = _.cloneDeep(dragItem.props);
      let newprops = {
        ...itemCopy,
        parentid: props.props.parentid
      };
      // 放置在普通布局，删除tabId，colId
      if (newprops.tabId) {
        delete newprops.tabId;
      }
      if (newprops.colId == 0 || newprops.colId) {
        delete newprops.colId;
      }
      let fromAreaIndex = dragItem.areaIndex;
      let fromDataSource = propsDatasource[fromAreaIndex].componentArea;
      let dragIndex = dragItem.coordinate[1];
      let dragCoordinate = dragItem.coordinate;
      //两个父组件一样,说明都是放在布局框中
      if (props.props.parentid == dragItem.props.parentid) {
        if (dragIndex == hoverIndex) {
          return;
        }
        if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
          return;
        }
        if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
          return;
        }

        let tempItem = toDataSource[dragIndex];
        toDataSource[dragIndex] = toDataSource[hoverIndex];
        toDataSource[hoverIndex] = tempItem;
        monitor.getItem().coordinate = ["mainArea", hoverIndex];
      } else {
        if (dragCoordinate[0] == "mainArea") {
          // 普通到普通
          fromDataSource.splice(dragIndex, 1);
          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            toDataSource.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["mainArea", hoverIndex];
            dragItem.areaIndex = props.areaIndex;
          } else {
            //在下面添加
            toDataSource.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["mainArea", hoverIndex + 1];
            dragItem.areaIndex = props.areaIndex;
          }
        } else if (dragCoordinate[0] == "tab") {
          //tab到普通
          let dragParent = fromDataSource.filter(
            item => dragItem.props.parentid === item.id
          )[0];
          let fromtabContent = dragParent.tabList.filter(
            res => res.id == dragItem.props.tabId
          )[0].content;
          fromtabContent.splice(dragIndex, 1);

          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            toDataSource.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["mainArea", hoverIndex];
            dragItem.areaIndex = props.areaIndex;
          } else {
            //在下面添加
            toDataSource.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["mainArea", hoverIndex + 1];
            dragItem.areaIndex = props.areaIndex;
          }
        } else if (dragCoordinate[0] == "layout") {
          // console.log(dragItem.props,fromDataSource,"dragItem.props既可以拖曳又可以放置的target")
          //layout到普通
          let dragParent = fromDataSource.filter(
            item => dragItem.props.parentid === item.id
          )[0];
          // 预防布局卡片在附近
          if (!dragParent) {
            return;
          }
          let fromtabContent =
            dragParent.component[dragCoordinate[2]].subComponent;
          fromtabContent.splice(dragIndex, 1);
          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            toDataSource.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["mainArea", hoverIndex];
            dragItem.areaIndex = props.areaIndex;
          } else {
            //在下面添加
            toDataSource.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["mainArea", hoverIndex + 1];
            dragItem.areaIndex = props.areaIndex;
          }
        }
        monitor.getItem().props.parentid = props.props.parentid;
      }
    } else {
      if (
        !systemCard[dragItem.commpentName] &&
        !antdUI[dragItem.commpentName]
      ) {
        message.error(localeJson.card_not_exist);
        return;
      }
      let uid = guid();
      monitor.getItem().id = uid;

      //新的属性
      let newprops = {
        // 用于渲染是什么组件
        componentName: dragItem.componentName,
        // key值用来自由布局
        key: uid,
        // 用来标志是在那个target里面的
        parentid: props.props.parentid,
        // 默认id
        id: uid,
        // 自由布局必须要的
        ["dataGrid"]: dragItem.props
          ? dragItem.props["dataGrid"]
          : {
              i: uid.toString(),
              x: 0,
              y: 0,
              w: 3,
              h: 1,
              isDraggable: true,
              isResizable: true
            },
        config: dragItem.config,
        isSingleton: dragItem.isSingleton,
        cardProps: dragItem.cardProps
      };
      // tab卡片需要单独加一个默认属性，用于设置tab数以及名字,由菜单拖进来的组件没有props属性
      if (dragItem.componentName == "SelectCard") {
        newprops.defaultActiveKey = 0;
        newprops.tabList = [
          {
            title: "选项卡1",
            id: guid(),
            content: [],
            locale: {
              en_US: {
                name: "tab1"
              },
              zh_CN: {
                name: "选项卡1"
              }
            }
          },
          {
            title: "选项卡2",
            id: guid(),
            content: [],
            locale: {
              en_US: {
                name: "tab2"
              },
              zh_CN: {
                name: "选项卡2"
              }
            }
          },
          {
            title: "选项卡3",
            id: guid(),
            content: [],
            locale: {
              en_US: {
                name: "tab3"
              },
              zh_CN: {
                name: "选项卡3"
              }
            }
          }
        ];
        newprops["dataGrid"] = {
          i: uid.toString(),
          x: 0,
          y: 0,
          w: 4,
          h: 2,
          isDraggable: true,
          isResizable: true
        };
      } else if (dragItem.componentName == "LayoutCard") {
        newprops.layout = "two_col_5_5";
        newprops.component = [
          {
            subComponent: []
          },
          {
            subComponent: []
          }
        ];
        newprops["dataGrid"] = {
          i: uid.toString(),
          x: 0,
          y: 0,
          w: 4,
          h: 2,
          isDraggable: true,
          isResizable: true
        };
      }

      if (hoverClientY < hoverMiddleY) {
        // 在上面添加
        toDataSource.splice(hoverIndex, 0, newprops);
        dragItem.areaIndex = props.areaIndex;
        dragItem.coordinate = ["mainArea", hoverIndex];
      } else {
        //在下面添加
        toDataSource.splice(hoverIndex + 1, 0, newprops);
        dragItem.coordinate = ["mainArea", hoverIndex + 1];
        dragItem.areaIndex = props.areaIndex;
      }
      dragItem.areaIndex = props.areaIndex;
      monitor.getItem().props = newprops;
    }
    // console.log(propsDatasource, "既可以拖曳又可以放置的target");
    props.operationItem(propsDatasource, dragItem);
  },
  drop(props, monitor, component) {
    if (monitor.didDrop()) return;
    // 操作要拖拉的组件
    return {
      ...props,
      id: props.id,
      isOver: monitor.isOver(),
      diffOffset: monitor.getDifferenceFromInitialOffset()
    };
  }
};

// 选项卡既可以拖曳又可以放置
export const tabDropTargetSpec = {
  hover(props, monitor, component) {
    const dragItem = monitor.getItem();
    // 如果id一样就不要移动
    if (dragItem.props && props.props.id == dragItem.props.id) {
      return false;
    }
    if (!dragItem.props && dragItem.id) {
      return false;
    }
    if (
      (dragItem.props && dragItem.props.componentName == "SelectCard") ||
      (dragItem.props && dragItem.props.componentName == "LayoutCard") ||
      (dragItem.props && dragItem.props.componentName == "SelectComponent") ||
      dragItem.componentName == "SelectCard" ||
      dragItem.componentName == "LayoutCard" ||
      dragItem.componentName == "SelectComponent"
    ) {
      return;
    }
    const hoverBoundingRect = findDOMNode(component).getBoundingClientRect();
    const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
    const clientOffset = monitor.getClientOffset();
    const hoverClientY = clientOffset.y - hoverBoundingRect.top;

    let toAreaIndex = props.areaIndex;
    let propsDatasource = _.cloneDeep(props.dataSource);
    let toDataSource = propsDatasource[toAreaIndex].componentArea;
    let toTabList = toDataSource.filter(
      item => props.props.parentid === item.id
    )[0];
    let totabContent = toTabList.tabList.filter(
      res => res.id == props.props.tabId
    )[0].content;
    let hoverIndex = props.coordinate[1];

    // 不是从菜单拖出来的
    if (dragItem.props) {
      let itemCopy = _.cloneDeep(dragItem.props);
      let newprops = {
        ...itemCopy,
        parentid: props.props.parentid,
        tabId: props.props.tabId
      };
      // 放置在tab卡片，colId
      if (newprops.colId == 0 || newprops.colId) {
        delete newprops.colId;
      }
      let fromAreaIndex = dragItem.areaIndex;
      let fromDataSource = propsDatasource[fromAreaIndex].componentArea;
      let dragIndex = dragItem.coordinate[1];
      let dragCoordinate = dragItem.coordinate;

      //两个父组件一样，说明都是tab
      if (props.props.parentid == dragItem.props.parentid) {
        if (dragIndex == hoverIndex) {
          return;
        }
        if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
          return;
        }
        if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
          return;
        }

        // 判断tab的选项卡是否一样
        if (dragItem.props.tabId == props.props.tabId) {
          let tempItem = totabContent[dragIndex];
          totabContent[dragIndex] = totabContent[hoverIndex];
          totabContent[hoverIndex] = tempItem;
          monitor.getItem().coordinate = ["tab", hoverIndex];
          dragItem.props.tabId = props.props.tabId;
        } else {
          let fromTabContent = toTabList.tabList.filter(
            res => res.id == dragItem.props.tabId
          )[0].content;
          fromTabContent.some(function(item, i) {
            if (item.id == dragItem.props.id) {
              fromTabContent.splice(i, 1);
              return true;
            } else {
              return false;
            }
          });
          totabContent.push(newprops);
          dragItem.areaIndex = areaIndex;
          dragItem.coordinate = ["tab", totabContent.length];
          dragItem.props.tabId = props.props.tabId;
        }
      } else {
        if (dragCoordinate[0] == "mainArea") {
          //普通到tab
          // console.log(dragItem, props, "普通到tab,dragItem,props选项卡既可以拖曳又可以放置target")
          fromDataSource.splice(dragIndex, 1);
          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            totabContent.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["tab", hoverIndex];
            dragItem.areaIndex = props.areaIndex;
            dragItem.props.tabId = props.props.tabId;
          } else {
            //在下面添加
            totabContent.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["tab", hoverIndex + 1];
            dragItem.areaIndex = props.areaIndex;
            dragItem.props.tabId = props.props.tabId;
          }
        } else if (dragCoordinate[0] == "layout") {
          //layout到tab
          // console.log(dragItem, props, "layout到tab,dragItem,props布局卡既可以拖曳又可以放置target")
          // 来源布局卡列表

          let dragParent = fromDataSource.filter(
            item => dragItem.props.parentid === item.id
          )[0];
          // 预防布局卡片在附近
          if (!dragParent) {
            return;
          }
          //   console.log(dragItem.props,fromDataSource,dragParent,"dragItem.props选项卡既可以拖曳又可以放置")
          let fromtabContent =
            dragParent.component[dragCoordinate[2]].subComponent;
          fromtabContent.splice(dragIndex, 1);

          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            totabContent.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["tab", hoverIndex];
            dragItem.areaIndex = props.areaIndex;
            dragItem.props.tabId = props.props.tabId;
          } else {
            //在下面添加
            totabContent.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["tab", hoverIndex + 1];
            dragItem.areaIndex = props.areaIndex;
            dragItem.props.tabId = props.props.tabId;
          }
        } else if (dragCoordinate[0] == "tab") {
          // 从tab到tab
          let dragParent = fromDataSource.filter(
            item => dragItem.props.parentid === item.id
          )[0];
          let fromtabContent = dragParent.tabList.filter(
            res => res.id == dragItem.props.tabId
          )[0].content;
          // console.log(dragItem, props, "tab到tab,dragItem,props选项卡既可以拖曳又可以放置target")
          //tab到tab
          fromtabContent.splice(dragIndex, 1);
          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            totabContent.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["tab", hoverIndex];
            dragItem.areaIndex = props.areaIndex;
            dragItem.props.tabId = props.props.tabId;
          } else {
            //在下面添加
            totabContent.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["tab", hoverIndex + 1];
            dragItem.areaIndex = props.areaIndex;
            dragItem.props.tabId = props.props.tabId;
          }
        }
        monitor.getItem().props.parentid = props.props.parentid;
      }
    } else {
      // console.log(props, dragItem, "从菜单中拉出来的")
      let uid = guid();
      monitor.getItem().id = uid;
      //新的属性
      let newprops = {
        // 用于渲染是什么组件
        componentName: dragItem.componentName,
        // key值用来自由布局
        key: uid,
        // 用来标志是在那个target里面的
        parentid: props.props.parentid,
        // 默认id
        id: uid,
        tabId: props.tabId,
        // 自由布局必须要的
        ["dataGrid"]: {
          i: uid.toString(),
          x: 0,
          y: 0,
          w: 3,
          h: 1,
          isDraggable: true,
          isResizable: true
        },
        isSingleton: dragItem.isSingleton,
        cardProps: dragItem.cardProps,
        config: dragItem.config
      };

      if (hoverClientY < hoverMiddleY) {
        // 在上面添加
        totabContent.splice(hoverIndex, 0, newprops);
        dragItem.coordinate = ["tab", hoverIndex];
        dragItem.areaIndex = props.areaIndex;
        dragItem.props = newprops;
      } else {
        //在下面添加
        totabContent.splice(hoverIndex + 1, 0, newprops);
        dragItem.coordinate = ["tab", hoverIndex + 1];
        dragItem.areaIndex = props.areaIndex;
        dragItem.props = newprops;
      }
      monitor.getItem().props = newprops;
    }
    // console.log(propsDatasource,"选项卡既可以拖曳又可以放置")
    props.operationItem(propsDatasource, dragItem);
  },
  canDrop() {
    return false;
  },
  drop(props, monitor, component) {
    if (monitor.didDrop()) return;
    // 操作要拖拉的组件
    return {
      ...props,
      id: props.id,
      isOver: monitor.isOver(),
      diffOffset: monitor.getDifferenceFromInitialOffset()
    };
  }
};

// 布局卡片既可以拖曳又可以放置的target
export const layoutDropTargetSpec = {
  hover(props, monitor, component) {
    const dragItem = monitor.getItem();
    // 如果id一样就不要移动
    if (dragItem.props && props.props.id == dragItem.props.id) {
      return false;
    }
    if (!dragItem.props && dragItem.id) {
      return false;
    }
    if (
      (dragItem.props && dragItem.props.componentName == "SelectCard") ||
      (dragItem.props && dragItem.props.componentName == "LayoutCard") ||
      dragItem.componentName == "SelectCard" ||
      dragItem.componentName == "LayoutCard"
    ) {
      return;
    }

    // console.log("layoutDropTargetSpec",props,dragItem)
    const hoverBoundingRect = findDOMNode(component).getBoundingClientRect();
    const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
    const clientOffset = monitor.getClientOffset();
    const hoverClientY = clientOffset.y - hoverBoundingRect.top;

    let toAreaIndex = props.areaIndex;
    let hoverIndex = props.coordinate[1];
    let hoverCoordinate = props.coordinate;
    let propsDatasource = _.cloneDeep(props.dataSource);
    let toDataSource = propsDatasource[toAreaIndex].componentArea;
    let toLayoutList = toDataSource.filter(
      item => props.props.parentid === item.id
    )[0];
    // 要放置的列表
    let toLayoutContent =
      toLayoutList.component[hoverCoordinate[2]].subComponent;
    const { colId } = props;

    // 不是从菜单拖出来的
    if (dragItem.props) {
      let itemCopy = _.cloneDeep(dragItem.props);
      let newprops = {
        ...itemCopy,
        parentid: props.props.parentid
      };
      // 放置在layout卡片，删除tabId
      if (newprops.tabId) {
        delete newprops.tabId;
      }
      let fromAreaIndex = dragItem.areaIndex;
      let fromDataSource = propsDatasource[fromAreaIndex].componentArea;
      let dragIndex = dragItem.coordinate[1];
      let dragCoordinate = dragItem.coordinate;
      // console.log(props,dragItem,"布局卡片既可以拖曳又可以放置的target")
      //两个父组件一样
      if (props.props.parentid == dragItem.props.parentid) {
        if (dragIndex == hoverIndex) {
          return;
        }
        if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
          return;
        }
        if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
          return;
        }
        //父组件相同，如果不是放在普通布局里面就是放置在布局卡片里面的，这个是布局卡片的既可以拖曳又可以放置的hover
        // 要放置的数据列表
        // console.log(props,dragItem,"父组件相同，如果不是放在普通布局里面就是放置在布局卡片里面的，这个是布局卡片的既可以拖曳又可以放置的hover")
        // 同一个布局
        if (hoverCoordinate[2] == dragCoordinate[2]) {
          let tempItem = toLayoutContent[dragIndex];
          toLayoutContent[dragIndex] = toLayoutContent[hoverIndex];
          toLayoutContent[hoverIndex] = tempItem;
          monitor.getItem().coordinate = ["layout", hoverIndex, colId];
        } else {
          let fromContent =
            toLayoutList.component[dragCoordinate[2]].subComponent;
          // console.log(fromContent,"父组件相同，如果不是放在普通布局里面就是放置在布局卡片里面的，")
          fromContent.some(function(item, i) {
            if (item.id == dragItem.props.id) {
              fromContent.splice(i, 1);
              return true;
            } else {
              return false;
            }
          });
          toLayoutContent.push(newprops);
          dragItem.areaIndex = props.areaIndex;
          dragItem.coordinate = ["layout", toLayoutContent.length, colId];
        }
      } else {
        // 普通到layout
        if (hoverCoordinate[0] == "layout" && dragCoordinate[0] == "mainArea") {
          // console.log(dragItem, props, "普通到layoutdragItem,props布局卡既可以拖曳又可以放置target")
          fromDataSource.splice(dragIndex, 1);
          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            toLayoutContent.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["layout", hoverIndex, colId];
            dragItem.areaIndex = props.areaIndex;
          } else {
            //在下面添加
            toLayoutContent.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["layout", hoverIndex + 1, colId];
            dragItem.areaIndex = props.areaIndex;
          }
        } else if (
          hoverCoordinate[0] == "layout" &&
          dragCoordinate[0] == "tab"
        ) {
          //tab到layout
          // console.log(dragItem, props, "tab到layout,dragItem,props布局卡既可以拖曳又可以放置target")
          // 来源选项卡列表
          let dragParent = fromDataSource.filter(
            item => dragItem.props.parentid === item.id
          )[0];
          let fromtabContent = dragParent.tabList.filter(
            res => res.id == dragItem.props.tabId
          )[0].content;
          fromtabContent.splice(dragIndex, 1);

          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            toLayoutContent.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["layout", hoverIndex, colId];
            dragItem.areaIndex = props.areaIndex;
          } else {
            //在下面添加
            toLayoutContent.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["layout", hoverIndex + 1, colId];
            dragItem.areaIndex = props.areaIndex;
          }
        } else if (
          hoverCoordinate[0] == "layout" &&
          dragCoordinate[0] == "layout"
        ) {
          //layout到layout
          // console.log(dragItem, props, "layout到layout,dragItem,props布局卡既可以拖曳又可以放置target")
          //   console.log(dragItem.props,fromDataSource,"dragItem.props布局卡片既可以拖曳又可以放置的target")
          let dragParent = fromDataSource.filter(
            item => dragItem.props.parentid === item.id
          )[0];
          // 预防布局卡片在附近
          if (dragParent) {
            return;
          }
          let fromtabContent =
            dragParent.component[dragCoordinate[2]].subComponent;
          fromtabContent.splice(dragIndex, 1);

          if (hoverClientY < hoverMiddleY) {
            // 在上面添加
            toLayoutContent.splice(hoverIndex, 0, newprops);
            dragItem.coordinate = ["layout", hoverIndex, colId];
            dragItem.areaIndex = props.areaIndex;
          } else {
            //在下面添加
            toLayoutContent.splice(hoverIndex + 1, 0, newprops);
            dragItem.coordinate = ["layout", hoverIndex + 1, colId];
            dragItem.areaIndex = props.areaIndex;
          }
        }
        monitor.getItem().props.parentid = props.props.parentid;
      }
    } else {
      if (
        !systemCard[dragItem.commpentName] &&
        !antdUI[dragItem.commpentName]
      ) {
        message.error(localeJson.card_not_exist);
        return;
      }
      // console.log(props, dragItem, "布局卡片从菜单中拉出来的")
      let uid = guid();
      monitor.getItem().id = uid;

      //新的属性
      let newprops = {
        // 用于渲染是什么组件
        componentName: dragItem.componentName,
        // key值用来自由布局
        key: uid,
        // 用来标志是在那个target里面的
        parentid: props.props.parentid,
        // 默认id
        id: uid,
        // 自由布局必须要的
        ["dataGrid"]: {
          i: uid.toString(),
          x: 0,
          y: 0,
          w: 3,
          h: 1,
          isDraggable: true,
          isResizable: true
        },
        isSingleton: dragItem.isSingleton,
        cardProps: dragItem.cardProps,
        config: dragItem.config
      };
      if (hoverClientY < hoverMiddleY) {
        // 在上面添加
        toLayoutContent.splice(hoverIndex, 0, newprops);
        dragItem.coordinate = ["layout", hoverIndex, colId];
        dragItem.areaIndex = props.areaIndex;
      } else {
        //在下面添加
        toLayoutContent.splice(hoverIndex + 1, 0, newprops);
        dragItem.coordinate = ["layout", hoverIndex + 1, colId];
        dragItem.areaIndex = props.areaIndex;
      }
      dragItem.areaIndex = props.areaIndex;
      monitor.getItem().props = newprops;
    }
    props.operationItem(propsDatasource, dragItem);
  },
  canDrop() {
    return false;
  },
  drop(props, monitor, component) {
    if (monitor.didDrop()) return;
    // 操作要拖拉的组件
    return {
      ...props,
      id: props.id,
      isOver: monitor.isOver(),
      diffOffset: monitor.getDifferenceFromInitialOffset()
    };
  }
};
