/*
 * @Description: 拖拉对外暴露组件
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 13:49:05
 */
import React, { Component } from "react";
import { DragSource, DropTarget } from "react-dnd";
import { ItemTypes } from "./item_types";
import { getSize } from "utils/util";
import {
  sourceSpec,
  targetSpec,
  dropTargetSpec,
  dropSourceSpec,
  tabDropTargetSpec,
  tabTargetSpec,
  layoutTargetSpec,
  layoutDropTargetSpec
} from "./specification";
import { dragCollect, dropCollect } from "./collectors";

// 用于菜单的拖拉源
class DragSourceComponent extends Component {
  componentDidMount() {
    const img = new Image();
    img.onload = () =>
      this.props.connectDragPreview && this.props.connectDragPreview(img);
    img.src = this.props.imgUrl;
  }

  render() {
    const { connectDragSource, children } = this.props;
    const opacity = 1;
    return (
      connectDragSource &&
      connectDragSource(<div style={{ opacity }}>{children}</div>)
    );
  }
}

// 用于布局的target
class DropTargetComponent extends Component {
  render() {
    const {
      connectDropTarget,
      style,
      children,
      page,
      isOverCurrent
    } = this.props;

    let height = getSize().windowH;
    let scrollHeight = 0;
    const { system } = page;
    // 如果是编辑状态
    if (page.editPage) {
      // 如果有banner
      if (system && system.banner) {
        scrollHeight = height - 175 - 120;
      } else {
        scrollHeight = height - 86 - 120;
      }
      scrollHeight = scrollHeight - 50;
    }

    let className = "";
    if (page.editPage) {
      className = className + " layoutContent";
    }
    if (isOverCurrent) {
      className = className + " drop_hover";
    }
    return (
      connectDropTarget &&
      connectDropTarget(
        <div
          className={className}
          style={{ minHeight: scrollHeight, ...style }}
        >
          {children}
        </div>
      )
    );
  }
}

// 普通的，用于拖拉并且hover之后，可以根据hover的位置放置组件，
class DragSourceTargetComponent extends Component {
  static defaultProps = {
    handleEdit: () => {}, // 编辑方法
    handleClose: () => {} // 删除
  };

  componentDidMount() {
    if (this.props.props && this.props.props.cardProps) {
      const { imgUrl } = this.props.props.cardProps;
      const img = new Image();
      img.onload = () =>
        this.props.connectDragPreview && this.props.connectDragPreview(img);
      img.src = imgUrl;
    }
  }

  render() {
    const {
      connectDragSource,
      connectDropTarget,
      children,
      isOverCurrent
    } = this.props;

    let classname = "";
    if (isOverCurrent) {
      classname = "boxHover";
    }
    let opacity = isOverCurrent ? 0 : 1;
    // console.log(opacity,"opacity")
    return (
      connectDropTarget &&
      connectDragSource &&
      connectDragSource(
        connectDropTarget(
          <div
            className={classname}
          >
            <div style={{ opacity }}> {children}</div>
          </div>
        )
      )
    );
  }
}

//tab标签的拖拉
class TabDragSourceComponent extends Component {
  static defaultProps = {
    handleEdit: () => {}, // 编辑方法
    handleClose: () => {} // 删除
  };

  componentDidMount() {
    if (this.props.props && this.props.props.cardProps) {
      const { imgUrl } = this.props.props.cardProps;
      const img = new Image();
      img.onload = () =>
        this.props.connectDragPreview && this.props.connectDragPreview(img);
      img.src = imgUrl;
    }
  }

  render() {
    const {
      connectDragSource,
      isDragging,
      children,
    } = this.props;
    let classname = "";
    if (isDragging) {
      classname = "boxHover";
    }
    const opacity = isDragging ? 0 : 1; //拖拽时为透明，不拖拽时完全不透明
    return (
      connectDragSource &&
      connectDragSource(
        <div
          className={classname}
          style={{ opacity }}
        >
          {children}
        </div>
      )
    );
  }
}

//tab的布局target
class TabDropTargetComponent extends Component {
  render() {
    const {
      connectDropTarget,
      style,
      children,
      isOverCurrent
    } = this.props;
    let className;
    if (isOverCurrent) {
      className = "drop_hover";
    }
    return (
      connectDropTarget &&
      connectDropTarget(
        <div className={className} style={{ ...style }}>
          {children}
        </div>
      )
    );
  }
}

// tab选项卡的，用于拖拉并且hover之后，可以根据hover的位置放置组件，hover是在target里面判断的
class DragTabSourceTargetComponent extends Component {
  static defaultProps = {
    handleEdit: () => {}, // 编辑方法
    handleClose: () => {} // 删除
  };

  componentDidMount() {
    if (this.props.props && this.props.props.cardProps) {
      const { imgUrl } = this.props.props.cardProps;
      const img = new Image();
      img.onload = () =>
        this.props.connectDragPreview && this.props.connectDragPreview(img);
      img.src = imgUrl;
    }
  }

  render() {
    const {
      connectDragSource,
      connectDropTarget,
      children,
      isOverCurrent
    } = this.props;

    let classname = "";
    if (isOverCurrent) {
      classname = "boxHover";
    }
    let opacity = isOverCurrent ? 0 : 1;

    return (
      connectDropTarget &&
      connectDragSource &&
      connectDragSource(
        connectDropTarget(
          <div
            className={classname}
          >
            <div style={{ opacity }}> {children}</div>
          </div>
        )
      )
    );
  }
}

//layout标签的拖拉
class LayoutDragSourceComponent extends Component {
  static defaultProps = {
    handleEdit: () => {}, // 编辑方法
    handleClose: () => {} // 删除
  };

  componentDidMount() {
    if (this.props.props && this.props.props.cardProps) {
      const { imgUrl } = this.props.props.cardProps;
      const img = new Image();
      img.onload = () =>
        this.props.connectDragPreview && this.props.connectDragPreview(img);
      img.src = imgUrl;
    }
  }

  render() {
    const {
      connectDragSource,
      isDragging,
      children,
    } = this.props;

    let classname = "";
    if (isDragging) {
      classname = "boxHover";
    }
    const opacity = isDragging ? 0 : 1; //拖拽时为透明，不拖拽时完全不透明

    return (
      connectDragSource &&
      connectDragSource(
        <div
          className={classname}
          style={{ opacity }}
        >
          {children}
        </div>
      )
    );
  }
}

//layout的布局target
class LayoutDropTargetComponent extends Component {
  render() {
    const {
      connectDropTarget,
      style,
      children,
      isOverCurrent,
      editPage
    } = this.props;
    let className;
    if (isOverCurrent) {
      className = " drop_hover";
    }
    if (editPage) {
      className = className + " layoutContent";
    }
    return (
      connectDropTarget &&
      connectDropTarget(
        <div className={className} style={{ ...style }}>
          {children}
        </div>
      )
    );
  }
}

// layout布局的，用于拖拉并且hover之后，可以根据hover的位置放置组件，hover是在target里面判断的
class DragLayoutSourceTargetComponent extends Component {
  static defaultProps = {
    handleEdit: () => {}, // 编辑方法
    handleClose: () => {} // 删除
  };

  componentDidMount() {
    if (this.props.props && this.props.props.cardProps) {
      const { imgUrl } = this.props.props.cardProps;
      const img = new Image();
      img.onload = () =>
        this.props.connectDragPreview && this.props.connectDragPreview(img);
      img.src = imgUrl;
    }
  }

  render() {
    const {
      connectDragSource,
      connectDropTarget,
      children,
      props,
      colId,
      isOverCurrent
    } = this.props;
    let classname = "";
    if (isOverCurrent) {
      classname = "boxHover";
    }
    let opacity = isOverCurrent ? 0 : 1;
    props.colId = colId;

    return (
      connectDropTarget &&
      connectDragSource &&
      connectDragSource(
        connectDropTarget(
          <div
            className={classname}
          >
            <div style={{ opacity }}> {children}</div>
          </div>
        )
      )
    );
  }
}

// 菜单拖曳
const DragSourceWrapper = DragSource(
  ItemTypes.DragMenu,
  sourceSpec,
  dragCollect
)(DragSourceComponent);
// 普通布局放置组件
const DropTargetWrapper = DropTarget(ItemTypes.Drop, targetSpec, dropCollect)(
  DropTargetComponent
);
// 普通的既可以拖曳又可以放置，并不是真正的放置在里面，只是为了hover
DragSourceTargetComponent = DropTarget(
  ItemTypes.Drop,
  dropTargetSpec,
  dropCollect
)(DragSourceTargetComponent);
const DragSourceTargetWrapper = DragSource(
  ItemTypes.Element,
  dropSourceSpec,
  dragCollect
)(DragSourceTargetComponent);

// tab的外壳可以拖曳
const TabDragSourceWrapper = DragSource(
  ItemTypes.DragMenu,
  dropSourceSpec,
  dragCollect
)(TabDragSourceComponent);
// tab的外壳的里面可以放置
const DragTabTargetWrapper = DropTarget(
  ItemTypes.Drop,
  tabTargetSpec,
  dropCollect
)(TabDropTargetComponent);
// tab里面的组件既可以拖曳又可以放置，并不是真正的放置在里面，只是为了hover
DragTabSourceTargetComponent = DropTarget(
  ItemTypes.Drop,
  tabDropTargetSpec,
  dropCollect
)(DragTabSourceTargetComponent);
const DragTabSourceTargetWrapper = DragSource(
  ItemTypes.Element,
  dropSourceSpec,
  dragCollect
)(DragTabSourceTargetComponent);

// layout的外壳可以拖曳
const LayoutDragSourceWrapper = DragSource(
  ItemTypes.DragMenu,
  dropSourceSpec,
  dragCollect
)(LayoutDragSourceComponent);
// layout的外壳的里面可以放置
const DragLayoutTargetWrapper = DropTarget(
  ItemTypes.Drop,
  layoutTargetSpec,
  dropCollect
)(LayoutDropTargetComponent);
// layout里面的组件既可以拖曳又可以放置，并不是真正的放置在里面，只是为了hover
DragLayoutSourceTargetComponent = DropTarget(
  ItemTypes.Drop,
  layoutDropTargetSpec,
  dropCollect
)(DragLayoutSourceTargetComponent);
const DragLayoutSourceTargetWrapper = DragSource(
  ItemTypes.Element,
  dropSourceSpec,
  dragCollect
)(DragLayoutSourceTargetComponent);

export {
  DragSourceWrapper,
  DropTargetWrapper,
  DragSourceTargetWrapper,
  DragTabTargetWrapper,
  DragTabSourceTargetWrapper,
  TabDragSourceWrapper,
  LayoutDragSourceWrapper,
  DragLayoutTargetWrapper,
  DragLayoutSourceTargetWrapper
};
