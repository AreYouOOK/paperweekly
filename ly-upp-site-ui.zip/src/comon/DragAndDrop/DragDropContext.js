/*
 * @Description: 拖曳组件装饰器
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 13:42:31
 */
// import HTML5Backend from "react-dnd-html5-backend";
// import { DndProvider } from "react-dnd";
// import withScrolling from "react-dnd-scrollzone";

// const ScrollingComponent = withScrolling("div");

// export default function DragDropContext(Target) {
//   class Wrap extends React.Component {
//     render() {
//         console.log("&&&&&&&&&&&&&")
//       return (
//         <DndProvider backend={HTML5Backend}>
//           <ScrollingComponent >
//             <Target {...this.props} />
//           </ScrollingComponent>
//         </DndProvider>
//       );
//     }
//   }
//   return Wrap;
// }
import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';

export default DragDropContext(HTML5Backend);
