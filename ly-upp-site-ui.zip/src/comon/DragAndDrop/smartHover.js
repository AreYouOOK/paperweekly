/*
 * @Description: 拖拉组件hover效果
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 13:43:21
 */
import React, { Component } from "react";
import { Icon } from "antd";
import { connect } from "react-redux";
import classnames from "classnames";

@connect(state => {
  return { ...state };
})
export default class SmartHover extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    let { edit, close, style, className, editPage, children } = this.props;
    return (
      <div
        className={classnames("SmartHover", { move: edit && editPage })}
        style={{ ...style }}
      >
        <div className="floatBtn">
          <span onClick={edit || (() => {})}>
            <Icon
              type="edit"
              style={{
                color: "white",
                cursor: "pointer",
                margin: "0 8px",
                display: edit && editPage ? "" : "none"
              }}
            />
          </span>
          <span onClick={close || (() => {})}>
            <Icon
              type="close"
              style={{
                color: "white",
                cursor: "pointer",
                margin: "0 8px",
                display: close && editPage ? "" : "none"
              }}
            />
          </span>
        </div>
        <div className={className}>{children}</div>
      </div>
    );
  }
}
