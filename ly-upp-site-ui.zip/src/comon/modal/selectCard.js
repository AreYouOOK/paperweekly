/*
 * @Description: 选项卡弹窗配置
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-03 10:13:58
 */
import React, { Component } from 'react'
import {
  Row,
  Col,
  Icon,
  Input,
  Radio,
  message,
  Form,
  Tooltip,
  Tabs
} from 'antd'
import _ from 'lodash'
import { findDOMNode } from 'react-dom'
import { DropTarget, DragSource } from 'react-dnd'
import { reqGetCardProps } from 'utils/api'
import { Scrollbars } from 'components'
import update from 'immutability-helper'
import { guid } from 'utils/util'
import Base from './base'
import Info from './info'

const RadioGroup = Radio.Group
const FormItem = Form.Item
const { TabPane } = Tabs

// 放置设置
const dropSetting = {
  type: ['TabElement'],
  spec: {
    canDrop(props, monitor) {},
    hover(props, monitor, component) {
      const dragIndex = monitor.getItem().index
      const hoverIndex = props.index
      const defaultActiveKey = props.defaultActiveKey
      if (dragIndex === hoverIndex) {
        return
      }
      const hoverBoundingRect = findDOMNode(component).getBoundingClientRect()
      const hoverMiddleY =
        (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2
      const clientOffset = monitor.getClientOffset()
      const hoverClientY = clientOffset.y - hoverBoundingRect.top
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return
      }
      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return
      }
      if (dragIndex == defaultActiveKey) {
        props.setDefaultActiveKey(hoverIndex)
      } else if (hoverIndex == defaultActiveKey) {
        props.setDefaultActiveKey(dragIndex)
      }
      props.moveTabElement(dragIndex, hoverIndex)
      monitor.getItem().index = hoverIndex
    },
    drop(props, monitor, component) {
      return {
        ...props,
        dropType: 'TabElement'
      }
    }
  },
  collect(connect, monitor) {
    return {
      connectDropTarget: connect.dropTarget(),
      isOver: monitor.isOver(),
      isOverCurrent: monitor.isOver({ shallow: true }),
      canDrop: monitor.canDrop(),
      itemType: monitor.getItemType()
    }
  }
}

// 拖拉设置
const dragSetting = {
  type: 'TabElement',
  spec: {
    beginDrag(props) {
      return {
        ...props,
        dragType: 'TabElement'
      }
    },
    endDrag(props, monitor) {
      const dropResult = monitor.getDropResult()
    },
    //重写isDragging方法，用于判断当前拖拽的元素
    isDragging(props, monitor) {
      return props.id == monitor.getItem().id
    }
  },
  collect(connect, monitor) {
    return {
      connectDragSource: connect.dragSource(),
      isDragging: monitor.isDragging(),
      connectDragPreview: connect.dragPreview()
    }
  }
}

class TabElement extends Component {
  constructor(props) {
    super(props)
  }

  render() {
    let {
      connectDragPreview,
      connectDragSource,
      connectDropTarget,
      isDragging
    } = this.props
    let opacity = isDragging ? 0.2 : 1 //拖拽时为透明，不拖拽时完全不透明
    return connectDragPreview(
      connectDropTarget(
        <div style={{ opacity }}>
          <Row style={{ height: '40px' }}>
            {connectDragSource(
              <div>
                <Col
                  span={2}
                  style={{
                    lineHeight: '32px',
                    fontSize: '28px',
                    textAlign: 'left'
                  }}
                >
                  <Icon type="bars" />
                </Col>
              </div>
            )}
            {this.props.children}
          </Row>
        </div>
      )
    )
  }
}
TabElement = DropTarget(
  dropSetting.type,
  dropSetting.spec,
  dropSetting.collect
)(TabElement)
TabElement = DragSource(
  dragSetting.type,
  dragSetting.spec,
  dragSetting.collect
)(TabElement)

@Form.create()
class TabsSetModal extends Component {
  constructor(props) {
    super(props)
    this.state = {
      reqCardProps: {},
      tabList: [
        {
          title: '选项卡1',
          locale: {
            en_US: {
              name: 'tab1'
            },
            zh_CN: {
              name: '选项卡1'
            }
          },
          content: [],
          id: guid()
        },
        {
          title: '选项卡2',
          id: guid(),
          locale: {
            en_US: {
              name: 'tab2'
            },
            zh_CN: {
              name: '选项卡2'
            }
          },
          content: []
        },
        {
          title: '选项卡3',
          id: guid(),
          content: [],
          locale: {
            en_US: {
              name: 'tab3'
            },
            zh_CN: {
              name: '选项卡3'
            }
          }
        }
      ],
      defaultActiveKey: 0
    }
  }

  componentWillMount() {
    this.setState(
      {
        language: this.props.login ? this.props.login.locale : 'zh_CN',
        tabList: this.props.modalProps.tabList
          ? _.cloneDeep(this.props.modalProps.tabList)
          : [],
        defaultActiveKey: this.props.modalProps.defaultActiveKey
      },
      () => {
        this.props.form.setFieldsValue({
          tabList: this.state.tabList,
          defaultActiveKey: this.state.defaultActiveKey
        })
      }
    )
    // 因为管理后台可以更改卡片信息，在这个拿到最新的卡片信息
    const cardId = this.props.modalProps.cardProps.cardId
    reqGetCardProps({ cardId }).then(res => {
      const { meta, data } = res.data
      if (!meta.success) return console.log('request card info fail')
      data.locale = data.cardName
      data.typeName = data.cardCategory
      this.setState({ reqCardProps: data })
    })
  }

  componentWillReceiveProps(nextProps) {
    if (
      !_.isEqual(this.props.modalProps.tabList, nextProps.modalProps.tabList)
    ) {
      this.setState({
        tabList: _.cloneDeep(nextProps.modalProps.tabList)
      })
      this.props.form.setFieldsValue({ tabList: nextProps.modalProps.tabList })
    }
    if (
      !_.isEqual(
        this.props.modalProps.defaultActiveKey,
        nextProps.modalProps.defaultActiveKey
      )
    ) {
      this.setState({
        defaultActiveKey: nextProps.modalProps.defaultActiveKey
      })
      this.props.form.setFieldsValue({
        defaultActiveKey: nextProps.modalProps.defaultActiveKey
      })
    }
  }

  //  改变默认的tab
  changeDefaultTap = e => {
    this.setState({
      defaultActiveKey: e.target.value
    })
    this.props.form.setFieldsValue({ defaultActiveKey: e.target.value })
  }

  // 设置默认的tab
  setDefaultActiveKey = val => {
    this.setState({
      defaultActiveKey: val
    })
    this.props.form.setFieldsValue({ defaultActiveKey: val })
  }

  // 添加tab
  addTab = () => {
    const { localeJson } = this.props.login
    let { tabList } = this.state
    if (tabList.length < 24) {
      tabList.push({
        title: '选项卡' + (tabList.length + 1),
        locale: {
          en_US: {
            name: 'tab' + (tabList.length + 1)
          },
          zh_CN: {
            name: '选项卡' + (tabList.length + 1)
          }
        },
        id: guid(),
        content: []
      })
      this.setState({ tabList })
      this.props.form.setFieldsValue({ tabList: tabList })
    } else {
      message.warning(localeJson.cardUp)
    }
  }

  // 移动tab
  moveTabElement = (dragIndex, hoverIndex) => {
    const { tabList } = this.state
    const dragTabElement = tabList[dragIndex]

    this.setState(
      update(this.state, {
        tabList: {
          $splice: [[dragIndex, 1], [hoverIndex, 0, dragTabElement]]
        }
      }),
      () => {
        this.props.form.setFieldsValue({ tabList: this.state.tabList })
      }
    )
  }

  // 删除tab
  delTab = index => {
    let { tabList, defaultActiveKey } = this.state
    tabList.splice(index, 1)
    let key = defaultActiveKey
    if (Number(defaultActiveKey) > tabList.length - 1) {
      key = 0
    }
    this.setState({ tabList, defaultActiveKey: key })
    this.props.form.setFieldsValue({ tabList: tabList, defaultActiveKey: key })
  }

  // 设置tab名字
  setTabName = (e, index) => {
    const { language } = this.state
    const { value } = e.target
    let { tabList } = this.state
    tabList[index].title = value
    // 判断原本tab有没有国际化设置
    if (!tabList[index].locale) {
      tabList[index].locale = {}
    }
    if (!tabList[index].locale[language]) {
      tabList[index].locale[language] = {}
    }
    tabList[index].locale[language].name = value
    this.setState({ tabList })
    this.props.form.setFieldsValue({ tabList: tabList })
  }

  // 保存设置的值
  setValue = () => {
    let props = {
      ...this.props.modalProps,
      tabList: this.state.tabList,
      defaultActiveKey: this.state.defaultActiveKey
    }
    return props
  }

  // 语言切换
  handleLanguage = type => {
    this.setState({
      language: type
    })
  }

  renderSelect = () => {
    const { language } = this.state
    let { tabList, defaultActiveKey } = this.state
    let jsxDOM = []
    let _this = this
    tabList.forEach((item, i, arr) => {
      let title =
        item.locale && item.locale[language]
          ? item.locale[language].name
          : item.title
      jsxDOM.push(
        <TabElement
          index={i}
          key={i}
          moveTabElement={_this.moveTabElement}
          id={item.id}
          defaultActiveKey={defaultActiveKey}
          setDefaultActiveKey={_this.setDefaultActiveKey}
        >
          <Col span={2} style={{ lineHeight: '32px', textAlign: 'left' }}>
            <Radio value={i}></Radio>
          </Col>
          <Col span={8}>
            <Input
              type="text"
              placeholder=""
              maxLength={15}
              value={title}
              onChange={e => {
                _this.setTabName(e, i)
              }}
            />
          </Col>
          <Col
            span={2}
            style={{
              lineHeight: '32px',
              fontSize: '24px',
              textAlign: 'center',
              display: arr.length > 1 ? 'initial' : 'none'
            }}
          >
            <Icon
              className="dynamic-delete-button"
              type="minus-circle-o"
              onClick={() => _this.delTab(i)}
            />
          </Col>
        </TabElement>
      )
    })
    return jsxDOM
  }

  render() {
    const { localeJson } = this.props.login
    let { defaultActiveKey, tabList, language, reqCardProps } = this.state
    const { getFieldDecorator } = this.props.form
    let languageList = window.locale ? window.locale.list : []
    const { modalProps } = this.props
    let base = (modalProps && modalProps.config) || {}
    return (
      <Tabs
        tabPosition="left"
        defaultActiveKey="1"
        style={{ height: 600 }}
        className="cardmodal"
      >
        <TabPane tab={localeJson.cardBaseSetting} key="1">
          <Scrollbars style={{ height: 624 }} autoHide>
            <Base {...this.props} config={base} />
          </Scrollbars>
        </TabPane>
        <TabPane tab={localeJson.cardExtraSetting} key="2">
          <Scrollbars style={{ height: 624 }} autoHide>
            <Row>
              <Col offset={4}>
                <div>{localeJson.cardSelectLangauge}</div>
                <div style={{ marginLeft: '4px' }}>
                  {languageList.map(res => {
                    return (
                      <Tooltip
                        key={res.type}
                        placement="topLeft"
                        title={localeJson[res.tip]}
                      >
                        <div
                          className={'imgdiv'}
                          onClick={() => this.handleLanguage(res.type)}
                        >
                          <img src={res.img} />
                          {language == res.type ? (
                            <div className={'circle'}></div>
                          ) : null}
                        </div>
                      </Tooltip>
                    )
                  })}
                </div>

                <div style={{ margin: '10px 0px' }}>
                  <Row>
                    <Col
                      span={2}
                      style={{ lineHeight: '32px', textAlign: 'left' }}
                    >
                      {localeJson.cardSort}
                    </Col>
                    <Col
                      span={2}
                      style={{ lineHeight: '32px', textAlign: 'left' }}
                    >
                      {localeJson.cardDefault}
                    </Col>
                    <Col
                      span={8}
                      style={{ lineHeight: '32px', textAlign: 'left' }}
                    >
                      {localeJson.cardTabName}
                    </Col>
                  </Row>
                  <RadioGroup
                    style={{ display: 'initial' }}
                    value={defaultActiveKey}
                    onChange={this.changeDefaultTap}
                  >
                    {this.renderSelect()}
                  </RadioGroup>
                </div>
                <Row>{localeJson.cardUp}</Row>
                <Row>
                  <Col
                    span={24}
                    onClick={this.addTab}
                    style={{
                      lineHeight: '32px',
                      textAlign: 'left',
                      color: '#609bff',
                      cursor: 'pointer'
                    }}
                  >
                    + {localeJson.cardAddTab}
                  </Col>
                </Row>
                <FormItem
                  style={{ display: 'none' }}
                  label={localeJson.cardDefaultTab}
                >
                  {getFieldDecorator('defaultActiveKey', {
                    initialValue: defaultActiveKey
                  })(<span></span>)}
                </FormItem>
                <FormItem
                  style={{ display: 'none' }}
                  label={localeJson.cardSelectTab}
                >
                  {getFieldDecorator('tabList', { initialValue: tabList })(
                    <span></span>
                  )}
                </FormItem>
              </Col>
            </Row>
          </Scrollbars>
        </TabPane>
        <TabPane tab={localeJson.cardBaseInfo} key="3">
          <Scrollbars style={{ height: 624 }} autoHide>
            <Info {...this.props.modalProps.cardProps} {...reqCardProps} />
          </Scrollbars>
        </TabPane>
      </Tabs>
    )
  }
}

export default TabsSetModal
