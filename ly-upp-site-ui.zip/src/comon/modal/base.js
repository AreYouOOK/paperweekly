/*
 * @Description: 卡片弹窗基本配置
 * @Author: xuqiuting
 * @Date: 2019-08-21 09:37:54
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-23 17:45:18
 */
import React from 'react'
import { FormData } from 'components'
import { connect } from 'react-redux'
import { cardFormList } from '../data'
import _ from 'lodash'

@connect(state => {
  return { ...state }
})
export default class CommonCardBase extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    // console.log('卡片基础设置这里拿到的props', this.props)
    const { localeJson, locale } = this.props.login
    const { config, modalProps } = this.props
    const { componentName } = modalProps
    let dataConfig = _.cloneDeep(config) || {}
    // 默认标题处理, 默认为卡片的名称
    const cardNameLocale = modalProps.cardProps.locale || {}
    const systemTitleLocale = JSON.parse(
      JSON.stringify(cardNameLocale).replace(/cardName/g, 'name')
    )
    if (!dataConfig.hasOwnProperty('systemTitleShow')) {
      if (
        componentName === 'LayoutCard' ||
        componentName === 'SelectCard' ||
        componentName === 'SelectComponent'
      ) {
        dataConfig.systemTitleShow = false
      } else {
        dataConfig.systemTitleShow = true
      }
      dataConfig.systemTitleLocale = systemTitleLocale
    }
    // 国际语言列表
    let languageList = window.locale ? window.locale.list : []
    return (
      <FormData
        form={this.props.form}
        languageList={languageList}
        localeJson={localeJson}
        language={locale}
        config={dataConfig}
        dataSouce={cardFormList}
      />
    )
  }
}
