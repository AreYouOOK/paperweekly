/*
 * @Description: 卡片帮助弹窗
 * @Author: xuqiuting
 * @Date: 2019-09-04 14:51:48
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 14:00:45
 */
import React from "react";
import { connect } from "react-redux";
import { Scrollbars } from "components";
import { getCardHelp } from "utils/api";
import { message } from "antd";

@connect(state => {
  return { login: state.login };
})
export default class HelpModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSouce: null
    };
  }

  componentDidMount() {
    const { cardProps } = this.props;
    // 如果有卡片id则请求卡片信息
    if (cardProps && cardProps.cardId) {
      this.getData(cardProps.cardId);
    }
  }

  // 获取数据
  getData = id => {
    getCardHelp(id).then(res => {
      const { data, meta } = res.data;
      if (meta.success) {
        this.setState({
          dataSouce: data
        });
      } else {
        message.error(meta.message);
      }
    });
  };
  
  render() {
    const { localeJson } = this.props.login;
    const { dataSouce } = this.state;
    return (
      <Scrollbars style={{ height: 624 }} autoHide>
        {dataSouce ? (
          <div dangerouslySetInnerHTML={{ __html: dataSouce }} />
        ) : (
          <div className="nodata">
            <img src={require("assets/images/nodata.png")} />
            <div>{localeJson.nodata}</div>
          </div>
        )}
      </Scrollbars>
    );
  }
}
