/*
 * @Description: 布局卡片基本信息
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-04 17:55:42
 */
import React from 'react'
import { Row, Col, Form, Tabs } from 'antd'
import _ from 'lodash'
import { connect } from 'react-redux'
import classnames from 'classnames'
import { Scrollbars } from 'components'
import { reqGetCardProps } from 'utils/api'
import Base from './base'
import Info from './info'

const FormItem = Form.Item
const { TabPane } = Tabs
@connect(state => {
  return { ...state }
})
export default class layoutCardModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      layoutList: [
        {
          name: '一列布局',
          type: 'horizontal',
          img: require('assets/images/layout/horizontal.jpg')
        },
        {
          name: '两列排列(3_7)',
          type: 'two_col_3_7',
          img: require('assets/images/layout/two_col_3_7.jpg')
        },
        {
          name: '两列排列(5_5)',
          type: 'two_col_5_5',
          img: require('assets/images/layout/two_col_5_5.jpg')
        },
        {
          name: '两列排列(7_3)',
          type: 'two_col_7_3',
          img: require('assets/images/layout/two_col_7_3.jpg')
        },
        {
          name: '三列排列(3_3_3)',
          type: 'three_col_3_3_3',
          img: require('assets/images/layout/three_col_3_3_3.jpg')
        },
        {
          name: '三列排列(3_4_3)',
          type: 'three_col_3_4_3',
          img: require('assets/images/layout/three_col_3_4_3.jpg')
        },
        {
          name: '三列排列(2_5_2)',
          type: 'three_col_2_5_2',
          img: require('assets/images/layout/three_col_2_5_2.jpg')
        }
      ],
      layout: 'horizontal',
      reqCardProps: {}
    }
  }

  componentWillMount() {
    this.setState(
      {
        layout: this.props.modalProps.layout
          ? this.props.modalProps.layout
          : 'horizontal'
      },
      () => {
        this.props.form.setFieldsValue({ layout: this.state.layout })
      }
    )
    // 因为管理后台可以更改卡片信息，在这个拿到最新的卡片信息
    const cardId = this.props.modalProps.cardProps.cardId
    reqGetCardProps({ cardId }).then(res => {
      const { meta, data } = res.data
      if (!meta.success) return console.log('request card info fail')
      data.locale = data.cardName
      data.typeName = data.cardCategory
      this.setState({ reqCardProps: data })
    })
  }

  componentWillReceiveProps(nextProps) {
    if (
      nextProps.modalProps.layout &&
      nextProps.modalProps.layout != this.state.layout
    ) {
      this.setState({
        layout: nextProps.modalProps.layout
      })
      this.props.form.setFieldsValue({ layout: nextProps.modalProps.layout })
    }
  }

  // 设置布局
  handleLayout = item => {
    this.setState({
      layout: item.type,
      layoutName: item.name
    })
    this.props.form.setFieldsValue({ layout: item.type })
  }

  render() {
    const { localeJson } = this.props.login
    const { getFieldDecorator } = this.props.form
    const { layoutList, reqCardProps } = this.state
    const { modalProps } = this.props
    // 卡片配置信息
    let base = (modalProps && modalProps.config) || {}

    return (
      <Tabs
        tabPosition="left"
        defaultActiveKey="1"
        style={{ height: 600 }}
        className="cardmodal"
      >
        <TabPane tab={localeJson.cardBaseSetting} key="1">
          <Scrollbars style={{ height: 624 }} autoHide>
            <Base {...this.props} config={base} />
          </Scrollbars>
        </TabPane>
        <TabPane tab={localeJson.cardExtraSetting} key="2">
          <Scrollbars style={{ height: 624 }} autoHide>
            <FormItem label={localeJson.cardLayout} style={{ display: 'none' }}>
              {getFieldDecorator('layout', { initialValue: this.state.layout })(
                <span></span>
              )}
            </FormItem>
            <Row>
              <Col span={4} style={{ textAlign: 'center' }}>
                {localeJson.cardLayout}：
              </Col>
              <Col span={20}>
                <ul className={`containerUl gridUl`}>
                  {layoutList.map(res => {
                    return (
                      <li onClick={() => this.handleLayout(res)} key={res.type}>
                        <img
                          className={classnames({
                            active: res.type == this.state.layout
                          })}
                          src={res.img}
                        />
                        <div> {localeJson[res.type]}</div>
                      </li>
                    )
                  })}
                </ul>
              </Col>
            </Row>
          </Scrollbars>
        </TabPane>

        <TabPane tab={localeJson.cardBaseInfo} key="3">
          <Scrollbars style={{ height: 624 }} autoHide>
            <Info {...this.props.modalProps.cardProps} {...reqCardProps} />
          </Scrollbars>
        </TabPane>
      </Tabs>
    )
  }
}
