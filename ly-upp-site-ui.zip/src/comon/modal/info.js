/*
 * @Description: 编辑卡片弹窗的卡片信息tabpane
 * @Author: chenzezhen
 * @Date: 2019-11-11 13:55:53
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-23 18:16:03
 */
import React from 'react'
import { Row, Col } from 'antd'
import { connect } from 'react-redux'

@connect(state => {
  return { ...state }
})
export default class CardInfo extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }
  render() {
    console.log(this.props)
    const { cardId, typeName, login, cardType, locale } = this.props
    const { localeJson } = login
    const lang = login.locale
    const cardTypeName = window.cardType.filter(v => v.id === cardType)[0]
    return (
      <div className="cardInfo">
        {/* 卡片id */}
        <Row className="infoItem">
          <Col span={5} className="label">
            {localeJson.cardInfoId}：
          </Col>
          <Col span={15} className="content">
            {cardId}
          </Col>
        </Row>
        {/* 卡片名称 */}
        <Row className="infoItem">
          <Col span={5} className="label">
            {localeJson.cardInfoName}：
          </Col>
          <Col span={15} className="content">
            {(locale[lang] && locale[lang].cardName) ||
              (locale.zh_CN && locale.zh_CN.cardName)}
          </Col>
        </Row>
        {/* 卡片类别 */}
        <Row className="infoItem">
          <Col span={5} className="label">
            {localeJson.cardInfoCategory}：
          </Col>
          <Col span={15} className="content">
            {(cardTypeName && cardTypeName.locale[lang]) ||
              (cardTypeName && cardTypeName.locale.zh_CN)}
          </Col>
        </Row>
        {/* 卡片类型 */}
        <Row className="infoItem">
          <Col span={5} className="label">
            {localeJson.cardInfoType}：
          </Col>
          <Col span={15} className="content">
            {(typeName && typeName[lang] && typeName[lang].typeName) ||
              (typeName && typeName.zh_CN && typeName.zh_CN.typeName)}
          </Col>
        </Row>
      </div>
    )
  }
}
