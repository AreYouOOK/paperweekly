/*
 * @Description: 卡片公共弹窗信息
 * @Author: xuqiuting
 * @Date: 2019-07-04 16:44:06
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-03 09:50:17
 */
import React, { Fragment } from 'react'
import { Tabs, Divider } from 'antd'
import Card from 'assets/js/lib'
import BuiltInAppTypeShowConfig from './../../template/builtInAppTypeShow/config'
import systemCard from 'comon/template/index'
import { connect } from 'react-redux'
import { Scrollbars } from 'components'
import { getLanguageTitle } from 'utils/util'
import { reqGetCardProps } from 'utils/api'
import Base from '../base'
import Info from '../info'
import _ from 'lodash'

const { TabPane } = Tabs
Card['BuiltInAppTypeShowConfig'] = BuiltInAppTypeShowConfig

@connect(state => {
  return { ...state }
})
export default class CommonCard extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      base: {},
      card: {},
      reqCardProps: {}
    }
  }

  componentDidMount() {
    // console.log('卡片弹窗拿到的prop', this.props)
    let config = {}
    if (this.props.componentName == 'LayoutCard') {
      let id = this.props.modalProps.id // 子卡片的id
      let subComponent = this.props.component[~~this.props.modalProps.colId]
        .subComponent // 子卡片集合
      let subIndex = subComponent.findIndex(v => v.id === id)
      // console.log(subIndex)
      // config = subComponent[0].config
      config = subComponent[subIndex].config
      // console.log(config)
    } else {
      config = this.props.modalProps.config
    }
    const { cardProps } = this.props.modalProps
    const defalutCardConfig = cardProps.config
    // base为基础设置（标题字体大小）
    // card为卡片设置（布局卡、选项卡、服务类型展示卡的配置）
    if (config) {
      this.setState({
        base: config.base,
        // card: config.card || config // 未设置卡片特殊配置时，卡片默认配置直接为config
        card: Object.assign({}, defalutCardConfig, config.card || config) // 未设置卡片特殊配置时，卡片默认配置直接为config
      })
    }
    // 因为管理后台可以更改卡片信息，在这个拿到最新的卡片信息
    const cardId = this.props.modalProps.cardProps.cardId
    reqGetCardProps({ cardId }).then(res => {
      const { meta, data } = res.data
      if (!meta.success) return console.log('request card info fail')
      data.locale = data.cardName
      data.typeName = data.cardCategory
      this.setState({ reqCardProps: data })
    })
  }

  render() {
    const { base, card, reqCardProps } = this.state
    const { modalProps } = this.props
    const { localeJson, locale } = this.props.login
    // 卡片基本信息
    let baseConfig = _.cloneDeep(base)
    // 卡片专属信息
    let cardConfig = _.cloneDeep(card)
    let Allcomponet = []
    // 卡片的弹窗，是卡片名称加上Config，必须这样命名才可以展示出来
    let componentName = modalProps.componentName + 'Config'
    let Component = systemCard[componentName] || Card[componentName]
    if (Component) {
      let obj = {
        cardName: Card[componentName],
        title: null,
        locale: {}
      }
      Allcomponet.push(obj)
    }
    // 选项卡，卡片内容后端已经配置，需要改变卡片内容的样式
    if (
      !Component &&
      modalProps.componentName == 'SelectComponent' &&
      modalProps.cardProps
    ) {
      // 选项卡
      let tabList = modalProps.cardProps.tabList
      tabList.map(item => {
        let config = item.componentName + 'Config'
        let tabCard = Card[config]
        if (tabCard) {
          let obj = {
            cardName: tabCard,
            title: item.title,
            locale: item.locale ? item.locale : {}
          }
          Allcomponet.push(obj)
        }
      })
    }

    return (
      <Tabs
        tabPosition="left"
        defaultActiveKey="1"
        style={{ height: 600 }}
        className="cardmodal"
      >
        <TabPane tab={localeJson.cardBaseSetting} key="1">
          <Scrollbars style={{ height: 624 }} autoHide>
            <Base {...this.props} config={baseConfig} />
          </Scrollbars>
        </TabPane>
        {Allcomponet.length > 0 ? (
          <TabPane tab={localeJson.cardExtraSetting} key="2">
            <Scrollbars style={{ height: 624 }} autoHide>
              {Allcomponet.map((item, index) => {
                let TabCard = item.cardName
                // 要展示的国际化标题
                let title = getLanguageTitle(
                  this.props,
                  item.locale,
                  'name',
                  item.title
                )
                return (
                  <Fragment key={index}>
                    {Allcomponet.length > 1 ? (
                      <span className="fontWeight">{title}：</span>
                    ) : null}
                    <TabCard
                      {...this.props}
                      modalProps={cardConfig}
                      config
                      cardId={
                        modalProps.cardProps && modalProps.cardProps.cardId
                      } // 为了能在应用展示配置弹窗拿到id请求
                      currentLanguage={locale}
                    />
                    {Allcomponet.length > 1 &&
                      index != Allcomponet.length - 1 && <Divider />}
                  </Fragment>
                )
              })}
            </Scrollbars>
          </TabPane>
        ) : null}

        <TabPane tab={localeJson.cardBaseInfo} key="3">
          <Scrollbars style={{ height: 624 }} autoHide>
            <Info {...this.props.modalProps.cardProps} {...reqCardProps} />
          </Scrollbars>
        </TabPane>
      </Tabs>
    )
  }
}
