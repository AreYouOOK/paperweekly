/*
 * @Description: 选项卡固定组件的卡片
 * @Author: xuqiuting
 * @Date: 2019-07-22 16:56:56
 * @LastEditors  : huangchuangbin
 * @LastEditTime : 2020-01-16 19:16:19
 * 
 */
import React, { Fragment } from 'react'
import { connect } from 'react-redux'
import { Tabs, Form } from 'antd'
import _ from 'lodash'
import CardWraper from 'comon/template/cardWraper'
import { getLanguageTitle } from 'utils/util'
import { getSelectCard } from 'utils/api'
import styled from 'styled-components'
import { generateEdit, getThemeStyle } from 'utils/themeData'
import classnames from 'classnames'
import { ErrorBoundary } from 'components'
const TabPane = Tabs.TabPane

@connect(state => {
  return { ...state }
})
@Form.create()
@ErrorBoundary
export default class SelectComponent extends React.Component {
  // 组件要传的参数
  static defaultProps = {
    defaultActiveKey: 0,
    tablist: []
  }

  constructor(props) {
    super(props)
    this.state = {
      tabList: [],
      defaultActiveKey: 0
    }
  }

  componentDidMount() {
    this.init(this.props)
  }

  componentWillReceiveProps(nextProps) {
    const { cardProps } = nextProps
    if (
      cardProps &&
      (!_.isEqual(nextProps.cardProps.tabList, this.state.tabList) ||
        this.state.defaultActiveKey != nextProps.defaultActiveKey)
    ) {
      this.init(nextProps)
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    // console.log(nextProps)
    if (
      !_.isEqual(nextProps.cardProps.tabList, this.state.tabList) ||
      this.props.page.editPage != nextProps.page.editPage ||
      this.state.defaultActiveKey != nextProps.defaultActiveKey ||
      nextProps.app.ifwinopen.SelectCard
    ) {
      return true
    } else {
      return false
    }
  }
  // 初始化卡片
/*   init = props => {
    const { cardProps } = props
    if (cardProps) {
      this.setState({
        tabList: cardProps.tabList ? cardProps.tabList : [],
        defaultActiveKey: cardProps.defaultActiveKey
          ? cardProps.defaultActiveKey
          : 0
      })
    }
  } */

  // 初始化卡片 重新调用接口获取选项卡内容
  init = props => {
    const { cardProps } = props
    if (cardProps) {        
      //调用接口获取选项卡内容
      let cardid = cardProps.cardId;
      getSelectCard(cardid).then(res => {
        if(res.data.meta){
          this.setState({
            tabList: res.data.data.tabList ? res.data.data.tabList : [],
            defaultActiveKey: cardProps.defaultActiveKey
              ? cardProps.defaultActiveKey
              : 0
          })
        }
      });     
    }
  }

  // 面板改变
  tabChange = key => {
    this.setState({
      defaultActiveKey: key
    })
  }

  render() {
    const { tabList, defaultActiveKey } = this.state
    const { page, handleEdit, config } = this.props
    const { editPage } = page
    // 卡片基本配置信息
    let base = (config && config.base) || {}
    // 标题样式
    let titleStyle = {}
    // 卡片设置
    let systemStyle = getThemeStyle('', this.props)
    if (base) {
      titleStyle = {
        fontFamily: base.systemTitleFontfamily,
        fontSize: base.systemTitleFontsize || 16,
        color: base.systemTitleColor
      }
      systemStyle = systemStyle + base.systemCardStyle
    }
    const Wrapper = styled.div`
      ${systemStyle}
    `
    // 要展示的国际化标题
    let cardName = getLanguageTitle(this.props, base.systemTitleLocale, 'name')

    return (
      <Fragment>
        <Wrapper
          className={classnames('cardWraper', {
            move: handleEdit && editPage
          })}
        >
          {generateEdit(null, this.props)}
          {base.systemTitleShow ? (
            <div className="clearfix" style={titleStyle}>
              <div className="fl title_font">{cardName}</div>
            </div>
          ) : null}
          {/* {console.log('SelectComponent的tabList', tabList)} */}
          <Tabs
            className="text_align_center"
            defaultActiveKey={defaultActiveKey.toString()}
            onChange={e => this.tabChange(e)}
          >
            {tabList.map((tab, index) => {
              let newProps = {
                ...this.props,
                tabId: tab.cardId,
                parentId: this.props.id,
                componentName: tab.componentName,
                cardProps: {
                  ...tabList[index],
                  locale: {},
                  title: ''
                },
                config: {
                  ...config,
                  base: {}
                }
              }
              // console.log('SelectComponent的tabItem拿到的props', newProps)
              let title = getLanguageTitle(
                this.props,
                tab.locale,
                'name',
                tab.title
              )
              return (
                <TabPane
                  tab={title}
                  key={index.toString()}
                  style={{ minHeight: '200px' }}
                >
                  <CardWraper {...newProps} cardfixed={true} wrapper={true} />
                </TabPane>
              )
            })}
          </Tabs>
        </Wrapper>
      </Fragment>
    )
  }
}
