import React from 'react'
import { Select, Input, message } from 'antd'
import { connect } from 'react-redux'
import PieChart from './pieChart'
import BarChart from './barChart'
import LineChart from './lineChart'
import CircularDiagramChart from './circularDiagramChart'
import { queryEchart } from '../../../utils/api'
import { ErrorBoundary } from 'components'
const { Search } = Input

@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class BuiltInEcharts extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      cardId: '',
      type: '',
      data: {},
      color: [],
      selectSql: []
    }
  }

  componentWillMount() {
    const { cardProps } = this.props
    const cardId = cardProps.cardId
    queryEchart({ cardId: cardId, results: '' }).then(res => {
      let { meta, data } = res.data
      if (!meta.success) return message.error(meta.message)
      let type = data.chartType
      let isSelect = data.isSelect
      let selectSql
      if (isSelect === '1' && data.selectSql != '') {
        try {
          selectSql = JSON.parse(data.selectSql)
        } catch (e) {
          selectSql = []
        }
      }
      let color = data.color
      if (color != '') {
        color = color.split(',')
        data.color = color
      } else {
        data.color = ['#3aa0ff','#4ecb73','#36cbcb','#f2637b','#fad337','#a97be9','#7172d8','#435188','#fa8c16','#e6560f']
      }

      this.setState({
        cardId: cardId,
        type: type,
        data: data,
        selectSql: selectSql
      })
    })
  }

  handleChange = value => {
    const { cardId } = this.state
    queryEchart({ cardId: cardId, results: value }).then(res => {
      let { meta, data } = res.data
      if (!meta.success) return message.error(meta.message)
      let isSelect = data.isSelect
      let selectSql
      let type = data.chartType
      let color = data.color

      if (color != '') {
        color = color.split(',')
        data.color = color
      } else {
        data.color = ['#3aa0ff','#4ecb73','#36cbcb','#f2637b','#fad337','#a97be9','#7172d8','#435188','#fa8c16','#e6560f']
      }
      if (isSelect === '1' && data.selectSql != '') {
        try {
          selectSql = JSON.parse(data.selectSql)
        } catch (e) {
          selectSql = []
        }
      }
      this.setState({
        cardId: cardId,
        type: type,
        data: data,
        selectSql: selectSql
      })
    })
  }

  render() {
    const { type, data, selectSql } = this.state
    let isSearch = data.isSearch
    let isSelect = data.isSelect
    let searchTitle = data.searchTitle
    return (
      <div>
        {isSearch === '1' ? (
          isSelect === '1' ? (
            <div>
              <span>{searchTitle === '' ? '' : searchTitle + ' ： '}</span>
              <Select
                showSearch
                placeholder="请选择"
                onChange={this.handleChange}
                optionFilterProp="children"
                style={{ width: 200 }}
              >
                <Select.Option value="">全部</Select.Option>
                {selectSql.map((items, index) => (
                  <Select.Option key={index} value={items.yhbh}>
                    {items.yhbh}
                  </Select.Option>
                ))}
              </Select>
            </div>
          ) : (
            <div>
              <span>{searchTitle === '' ? '' : searchTitle + ' ： '}</span>
              <Search
                placeholder="请输入"
                onSearch={this.handleChange}
                style={{ width: 200 }}
              />
            </div>
          )
        ) : null}

        <div className="echartsContainer">
          {/* 柱状图（静态） */}
          {type === '1' && <BarChart type="2" data={data} />}
          {/* 折线图（静态） */}
          {type === '2' && <LineChart type="3" data={data} />}
          {/* 饼状图（静态） */}
          {type === '3' && <PieChart type="1" data={data} />}
          {/* 环形图 (静态) */}
          {type === '4' && <CircularDiagramChart type="4" data={data} />}
        </div>
      </div>
    )
  }
}
