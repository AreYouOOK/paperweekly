import React from 'react'
import { connect } from 'react-redux'
import echarts from 'echarts'
import { Row, Col } from 'antd'
import { guid } from 'utils/util'
export default class CircularDiagramChart extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      data: null,
      id: ''
    }
  }
  componentWillMount() {
    this.setState(
      {
        id: 'circularDiagramChart' + guid(),
        data: this.props.data
      },
      () => {
        this.circularDiagramChart()
      }
    )
  }
  // componentWillReceiveProps(nextProps) {
  //   this.setState(
  //     {
  //       id: 'circularDiagramChart' + guid(),
  //       data: nextProps.data
  //     },
  //     () => {
  //       this.circularDiagramChart()
  //     }
  //   )
  // }
  //环形图
  circularDiagramChart = () => {
    const circularDiagramChart = echarts.init(
      document.getElementById(this.state.id)
    )
    const data = this.state.data
    if (!data) return

    let legend = []
    let xAxis = []
    try {
      legend = data.legend == '' ? [] : JSON.parse(data.legend)
      xAxis = JSON.parse(data.xAxis)
    } catch (e) {
      legend = []
      xAxis = []
    }

    let radius = data.radius.replace(/'/g, '').substring(1)
    radius = radius.substring(0, radius.length - 1).split(',')
    const option = {
      title: {
        show: data.title, //显示策略，默认值true,可选为：true（显示） | false（隐藏）
        text: data.title //主标题文本，'\n'指定换行
      },
      tooltip: {
        trigger: 'item',
        formatter: data.formatter
      },
      color: data.color,
      grid: {
		left: data.left ==''?'50%':data.left,  
		top : data.top ==''?'50%':data.top, 
        containLabel: true
      },
      legend: {
        orient: data.orient,
        x: data.x,
        left: data.legendLeft==''?'auto':data.legendLeft,
        bottom: data.legendBottom==''?'auto':data.legendBottom,
        top: data.legendTop==''?'auto':data.legendTop,
        data: legend
      },
      series: [
        {
          name: data.title,
          type: 'pie',
          radius: radius,
          avoidLabelOverlap: false,
		  center:[data.left ==''?'50%':data.left,data.top ==''?'50%':data.top],
          label: {
            normal: {
				show: true,
				position: data.position==''?'right':data.position,
			},
            emphasis: {
              show: true,
              textStyle: {
                fontSize: data.fontSize == '' ? '14' : data.fontSize,
                fontWeight: data.fontWeight == '' ? 'bold' : data.fontWeight
              }
            }
          },
          labelLine: {
            normal: {
              show: false
            }
          },
          data: xAxis
        }
      ]
    }
    circularDiagramChart.setOption(option)
    if (data.moreUrl) {
      circularDiagramChart.on('click', function(params) {
        window.open(data.moreUrl)
      })
    }
  }

  render() {
    const data = this.state.data
    if (!data) return ''
    return (
      <div>
        {/* 环形图 */}
        <div
          id={this.state.id}
          style={{ height: data.height, width: data.width }}
        ></div>
      </div>
    )
  }
}
