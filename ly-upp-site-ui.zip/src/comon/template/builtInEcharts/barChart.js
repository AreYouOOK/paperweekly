import React from 'react'
import { Row, Col } from 'antd'
import echarts from 'echarts'
import { guid } from 'utils/util'
export default class BarChart extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      data: null,
      id: ''
    }
  }

  componentWillMount() {
    this.setState(
      {
        id: 'circularDiagramChart' + guid(),
        data: this.props.data
      },
      () => {
        this.barChart()
      }
    )
  }

  //   componentWillReceiveProps(nextProps) {
  //     this.setState(
  //       {
  //         //id: 'circularDiagramChart' + guid(),
  //         data: nextProps.data
  //       },
  //       () => {
  //         this.barChart()
  //       }
  //     )
  //   }
  // 柱状图（静态）
  barChart = () => {
    const visitChart = echarts.init(document.getElementById(this.state.id))
    const data = this.props.data
    let legend = []
    let xAxis = []
    let yAxis = []
    try {
      legend = data.legend == '' ? [] : JSON.parse(data.legend)
      xAxis = JSON.parse(data.xAxis)
      yAxis = JSON.parse(data.yAxis)
    } catch (e) {
      legend = []
      xAxis = []
      yAxis = []
    }
    let map = {}
    let series = []
    for (let item of yAxis) {
      map = {
        name: item.name,
        type: 'bar',
        data: item.value
      }
      series.push(map)
    }
 
    const option = {
      title: {
        show: data.title, //显示策略，默认值true,可选为：true（显示） | false（隐藏）
        text: data.title //主标题文本，'\n'指定换行
      },
      tooltip: {
        trigger: 'axis',
        formatter: data.formatter
      },
      color: data.color,
      //color: ['#f2637b','#3aa0ff','#4ecb73','#36cbcb','#f2637b','#fad337','#a97be9','#7172d8','#435188','#fa8c16','#e6560f'],
      legend: {
        orient: data.orient,
        x: data.x,
        left: data.legendLeft== '' ? 'auto':data.legendLeft,
        bottom: data.legendBottom== '' ? 'auto':data.legendBottom,
        top: data.legendTop== '' ? 'auto':data.legendTop,
        data: legend
      },
      calculable: true,
      grid: {
        left: data.left == '' ? '5' : data.left,
        right: data.right == '' ? '5' : data.right,
        bottom: data.bottom == '' ? '5' : data.bottom,
        top: data.top == '' ? '5' : data.top,
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          axisLabel: {
            rotate: data.rotate == '' ? 0 : ~~data.rotate, // 设置x轴文字倾斜
            interval: data.interval == '' ? 'auto' : ~~data.interval, // 可以设置成 0 或 auto 强制显示所有标签。如果设置为 1，表示『隔一个标签显示一个标签』，如果值为 2，表示隔两个标签显示一个标签，以此类推。
          },
          data: xAxis
        }
      ],
      yAxis: [
        {
          type: 'value'
        }
      ],
      series: series
    }

    visitChart.setOption(option)
    if (data.moreUrl) {
      visitChart.on('click', function(params) {
        window.open(data.moreUrl)
      })
    }
  }

  render() {
    const data = this.state.data
    if (!data) return ''
    return (
      <div>
        {/* 柱状图 */}
        <div
          id={this.state.id}
          style={{ height: data.height, width: data.width }}
        ></div>
      </div>
    )
  }
}
