import React from 'react'
import { connect } from 'react-redux'
import echarts from 'echarts'
import { Row, Col } from 'antd'
import { guid } from 'utils/util'
export default class PieChart extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      data: null,
      id: ''
    }
  }
  componentWillMount() {
    this.setState(
      {
        id: 'circularDiagramChart' + guid(),
        data: this.props.data
      },
      () => {
        this.pieChart()
      }
    )
  }
  // componentWillReceiveProps(nextProps) {
  //   this.setState(
  //     {
  //       id: 'circularDiagramChart' + guid(),
  //       data: nextProps.data
  //     },
  //     () => {
  //       this.pieChart()
  //     }
  //   )
  // }

  // 饼状图（静态）
  pieChart = () => {
    const visitorTypeChart = echarts.init(
      document.getElementById(this.state.id)
    )
    const data = this.state.data
    if (!data) return
    let legend = []
    let xAxis = []
    try {
      legend = data.legend == '' ? [] : JSON.parse(data.legend)
      xAxis = JSON.parse(data.xAxis)
    } catch (e) {
      legend = []
      xAxis = []
    }
    const option = {
      title: {
        show: data.title, //显示策略，默认值true,可选为：true（显示） | false（隐藏）
        text: data.title //主标题文本，'\n'指定换行
      },
      tooltip: {
        trigger: 'item',
        formatter: data.formatter
      },
      color: data.color,
      grid: {
        left: data.left == '' ? '5' : data.left,
        right: data.right == '' ? '5' : data.right,
        bottom: data.bottom == '' ? '5' : data.bottom,
        top: data.top == '' ? '5' : data.top,
        containLabel: true
      },
      legend: {
        orient: data.orient, // 对照标注 默认为horizontal垂直布局 vertical为水平布局
        left: data.legendLeft== '' ? 'auto':data.legendLeft,
        bottom: data.legendBottom== '' ? 'auto':data.legendBottom,
        top: data.legendTop== '' ? 'auto':data.legendTop,
        x: data.x,
        data: legend
      },
      series: [
        {
          name: data.title,
          type: 'pie',
          left: data.left,
          top: data.top,
          right: data.right,
          bottom: data.bottom,
          radius: data.radius,
          center: [data.radiusH, data.radiusV],
          label: {
            formatter: '{b}  {d}%',
            show: true
          },
          data: xAxis,
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    }
    visitorTypeChart.setOption(option, true)
    if (data.moreUrl) {
      visitorTypeChart.on('click', function(params) {
        window.open(data.moreUrl)
      })
    }
  }

  render() {
    const data = this.state.data
    if (!data) return ''
    return (
      <div>
        {/* 饼状图 */}
        <div
          id={this.state.id}
          style={{ height: data.height, width: data.width }}
        ></div>
      </div>
    )
  }
}
