/*
 * @Description: iframe卡片
 * @Author: xuqiuting
 * @Date: 2019-07-22 14:33:25
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-18 17:43:30
 */
import React from 'react'
import { connect } from 'react-redux'
import { ErrorBoundary } from 'components'
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class IfameComponent extends React.Component {
  // 组件要传的参数
  static defaultProps = {
    cardProps: {
      width: '200px',
      height: '400px',
      url: ''
    }
  }

  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    const { cardProps } = this.props
    const { width, height, url } = cardProps
    return (
      <div style={{ overflow: 'auto' }}>
        <iframe
          ref="iframe"
          src={url}
          width={height}
          height={width}
          scrolling="no"
          frameBorder="0"
        />
      </div>
    )
  }
}
