/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-09-23 14:00:10
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-04 09:41:39
 */
import React from 'react'
import { connect } from 'react-redux'
import { Schedule } from 'ly-calendar-card'
import { ErrorBoundary } from 'components'
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class ScheduleCard extends React.Component {
  static defaultProps = {
    disabled: false,
    lang: 'zh_CN'
  }
  constructor(props) {
    super(props)
    this.state = {}
  }
  render() {
    return (
      // disabled 当为卡片编辑状态的时候，不能跳转日程管理页面和展开日志
      <Schedule
        lang={this.props.login.locale}
        disabled={this.props.page.editPage}
      />
    )
  }
}
