/*
 * @Description: file content
 * @Author: xuqiuting
 * @Date: 2019-07-22 16:56:56
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-21 17:22:36
 */
import React from 'react'
import { Row, Col } from 'antd'
import { DragLayoutTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import _ from 'lodash'
import ElementMap from './elementMap'
import classnames from 'classnames'
import { connect } from 'react-redux'

@connect(state => {
  return { ...state }
})
export default class TwoCol extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      component: [],
      pageType: 'home',
      layout: 'two_col_5_5',
      colList: [
        { key: 0, span: 12 },
        { key: 1, span: 12 }
      ],
      subComponent: [
        {
          subComponent: []
        },
        {
          subComponent: []
        }
      ]
    }
  }

  componentDidMount() {
    this.init(this.props)
  }

  shouldComponentUpdate(nextProps, nextState) {
    // console.log(nextProps.modalVisible == false)
    // console.log(this.props.page.editPage != nextProps.page.editPage)
    // console.log(nextState.subComponent)
    // console.log(this.state.subComponent)
    // console.log(!_.isEqual(nextState.subComponent, this.state.subComponent))
    if (
      nextProps.modalVisible == true
      // this.props.page.editPage != nextProps.page.editPage ||
      // !_.isEqual(nextState.subComponent, this.state.subComponent)
    ) {
      return false
    } else {
      return true
    }
  }

  // 组件初始化
  init = props => {
    let { layout, operationItem, parentid, id } = props
    let dataSource = _.cloneDeep(props.dataSource)
    let component = _.cloneDeep(props.component)
    let colList = this.state.colList
    // 组装组件
    let arr = []
    if (component.length > 2) {
      arr.push(component[0])
      for (let i = 2; i < component.length; i++) {
        let newComponent = component[i].subComponent.map(res => {
          return {
            ...res,
            colId: 0
          }
        })
        arr[0].subComponent = [...arr[0].subComponent, ...newComponent]
      }
      arr.push(component[1])
    } else if (component.length == 1) {
      arr = [
        ...component,
        {
          subComponent: []
        }
      ]
    }
    // console.log(dataSource,arr,"dataSource")
    if (arr.length > 0) {
      dataSource[parentid].componentArea.filter(
        res => res.id == id
      )[0].component = arr
      operationItem(dataSource)
    } else {
      //组装布局
      if (layout == 'two_col_3_7') {
        colList = [
          { key: 0, span: 7 },
          { key: 1, span: 17 }
        ]
      } else if (layout == 'two_col_5_5') {
        colList = [
          { key: 0, span: 12 },
          { key: 1, span: 12 }
        ]
      } else {
        colList = [
          { key: 0, span: 17 },
          { key: 1, span: 7 }
        ]
      }

      this.setState({
        layout: layout,
        colList: colList,
        subComponent: [...component],
        component: _.cloneDeep(props.component)
      })
    }
  }

  render() {
    const { subComponent, colList } = this.state
    const {
      id,
      pageType,
      dataSource,
      areaIndex,
      operationItem,
      handleDelete,
      handleEdit,
      handleHelp,
      editPage
    } = this.props
    return (
      <Row style={{ width: '100%', height: '100%' }}>
        {colList.map((res, index) => {
          return (
            <Col
              key={res.key}
              span={res.span}
              className={classnames({ pdl10: index != 0 })}
              style={{ height: '100%' }}
            >
              <DragLayoutTargetWrapper
                id={id}
                editPage={editPage}
                areaIndex={areaIndex}
                colId={res.key}
                dataSource={dataSource}
                style={{ width: '100%', minHeight: '280px' }}
                pageType={pageType}
                operationItem={operationItem}
              >
                <ElementMap
                  editPage={editPage}
                  areaIndex={areaIndex}
                  colId={res.key}
                  operationItem={operationItem}
                  handleHelp={handleHelp}
                  subComponent={subComponent}
                  dataSource={dataSource}
                  pageType={pageType}
                  handleDelete={handleDelete}
                  handleEdit={handleEdit}
                />
              </DragLayoutTargetWrapper>
            </Col>
          )
        })}
      </Row>
    )
  }
}
