/*
 * @Description: file content
 * @Author: xuqiuting
 * @Date: 2019-07-22 16:56:56
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-21 17:22:49
 */
import React from 'react'
import { Row, Col } from 'antd'
import { DragLayoutTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import _ from 'lodash'
import ElementMap from './elementMap'
import classnames from 'classnames'
import { connect } from 'react-redux'

@connect(state => {
  return { ...state }
})
export default class ThreeCol extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      component: [],
      pageType: 'home',
      layout: 'three_col_3_3_3',
      colList: [
        { key: 0, span: 8 },
        { key: 1, span: 8 },
        { key: 2, span: 8 }
      ],
      subComponent: [
        {
          subComponent: []
        },
        {
          subComponent: []
        },
        {
          subComponent: []
        }
      ]
    }
  }

  componentDidMount() {
    this.init(this.props)
  }

  shouldComponentUpdate(nextProps, nextState) {
    // console.log(nextProps.modalVisible == false)
    // console.log(this.props.page.editPage != nextProps.page.editPage)
    // console.log(nextState.subComponent)
    // console.log(this.state.subComponent)
    // console.log(!_.isEqual(nextState.subComponent, this.state.subComponent))
    if (
      nextProps.modalVisible == true
      // this.props.page.editPage != nextProps.page.editPage ||
      // !_.isEqual(nextState.subComponent, this.state.subComponent)
    ) {
      return false
    } else {
      return true
    }
  }

  // 组件初始化
  init = props => {
    let { layout, operationItem, parentid, id } = props
    let dataSource = _.cloneDeep(props.dataSource)
    let component = _.cloneDeep(props.component)
    let colList = this.state.colList
    let arr = []
    if (component.length == 1) {
      arr = [
        ...component,
        {
          subComponent: []
        },
        {
          subComponent: []
        }
      ]
    } else if (component.length == 2) {
      arr = [
        ...component,
        {
          subComponent: []
        }
      ]
    }
    if (arr.length > 0) {
      dataSource[parentid].componentArea.filter(
        res => res.id == id
      )[0].component = arr
      operationItem(dataSource)
    } else {
      //组装布局
      if (layout == 'three_col_3_3_3') {
        colList = [
          { key: 0, span: 8 },
          { key: 1, span: 8 },
          { key: 2, span: 8 }
        ]
      } else if (layout == 'three_col_3_4_3') {
        colList = [
          { key: 0, span: 7 },
          { key: 1, span: 10 },
          { key: 2, span: 7 }
        ]
      } else {
        colList = [
          { key: 0, span: 6 },
          { key: 1, span: 12 },
          { key: 2, span: 6 }
        ]
      }
      this.setState({
        colList: colList,
        layout: layout,
        subComponent: arr.length > 0 ? [...arr] : [...component]
      })
    }
  }

  render() {
    const { subComponent, colList } = this.state
    const {
      id,
      pageType,
      dataSource,
      areaIndex,
      operationItem,
      handleDelete,
      handleHelp,
      handleEdit,
      editPage
    } = this.props
    return (
      <Row style={{ width: '100%', height: '100%' }}>
        {colList.map((res, index) => {
          return (
            <Col
              key={res.key}
              span={res.span}
              className={classnames({ pdl10: index != 0 })}
              style={{ height: '100%' }}
            >
              <DragLayoutTargetWrapper
                id={id}
                editPage={editPage}
                areaIndex={areaIndex}
                colId={res.key}
                dataSource={dataSource}
                style={{ width: '100%', minHeight: '280px' }}
                pageType={pageType}
                operationItem={operationItem}
              >
                <ElementMap
                  editPage={editPage}
                  areaIndex={areaIndex}
                  colId={res.key}
                  operationItem={operationItem}
                  subComponent={subComponent}
                  dataSource={dataSource}
                  pageType={pageType}
                  handleDelete={handleDelete}
                  handleHelp={handleHelp}
                  handleEdit={handleEdit}
                />
              </DragLayoutTargetWrapper>
            </Col>
          )
        })}
      </Row>
    )
  }
}
