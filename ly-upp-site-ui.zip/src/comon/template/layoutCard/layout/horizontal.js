/*
 * @Description: file content
 * @Author: xuqiuting
 * @Date: 2019-09-02 14:08:02
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-10 15:45:36
 */
import React from 'react'
import { Row, Col } from 'antd'
import { DragLayoutTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import _ from 'lodash'
import ElementMap from './elementMap'
// import classnames from 'classnames'
import { connect } from 'react-redux'

@connect(state => {
  return { ...state }
})
export default class Horizontal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      component: [],
      pageType: 'home',
      layout: 'horizontal',
      subComponent: [
        {
          subComponent: []
        }
      ]
    }
  }

  componentDidMount() {
    this.init(this.props)
  }

  shouldComponentUpdate(nextProps, nextState) {
    // console.log(nextProps.modalVisible)
    // console.log(nextProps.modalVisible == false)
    // console.log(this.props.page.editPage != nextProps.page.editPage)
    // console.log(nextState.subComponent)
    // console.log(this.state.subComponent)
    // console.log(!_.isEqual(nextState.subComponent, this.state.subComponent))
    if (
      nextProps.modalVisible == true
      // this.props.page.editPage != nextProps.page.editPage ||
      // !_.isEqual(nextState.subComponent, this.state.subComponent)
    ) {
      return false
    } else {
      return true
    }
  }

  // 组件初始化
  init = props => {
    let { layout, operationItem, parentid, id } = props
    let dataSource = _.cloneDeep(props.dataSource)
    let component = _.cloneDeep(props.component)
    // 组装组件
    let arr = []
    if (component.length > 1) {
      arr.push(component[0])
      for (let i = 1; i < component.length; i++) {
        let newComponent = component[i].subComponent.map(res => {
          return {
            ...res,
            colId: 0
          }
        })
        arr[0].subComponent = [...arr[0].subComponent, ...newComponent]
      }
    }

    if (arr.length > 0) {
      dataSource[parentid].componentArea.filter(
        res => res.id == id
      )[0].component = arr
      operationItem(dataSource)
    } else {
      this.setState({
        layout: layout,
        subComponent: [...component]
      })
    }
  }

  render() {
    const { subComponent } = this.state
    const {
      id,
      pageType,
      dataSource,
      areaIndex,
      operationItem,
      handleDelete,
      handleHelp,
      handleEdit,
      editPage
    } = this.props
    return (
      <Row style={{ width: '100%', height: '100%' }}>
        <Col span={24} style={{ height: '100%' }}>
          <DragLayoutTargetWrapper
            id={id}
            editPage={editPage}
            areaIndex={areaIndex}
            colId={0}
            dataSource={dataSource}
            style={{ width: '100%', minHeight: '280px' }}
            pageType={pageType}
            operationItem={operationItem}
          >
            <ElementMap
              editPage={editPage}
              areaIndex={areaIndex}
              colId={0}
              operationItem={operationItem}
              subComponent={subComponent}
              dataSource={dataSource}
              pageType={pageType}
              handleDelete={handleDelete}
              handleHelp={handleHelp}
              handleEdit={handleEdit}
            />
          </DragLayoutTargetWrapper>
        </Col>
      </Row>
    )
  }
}
