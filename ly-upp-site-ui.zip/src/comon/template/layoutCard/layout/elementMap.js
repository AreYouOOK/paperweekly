/*
 * @Description: file content
 * @Author: xuqiuting
 * @Date: 2019-07-22 16:56:56
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-11-25 13:51:35
 */
import React from 'react'
import { DragLayoutSourceTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import { connect } from 'react-redux'
import CardWraper from 'comon/template/cardWraper'
import _ from 'lodash'

@connect(state => {
  return { ...state }
})
export default class ElementMap extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  shouldComponentUpdate(nextProps, nextState) {
    // console.log(nextProps)
    // let object = nextProps.page.element[nextProps.pageType];
    // let objectPre = this.props.page.element[nextProps.pageType];
    if (
      this.props.page.editPage != nextProps.page.editPage ||
      !_.isEqual(nextProps.subComponent, this.props.subComponent)
    ) {
      // console.log("**********************")
      return true
    } else {
      return false
    }
  }

  render() {
    const {
      dataSource,
      areaIndex,
      handleDelete,
      handleHelp,
      pageType,
      handleEdit,
      operationItem,
      colId,
      subComponent,
      editPage
    } = this.props
    const areaDataSource = subComponent[colId].subComponent
    // console.log("layoutElementMap",subComponent)
    return (
      <div>
        {areaDataSource &&
          areaDataSource.map((res, index) => {
            let newProps = {
              ...res,
              pageType: pageType
            }
            return (
              <DragLayoutSourceTargetWrapper
                editPage={editPage}
                key={index}
                coordinate={['layout', index, colId]}
                areaIndex={areaIndex}
                dataSource={dataSource}
                props={res}
                colId={colId}
                pageType={pageType}
                handleDelete={handleDelete}
                handleHelp={handleHelp}
                handleEdit={handleEdit}
                operationItem={operationItem}
              >
                <CardWraper
                  handleDelete={handleDelete}
                  handleHelp={handleHelp}
                  handleEdit={handleEdit}
                  wrapper={true} // 是否是放在layout布局卡和tab中的,默认边距不一样
                  {...newProps}
                />
              </DragLayoutSourceTargetWrapper>
            )
          })}
      </div>
    )
  }
}
