/*
 * @Description:布局卡片
 * @Author: xuqiuting
 * @Date: 2019-07-22 16:56:56
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-24 14:45:54
 */
import React, { Fragment } from 'react'
import { connect } from 'react-redux'
import { Modal, Form } from 'antd'
import _ from 'lodash'
import TwoCol from './layout/twoCol'
import ThreeCol from './layout/threeCol'
import Horizontal from './layout/horizontal'
import CommonCard from 'comon/modal/commonCard/index'
import HelpModal from 'comon/modal/helpModal'
import classnames from 'classnames'
import { cardFormList } from 'comon/data'
import styled from 'styled-components'
import { generateEdit, getThemeStyle } from 'utils/themeData'
import { getLanguageTitle } from 'utils/util'
import { cardFormChange } from 'redux/actions/cardData'

const confirm = Modal.confirm

@connect(state => {
  return { ...state }
})
@Form.create({
  // antd Form组件任意一个表单变化就会触发这个函数
  // 在函数内可以操作props 但是无法操作state
  onValuesChange: (props, changedValues, allValues) => {
    console.log(props, changedValues, allValues)
    // 若表单变化 在redux设置isFormChange字段为true
    // 但是由于设置完后isFormChange一直为true 直接在shouldComponentUpdate判断nextProps的isFormChange为true 会导致死循环渲染 页面卡死
    // 因此在设置为true后需延迟设置会false 确保该字段记录的是当前变化和下次变化的差异
    props.dispatch(cardFormChange(true))
    setTimeout(() => {
      props.dispatch(cardFormChange(false))
    }, 100)
  }
})
export default class LayoutCard extends React.Component {
  static defaultProps = {
    defaultActiveKey: 0
  }

  constructor(props) {
    super(props)
    this.state = {
      component: [],
      layout: null,
      modalVisible: false,
      helpVislble: false,
      modalType: null,
      modalProps: {},
      ids: []
    }
  }

  componentDidMount() {
    this.init(this.props)
  }

  componentWillReceiveProps(nextProps) {
    if (
      nextProps.layout !== this.state.layout ||
      !_.isEqual(nextProps.component, this.state.component)
    ) {
      this.init(nextProps)
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (
      nextProps.layout !== this.state.layout ||
      !_.isEqual(nextProps.component, this.state.component) ||
      this.props.page.editPage != nextProps.page.editPage || // 判断页面编辑状态变化
      // nextProps.app.ifwinopen.LayoutCard || // 没看懂有什么用
      this.props.page.editPage != nextProps.page.editPage ||
      nextState.modalVisible != this.state.modalVisible ||
      // this.state.helpVislble != nextState.helpVislble ||
      (nextProps.cardData.isFormChange != this.props.cardData.isFormChange &&
        nextProps.cardData.isFormChange) || // 子卡片弹窗表单
      !_.isEqual(this.props.config, nextProps.config) // 选项卡卡片弹窗表单
    ) {
      return true
    } else {
      return false
    }
  }

  // 初始化组件
  init = props => {
    // console.log(props.component,props.dataSource,"componentindex")
    let { component, layout } = props
    this.setState({
      component: _.cloneDeep(component),
      layout: layout
    })
  }

  // 生成对应的布局
  gennerateElement = () => {
    const { layout } = this.state
    let type = layout
    if (layout && layout.length == 11 && layout.indexOf('two_col') != -1) {
      type = 'two_col'
    } else if (
      layout &&
      layout.length == 15 &&
      layout.indexOf('three_col') != -1
    ) {
      type = 'three_col'
    }
    switch (type) {
      case 'horizontal':
        return (
          <Horizontal
            modalVisible={this.state.modalVisible}
            {...this.props}
            handleEdit={this.handleEdit}
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
          />
        )
      case 'two_col':
        return (
          <TwoCol
            modalVisible={this.state.modalVisible}
            {...this.props}
            handleEdit={this.handleEdit}
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
          />
        )
      case 'three_col':
        return (
          <ThreeCol
            modalVisible={this.state.modalVisible}
            {...this.props}
            handleEdit={this.handleEdit}
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
          />
        )
      default:
        return null
    }
  }

  //组件弹窗
  generateModal = () => {
    const { modalProps } = this.state
    return <CommonCard {...this.props} modalProps={modalProps} />
  }

  // 编辑
  handleEdit = props => {
    this.setState({
      modalType: props.componentName,
      modalProps: props
    })
    console.log(props)
    this.handleModalCancel()
  }

  // 弹窗确定
  handleModalOk = e => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.setCommonCardModal(values)
      }
    })
  }

  // 保存普通卡片
  setCommonCardModal = values => {
    const { modalProps } = this.state
    let count = 0
    let base = {}
    let card = {}
    if (modalProps.config) {
      base = modalProps.config.base || {}
      card = modalProps.config.card || {}
    }

    // 系统配置
    for (let key in values) {
      let remark = false
      cardFormList.map(item => {
        if (item.name === key) {
          remark = true
        }
      })
      if (remark) {
        base[key] = values[key]
      } else {
        card[key] = values[key]
      }
    }
    let config = {
      base: {
        ...base
      },
      card: {
        ...card
      }
    }
    // 拿到布局卡片在最外层的位置，然后修改布局卡片里面的卡片
    let { parentid, id, operationItem } = this.props
    let dataSource = _.cloneDeep(this.props.dataSource)
    let tabList = dataSource[parentid].componentArea.filter(
      res => res.id == id
    )[0]
    let component = tabList.component[modalProps.colId].subComponent
    component.some(function(item, i) {
      if (item.id == modalProps.id) {
        item.config = config
        return true
      } else {
        return false
      }
    })
    operationItem(dataSource)
    this.handleModalCancel()
  }

  // 弹窗取消
  handleModalCancel = () => {
    this.setState({
      modalVisible: !this.state.modalVisible
    })
  }

  // 删除
  handleDelete = props => {
    let { dataSource, parentid, id, operationItem, login } = this.props
    let tabList = dataSource[parentid].componentArea.filter(
      res => res.id == id
    )[0]
    let component = tabList.component[props.colId].subComponent

    confirm({
      title: login.localeJson.sure_to_delete_card,
      okType: 'danger',
      onOk() {
        component.some(function(item, i) {
          if (item.id == props.id) {
            component.splice(i, 1)
            return true
          } else {
            return false
          }
        })
        operationItem(dataSource, props, 'delete')
      },
      onCancel() {}
    })
  }

  // 提示弹窗
  handleHelp = props => {
    this.setState({
      helpProps: props.cardProps,
      helpVislble: !this.state.helpVislble
    })
  }

  render() {
    const { login, page, config, handleEdit } = this.props
    const { localeJson } = login
    const { editPage } = page
    let base = config || {}
    // 标题样式
    let titleStyle = {}
    // 卡片设置
    let systemStyle = getThemeStyle('', this.props)
    if (config) {
      titleStyle = {
        fontFamily: config.systemTitleFontfamily,
        fontSize: config.systemTitleFontsize || 16,
        color: config.systemTitleColor
      }
      systemStyle = systemStyle + config.systemCardStyle
    }
    const Wrapper = styled.div`
      ${systemStyle}
    `
    // 要展示的国际化标题
    let cardName = getLanguageTitle(this.props, base.systemTitleLocale, 'name')
    console.log(this.props)
    return (
      <Fragment>
        <Wrapper
          className={classnames('cardWraper', {
            move: handleEdit && editPage
          })}
        >
          {generateEdit(null, this.props)}
          {base.systemTitleShow ? (
            <div className="clearfix" style={titleStyle}>
              <div className="fl title_font">{cardName}</div>
            </div>
          ) : null}
          {this.gennerateElement()}
        </Wrapper>
        <Modal
          title={localeJson.edit}
          width={800}
          visible={this.state.modalVisible}
          onOk={this.handleModalOk}
          onCancel={this.handleModalCancel}
          destroyOnClose
        >
          <Form>{this.generateModal()}</Form>
        </Modal>
        <Modal
          title={localeJson.cardHelp}
          width={800}
          bodyStyle={{ padding: '24px' }}
          visible={this.state.helpVislble}
          footer={null}
          destroyOnClose
          onCancel={this.handleHelp}
        >
          <HelpModal cardProps={this.state.helpProps} />
        </Modal>
      </Fragment>
    )
  }
}
