/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-08-29 11:13:46
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-10 18:12:34
 */
import React from 'react'
import { connect } from 'react-redux'
import { message } from 'antd'
import { downloadApi, searchThemeCard } from 'utils/api'
// import PopoverContent from "./popover";
// import PoverMadal from "./modal";
import IconSchool from 'assets/images/school.png'
import IconEmail from 'assets/images/email.png'
import IconWages from 'assets/images/wages.png'
import IconHelp from 'assets/images/help.png'
import { ErrorBoundary } from 'components'
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class SearchCard extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      modalVisible: false,
      modalProps: {},
      cardList: [
        {
          name: {
            zh_CN: '校情统计',
            en_US: 'School Situation Statistics'
          },
          icon: IconSchool
        },
        {
          name: {
            zh_CN: '我的邮箱',
            en_US: 'My Mailbox'
          },
          icon: IconEmail
        },
        {
          name: {
            zh_CN: '工资信息',
            en_US: 'Wage Information'
          },
          icon: IconWages
        },
        {
          name: {
            zh_CN: '帮助中心',
            en_US: 'Help Center'
          },
          icon: IconHelp
        }
      ]
    }
  }

  componentDidMount() {}

  // 搜索
  handleSearch = value => {
    this.search.input.state.value = value
    value = value.replace(/^\s+|\s+$/g, '').trim()
    this.getSearchData(value)
  }

  // 聚焦
  handleFocus = e => {
    this.setState({
      visible: true
    })
    let value = this.search.input.state.value || ''
    this.getSearchData(value)
  }

  // 输入改变
  onSearchChange = e => {
    let value = e.target.value
    setTimeout(this.getSearchData(value), 500)
  }

  // 获取数据
  getSearchData = (value, type) => {
    const { nodata } = this.state
    let params = {
      pageId: '1',
      searchName: value.replace(/^\s+|\s+$/g, '')
    }
    searchThemeCard(params).then(res => {
      let { data, meta } = res.data
      if (meta.success) {
        this.setState({
          visible: type ? false : true,
          searchData: data
            ? data.map(item => {
                return {
                  ...item,
                  list: item.list.map(list => {
                    return {
                      imgUrl: list.cardpic
                        ? `${downloadApi}?attachmentId=${list.cardpic}`
                        : null,
                      ...list
                    }
                  })
                }
              })
            : nodata
        })
      } else {
        this.setState({
          visible: type ? false : true,
          searchData: nodata
        })
        message.error(meta.message)
      }
    })
  }

  // 弹窗
  handleModalOk = () => {
    this.setState({
      modalVisible: !this.state.modalVisible
    })
  }

  // 弹窗
  handleModal = item => {
    this.setState({
      modalProps: item,
      modalVisible: true
    })
  }

  onVisibleChange = visible => {
    this.setState({
      visible: visible
    })
  }

  render() {
    const { locale } = this.props.login
    const { cardList } = this.state
    return (
      <div className="functionCard">
        {cardList.map((item, index) => {
          return (
            <div className="cardBox" key={index}>
              <img src={item.icon} />
              <p className="name">{item.name[locale]}</p>
            </div>
          )
        })}
        <style jsx="true" global="true">{`
          .functionCard {
            // display: grid;
            // grid-template-columns: 50% 50%;
          }
          .functionCard .cardBox {
            position: relative;
            text-align: center;
            height: 190px;
            width: 49%;
            margin: 3px 0;
            background-color: rgba(255, 255, 255, 0.1);
            cursor: pointer;
            display: inline-block;
          }
          .functionCard .cardBox > img {
            width: 60px;
            height: 60px;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            transition: all 0.5s;
            margin: 50px 0 10px;
          }
          .functionCard .cardBox:first-child,
          .functionCard .cardBox:nth-child(3) {
            margin-right: 6px;
          }
          .functionCard .cardBox > img:hover {
            transform: scale(1.2) translateX(-50%);
          }
          .functionCard .cardBox > p {
            color: #fff;
            padding-top: 120px;
          }
        `}</style>
      </div>
    )
  }
}
