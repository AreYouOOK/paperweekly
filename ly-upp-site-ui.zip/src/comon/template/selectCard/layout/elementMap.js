/*
 * @Description: 选项卡卡片遍历组件
 * @Author: xuqiuting
 * @Date: 2019-07-22 16:56:56
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-21 16:12:39
 */
import React from "react";
import { DragTabSourceTargetWrapper } from "comon/DragAndDrop/wrapper_component";
import { connect } from "react-redux";
import CardWraper from "comon/template/cardWraper";
import _ from "lodash";

@connect(state => {
  return { ...state };
})
export default class ElementMap extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  shouldComponentUpdate(nextProps, nextState) {
  
    // let object = nextProps.page.element[nextProps.pageType];
    // let objectPre = this.props.page.element[nextProps.pageType];
    if (
      this.props.page.editPage != nextProps.page.editPage ||
      !_.isEqual(nextProps.subComponent, this.props.subComponent)
    ) {
      // console.log("**********************")
      return true;
    } else {
      return false;
    }
  }

  render() {
    const {
      dataSource,
      areaIndex,
      handleDelete,
      handleHelp,
      pageType,
      handleEdit,
      operationItem,
      tabId,
      subComponent,
      editPage
    } = this.props;
    return (
      <div>
        {subComponent.map((res, index) => {
          // 系统卡片
          let newProps = {
            ...res,
            pageType: pageType
          };
          return (
            <DragTabSourceTargetWrapper
              editPage={editPage} // 是否处于编辑状态
              key={index} // 组件的key
              coordinate={["tab", index]} // 组件的唯一标志，用于区分其他组件布局
              areaIndex={areaIndex} // 组件的序号
              dataSource={dataSource} // 页面所有组件
              props={res} // 组件的属性
              tabId={tabId} // 选卡片的tab
              pageType={pageType} // 标注属于哪个页面的
              handleDelete={handleDelete} // 删除选卡片里面卡片的方法
              handleHelp={handleHelp} // 帮助方法
              handleEdit={handleEdit} // 编辑组件的方法
              operationItem={operationItem} // 操作组件的方法
            >
              <CardWraper
                wrapper={true} // 是否是放在layout布局卡和tab中的
                handleDelete={handleDelete}
                handleHelp={handleHelp}
                handleEdit={handleEdit}
                {...newProps}
              />
            </DragTabSourceTargetWrapper>
          );
        })}
      </div>
    );
  }
}
