/*
 * @Description: 选卡片卡片横向布局
 * @Author: xuqiuting
 * @Date: 2019-07-22 16:56:56
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-16 11:03:23
 */
import React from 'react'
import { connect } from 'react-redux'
import { Row, Col } from 'antd'
import { DragTabTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import _ from 'lodash'
import ElementMap from './elementMap'

@connect(state => {
  return { ...state }
})
export default class Horizontal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      subComponent: [],
      pageType: 'home',
      parentId: this.props.parentId
    }
  }

  componentDidMount() {
    //console.log(this.props.subComponent)
    this.init(this.props.subComponent)
    // console.log(this.props.subComponent,"this.props.subComponent")
  }

  componentWillReceiveProps(nextProps) {
    //console.log(nextProps.subComponent)
    if (!_.isEqual(nextProps.subComponent, this.state.subComponent)) {
      this.init(nextProps.subComponent)
      // console.log(nextProps.subComponent,".nextProps.subComponent")
    }
  }

  // shouldComponentUpdate(nextProps, nextState) {
  //   // console.log(nextProsps.modalVisible)
  //   // console.log(nextProps.modalVisible == false)
  //   // console.log(this.props.page.editPage != nextProps.page.editPage)
  //   // console.log(nextState.subComponent)
  //   // console.log(this.state.subComponent)
  //   // console.log(!_.isEqual(nextState.subComponent, this.state.subComponent))
  //   if (
  //     nextProps.modalVisible == true
  //     // this.props.page.editPage != nextProps.page.editPage ||
  //     // !_.isEqual(nextState.subComponent, this.state.subComponent)
  //   ) {
  //     return false
  //   } else {
  //     console.log('shouldComponentUpdate?')
  //     return true
  //   }
  // }

  // 组件初始化
  init = subComponent => {
    // console.log(subComponent,"subComponent")
    this.setState(
      {
        subComponent: _.cloneDeep(subComponent)
      },
      () => {
        // console.log(this.state.subComponent)
      }
    )
  }

  render() {
    // console.log('render!!')
    const { subComponent } = this.state
    const {
      tabId,
      id,
      pageType,
      dataSource,
      areaIndex,
      operationItem,
      handleDelete,
      handleHelp,
      handleEdit,
      editPage
    } = this.props
    return (
      <Row style={{ width: '100%', height: '100%' }}>
        <Col key={0} span={24} style={{ height: '100%' }}>
          <DragTabTargetWrapper
            editPage={editPage}
            id={id}
            areaIndex={areaIndex}
            tabId={tabId}
            dataSource={dataSource}
            style={{ width: '100%', height: '100%' }}
            pageType={pageType}
            operationItem={operationItem}
          >
            <ElementMap
              editPage={editPage}
              areaIndex={areaIndex}
              operationItem={operationItem}
              tabId={tabId}
              subComponent={subComponent}
              dataSource={dataSource}
              pageType={pageType}
              handleDelete={handleDelete}
              handleHelp={handleHelp}
              handleEdit={handleEdit}
            />
          </DragTabTargetWrapper>
        </Col>
      </Row>
    )
  }
}
