/*
 * @Author: zouting
 * @Date: 2018-10-31 16:09:00
 * @Last Modified by: zting
 * @Last Modified time: 2018-12-27 17:27:56
 */
/**
 * Created by Administrator on 2018/5/11.
 * 组织架构-部门管理编辑模块
 */
import axios from 'axios'
import React from 'react'
import {
  Button,
  Form,
  Input,
  Layout,
  message,
  Select,
  Modal,
  Pagination,
  DatePicker
} from 'antd'
import { connect } from 'react-redux'
import absent from 'assets/images/absent.png'
import echarts from 'echarts'
import { getSrviceCenter, queryforTotalPage } from '../../../utils/api'
import { setCardRequestData } from 'redux/actions/cardData'
import { ErrorBoundary } from 'components'
const { RangePicker } = DatePicker
let x = null
let y = null
let count = false
@connect(state => {
  const { login, config, page } = state
  return { login, config, page }
})
@Form.create()
@ErrorBoundary
export default class ServiceComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      html: '',
      css: '',
      js: '',
      ihtml: '',
      ijs: '',
      icss: '',
      tihtml: '',
      tijs: '',
      ticss: '',
      show: false,
      source: '',
      ifpage: '0',
      ifsearch: '0',
      pagenum: '5',
      searchtips: '',
      head: '',
      tail: '',
      data: {},
      pagecount: 1,
      url: '',
      keyword: '',
      originhtml: '',
      total: 100,
      timestamp: 0
    }
  }
  componentWillMount() {
    // 在预加载阶段，在数据库请求整页面
    // $("script").eq($("script").length - 1).remove()
    // $("head style").eq($("head style").length - 1).remove()
    let time = Date.now()
    window['echarts' + time] = echarts
    const { cardProps, tabId } = this.props
    const { localeJson } = this.props.login
    let CardREID =
      cardProps.commpentName == 'ServiceComponent' ? cardProps.cardId : tabId
    const { requestData } = this.props.cardData
    let GetRequestData
    if (requestData[CardREID]) {
      GetRequestData = this.getCardRequestData
    } else {
      GetRequestData = queryforTotalPage
    }
    GetRequestData(CardREID).then(res => {
      let resourceData = []
      let { meta, data } = res.data
      if (meta.success && data) {
        const cardRes = Object.assign({}, requestData, { [CardREID]: res })
        this.props.dispatch(setCardRequestData(cardRes))
        //let dataSourceID = data.contentDisplay.dataSourceID || ''
        let html = data.contentDisplay.html || ''
        let css = data.contentDisplay.css || ''
        let js = data.contentDisplay.js || ''
        let shtml = data.contentDisplay.shtml || ''
        let scss = data.contentDisplay.scss || ''
        let sjs = data.contentDisplay.sjs || ''
        let keyword = data.contentDisplay.keyword || ''
        let tiedword = data.contentDisplay.tiedword || ''
        let sdataSourceID = data.contentDisplay.sdataSourceID || ''
        let ifpage = data.contentDisplay.ifpage || ''
        let ifsearch = data.contentDisplay.ifsearch || ''
        let pagenum = data.contentDisplay.pagenum || ''
        let searchtips = data.contentDisplay.searchtips || ''
        let resultData = data.data
        // if (data.contentDisplay.cardName != '课表信息2_GX（老师）') {
        //   return
        // }
        this.setState({
          timestamp: time,
          ihtml: shtml,
          icss: scss,
          ijs: sjs,
          tihtml: shtml,
          ticss: scss,
          tijs: sjs,
          source: sdataSourceID,
          ifpage,
          ifsearch,
          pagenum,
          searchtips,
          keyword,
          html,
          originhtml: html,
          css,
          js,
          tiedword,
          head: data.cardTemplate
            ? data.cardTemplate.contentPrefix
              ? data.cardTemplate.contentPrefix
              : ''
            : '',
          tail: data.cardTemplate
            ? data.cardTemplate.contentSuffix
              ? data.cardTemplate.contentSuffix
              : ''
            : '',
          source: data.innerSource,
          url: data.outerSource
        })
        try {
          resourceData = JSON.parse(resultData)
        } catch (e) {
          resourceData = []
        }
        resourceData = JSON.stringify(resourceData) == '{}' ? [] : resourceData
        // 创建新标签 准备接入接口数据
        let doc = document
        x = doc.createElement('script')
        doc.documentElement.appendChild(x)
        y = doc.createElement('style')
        doc.getElementsByTagName('head')[0].appendChild(y)
        let str = ''
        // 根据规则将数据替换给关键字，以及绑定onclick事件
        if (resourceData.length <= 0) {
          str =
            "<img style='display:block;margin:auto' src=" +
            absent +
            '></img>' +
            '<p style="text-align: center">' +
            localeJson.nodata +
            '</p>'
        } else {
          if (html) {
            let array = Object.keys(resourceData[0])
            for (let i in resourceData) {
              let le = html
              if (tiedword) {
                let ne = le.indexOf('#{' + tiedword + '}')
                if (ne > 0) {
                  let xe = le.substring(0, ne)
                  if (xe.lastIndexOf('>') != -1) {
                    let kk = Array.from(le)
                    kk[xe.lastIndexOf('>')] =
                      ' onclick="g' +
                      this.state.timestamp +
                      "('" +
                      resourceData[i][keyword] +
                      '\')" >'
                    le = kk.join('')
                  }
                }
              }
              str += le
              for (let j in array) {
                let regex = new RegExp('#{' + array[j] + '}', 'g')
                str = str.replace(
                  regex,
                  resourceData[i][array[j]] || resourceData[i][array[j]] == 0
                    ? resourceData[i][array[j]]
                    : '&nbsp;'
                )
              }
            }
          } else {
            str = ''
          }
        }
        // 拼接模板取出的头尾html 开始渲染整个页面（js需要在html 后预留时间差）
        str = this.state.head + str + this.state.tail
        //console.log(this.props.page.system.skin)
        this.setState(
          {
            css: css
              .replace(new RegExp('#test', 'g'), '#test' + this.state.timestamp)
              .replace(
                new RegExp('#{window.defaultPageColor}', 'g'),
                this.props.page.system.skin
              ),
            html: str
          },
          () => {
            y.innerHTML = this.state.css
            this.setState(
              {
                js:
                  js
                    .replace(
                      new RegExp('#test', 'g'),
                      '#test' + this.state.timestamp
                    )
                    .replace(
                      /window.echarts.init/g,
                      "window['echarts" + this.state.timestamp + "'].init"
                    ) +
                  ';function g' +
                  this.state.timestamp +
                  "(e){window['z" +
                  this.state.timestamp +
                  "']=e}"
              },
              () => {
                // $("#test"+this.state.timestamp).html(str)
                x.innerHTML = this.state.js
                //  console.log(document.documentElement)
              }
            )
          }
        )
      } else {
        message.error('卡片数据请求失败')
      }
    })
  }

  // 获取缓存的卡片请求数据
  getCardRequestData = cardId => {
    const { requestData } = this.props.cardData
    return new Promise((resolve, reject) => {
      if (requestData[cardId]) {
        resolve(requestData[cardId])
      } else {
        reject(false)
      }
    })
  }

  // 内部页面绑定事件 跳出弹窗
  commonclick = v => e => {
    if (v == this.state.timestamp) {
      let h = this.props.login.data.userId
      if (!this.state.source || !window['z' + this.state.timestamp]) {
        return
      }
      let k = this.state.source
      if (k.indexOf('?') != -1) {
        let j = k.split('?')[1] + '?'
        k.split('?')[1]
          .split('&')
          .map(item => {
            if (item.split('=')[1].indexOf(':') == -1) {
              j += item + '&'
              j = j.substring(0, j.length - 1)
            } else {
              j +=
                item.split('=')[0] +
                '=' +
                window['z' + this.state.timestamp] +
                '&'
              j = j.substring(0, j.length - 1)
            }
          })
        k = j
      }
      // 请求对应接口数据
      getSrviceCenter({ interfaceAddresst: k, results: '' }).then(res => {
        let { meta, data } = res.data
        if (meta.success) {
          let g = []
          try {
            g = JSON.parse(data).data
          } catch (e) {
            g = []
          }
          // 创建标签准备渲染
          let doc = document
          x = doc.createElement('script')
          doc.documentElement.appendChild(x)
          y = doc.createElement('style')
          doc.getElementsByTagName('head')[0].appendChild(y)
          let result = g[0]
          let str = ''
          // 根据数据  以及规则替换关键字 渲染到页面
          if (result.length <= 0) {
            str =
              "<img style='display:block;margin:auto' src=" +
              absent +
              "></img><p style='text-algin:center;'>" +
              localeJson.nodata +
              '</p>'
          } else {
            if (this.state.tihtml) {
              str = this.state.tihtml
              let array = Object.keys(result)

              for (let j in array) {
                let regex = new RegExp('#{' + array[j] + '}', 'g')
                str = str.replace(
                  regex,
                  result[array[j]] || result[array[j]] == 0
                    ? result[array[j]]
                    : '&nbsp;'
                )
              }
              this.setState(
                {
                  ihtml: str,
                  icss: this.state.ticss.replace(
                    new RegExp('#test2', 'g'),
                    '#test2' + this.state.timestamp
                  ),
                  ijs: this.state.tijs.replace(
                    new RegExp('#test2', 'g'),
                    '#test2' + this.state.timestamp
                  ),
                  show: true
                },
                () => {
                  // $("#test2"+this.state.timestamp).html(str)
                  x.innerHTML = this.state.ijs
                  y.innerHTML = this.state.icss
                  // console.log(document.documentElement)
                }
              )
            }
            // this.setState({
            //     show: true
            // })
          }
        } else {
          message.error('请求跳转接口数据失败')
        }
      })
    }
  }

  // 分页或者查询，触发事件
  changehtml = v => e => {
    const { localeJson } = this.props.login
    // 判断是查询还是分页
    if (v == this.state.timestamp) {
      let pcount = ''
      let url = ''
      if (typeof e == 'object') {
        pcount = this.state.pagecount
      } else {
        pcount = e
        this.setState({
          pagecount: e
        })
      }
      // 根据规则拼接请求url
      for (let item of Object.keys(this.state.data)) {
        url += this.state.data[item]
          ? '&' + item + '=' + this.state.data[item]
          : ''
      }
      let zz = ''
      if (this.state.url.indexOf('?') != -1) {
        let ll = this.state.url.split('?')[1].split('&')
        for (let item of ll) {
          if (item.split('=')[1].indexOf(':') == -1) {
            zz += '&' + item
          }
        }
      }
      this.state.ifpage == '0'
        ? (url = this.state.url.split('?')[0] + '?' + zz.substring(1) + url)
        : (url =
            this.state.url.split('?')[0] +
            '?startpage=' +
            pcount +
            '&pagesize=' +
            this.state.pagenum +
            url +
            zz)
      //$("#test"+this.state.timestamp).html("")
      this.setState(
        {
          // html: ""
        },
        () => {
          $('script')
            .eq($('script').length - 1)
            .remove()
          // $("head style").eq($("head style").length - 1).remove()
        }
      )
      // 请求接口数据
      getSrviceCenter({ interfaceAddresst: url, results: '' }).then(res => {
        let { meta, data } = res.data
        if (meta.success) {
          let g = []
          try {
            g = JSON.parse(data).data
          } catch (e) {
            g = []
          }
          JSON.stringify(g) == '{}' ? (g = []) : (g = g)
          let doc = document
          x = doc.createElement('script')
          doc.documentElement.appendChild(x)
          y = doc.createElement('style')
          doc.getElementsByTagName('head')[0].appendChild(y)
          let str = ''
          // 将关键字，替换对应数据，添加点击事件，将最终字符串加到已创建标签内 准备渲染 (js 需要预留时间差)
          if (g.length <= 0) {
            str =
              "<img style='display:block;margin:auto' src=" +
              absent +
              "></img><p style='text-algin:center;'>" +
              localeJson.nodata +
              '</p>'
          } else {
            if (this.state.originhtml) {
              let array = Object.keys(g[0])
              let resultdata = g
              for (let i in resultdata) {
                let le = this.state.originhtml
                if (this.state.tiedword) {
                  let ne = le.indexOf('#{' + this.state.tiedword + '}')
                  if (ne > 0) {
                    let xe = le.substring(0, ne)
                    if (xe.lastIndexOf('>') != -1) {
                      let kk = Array.from(le)
                      kk[xe.lastIndexOf('>')] =
                        ' onclick=g' +
                        this.state.timestamp +
                        "('" +
                        resultdata[i][this.state.keyword] +
                        "') >"
                      le = kk.join('')
                    }
                  }
                }
                str += le
                for (let j in array) {
                  let regex = new RegExp('#{' + array[j] + '}', 'g')
                  str = str.replace(
                    regex,
                    resultdata[i][array[j]] ? resultdata[i][array[j]] : '——'
                  )
                }
              }
            } else {
              str = ''
            }
          }
          str = this.state.head + str + this.state.tail
          this.setState(
            {
              html: str
            },
            () => {
              // $("#test"+this.state.timestamp).html(str)
              let css = this.state.css ? this.state.css : ''
              let js = this.state.js ? this.state.js : ''
              this.setState(
                {
                  css: css,
                  js:
                    js +
                    ';function g' +
                    this.state.timestamp +
                    "(e){window['z" +
                    this.state.timestamp +
                    "']=e}"
                },
                () => {
                  x.innerHTML = this.state.js
                  //y.innerHTML = this.state.css
                  // console.log(document.documentElement)
                }
              )
            }
          )
        } else {
          message.error('请求接口失败')
        }
      })
    }
  }

  render() {
    let { ifsearch, ifpage, pagenum, searchtips, data, timestamp } = this.state
    return (
      <React.Fragment>
        <div style={{ height: '100%', width: '100%' }}>
          <Form
            style={{ display: 'flex', justifyContent: 'center' }}
            layout="inline"
            style={{ display: ifsearch == 1 ? 'block' : 'none' }}
          >
            {searchtips
              ? searchtips.split('|').map((item, index) => {
                  return item.split('*').length > 1 ? (
                    item.split('*')[2] == '1' ? (
                      <Form.Item label={item.split('*')[1] + '*'}>
                        <Input
                          size="small"
                          value={data[item.split('*')[0]]}
                          onChange={e => {
                            data[item.split('*')[0]] = e.target.value
                            this.setState({
                              data
                            })
                          }}
                        />
                      </Form.Item>
                    ) : item.split('*')[2].split('(')[0] == '2' ? (
                      <Form.Item label={item.split('*')[1] + '*'}>
                        <Select
                          size="small"
                          value={data[item.split('*')[0]] || ''}
                          onChange={e => {
                            data[item.split('*')[0]] = e
                            this.setState({
                              data
                            })
                          }}
                        >
                          {item
                            .split('*')[2]
                            .split('(')[1]
                            .split(')')[0]
                            .split(',').length > 1
                            ? item
                                .split('*')[2]
                                .split('(')[1]
                                .split(')')[0]
                                .split(',')
                                .map(item2 => {
                                  return (
                                    <Select.Option value={item2}>
                                      {item2}
                                    </Select.Option>
                                  )
                                })
                            : axios
                                .get(
                                  item
                                    .split('*')[2]
                                    .split('(')[1]
                                    .split(')')[0]
                                )
                                .then(res => {
                                  if (res.data.length > 0) {
                                    res.data.map(item3 => {
                                      return (
                                        <Select.Option value={itme3}>
                                          {item3}
                                        </Select.Option>
                                      )
                                    })
                                  }
                                })}
                        </Select>
                      </Form.Item>
                    ) : item.split('*')[2] == '3' ? (
                      <Form.Item label={item.split('*')[1] + '*'}>
                        <RangePicker showTime size={'small'} />
                      </Form.Item>
                    ) : null
                  ) : null
                })
              : null}
            <Form.Item
              style={{ display: searchtips ? 'inline-block' : 'none' }}
            >
              <Button
                type="primary"
                size={'small'}
                onClick={this.changehtml(timestamp)}
              >
                查询
              </Button>
              <Button
                size={'small'}
                onClick={() => {
                  this.setState({
                    data: {}
                  })
                }}
              >
                重置
              </Button>
            </Form.Item>
          </Form>
          <div
            id={'test' + timestamp}
            dangerouslySetInnerHTML={{ __html: this.state.html }}
            onClick={this.commonclick(timestamp)}
          ></div>
          <div
            style={{
              display: ifpage == 1 ? 'flex' : 'none',
              justifyContent: 'center'
            }}
          >
            <Pagination
              showTotal={() => '共' + this.state.total + '条'}
              size="small"
              showLessItems
              showQuickJumper
              current={this.state.pagecount}
              total={this.state.total}
              pageSize={~~pagenum}
              onChange={this.changehtml(timestamp)}
            />
          </div>
        </div>
        <Modal
          width={750}
          zIndex={100}
          visible={this.state.show}
          footer={null}
          onCancel={() => {
            if (count == false) {
              count = true
              window['z' + timestamp] = null
              $('#test2' + timestamp).html('')
              this.setState(
                {
                  ihtml: '',
                  show: false
                },
                () => {
                  $('script')
                    .eq($('script').length - 1)
                    .remove()
                  $('head style')
                    .eq($('head style').length - 1)
                    .remove()
                  setTimeout(() => {
                    count = false
                  }, 200)
                }
              )
            }
          }}
        >
          <div
            id={'test2' + timestamp}
            dangerouslySetInnerHTML={{ __html: this.state.ihtml }}
          ></div>
        </Modal>
      </React.Fragment>
    )
  }
}
