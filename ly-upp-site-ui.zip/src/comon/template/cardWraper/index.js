/*
 * @Description: 卡片包裹
 * @Author: xuqiuting
 * @Date: 2019-07-16 16:30:49
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-20 16:50:12
 */
import React from 'react'
import { connect } from 'react-redux'
import Card from 'assets/js/lib'
import InerCard from '../index'
import classnames from 'classnames'
import styled from 'styled-components'
import { getThemeStyle, generateEdit } from 'utils/themeData'
import { getLanguageTitle } from 'utils/util'
import _ from 'lodash'

@connect(state => {
  return { ...state }
})
export default class CardWraper extends React.Component {
  static defaultProps = {
    componentName: null, // 要渲染的卡片类型，必须与组件库里面的名字相一致
    title: '待办事项', //头部名称
    more: null, //更多
    config: {}
  }

  constructor(props) {
    super(props)
  }

  shouldComponentUpdate(nextProps, nextState) {
    // console.log(JSON.stringify(nextProps.config))
    // console.log(JSON.stringify(this.props.config))
    if (
      this.props.page.editPage !== nextProps.page.editPage ||
      !_.isEqual(this.props.config, nextProps.config) ||
      this.props.login.locale !== nextProps.login.locale
    ) {
      return true
    } else {
      return false
    }
  }

  render() {
    const {
      componentName,
      login,
      page,
      config,
      cardProps,
      handleEdit,
      cardfixed // 是否是固定的卡片，不可以编辑
    } = this.props
    const { editPage } = page
    // console.log('CardWraper拿到的props', this.props)
    let Component = InerCard[componentName] || Card[componentName]
    let base = (config && config.base) || {}
    let card = (config && config.card) || null
    // 标题样式
    let titleStyle = {}
    // 卡片设置
    let systemStyle = getThemeStyle(componentName, this.props)
    if (config && config.base) {
      titleStyle = {
        fontFamily: config.base.systemTitleFontfamily,
        fontSize: config.base.systemTitleFontsize || 16,
        color: config.base.systemTitleColor
      }
      systemStyle = systemStyle + config.base.systemCardStyle
    }
    const Wrapper = styled.div`
      ${systemStyle}
    `
    // 展示的国际化标题
    // 未设置标题默认展示卡片名称作为卡片标题
    const cardNameLocale = cardProps.locale || {}
    const systemTitleLocale = JSON.parse(
      JSON.stringify(cardNameLocale).replace(/cardName/g, 'name')
    )
    // console.log('卡片标题这里拿到的props', this.props)
    if (!base.hasOwnProperty('systemTitleShow')) {
      base.systemTitleShow = true
      base.systemTitleLocale = systemTitleLocale
    }
    let cardName = getLanguageTitle(this.props, base.systemTitleLocale, 'name')
    // console.log('cardWraper这里拿到的props', this.props)
    // 如果是selectCommponenet的子卡片，不显示标题
    if (this.props.hasOwnProperty('tablist')) {
      cardName = ''
    }
    // 如果是日历卡 将z-index设为10 避免展开日历时被其他卡片覆盖
    let isSchedule = false
    if (cardProps.commpentName === 'Schedule') isSchedule = true
    return (
      <Wrapper
        className={classnames({
          cardWraper: Component,
          move: handleEdit && editPage
        })}
        style={isSchedule ? { zIndex: 10 } : {}}
      >
        {!cardfixed && generateEdit(componentName, this.props)}
        {base.systemTitleShow ? (
          <div className="clearfix" style={titleStyle}>
            <div className="fl title_font">{cardName}</div>
          </div>
        ) : null}
        {Component ? (
          <Component
            // 国际化语言
            currentLanguage={login.locale}
            modalProps={card}
            {...this.props}
          />
        ) : null}
      </Wrapper>
    )
  }
}
