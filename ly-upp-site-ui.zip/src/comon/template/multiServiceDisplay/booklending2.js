/*
 * @Description: file content
 * @Author: liyaochuan
 * @Date: 2019-10-17 18:46:45
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-18 17:44:01
 */
import React from 'react'
import { connect } from 'react-redux'
import { message } from 'antd'
import Collapse from './components/collapse'
import absent from 'assets/images/absent.png'
import Titlebar from './components/titlebar'
import { getBookBorrow } from '../../../utils/api'
import NaNpage from './components/NaNPage'
import { ErrorBoundary } from 'components'
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class Booklending2 extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      data: {},
      dataDetails: []
    }
  }

  componentWillMount() {
    getBookBorrow().then(res => {
      let { meta, data } = res
      if (data.meta.success) {
        this.setState({
          data: data.data.bookBorrow,
          dataDetails: data.data.lstBookDetail
        })
      } else {
        message.error('数据请求失败')
      }
    })
  }

  render() {
    let { data, dataDetails } = this.state
    return (
      <React.Fragment>
        {data && JSON.stringify(data) !== '{}' ? (
          <div>
            <Titlebar type={'Booklending2'} data={data}></Titlebar>
            <Collapse
              type={'Booklending2'}
              dataDetails={dataDetails ? dataDetails : []}
            ></Collapse>
          </div>
        ) : (
          <NaNpage />
        )}
      </React.Fragment>
    )
  }
}
