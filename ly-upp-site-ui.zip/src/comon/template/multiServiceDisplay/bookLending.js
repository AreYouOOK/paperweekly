/*
 * @Description: file content
 * @Author: liyaochuan
 * @Date: 2019-10-17 18:46:45
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-18 17:43:51
 */
import React from 'react'
import { connect } from 'react-redux'
import { message } from 'antd'
import Collapse from './components/collapse'
import absent from 'assets/images/absent.png'
import Titlebar from './components/titlebar'
import { getBookBorrow } from '../../../utils/api'
import NaNpage from './components/NaNPage'
import { ErrorBoundary } from 'components'
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class Booklending extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      data: {},
      dataDetails: []
    }
  }

  componentWillMount() {
    getBookBorrow().then(res => {
      let { meta, data } = res
      if (data.meta.success) {
        //data.data.bookBorrow = {}
        this.setState({
          data: data.data.bookBorrow,
          dataDetails: data.data.lstBookDetail
        })
      } else {
        message.error('数据请求失败')
      }
    })
  }

  render() {
    let { data, dataDetails } = this.state
    return (
      <React.Fragment>
        {data && JSON.stringify(data) !== '{}' ? (
          <div>
            <Titlebar type={'Booklending'} data={data}></Titlebar>
            <Collapse
              type={'Booklending'}
              dataDetails={dataDetails ? dataDetails : []}
            ></Collapse>
          </div>
        ) : (
          <NaNpage />
        )}
      </React.Fragment>
    )
  }
}
