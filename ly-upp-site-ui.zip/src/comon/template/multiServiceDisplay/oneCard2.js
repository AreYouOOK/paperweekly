/*
 * @Description: file content
 * @Author: liyaochuan
 * @Date: 2019-10-17 18:46:45
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-18 17:44:18
 */
import React from 'react'
import { connect } from 'react-redux'
import { Input, Popover, message, Modal } from 'antd'
import Titlebar from './components/titlebar'
import absent from 'assets/images/absent.png'
import Echarts from './components/echarts'
import { getIpassDetail, getIPassDailyCustom } from '../../../utils/api'
import NaNpage from './components/NaNPage'
import { ErrorBoundary } from 'components'
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class OneCard2 extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      data: {},
      dataDetails: []
    }
  }

  componentWillMount() {
    getIpassDetail().then(res => {
      let { meta, data } = res
      if (data.meta.success) {
        this.setState({
          data: data.data.iPass,
          dataDetails: [
            data.data.strList[0].map(item => item.substring(5)),
            data.data.strList[1]
          ]
        })
      } else {
        message.error('数据请求失败')
      }
    })
  }

  render() {
    let { data, dataDetails } = this.state
    return (
      <React.Fragment>
        {data && JSON.stringify(data) !== '{}' ? (
          <div>
            <Titlebar type={'OneCard2'} data={data}></Titlebar>
            <Echarts
              type={'OneCard2'}
              dataDetails={dataDetails ? dataDetails : []}
            ></Echarts>
          </div>
        ) : (
          <NaNpage />
        )}
      </React.Fragment>
    )
  }
}
