/*
 * @Description: file content
 * @Author: liyaochuan
 * @Date: 2019-10-17 18:46:45
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-12-04 17:55:39
 */
import React from 'react'
import { connect } from 'react-redux'
import echarts from 'echarts'

const option1 = {
  title: {
    text: '本周消费统计',
    textStyle: {
      //主标题文本样式{"fontSize": 18,"fontWeight": "bolder","color": "#333"}
      fontFamily: 'Arial',
      fontSize: 16,
      fontStyle: 'normal',
      fontWeight: 'bold',
      color: '#999999'
    },
    x: '12px'
  },
  tooltip: {
    trigger: 'axis'
  },
  legend: {
    data: ['邮件营销', '联盟广告', '视频广告', '直接访问', '搜索引擎']
  },
  grid: {
    top: '25%',
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
  },
  toolbox: {
    feature: {
      saveAsImage: {}
    }
  },
  xAxis: {
    type: 'category',
    boundaryGap: [0, '10%'],
    data: []
  },
  yAxis: {
    type: 'value'
  },
  series: [
    {
      name: '当日消费(元)',
      type: 'line',
      stack: '总量',
      data: [],
      itemStyle: {
        normal: {
          color: '#8cd5c2', //改变折线点的颜色
          lineStyle: {
            color: '#8cd5c2' //改变折线颜色
          }
        }
      }
    }
  ]
}

const option2 = {
  tooltip: {
    trigger: 'item',
    formatter: '{a} <br/>{b}: {c} ({d}%)'
  },
  legend: {
    orient: 'vertical',
    x: 'left',
    data: ['直接访问', '邮件营销', '联盟广告', '视频广告', '搜索引擎']
  },
  color: ['#00FFFF', '#FF8C00', '#00FF00'],
  series: [
    {
      name: '工资比例',
      type: 'pie',
      radius: ['50%', '70%'],
      avoidLabelOverlap: false,
      center: ['50%', '50%'],
      label: {
        normal: {
          show: true,
          position: 'left'
        },
        emphasis: {
          show: true,
          textStyle: {
            fontSize: '20',
            fontWeight: 'bold'
          }
        }
      },
      labelLine: {
        normal: {
          show: true
        }
      },
      data: []
    }
  ]
}

@connect(state => {
  return { ...state }
})
export default class Echarts extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      chartType: option1,
      data: [],
      fresh: true,
      timestamp: ''
    }
  }

  componentWillMount() {
    let { type, dataDetails } = this.props
    this.setState({
      timestamp: new Date().getTime()
    })
    switch (type) {
      case 'OneCard':
        option1.xAxis.data = dataDetails[0]
        option1.series[0].data = dataDetails[1]
        this.setState({}, () => {
          // setTimeout(() => {
          this.freshcharts()
          // }, 1000)
        })
        return
      case 'OneCard2':
        option1.xAxis.data = dataDetails[0]
        option1.series[0].data = dataDetails[1]
        this.setState({}, () => {
          // setTimeout(() => {
          this.freshcharts()
          //}, 1000)
        })
        return
      case 'Salary':
        option2.series[0].data = dataDetails
        this.setState(
          {
            chartType: option2
          },
          () => {
            //  setTimeout(() => {
            this.freshcharts()
            // }, 1000)
          }
        )
        return
    }
  }

  freshcharts = () => {
    let that = this
    let echarts1 = echarts.init(
      document.getElementById('x' + this.props.type + this.state.timestamp)
    )
    echarts1.setOption(this.state.chartType)

    window.addEventListener('resize', () => {
      echarts1.dispose()
      echarts1 = echarts.init(
        document.getElementById('x' + that.props.type + this.state.timestamp)
      )
      echarts1.setOption(this.state.chartType)
    })
  }

  render() {
    return (
      <div>
        <style jsx="true" global="true">{`       
            #x${this.props.type + this.state.timestamp}{
              height:150px;
          `}</style>
        <div id={'x' + this.props.type + this.state.timestamp}></div>
      </div>
    )
  }
}
