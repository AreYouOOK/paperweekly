/*
 * @Description: file content
 * @Author: liyaochuan
 * @Date: 2019-10-17 18:46:45
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-06 14:08:53
 */
import React from 'react'
import { connect } from 'react-redux'
import absent from 'assets/images/absent.png'

@connect(state => {
  return { ...state }
})
export default class NaNpage extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    const { localeJson } = this.props.login
    return (
      <div style={{ textAlign: 'center', marginTop: '10%' }}>
        <img src={absent}></img>
        <div style={{ color: '#999999', fontSize: '16px' }}>{localeJson.nodata}</div>
      </div>
    )
  }
}
