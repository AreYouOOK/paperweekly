/*
 * @Description: file content
 * @Author: liyaochuan
 * @Date: 2019-10-17 18:46:45
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-10-30 10:47:30
 */
import React from 'react'
import { connect } from 'react-redux'

@connect(state => {
  return { ...state }
})
export default class Collapse extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props),
      (this.state = {
        img: false,
        count1: 0,
        count2: 0,
        timestamp: ''
      })
  }

  componentWillMount() {
    this.setState({
      timestamp: new Date().getTime()
    })
    let count = this.props.dataDetails.length
    let count1 = this.props.dataDetails.filter(item => !~~item.status).length
    let count2 = count - count1
    switch (this.props.type) {
      case 'Booklending':
        this.setState({
          count1,
          count2
        })
        return
      case 'Booklending2':
        this.setState({
          count1,
          count2
        })
        return
    }
  }

  click = () => {
    $(
      '.tabdiv' +
        this.props.type +
        this.state.timestamp +
        '+.innerContent' +
        this.props.type +
        this.state.timestamp +
        ' div'
    ).slideToggle(500)
    this.setState({
      img: !this.state.img
    })
  }

  render() {
    let dataDetails = this.props.dataDetails ? this.props.dataDetails : []
    let { img, count1, count2 } = this.state
    return (
      <div className="mainBody">
        <div className={'tabdiv' + this.props.type + this.state.timestamp}>
          已借阅图书
          <span
            style={{ fontWeight: '600', color: '#4A90E2', marginLeft: '10px' }}
          >
            {'(' + count1 + '本)'}
          </span>
          <span
            id="b1"
            className={'tabbutton' + this.props.type + this.state.timestamp}
            style={{ transform: `rotate(${img ? 0 : -90}deg)` }}
            onClick={this.click}
          ></span>
        </div>
        <div
          className={'innerContent' + this.props.type + this.state.timestamp}
          style={{ color: 'grey', position: 'relative', padding: '5px' }}
        >
          {dataDetails.map((item, index) => {
            if (!~~item.status) {
              return (
                <div className="origin" key={index}>
                  {item.bookName}
                  <span>• {item.desc}</span>
                </div>
              )
            }
          })}
        </div>
        <div className={'tabdiv' + this.props.type + this.state.timestamp}>
          已过期图书
          <span
            style={{ fontWeight: '600', color: '#4A90E2', marginLeft: '10px' }}
          >
            {'(' + count2 + '本)'}
          </span>
          <span
            id="b2"
            className={'tabbutton' + this.props.type + this.state.timestamp}
            style={{ transform: `rotate(${!img ? 0 : -90}deg)` }}
            onClick={this.click}
          ></span>
        </div>
        <div
          className={'innerContent' + this.props.type + this.state.timestamp}
          style={{ color: 'grey', position: 'relative', padding: '5px' }}
        >
          {dataDetails.map((item, index) => {
            if (~~item.status) {
              return (
                <div key={index}>
                  {item.bookName}
                  <span>• {item.desc}</span>
                </div>
              )
            }
          })}
        </div>
        <style jsx="true" global="true">{`

.mainBody{
  height:152px;
}        
      .tabbutton${this.props.type}${this.state.timestamp}{
          position: absolute; 
          right: 0;
          cursor: pointer;
          height:26px;
          width:26px;
          display:inline-block;
          background-repeat: no-repeat;
          background-position:center;			
          background-size: 100% 100%;
          background: url('assets/images/arrow-drop-right-line-to-down.svg');
          transition:0.5s
        }
      .tabdiv${this.props.type}${this.state.timestamp}{
      
          margin: 0px 8px;
          padding-left: 10px;
          position: relative;
        }

       .innerContent${this.props.type}${this.state.timestamp} div{
          margin-bottom: 8px;
          margin-left: 12px;
            position: relative;

        }
        .origin{
         display:none

        }
         .innerContent${this.props.type}${this.state.timestamp} div span{
          
        right: 0;
        position:absolute;
        }
    
        `}</style>
      </div>
    )
  }
}
