/*
 * @Description: file content
 * @Author: liyaochuan
 * @Date: 2019-10-17 18:46:45
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-12-04 17:56:14
 */
import React from 'react'
import { connect } from 'react-redux'
import classnames from 'classnames'

@connect(state => {
  return { ...state }
})
export default class Titlebar extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      showNumber: false,
      transformZ: false,
      animate: '15554',
      img: '',
      titleName: '',
      detailName: '',
      swiftTip: '',
      swiftBackTip: '',
      imgcolor: '',
      ifGoPage: false,
      ifFirstTheme: true,
      detailTitles: ['', '', ''],
      detailNumbers: ['', '', ''],
      mainNumber: '',
      detailNumber: '',
      ifFront: true
    }
  }

  componentWillMount() {
    let data = this.props.data
    switch (this.props.type) {
      case 'Salary':
        this.setState({
          img: 'url(/assets/images/v1wage.png)',
          titleName: '实发工资',
          detailName: '工资发放年月：',
          swiftTip: '查看工资明细',
          //swiftBackTip: '查看总数',
          imgcolor: 'blue',
          ifGoPage: true,
          mainNumber: data ? data.salary + '元' : '',
          detailTitles: ['基本工资：', '绩效工资：', '岗位津贴：'],
          detailNumbers: [
            (data ? data.baseSalary : '') + '元',
            (data ? data.meritsSalary : '') + '元',
            (data ? data.cumDeduction : '') + '元'
          ],
          detailNumber: data ? data.time : ''
        })
        return
      case 'OneCard':
        this.setState({
          img: 'url(/assets/images/v1card.png)',
          titleName: '卡余额',
          detailName: '统计已用：',
          swiftTip: '查看消费统计',
          //swiftBackTip: '返回概况',
          imgcolor: 'green',
          ifGoPage: true,
          mainNumber: data ? data.balance + '元' : '',
          detailTitles: ['昨日消费：', '本周消费：', '本月消费：'],
          detailNumbers: [
            (data ? data.weekConsum : '') + '元',
            (data ? data.monthConsum : '') + '元',
            (data ? data.yestConsum : '') + '元'
          ],
          detailNumber: data ? data.iPassId : ''
        })
        return
      case 'OneCard2':
        this.setState({
          ifFirstTheme: false,
          detailName: '今日消费：',
          titleName: '卡余额',
          mainNumber: data ? data.balance + '元' : '',
          detailNumber: data ? data.iPassId : ''
        })
        return
      case 'Booklending':
        this.setState({
          img: 'url(/assets/images/v1book.png)',
          titleName: '余额',
          detailName: '借书证号：',
          imgcolor: '#6090c2',
          mainNumber: data ? data.balance + '元' : '',
          detailNumber: data ? data.borrowId : ''
        })
        return
      case 'Booklending2':
        this.setState({
          ifFirstTheme: false,
          detailName: '借书证号：',
          titleName: '余额',
          mainNumber: data ? data.balance + '元' : '',
          detailNumber: data ? data.borrowId : ''
        })
        return
    }
  }

  swiftZ = e => {
    this.setState(
      {
        animate: '1'
      },
      () => {
        setTimeout(() => {
          this.setState({
            ifFront: !this.state.ifFront,
            transformZ: !this.state.transformZ,
            animate: '224544'
          })
        }, 300)
      }
    )
  }

  cover = () => {
    this.setState({
      showNumber: !this.state.showNumber
    })
  }

  render() {
    let {
      ifFront,
      showNumber,
      transformZ,
      animate,
      img,
      titleName,
      detailName,
      swiftTip,
      swiftBackTip,
      imgcolor,
      ifGoPage,
      ifFirstTheme,
      detailTitles,
      detailNumbers,
      mainNumber,
      detailNumber
    } = this.state
    return (
      <div
        style={{ height: ifFirstTheme ? '160px' : '120px', paddingTop: '0px' }}
      >
        <div
          className={classnames('outsider')}
          style={{
            transition: 'all 0.3s',
            transform: `rotateY(${animate == '1' ? 90 : 0}deg)`,
            borderRadius: '16px',
            padding: '18px',
            backgroundImage: img,
            backgroundRepeat: 'no-repeat',
            backgroundSize: '106%',
            backgroundPosition: 'center',
            color: 'white'
          }}
        >
          <div
            className="salaryin"
            style={{
              padding: '5.5px 0',
              display: !transformZ ? 'block' : 'none'
            }}
          >
            <div style={{ font: '36px bolder', marginBottom: '6px' }}>
              <span
                className={classnames({ blur: showNumber })}
                style={{ color: ifFirstTheme ? 'white' : 'red' }}
              >
                {mainNumber}
              </span>
              <span
                style={{
                  position: 'relative',
                  marginLeft: '10px',
                  color: '#999999',
                  fontSize: '14px',
                  display: ifFirstTheme ? 'none' : 'inline'
                }}
              >
                {titleName}
              </span>
              <span
                className="eye"
                style={{
                  position: 'relative',
                  cursor: 'pointer',
                  display: ifFirstTheme && ifGoPage ? 'inline' : 'none'
                }}
                onClick={this.cover}
              >
                <span
                  style={{
                    display: 'inline-block',
                    marginLeft: '10px',
                    width: '20px',
                    height: '20px',
                    background: `url(/assets/images/${
                      !showNumber ? 'eye-line' : 'eye-off-line'
                    }.png)`
                  }}
                ></span>
              </span>
            </div>
            <div
              style={{
                marginBottom: '6px',
                display: ifFirstTheme ? 'block' : 'none'
              }}
            >
              {titleName}
            </div>
            <div
              style={{
                position: 'relative',
                color: ifFirstTheme ? 'white' : '#999999'
              }}
            >
              {detailName}
              {detailNumber}
              <span style={{ position: 'absolute', right: '0' }}>
                {swiftTip + ' '}
                <span
                  className="move"
                  onMouseEnter={this.swiftZ}
                  style={{
                    background: 'white',
                    color: imgcolor,
                    lineHeight: '20px',
                    textAlign: 'center',
                    display: ifGoPage ? 'inline-block' : 'none',
                    width: '20px',
                    height: '20px',
                    border: '1px solid white',
                    borderRadius: '100%',
                    cursor: 'pointer'
                  }}
                >
                  ➱
                </span>
              </span>
            </div>
          </div>
          <div
            className="salaryout"
            style={{ display: transformZ ? 'block' : 'none', padding: '9.5px' }}
            onMouseLeave={this.swiftZ}
          >
            <div style={{ margin: '10px 0' }}>
              {detailTitles[0]}
              {detailNumbers[0]}
            </div>
            <div style={{ margin: '10px 0' }}>
              {detailTitles[1]}
              {detailNumbers[1]}
            </div>
            <div style={{ position: 'relative' }}>
              {detailTitles[2]}
              {detailNumbers[2]}
              <span style={{ position: 'absolute', right: '0' }}>
                {swiftBackTip}
                <span
                  className="out"
                  style={{
                    background: 'white',
                    color: imgcolor,
                    lineHeight: '20px',
                    textAlign: 'center',
                    display: ifFront ? 'inline-block' : 'none',
                    width: '20px',
                    height: '20px',
                    border: '1px solid white',
                    borderRadius: '100%',
                    cursor: 'pointer',
                    marginLeft: '5px'
                  }}
                >
                  ➱
                </span>
              </span>
            </div>
          </div>
        </div>
        <style jsx="true" global="true">{`
    .eye:hover{color:pink!important;cursor:pointer }
    
    .blur {	
        filter: url('#blur'); /* IE10, IE11 */
        
        -webkit-filter: blur(10px); /* Chrome, Opera */
           -moz-filter: blur(10px);
            -ms-filter: blur(10px);    
                filter: blur(10px); 
        
        filter: progid:DXImageTransform.Microsoft.Blur(Pixel Radius=10, MakeShadow=false); /* IE6~IE9 */
    }
  }

        `}</style>
        <svg version="1.1" xmlns="http://www.w3.org/2000/svg">
          <filter id="blur">
            <feGaussianBlur stdDeviation="5"></feGaussianBlur>
          </filter>
        </svg>
      </div>
    )
  }
}
