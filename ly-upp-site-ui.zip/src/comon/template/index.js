/*
 * @Description: 卡片组件入口文件
 * @Author: xuqiuting
 * @Date: 2019-07-22 16:57:09
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-17 15:34:03
 */
import SelectCard from './selectCard/index.js'
import LayoutCard from './layoutCard/index.js'
import SelectComponent from './selectComponent/index.js'
import IfameComponent from './IfameComponent/index.js'
import CardWraper from './cardWraper/index.js'
import ServiceComponent from './serviceComponent/index.js'
import Mailcard from './mailCard/index'
import BuiltInEcharts from './builtInEcharts/index.js'
import SearchCard from './searchCard/index.js'
import BuiltInAppTypeShow from './builtInAppTypeShow/index.js'
import FunctionCard from './functionCard/index.js'
import TimetableCard from './timetableCard/index.js'
import Salary from './multiServiceDisplay/salary.js'
import OneCard from './multiServiceDisplay/oneCard.js'
import Booklending from './multiServiceDisplay/bookLending.js'
import OneCard2 from './multiServiceDisplay/oneCard2.js'
import Booklending2 from './multiServiceDisplay/booklending2.js'
import Schedule from './schedule/index.js'

const components = {
  SelectCard,
  LayoutCard,
  SelectComponent,
  IfameComponent,
  CardWraper,
  ServiceComponent,
  Mailcard,
  BuiltInEcharts,
  SearchCard,
  BuiltInAppTypeShow,
  FunctionCard,
  TimetableCard,
  Salary,
  OneCard,
  Booklending,
  OneCard2,
  Booklending2,
  Schedule
}
export default components
