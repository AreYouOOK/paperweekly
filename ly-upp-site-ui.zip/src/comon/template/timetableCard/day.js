/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-09-16 18:57:44
 * @LastEditors  : liyaochuan
 * @LastEditTime : 2019-12-18 14:32:42
 */
import React from 'react'
import { connect } from 'react-redux'
import { Popover, Calendar, Icon, message } from 'antd'
import { queryWeekSchedule } from 'utils/api'
import moment from 'moment'
import classnames from 'classnames'

const formatDate = (timeStr, type) => {
  const date = new Date(timeStr)
  let y = date.getFullYear()
  let m = date.getMonth() + 1
  let d = date.getDate()
  let day = date.getDay()
  if (m < 10) {
    m = '0' + m
  }
  if (d < 10) {
    d = '0' + d
  }
  if (type === 'YYYY-MM-DD') {
    return y + '-' + m + '-' + d
  } else if (type === 'YYYYMMDD') {
    return y + '' + m + '' + d
  } else if (type === 'd') {
    if (day == 0) {
      return 7
    } else {
      return day
    }
  } else {
    return m + '-' + d
  }
}

@connect(state => {
  return { ...state }
})
export default class TimeTableDayCard extends React.Component {
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      show: true,
      activeTab: 1,
      date: formatDate(new Date()), // 用于展示
      fullDate: formatDate(new Date(), 'YYYY-MM-DD'),
      list: Array(3).fill([]),
      year: '',
      semester: '',
      day: '',
      week: '',
      type: '',
      beginDate: null,
      endDate: null
    }
  }

  componentDidMount() {
    this.getSchedule()
  }

  // 切换早上、中午、晚上tab
  handleTabChange = activeTab => e => {
    setTimeout(() => {
      document.documentElement.style.setProperty(
        '--left',
        (activeTab - 1) * 60 + 'px'
      )
    }, 300)
    this.setState(
      {
        activeTab,
        show: false
      },
      () => {
        this.setState({ show: true }, () => {
          const timeTable = document.querySelector('.timeTable')
          timeTable.classList.add('fadeIn')
          this.uniteTdCells()
        })
      }
    )
  }

  // 不可选的日期
  hanleDisabledDate = date => {
    const currDate = date.format('YYYYMMDD')
    const { beginDate, endDate } = this.state
    if (currDate < beginDate || currDate > endDate) {
      return true
    } else {
      return false
    }
  }

  // 选择时间
  onSelectDate = date => {
    const currDate = date.format('YYYYMMDD')
    const { beginDate, endDate } = this.state
    const { localeJson } = this.props.login
    if (currDate < beginDate || currDate > endDate) {
      return message.warning(
        localeJson.timeTable_card_tips + `（${beginDate}~${endDate}）`
      )
    }
    this.setState({ show: false }, () => {
      this.setState(
        {
          activeTab: 1,
          date: date.format('MM-DD'),
          fullDate: date.format('YYYY-MM-DD'),
          show: true
        },
        () => {
          const timeTable = document.querySelector('.timeTable')
          timeTable.classList.add('fadeIn')
          const day =
            date.format('YYYYMMDD') +
            ',' +
            (date.format('d') == 0 ? 7 : date.format('d'))
          this.getSchedule(day)
        }
      )
    })
  }

  // 选择前一天&后一天
  onChangeDate = symbol => {
    const { fullDate } = this.state
    const prevDate = new Date(
      new Date(fullDate).getTime() + 24 * 60 * 60 * 1000 * symbol
    )
    // 判断是否为可选日期
    const prev = formatDate(prevDate, 'YYYYMMDD')
    const { beginDate, endDate } = this.state
    const { localeJson } = this.props.login
    if (prev < beginDate || prev > endDate) {
      return message.warning(
        localeJson.timeTable_card_tips + `（${beginDate}~${endDate}）`
      )
    }

    this.setState({ show: false }, () => {
      this.setState(
        {
          activeTab: 1,
          date: formatDate(prevDate),
          fullDate: formatDate(prevDate, 'YYYY-MM-DD'),
          show: true
        },
        () => {
          const timeTable = document.querySelector('.timeTable')
          timeTable.classList.add('fadeIn')
          const day =
            this.state.fullDate.replace(/-/g, '') +
            ',' +
            (prevDate.getDay() == 0 ? 7 : prevDate.getDay())
          this.getSchedule(day)
        }
      )
    })
  }

  // 合并相同单元格
  uniteTdCells = () => {
    // var table = document.getElementById(tableId);
    var table = document.getElementById('timeTable')
    // return console.log(table, table.rows)
    for (let i = 0; i < table.rows.length; i++) {
      for (let c = 0; c < table.rows[i].cells.length; c++) {
        // if (c == 0 || c == 1) { //选择要合并的列序数，去掉默认全部合并
        for (let j = i + 1; j < table.rows.length; j++) {
          let cell1 = table.rows[i].cells[c].innerHTML
          let cell2 = table.rows[j].cells[c].innerHTML
          if (cell1 && cell2 && cell1 === cell2) {
            table.rows[j].cells[c].style.display = 'none'
            table.rows[j].cells[c].style.verticalAlign = 'middle'
            table.rows[i].cells[c].rowSpan++
          } else {
            table.rows[j].cells[c].style.verticalAlign = 'middle' //合并后剩余项内容自动居中
            break
          }
        }
        // }
      }
    }
  }

  // 获取课表数据
  getSchedule = day => {
    // console.log('????')
    const today =
      this.state.fullDate.replace(/-/g, '') + ',' + new Date().getDay()
    const params = {
      cardId: this.props.cardProps.cardId, // '59fd54e5b8554db0ab4a8e7033589fc5'
      results: day || today // 20190920,5
    }
    queryWeekSchedule(params).then(res => {
      const { data, meta } = res.data
      if (!meta.success) return message.error(meta.message)
      const { activeTab } = this.state
      // 上午：swskjc  ；下午 ：xwskjc  晚上：wsskjc
      let list = []
      list[0] = [...data.resultsJsonArr].splice(0, ~~data.swskjc)
      list[1] = [...data.resultsJsonArr].splice(~~data.swskjc, ~~data.xwskjc)
      list[2] = [...data.resultsJsonArr].splice(
        ~~data.swskjc + ~~data.xwskjc,
        ~~data.wsskjc
      )
      this.setState(
        {
          list,
          year: data.xn,
          semester: data.xq,
          day: data.xqj,
          week: data.zs,
          type: data.zsms,
          beginDate: data.ksTime,
          endDate: data.jsTime
        },
        () => {
          this.uniteTdCells('timeTable')
        }
      )
    })
  }

  render() {
    // const { locale } = this.props.login
    const {
      date,
      fullDate,
      activeTab,
      list,
      year,
      semester,
      day,
      week
    } = this.state
    return (
      <div className="timeWeekTableCard">
        <div className="timeInfo">
          <span className="infoText">
            <strong>{week}</strong>周
          </span>
          <span className="infoText">{`${year}年第${semester}学期`}</span>
        </div>
        <div
          className={classnames(
            'timeTableBox',
            { action1: activeTab === 1 },
            { action2: activeTab === 2 },
            { action3: activeTab === 3 }
          )}
        >
          <div className="tabBox">
            <span
              className={classnames('timetab')}
              style={{ zIndex: activeTab === 2 ? 2 : 3 }}
              onClick={this.handleTabChange(1)}
            >
              上午
            </span>
            <span
              className={classnames('timetab')}
              style={{ zIndex: activeTab === 2 ? 3 : 2 }}
              onClick={this.handleTabChange(2)}
            >
              下午
            </span>
            <span
              className={classnames('timetab')}
              style={{ zIndex: activeTab === 3 ? 3 : 1 }}
              onClick={this.handleTabChange(3)}
            >
              晚上
            </span>
            <span
              className={classnames('timetab', 'active')}
              style={{ zIndex: 2 }}
            ></span>
          </div>
          <div className="dateBox">
            <Icon type="left" onClick={e => this.onChangeDate(-1)} />
            <Popover
              trigger="click"
              content={
                <div style={{ width: 280 }}>
                  <Calendar
                    value={moment(fullDate)}
                    fullscreen={false}
                    onPanelChange={this.onSelectDate}
                    onSelect={this.onSelectDate}
                    disabledDate={this.hanleDisabledDate}
                  />
                </div>
              }
            >
              <span className="date">{date}</span>
            </Popover>
            <Icon type="right" onClick={e => this.onChangeDate(1)} />
          </div>
          {this.state.show && (
            <div className={classnames('timeTable')}>
              {/* <div className={classnames("timeTable", { fadeIn: this.state.show }, { fadeOut: !this.state.show })}> */}
              <table id="timeTable">
                <tbody>
                  <tr className="title" style={{ height: 30 }}>
                    <th style={{ textAlign: 'center', width: '20%' }}></th>
                    <th style={{ textAlign: 'center', width: '30%' }}>
                      课程名
                    </th>
                    <th style={{ textAlign: 'center', width: '30%' }}>教室</th>
                    <th style={{ textAlign: 'center', width: '20%' }}>班次</th>
                  </tr>
                  {list[activeTab - 1].map(item => {
                    return (
                      <tr key={item.jc}>
                        <td className="title">第{item.jc}节</td>
                        <td>{item.kcmc}</td>
                        <td>{item.skdd}</td>
                        <td>{item.bj}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <style jsx="true" global="true">{`
          :root {
            --left: 0px;
          }
          .action3 .timetab:nth-child(1) {
            border-right: 1px solid transparent;
          }
          .action3 .timetab:nth-child(2) {
            border-right: 1px solid transparent;
          }
          .action3 .timetab:nth-child(4) {
            animation-name: active3;
            animation-duration: 0.3s;
            animation-timing-function: ease;
            animation-delay: 0s;
            animation-iteration-count: 1;
            animation-direction: normal;
            animation-fill-mode: forwards;
            animation-play-state: running;
          }
          @keyframes active3 {
            from {
              transform: translate3d(var(--left), 0, 0);
            }
            to {
              transform: translate3d(120px, 0, 0);
            }
          }
          .action3 .timetab:nth-child(3) {
            color: white;
          }
          .action1 .timetab:nth-child(2) {
            border-left: 1px solid transparent;
          }
          .action1 .timetab:nth-child(3) {
            border-left: 1px solid transparent;
          }
          .action1 .timetab:nth-child(4) {
            animation-name: active1;
            animation-duration: 0.3s;
            animation-timing-function: ease;
            animation-delay: 0s;
            animation-iteration-count: 1;
            animation-direction: normal;
            animation-fill-mode: forwards;
            animation-play-state: running;
          }
          @keyframes active1 {
            from {
              transform: translate3d(var(--left), 0, 0);
            }
            to {
              transform: translate3d(0px, 0, 0);
            }
          }
          .action1 .timetab:nth-child(1) {
            color: white;
          }
          .action2 .timetab:nth-child(1) {
            border-right: 1px solid transparent;
          }
          .action2 .timetab:nth-child(3) {
            border-left: 1px solid transparent;
          }
          .action2 .timetab:nth-child(4) {
            animation-name: active2;
            animation-duration: 0.3s;
            animation-timing-function: ease;
            animation-delay: 0s;
            animation-iteration-count: 1;
            animation-direction: normal;
            animation-fill-mode: forwards;
            animation-play-state: running;
          }
          @keyframes active2 {
            from {
              transform: translate3d(var(--left), 0, 0);
            }
            to {
              transform: translate3d(60px, 0, 0);
            }
          }
          .action2 .timetab:nth-child(2) {
            color: white;
          }
          .timeWeekTableCard {
          }
          .ant-select.ant-fullcalendar-year-select.ant-select-sm {
            min-width: 88px !important;
          }
          .timeWeekTableCard .infoText {
            padding-left: 8px;
            color: #666;
          }
          .timeWeekTableCard .infoText strong {
            font-size: 30px;
            padding-right: 8px;
            padding-left: 8px;
          }
          .timeWeekTableCard .timeTableBox {
            position: relative;
            margin-top: 15px;
          }
          .timeWeekTableCard .tabBox {
            margin-left: 10px;
            color: #aaa;
            position: relative;
            height: 32px;
          }
          .timeWeekTableCard .tabBox .timetab {
            display: inline-block;
            background: transparent;
            box-sizing: content-box;
            border: 1px solid rgba(214, 213, 213, 0.65);
            border-bottom: transparent;
            border-radius: 6px 6px 0 0;
            padding: 4px;
            width: 60px;
            height: 23px;
            line-height: 23px;
            text-align: center;
            z-index: 1;
            position: absolute;
            cursor: pointer;
          }
          .timeWeekTableCard .tabBox .timetab + .timetab:not(.active) {
            border-left: 0;
          }
          .timeWeekTableCard .tabBox .timetab.active {
            background: #fdb66a;
            color: white;
            box-shadow: 1px -2px 3px #f3cca3;
            border: 1px solid #fdb66a;
          }
          .timeWeekTableCard .tabBox .timetab:nth-child(1) {
            left: 0;
          }
          .timeWeekTableCard .tabBox .timetab:nth-child(2) {
            left: 60px;
          }
          .timeWeekTableCard .tabBox .timetab:nth-child(3) {
            left: 120px;
          }
          .timeWeekTableCard .dateBox {
            position: absolute;
            top: 0px;
            right: 12px;
            color: grey;
            display: inline-block;
          }
          .timeWeekTableCard .dateBox .date {
            display: inline-block;
            border: 1px solid lightgrey;
            width: 62px;
            text-align: center;
            margin: 0 10px;
            padding: 1px;
            border-radius: 4px;
            cursor: pointer;
          }
          .timeWeekTableCard .dateBox .date:hover {
            border: 1px solid #aad1f7 !important;
          }
          .timeWeekTableCard .dateBox i {
            color: #aaa;
            font-size: 13px;
            width: 15px;
          }
          .timeWeekTableCard .dateBox i:hover {
            font-size: 15px;
            color: #5a5a5a;
          }
          .timeWeekTableCard .timeTable {
            width: 100%;
            // max-width: 450px;
            // min-width: 335px;
            display: inline-block;
            border-radius: 5px;
            overflow: hidden;
            border: 1px solid lightgrey;
            background: linear-gradient(to bottom right, #c1e4f9, #2a89e4);
            font-size: 13px;
          }
          .timeWeekTableCard .timeTable table {
            width: 100%;
            border-collapse: collapse;
            z-index: 4;
            text-align: center;
          }
          .timeWeekTableCard .timeTable table tr td {
            padding: 8px;
          }
          .timeWeekTableCard .title {
            background: transparent;
            color: white;
            font-weight: normal;
          }
          .timeWeekTableCard td + td {
            border: 1px solid #eee;
            border-bottom: 0;
            background: #fff;
          }
        `}</style>
      </div>
    )
  }
}
