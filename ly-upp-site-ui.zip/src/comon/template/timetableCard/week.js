/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-09-17 17:17:50
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-11-22 15:34:09
 */
import React from 'react'
import { connect } from 'react-redux'
import { Select, Icon, Modal, message } from 'antd'
import Timetables from './util/index.js'
import { queryWeekSchedule } from 'utils/api'
import { guid } from 'utils/util'

const { Option } = Select
const { info } = Modal

const timetableType = [
  [{ index: '1' }, 1],
  [{ index: '2' }, 1],
  [{ index: '3' }, 1],
  [{ index: '4' }, 1],
  [{ index: '5' }, 1],
  [{ index: '6' }, 1],
  [{ index: '7' }, 1],
  [{ index: '8' }, 1],
  [{ index: '9' }, 1],
  [{ index: '10' }, 1],
  [{ index: '11' }, 1],
  [{ index: '12' }, 1]
  // [{index: '12',name: '20:30'}, 1]
]
const weekList = ['一', '二', '三', '四', '五', '六', '日']
const highlightWeek = new Date().getDay()
const timeTableStyles = {
  Gheight: 35,
  leftHandWidth: 50
  // palette: ['#ff6633', '#1890ff']
}

let timeTable = null

@connect(state => {
  return { ...state }
})
export default class SearchCard extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      idStr: '',
      type: '', // 课表的类型
      year: '', // 学年
      semester: '', // 学期
      day: '', // 星期几
      week: 1, // 周次
      list: [] // 课表数据
    }
  }

  componentWillMount() {
    const randomStr = guid()
    this.setState({ idStr: 'timeTableWeekCard_' + randomStr })
  }

  componentDidMount() {
    this.getSchedule('', () => {
      // 实例化(初始化课表)
      timeTable = new Timetables({
        // el: "#coursesTable",
        el: `#${this.state.idStr}`,
        timetables: this.state.list, // course
        week: weekList,
        timetableType: timetableType,
        highlightWeek: highlightWeek,
        gridOnClick: e => {
          console.log(e)
          Modal.destroyAll()
          if (!e.name) return
          info({
            title: '课程信息',
            content: (
              <div>
                <p>{e.name}</p>
                <p>
                  {e.week}, 第{e.index}节课, 课长{e.length}节
                </p>
              </div>
            ),
            onOk() {}
          })
        },
        styles: timeTableStyles
      })
    })
  }

  //重新设置参数 渲染
  onChange = week => {
    this.getSchedule(week, () => {
      timeTable.setOption({
        timetables: this.state.list
      })
    })
  }

  getSchedule = (week, cb) => {
    const params = {
      cardId: this.props.cardProps.cardId, // 'e3f939509c2e4b84b9687b5ce50ef1f8'
      results: week
    }
    queryWeekSchedule(params).then(res => {
      const { data, meta } = res.data
      if (!meta.success) return message.error(meta.message)
      this.setState(
        {
          list: data.resultsJsonArr,
          year: data.xn,
          semester: data.xq,
          day: data.xqj,
          week: data.zs,
          type: data.zsms
        },
        cb
      )
    })
  }

  render() {
    // const { locale } = this.props.login
    return (
      <div className="timeTableWeekCard">
        <div className="select-container">
          <Select
            size="small"
            value={~~this.state.week}
            onChange={this.onChange}
            dropdownMatchSelectWidth={false}
            // suffixIcon={<Icon type="caret-down" style={{ color: "#1890ff" }} />}
          >
            {Array(18)
              .fill()
              .map((v, i) => {
                return (
                  <Option className="week_option" key={i} value={i + 1}>
                    第{i + 1}周
                  </Option>
                )
              })}
          </Select>
        </div>
        {/* <div id="coursesTable"></div> */}
        <div id={this.state.idStr}></div>
        <style jsx="true" global="true">{`
          #courseWrapper {
            border: 0 !important;
          }
          .timeTableWeekCard {
            position: relative;
          }
          .week_option {
            font-size: 12px;
          }
          .timeTableWeekCard .ant-select-selection {
            width: 56px;
            border: 0px;
            font-size: 12px;
          }
          .timeTableWeekCard .ant-select-sm {
            width: 53px !important;
          }
          .timeTableWeekCard .ant-select-selection__rendered {
            margin: 0 !important;
          }
          .timeTableWeekCard .ant-select-selection-selected-value {
            padding-right: 14px !important;
          }
          .timeTableWeekCard .ant-select-arrow {
            right: 0 !important;
          }
          .timeTableWeekCard .ant-select-focused .ant-select-selection,
          .timeTableWeekCard .ant-select-selection:focus,
          .timeTableWeekCard .ant-select-selection:active {
            border: 0 !important;
            box-shadow: unset !important;
          }
          .timeTableWeekCard .select-container {
            position: absolute;
            z-index: 2;
            padding: 2px;
          }
          // .course-hasContent {
          //   border-radius: 6px;
          //   padding: 4px;
          //   font-size: 12px;
          //   overflow-wrap: break-word;
          // }
          .Courses-content ul {
            margin-bottom: 2px !important;
          }
          .Courses-content li {
            border-radius: 6px;
            border: 2px solid #fff;
            padding: 6px;
            font-size: 12px;
          }
          .Courses-head > div {
            text-align: center;
            font-size: 13px;
            line-height: 30px;
          }
          .highlight-week {
            color: #54abff;
          }
          .Courses-leftHand > div > p {
            text-align: center;
            line-height: 37px;
            border-bottom: 1px solid #eee;
            border-left: 1px solid #eee;
            font-size: 12px;
          }
          .Courses-leftHand > div + div {
            height: 37px !important;
          }
          .left-hand-TextDom {
            border-bottom: 1px solid #eee;
          }
        `}</style>
      </div>
    )
  }
}
