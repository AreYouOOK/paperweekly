/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-09-23 14:00:10
 * @LastEditors  : liyaochuan
 * @LastEditTime : 2019-12-18 14:07:23
 */
import React from 'react'
import { connect } from 'react-redux'
import { message } from 'antd'
import Day from './day.js'
import Week from './week.js'
import { queryWeekSchedule } from 'utils/api'
import { ErrorBoundary } from 'components'
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class TimeTableDayCard extends React.Component {
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      type: ''
    }
  }

  componentWillMount() {
    this.getSchedule()
  }

  // 获取课表数据
  getSchedule = () => {
    // console.log(this.props.cardProps.cardId)
    const params = {
      cardId: this.props.cardProps.cardId,
      results: ''
    }
    queryWeekSchedule(params).then(res => {
      const { data, meta } = res.data
      if (!meta.success) return message.error(meta.message)
      this.setState({ type: data.zsms })
    })
  }

  render() {
    const { type } = this.state
    return (
      <div className="timeTableCardWrapper">
        {type === '1' && <Day {...this.props} />}
        {type === '2' && <Week {...this.props} />}
      </div>
    )
  }
}
