/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-12-18 17:07:51
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-30 10:12:55
 */
import React from 'react'
import styles from './index.less'
import ServiceBox from './serviceBox'
import AddBox from './addBox'
import classNames from 'classnames'

export default class ServiceContainer extends React.Component {
  // 组件应该要传的参数
  static defaultProps = {}

  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    /*
     ** contentType：内容展示类型
     ** minShowWidth：应用的宽度
     ** imgStyle：应用图标的样式
     ** arr：应用列表
     ** addText：添加icon的国际化文字
     ** noDescText：没有描述的国际化文字
     ** language：当前的国际化语言
     ** handleAdd：点击添加icon的事件
     ** linkToServicePage：点击应用的事件
     */
    const {
      contentType,
      minShowWidth,
      imgStyle,
      arr,
      addText,
      noDescText,
      language,
      handleAdd,
      linkToServicePage
    } = this.props
    return (
      <div {...this.props} className={styles.serviceCard}>
        {arr.map((item, index) => {
          const locale = (item && item.locale && JSON.parse(item.locale)) || {}
          const name =
            (locale[language] && locale[language].appName) ||
            (locale.zh_CN && locale.zh_CN.appName) ||
            (locale.en_US && locale.en_US.appName)
          const desc =
            (locale[language] && locale[language].desc) ||
            (locale.zh_CN && locale.zh_CN.desc) ||
            (locale.en_US && locale.en_US.desc) ||
            noDescText
          return item ? (
            <ServiceBox
              className={styles.serviceBox}
              key={index}
              style={{ width: ~~minShowWidth + 30 }}
              onClick={linkToServicePage(item.appLink)}
              contentType={contentType}
              app={item}
              imgStyle={imgStyle}
              name={name}
              desc={desc}
            />
          ) : (
            <AddBox
              className={classNames(styles.serviceBox, 'addServiceBox')}
              onClick={handleAdd}
              key={index}
              contentType={contentType}
              imgStyle={imgStyle}
              addText={addText}
            />
          )
        })}
      </div>
    )
  }
}
