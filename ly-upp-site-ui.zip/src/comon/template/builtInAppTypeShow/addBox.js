/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-12-18 17:07:51
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-19 09:19:19
 */
import React from 'react'
import styles from './index.less'

export default class AddBox extends React.Component {
  // 组件应该要传的参数
  static defaultProps = {}

  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    /*
     ** contentType：内容展示类型
     ** imgStyle：应用图标样式
     ** addText：添加icon的国际化文字
     */
    const { contentType, imgStyle, addText } = this.props
    return (
      <div {...this.props}>
        {['2', '3', '4'].includes(contentType) && (
          <img src={require('assets/images/plus.png')} style={imgStyle} />
        )}
        {['1', '3', '4'].includes(contentType) && (
          <p className={styles.name}>{addText}</p>
        )}
      </div>
    )
  }
}
