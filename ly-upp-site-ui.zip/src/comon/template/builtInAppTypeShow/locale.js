/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-08-26 11:51:42
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-24 11:54:51
 */
'use strict'

Object.defineProperty(exports, '__esModule', {
  value: true
})
exports.localeData = void 0
var localeData = {
  zh_CN: {
    serviceShowType: '应用展示类型',
    serviceType: '应用类型',
    showType: '显示类别',
    appCategory: '应用类别',
    recommendApp: '推荐应用',
    rankApp: '订阅排行',
    newApp: '最新应用',
    subscribeApp: '订阅应用',
    serviceShowType_static: '静态多排展示',
    serviceShowType_scroll: '滚动展示',
    serviceShowType_page: '翻页展示',
    contentType: '内容显示类型',
    contentType_name: '仅显示名称',
    contentType_img: '仅显示图片',
    contentType_name_img: '显示图片和名称',
    contentType_name_img_desc: '显示图片、名称和描述',
    showCount: '显示个数',
    showPageCount: '每页显示个数',
    minShowWidth: '图标显示宽度',
    minShowHight: '图标显示高度',
    rollSpace: '滚动速度',
    rollDirection: '滚动方向',
    rollDirection_left: '向左',
    rollDirection_right: '向右'
  },
  en_US: {
    serviceShowType: 'Service Display Type',
    serviceType: 'Service Type',
    showType: 'Display Type',
    appCategory: 'Service Category',
    recommendApp: 'Recommend Service',
    rankApp: 'Subscription Rank',
    newApp: 'Latest Service',
    subscribeApp: 'Subscribed Service',
    serviceShowType_static: 'Static multi-row display',
    serviceShowType_scroll: 'Rolling display',
    serviceShowType_page: 'Page display',
    contentType: 'Content Display Type',
    contentType_name: 'Display name only',
    contentType_img: 'Display picture only',
    contentType_name_img: 'Display picture and name',
    contentType_name_img_desc: 'Display picture, name and description',
    showCount: 'Display Count',
    showPageCount: 'Display count',
    minShowWidth: 'Picture width',
    minShowHight: 'Picture height',
    rollSpace: 'Rolling speed',
    rollDirection: 'Rolling direction',
    rollDirection_left: 'left',
    rollDirection_right: 'right'
  }
}
exports.localeData = localeData
