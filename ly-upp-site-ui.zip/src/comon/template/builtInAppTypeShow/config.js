import React, { Fragment } from 'react'
import { Form, Select, Tooltip, InputNumber } from 'antd'
import { localeData } from './locale'
import { queryServiceTypeList } from 'utils/api'

const FormItem = Form.Item
const Option = Select.Option

export default class ServiceConfig extends React.Component {
  // 组件应该要传的参数
  static defaultProps = {
    currentLanguage: 'zh_CN',
    modalProps: {} // 弹窗属性
  }

  constructor(props) {
    super(props)
    this.state = {}
  }

  componentDidMount() {
    this.handleInit(this.props)
  }

  // 初始化
  handleInit = props => {
    // 请求应用展示卡片默认配置（显示类型和应用类型）
    const params = {
      cardId: props.cardId
    }
    queryServiceTypeList(params).then(res => {
      const { data, meta } = res.data
      if (!meta.success) return console.log('应用展示弹窗请求卡片配置失败')
      let { serviceTypeName, serviceType, showType } = data
      serviceTypeName = serviceTypeName.map(item => {
        return (item && JSON.parse(item)) || {}
      })
      this.setState({
        ...props.modalProps,
        serviceTypeName,
        serviceType,
        showType
      })
    })
  }

  // 改变表单值存在state里
  handlePropChange = propName => value => {
    this.setState({ [propName]: value })
  }

  render() {
    const { getFieldDecorator } = this.props.form
    const { currentLanguage } = this.props
    const locale = localeData[currentLanguage] || {}
    const showTypeList = [
      null,
      locale.appCategory,
      locale.recommendApp,
      locale.rankApp,
      locale.newApp,
      locale.subscribeApp
    ]
    const formItemLayout = {
      labelCol: { span: 5 },
      wrapperCol: { span: 15 }
    }
    let serviceTypeNameStr = ''
    if (
      Array.isArray(this.state.serviceTypeName) &&
      this.state.serviceTypeName.length
    ) {
      serviceTypeNameStr = this.state.serviceTypeName
        .map(item => {
          return (
            (item[currentLanguage] && item[currentLanguage].typeName) ||
            (item.zh_CN && item.zh_CN.typeName) ||
            window.locale.No_text
          )
        })
        .join(',')
    }
    return (
      <Fragment>
        <FormItem {...formItemLayout} label={locale.showType || '显示类别'}>
          <span>{showTypeList[~~this.state.showType]}</span>
        </FormItem>
        {this.state.showType == '1' && (
          <FormItem
            {...formItemLayout}
            label={locale.serviceType || '应用类型'}
          >
            <span>{serviceTypeNameStr}</span>
          </FormItem>
        )}
        <FormItem
          {...formItemLayout}
          label={locale.serviceShowType || '应用类别展示类型'}
        >
          {getFieldDecorator('serviceShowType', {
            initialValue: this.state.serviceShowType || '1'
          })(
            <Select onChange={this.handlePropChange('serviceShowType')}>
              <Option value="1">
                {locale.serviceShowType_static || '静态多排展示'}
              </Option>
              <Option value="2">
                {locale.serviceShowType_scroll || '滚动展示'}
              </Option>
              <Option value="3">
                {locale.serviceShowType_page || '翻页展示'}
              </Option>
            </Select>
          )}
        </FormItem>

        <FormItem {...formItemLayout} label={locale.contentType || '显示类别'}>
          {getFieldDecorator('contentType', {
            initialValue: this.state.contentType || '3'
          })(
            <Select>
              <Option value="1">
                {locale.contentType_name || '仅显示名称'}
              </Option>
              <Option value="2">
                {locale.contentType_img || '仅显示图片'}
              </Option>
              <Option value="3">
                {locale.contentType_name_img || '显示图片和名称'}
              </Option>
              <Option value="4">
                {locale.contentType_name_img_desc || '显示图片、名称和描述'}
              </Option>
            </Select>
          )}
        </FormItem>
        <FormItem
          {...formItemLayout}
          label={locale.minShowWidth || '图标显示宽度'}
        >
          {getFieldDecorator('minShowWidth', {
            initialValue: this.state.minShowWidth || undefined
          })(<InputNumber />)}
        </FormItem>
        <FormItem
          {...formItemLayout}
          label={locale.minShowHight || '图标显示高度'}
        >
          {getFieldDecorator('minShowHight', {
            initialValue: this.state.minShowHight || undefined
          })(<InputNumber />)}
        </FormItem>
        {this.state.serviceShowType == '1' ||
        this.state.serviceShowType == '3' ? (
          <FormItem
            {...formItemLayout}
            label={
              this.state.serviceShowType == '3'
                ? locale.showPageCount || '每页显示个数'
                : locale.showCount || '显示个数'
            }
          >
            {getFieldDecorator('showCount', {
              initialValue: this.state.showCount || undefined
            })(<InputNumber />)}
          </FormItem>
        ) : (
          <React.Fragment>
            <FormItem
              {...formItemLayout}
              label={locale.rollSpace || '滚动速度'}
            >
              {getFieldDecorator('rollSpace', {
                initialValue: this.state.rollSpace || undefined
              })(<InputNumber />)}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label={locale.rollDirection || '滚动方向'}
            >
              {getFieldDecorator('rollDirection', {
                initialValue: this.state.rollDirection || '2'
              })(
                <Select>
                  <Option value="1">
                    {locale.rollDirection_left || '向左'}
                  </Option>
                  <Option value="2">
                    {locale.rollDirection_right || '向右'}
                  </Option>
                </Select>
              )}
            </FormItem>
          </React.Fragment>
        )}
      </Fragment>
    )
  }
}
