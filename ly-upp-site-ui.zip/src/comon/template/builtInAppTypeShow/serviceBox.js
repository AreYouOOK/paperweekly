/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-12-18 17:07:51
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-18 18:43:08
 */
import React from 'react'
import { Tooltip } from 'antd'
import styles from './index.less'
import { handleImageUrl } from 'utils/util'

export default class ServiceBox extends React.Component {
  static defaultProps = {}

  constructor(props) {
    super(props)
    this.state = {}
  }

  render() {
    /*
     ** contentType: 展示内容类型
     ** app: 应用item
     ** imgStyle: 应用图标的样式
     ** name: 应用名称
     ** desc: 应用描述
     */
    const { contentType, app, imgStyle, name, desc } = this.props
    return (
      <div {...this.props}>
        {['2', '3', '4'].includes(contentType) && (
          <img
            src={
              app.appIcon
                ? handleImageUrl(app.appIcon)
                : require('assets/images/defaultAppIcon.png')
            }
            onError={event => {
              const img = event.nativeEvent.srcElement
              img.src = require('assets/images/defaultAppIcon.png')
              img.onerror = null
            }}
            style={imgStyle}
          />
        )}
        {['1', '3', '4'].includes(contentType) && (
          <Tooltip title={name}>
            <p className={styles.name}>{name}</p>
          </Tooltip>
        )}
        {contentType === '4' && (
          <Tooltip title={desc}>
            <p className={styles.desc}>{desc}</p>
          </Tooltip>
        )}
      </div>
    )
  }
}
