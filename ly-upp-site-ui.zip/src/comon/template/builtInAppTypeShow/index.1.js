/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-09-06 18:59:36
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-18 17:22:49
 */
import React from 'react'
import { message, Tooltip, Carousel } from 'antd'
import { connect } from 'react-redux'
import { handleImageUrl, guid, splitArray } from 'utils/util'
import { queryServiceTypeList } from 'utils/api'
import styles from './index.less'
import { openCollectModal, setAppTypeList } from 'redux/actions/app'
import _ from 'lodash'
import { ErrorBoundary } from 'components'
import IconMore from 'assets/images/icon_more.png'
import classNames from 'classnames'

let timerObj = {}

@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class BuiltInAppTypeShow extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      appList: [],
      scrollWidth: 0,
      id: '',
      id1: '',
      id2: '',
      timer1: '', // 滚动区域的定时器的【名称】
      timer2: '', // 复制的滚动区域定时器的【名称】
      timer3: '', // 监听卡片宽度定时器的【名称】,

      serviceShowType: '1', // 应用类别展示类型 (1、静态多排页面 2、滚动展示)
      contentType: '3', // 内容显示类型 (1、标题 2、图 3、图+标题 4、图+标题+描述)
      minShowWidth: '50', // 图标宽度
      minShowHight: '50', // 图标高度
      rollDirection: '1', // 滚动方向 (1、左边 2、右边)
      rollSpace: '2', // 滚动速度
      showCount: '' // 显示个数
    }
  }

  linkToServicePage = url => e => {
    window.open(url, '_blank').location
  }

  handleAdd = () => {
    const { serviceType } = this.props.cardProps.config
    this.props.dispatch(openCollectModal(true))
    setTimeout(() => {
      const dom = document.querySelector('.appCenter .ant-tabs-tab')
      if (dom) {
        dom.click()
        setTimeout(() => {
          this.props.dispatch(setAppTypeList(serviceType))
        }, 1000)
      }
    }, 100)
  }

  scroll1 = () => {
    const {
      scrollWidth,
      id,
      id1,
      timer1,
      rollSpace,
      rollDirection
    } = this.state
    const ele = document.getElementById(id1)
    if (!document.getElementById(id)) return
    let cardWidth = document.getElementById(id).clientWidth
    // const target = rollDirection === '2' ? scrollWidth : - scrollWidth
    const target = rollDirection === '2' ? cardWidth : -scrollWidth
    // 目标值如果大于当前值取正，目标值如果小于当前值取负
    let speed = target > ele.offsetLeft ? ~~rollSpace : -~~rollSpace // speed指的是步长
    // 在执行之前就获取当前值和目标值之差
    let val = target - ele.offsetLeft
    ele.style.left = ele.offsetLeft + speed + 'px'
    // 移动的过程中，如果目标值和当前值之差如果小于步长，回到复活点
    // 因为步长有正有负，所有转换成绝对值来比较
    if (Math.abs(val) < Math.abs(speed)) {
      ele.style.left =
        rollDirection === '2'
          ? -scrollWidth - (scrollWidth - cardWidth) + 'px'
          : scrollWidth + 'px'
    }
    // 滚动内容的宽度 < 卡片宽度，则停止滚动
    cardWidth = document.getElementById(id).clientWidth
    // console.log('滚动宽度：', scrollWidth)
    // console.log('卡片宽度：', cardWidth)
    if (cardWidth >= scrollWidth) {
      ele.style.left = '0px'
      cancelAnimationFrame(timerObj[timer1])
    }
    timerObj[timer1] = requestAnimationFrame(this.scroll1)
  }

  scroll2 = () => {
    // 考虑过封装成一个函数，但cancelAnimationFrame不能用，所以放弃封装
    const {
      scrollWidth,
      id,
      id2,
      timer2,
      rollSpace,
      rollDirection
    } = this.state
    const ele = document.getElementById(id2)
    if (!document.getElementById(id)) return
    let cardWidth = document.getElementById(id).clientWidth
    const target = rollDirection === '2' ? cardWidth : -scrollWidth
    // 目标值如果大于当前值取正，目标值如果小于当前值取负
    let speed = target > ele.offsetLeft ? ~~rollSpace : -~~rollSpace // speed指的是步长
    // 在执行之前就获取当前值和目标值之差
    let val = target - ele.offsetLeft
    ele.style.left = ele.offsetLeft + speed + 'px'
    // 移动的过程中，如果目标值和当前值之差如果小于步长，回到复活点
    // 因为步长有正有负，所有转换成绝对值来比较
    if (Math.abs(val) < Math.abs(speed)) {
      ele.style.left =
        rollDirection === '2'
          ? -scrollWidth - (scrollWidth - cardWidth) + 'px'
          : scrollWidth + 'px'
    }
    // 滚动内容的宽度 < 卡片宽度，则停止滚动
    cardWidth = document.getElementById(id).clientWidth
    if (cardWidth >= scrollWidth) {
      ele.style.left =
        rollDirection === '2' ? -scrollWidth + 'px' : scrollWidth + 'px'
      cancelAnimationFrame(timerObj[timer2])
    }
    timerObj[timer2] = requestAnimationFrame(this.scroll2)
  }

  // 监听卡片宽度
  handleCardWidthChange = () => {
    const { scrollWidth, id, id2, timer3 } = this.state
    timerObj[timer3] = setInterval(() => {
      let cardWidth = document.getElementById(id).clientWidth
      const dom = document.getElementById(id2)
      if (cardWidth >= scrollWidth) {
        dom.style.visibility = 'hidden'
      } else {
        dom.style.visibility = 'visible'
      }
    }, 100)
  }

  stop = () => {
    if (this.state.serviceShowType === '1') return
    const { timer1, timer2 } = this.state
    cancelAnimationFrame(timerObj[timer1])
    cancelAnimationFrame(timerObj[timer2])
  }

  continue = () => {
    if (this.state.serviceShowType === '1') return
    const { timer1, timer2 } = this.state
    timerObj[timer1] = requestAnimationFrame(this.scroll1)
    timerObj[timer2] = requestAnimationFrame(this.scroll2)
  }

  componentDidMount() {
    const randomStr = guid()
    const { cardProps, page } = this.props
    const params = { cardId: cardProps.cardId }
    let card = this.props.config.card || this.props.config
    // console.log('应用展示卡片', this.props)
    if (!card) card = {}
    queryServiceTypeList(params).then(res => {
      const { data, meta } = res.data
      if (!meta.success) return message.error(meta.message)
      const showCount = card.showCount || data.showCount || ''
      const serviceShowType =
        card.serviceShowType || data.serviceShowType || '1'
      const appList = data.appList || []
      const appLength = appList.length > showCount ? appList.length : showCount
      // const list =
      //   ~~showCount && serviceShowType == '1'
      //     ? appList.slice(0, showCount)
      //     : appList
      this.setState(
        {
          scrollWidth:
            // list.length *
            appLength *
            (Number(card.minShowWidth || data.minShowWidth || 50) + 30 + 10), // 滚动区域的宽度 * 应用数（30、10是margin）
          id: 'serviceContainer' + randomStr,
          id1: 'serviceCard' + randomStr + '_1',
          id2: 'serviceCard' + randomStr + '_2',
          timer1: 'timer1_' + randomStr,
          timer2: 'timer2_' + randomStr,
          timer3: 'timer3_' + randomStr,
          serviceShowType,
          contentType: card.contentType || data.contentType || '3',
          minShowHight: card.minShowHight || data.minShowHight || 50,
          minShowWidth: card.minShowWidth || data.minShowWidth || 50,
          rollDirection: card.rollDirection || data.rollDirection || '1',
          rollSpace: card.rollSpace || data.rollSpace || '2',
          showCount,
          // appList: list
          appList
        },
        () => {
          if (this.state.serviceShowType === '1') return
          const { timer1, timer2, timer3 } = this.state
          timerObj[timer1] = null
          timerObj[timer2] = null
          timerObj[timer3] = null
          this.handleCardWidthChange()
          timerObj.timer1 = requestAnimationFrame(this.scroll1)
          timerObj.timer2 = requestAnimationFrame(this.scroll2)
        }
      )
    })
  }

  componentWillUnmount() {
    if (this.state.serviceShowType === '1') return
    const { timer1, timer2, timer3 } = this.state
    timer1 && clearInterval(timerObj[timer1])
    timer2 && clearInterval(timerObj[timer2])
    timer3 && clearInterval(timerObj[timer3])
  }

  render() {
    const language = this.props.login.locale
    const { localeJson } = this.props.login
    const {
      appList,
      scrollWidth,
      id,
      id1,
      id2,
      minShowWidth,
      minShowHight,
      contentType,
      rollDirection,
      serviceShowType,
      showCount
    } = this.state
    // const serviceShowType = '3'
    const pageCount = 5
    const splitAppList = splitArray(appList.concat(null), pageCount)
    const imgStyle = {
      width: ~~minShowWidth || 50,
      height: ~~minShowHight || 50
    }
    const textH = 21 // 标题和描述的行高
    const cardHList = [
      textH, // 名称
      ~~minShowHight, // 图片
      ~~minShowHight + textH, // 图片+名称
      ~~minShowHight + textH * 2 // 图片+名称+描述
    ]
    const cardStyle = {
      minHeight: 30 + 20 + cardHList[~~contentType - 1] // 30、20是盒子的padding和margin
    }
    const list = ~~showCount ? appList.slice(0, showCount) : appList
    return (
      <div
        className={classNames(
          'checkMore',
          serviceShowType === '2' ? styles.scrollCard : null
        )}
        id={id}
        style={cardStyle}
        onMouseOver={this.stop}
        onMouseLeave={this.continue}
      >
        <a style={{ display: 'none' }} href="http://baidu.com" target="_blank">
          <div>
            <span>更多</span>
            <img src={IconMore} alt="" />
          </div>
        </a>
        {/* <Button onClick={this.stop} style={{ zIndex: 888 }}>stop</Button>
      <Button onClick={this.continue} style={{ zIndex: 888 }}>continue</Button> */}
        {serviceShowType === '3' ? (
          <div>
            <Carousel
            // autoplay
            >
              {splitAppList.map((arr, i) => {
                return (
                  <div key={i}>
                    <div className={styles.serviceCard}>
                      {arr.map((item, index) => {
                        const locale =
                          (item && item.locale && JSON.parse(item.locale)) || {}
                        const name =
                          (locale[language] && locale[language].appName) ||
                          (locale.zh_CN && locale.zh_CN.appName) ||
                          (locale.en_US && locale.en_US.appName)
                        const desc =
                          (locale[language] && locale[language].desc) ||
                          (locale.zh_CN && locale.zh_CN.desc) ||
                          (locale.en_US && locale.en_US.desc) ||
                          localeJson.noDesc
                        return (
                          list.length > 0 &&
                          (item ? (
                            <div
                              className={styles.serviceBox}
                              key={index}
                              style={{ width: ~~minShowWidth + 30 }}
                              onClick={this.linkToServicePage(item.appLink)}
                            >
                              {['2', '3', '4'].includes(contentType) && (
                                <img
                                  src={
                                    item.appIcon
                                      ? handleImageUrl(item.appIcon)
                                      : require('assets/images/defaultAppIcon.png')
                                  }
                                  onError={event => {
                                    const img = event.nativeEvent.srcElement
                                    img.src = require('assets/images/defaultAppIcon.png')
                                    img.onerror = null
                                  }}
                                  style={imgStyle}
                                />
                              )}
                              {['1', '3', '4'].includes(contentType) && (
                                <Tooltip title={name}>
                                  <p className={styles.name}>{name}</p>
                                </Tooltip>
                              )}
                              {contentType === '4' && (
                                <Tooltip title={desc}>
                                  <p className={styles.desc}>{desc}</p>
                                </Tooltip>
                              )}
                            </div>
                          ) : (
                            <div
                              className={styles.serviceBox}
                              onClick={this.handleAdd}
                              key={index}
                            >
                              {['2', '3', '4'].includes(contentType) && (
                                <img
                                  src={require('assets/images/plus.png')}
                                  style={imgStyle}
                                />
                              )}

                              {['1', '3', '4'].includes(contentType) && (
                                <p className={styles.name}>{localeJson.add}</p>
                              )}
                            </div>
                          ))
                        )
                      })}
                    </div>
                  </div>
                )
              })}
            </Carousel>
          </div>
        ) : (
          <React.Fragment>
            <div className={styles.serviceCard} id={id1}>
              {list.map((item, index) => {
                const locale = (item.locale && JSON.parse(item.locale)) || {}
                const name =
                  (locale[language] && locale[language].appName) ||
                  (locale.zh_CN && locale.zh_CN.appName) ||
                  (locale.en_US && locale.en_US.appName)
                const desc =
                  (locale[language] && locale[language].desc) ||
                  (locale.zh_CN && locale.zh_CN.desc) ||
                  (locale.en_US && locale.en_US.desc) ||
                  localeJson.noDesc
                return list.length > 0 && index == list.length - 1 ? (
                  <div
                    className={styles.serviceBox}
                    onClick={this.handleAdd}
                    key={index}
                  >
                    {['2', '3', '4'].includes(contentType) && (
                      <img
                        src={require('assets/images/plus.png')}
                        style={imgStyle}
                      />
                    )}

                    {['1', '3', '4'].includes(contentType) && (
                      <p className={styles.name}>{localeJson.add}</p>
                    )}
                  </div>
                ) : (
                  <div
                    className={styles.serviceBox}
                    style={{ width: ~~minShowWidth + 30 }}
                    key={index}
                    onClick={this.linkToServicePage(item.appLink)}
                  >
                    {['2', '3', '4'].includes(contentType) && (
                      <img
                        src={
                          item.appIcon
                            ? handleImageUrl(item.appIcon)
                            : require('assets/images/defaultAppIcon.png')
                        }
                        onError={event => {
                          const img = event.nativeEvent.srcElement
                          img.src = require('assets/images/defaultAppIcon.png')
                          img.onerror = null
                        }}
                        style={imgStyle}
                      />
                    )}
                    {['1', '3', '4'].includes(contentType) && (
                      <Tooltip title={name}>
                        <p className={styles.name}>{name}</p>
                      </Tooltip>
                    )}
                    {contentType === '4' && (
                      <Tooltip title={desc}>
                        <p className={styles.desc}>{desc}</p>
                      </Tooltip>
                    )}
                  </div>
                )
              })}
            </div>
            <div
              className={styles.serviceCard}
              id={id2}
              style={{
                left: rollDirection === '2' ? -scrollWidth : scrollWidth,
                visibility: 'hidden',
                display: serviceShowType === '2' ? 'inline-flex' : 'none'
              }}
            >
              {list.map((item, index) => {
                const locale = (item.locale && JSON.parse(item.locale)) || {}
                const name =
                  (locale[language] && locale[language].appName) ||
                  (locale.zh_CN && locale.zh_CN.appName) ||
                  (locale.en_US && locale.en_US.appName)
                const desc =
                  (locale[language] && locale[language].desc) ||
                  (locale.zh_CN && locale.zh_CN.desc) ||
                  (locale.en_US && locale.en_US.desc) ||
                  localeJson.noDesc
                return list.length > 0 && index == list.length - 1 ? (
                  <div
                    className={styles.serviceBox}
                    onClick={this.handleAdd}
                    key={index}
                  >
                    {['2', '3', '4'].includes(contentType) && (
                      <img
                        src={require('assets/images/plus.png')}
                        style={imgStyle}
                      />
                    )}

                    {['1', '3', '4'].includes(contentType) && (
                      <p className={styles.name}>{localeJson.add}</p>
                    )}
                  </div>
                ) : (
                  <div
                    className={styles.serviceBox}
                    style={{ width: Number(minShowWidth) + 30 }}
                    key={index}
                    onClick={this.linkToServicePage(item.appLink)}
                  >
                    {['2', '3', '4'].includes(contentType) && (
                      <img
                        style={imgStyle}
                        src={
                          item.appIcon
                            ? handleImageUrl(item.appIcon)
                            : require('assets/images/defaultAppIcon.png')
                        }
                        onError={event => {
                          const img = event.nativeEvent.srcElement
                          img.src = require('assets/images/defaultAppIcon.png')
                          img.onerror = null
                        }}
                        alt=""
                      />
                    )}
                    {['1', '3', '4'].includes(contentType) && (
                      <Tooltip title={item.mame}>
                        <p className={styles.name}>{name}</p>
                      </Tooltip>
                    )}
                    {contentType === '4' && (
                      <Tooltip title={desc}>
                        <p className={styles.desc}>{desc}</p>
                      </Tooltip>
                    )}
                  </div>
                )
              })}
            </div>
          </React.Fragment>
        )}
      </div>
    )
  }
}
