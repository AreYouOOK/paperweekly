/*
 * @Author: zouting
 * @Date: 2018-10-31 16:09:00
 * @Last Modified by: zting
 * @Last Modified time: 2018-12-27 17:27:56
 */
/**
 * Created by Administrator on 2018/5/11.
 * 组织架构-部门管理编辑模块
 */
import React, { Component, PropTypes } from 'react'
import {
  Button,
  Form,
  Input,
  Layout,
  Switch,
  TreeSelect,
  message,
  Spin,
  Select,
  Tree,
  Icon,
  Radio,
  Tag,
  Modal
} from 'antd'
import { connect } from 'react-redux'
import createHistory from 'history/createHashHistory'
import {
  queryforHTML,
  getCardInterface,
  getSrviceCenter,
  querySystemConfigContent,
  mailtest,
  searchforCardId
} from '../../../utils/api'
import Emailbind from './bind'
import Emailregister from './register'
const TextArea = Input.TextArea
const history = createHistory()
let x = null
let y = null
@connect(state => {
  const { login, config } = state
  return { login, config }
})
@Form.create()
export default class MailCard extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      data: {},
      html: '',
      js: '',
      css: '',
      show: false,
      show2: false,
      id: '',
      hover: [1, 1, 1],
      timestamp: 0,
      cardId: ''
    }
  }

  componentWillMount() {
    let time = Date.now()
    //预加载事件 到数据库请求整个页面字符串
    const { cardProps } = this.props
    let CardREID = cardProps.cardId ? cardProps.cardId : cardProps.tabId
    mailtest({ cardid: CardREID }).then(res => {
      // let data = {
      //   newCount: '11',
      //   totalCount: '22',
      //   loginUrl: 'www.baidu.com',
      //   url: 'www.baidu.com',
      //   userId: '12',
      //   idCard: '4521554554488755',
      //   nickName: '逮虾户',
      //   isRegister: '1',
      //   isBind: '1',
      //   js: '',
      //   css:
      //     '	#test .innerContent div{margin: 15px;}#test .bottomButton span {height: 40px;width: 99px;display: inline-block;line-height: 40px;text-align: center;border-radius: 20px;border: 1px solid gainsboro;box-shadow: 0px 0px 0.5px lightgrey inset;}                   #test .bottomButton span:hover {background: #4a90e2;color: white;cursor: pointer;}',
      //   html:
      //     "<div style='height:340px;padding-top:20px'><div style='border-radius: 16px;'><div style='display:flex;justify-content:space-around;padding: 20px;'><div style='display: inline-block;width: 80%;height: 160px;background-image: url('assets/images/v1mail.png');background-repeat: no-repeat;background-position:center '></div><div class='innerContent' style='display: inline-block;width: 180px;height: 140px;padding: 10px;font:bolder  14px  '微软雅黑' '><div><span style='font:bold 36px;color:red;'>8</span> 未读邮件</div><div>28 邮件总数</div><div>20 已读邮件</div></div></div></div><div style='text-align: center;margin:20px;color: grey;'>最后更新时间：2019-12-21 02:23:21</div><div class='bottomButton' style='display: flex;justify-content: center;'><div><span style='margin-right:60px'>绑定邮箱</span><span>进入邮箱</span></div></div></div>",
      //   etype: '',
      //   Iscas: '1',
      //   register: 'false',
      //   bind: 'false'
      // }
      if (res.data.meta.success) {
        this.setState(
          {
            cardId: CardREID,
            timestamp: time,
            data: res.data.data
          },
          () => {
            console.log(this.state.data)
            let {
              totalCount,
              newCount,
              html,
              css,
              js,
              register
            } = this.state.data
            //创建标签准备渲染
            x = document.createElement('script')
            document.documentElement.appendChild(x)
            y = document.createElement('style')
            document.head.appendChild(y)
            let str = ''
            //根据数据渲染 预留js字符串时间差
            if (!totalCount || !newCount) {
              if (register === 'false') {
                str = '<div>邮箱未注册</div>'
              } else {
                str = '<div>数据返回失败，请刷新页面或联系管理员</div>'
              }
            } else {
              if (html) {
                str = html
                  .replace('#{totalCount}', totalCount)
                  .replace('#{newCount}', newCount)
              } else {
                str = ''
              }
            }
            this.setState(
              {
                html: str
              },
              () => {
                this.setState(
                  {
                    css:
                      css &&
                      css.replace(
                        new RegExp('#test', 'g'),
                        '#test' + this.state.timestamp
                      ),
                    js:
                      js &&
                      js.replace(
                        new RegExp('#test', 'g'),
                        '#test' + this.state.timestamp
                      )
                  },
                  () => {
                    //console.log($("#test"))
                    //$("#test").html(str)
                    x.innerHTML = this.state.js
                    y.innerHTML = this.state.css
                    //console.log(document.documentElement)
                  }
                )
              }
            )
          }
        )
      } else {
        message.error({ title: '提示', content: '卡片接口请求失败' })
      }
    })
  }

  //跳转到邮箱登录页面
  herftomailbox = () => {
    mailtest({ cardid: this.state.cardId }).then(res => {
      if (res.data.meta.success) {
        window.open(res.data.data.loginUrl, '_blank')
      } else {
        Modal.error({ title: '提示', content: '跳转邮箱失败' })
      }
    })
  }

  swift = () => {
    this.setState({
      show: false
    })
  }

  swift2 = () => {
    this.setState({
      show2: false
    })
  }

  //鼠标选中 增加高亮
  toggleHover = v => e => {
    let x = this.state.hover
    x[v] = x[v] == 1 ? 0.6 : 1
    this.setState({
      hover: x
    })
  }

  render() {
    const { show, show2, data, id, timestamp } = this.state
    return (
      <div>
        <div
          onMouseEnter={this.toggleHover(2)}
          onMouseLeave={this.toggleHover(2)}
          onClick={this.herftomailbox}
          style={{
            opacity: this.state.hover[2],
            cursor: 'pointer'
            //display: data.Iscas == '1' ? 'block' : 'none'
          }}
          id={'test' + timestamp}
          dangerouslySetInnerHTML={{ __html: this.state.html }}
        ></div>
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <Button
            type="primary"
            onMouseEnter={this.toggleHover(0)}
            onMouseLeave={this.toggleHover(0)}
            style={{
              marginRight: '20px',
              opacity: this.state.hover[0],
              display:
                data.register === 'false' && data.isRegister != '0'
                  ? 'block'
                  : 'none'
            }}
            onClick={() => {
              this.setState({ show: true })
            }}
          >
            注册
          </Button>
          <Modal
            width={750}
            title="邮箱注册"
            visible={show}
            footer={null}
            maskClosable={false}
            onCancel={() => {
              this.setState({ show: false })
            }}
          >
            <Emailregister
              show={show}
              etype={data.etype}
              swift={this.swift}
              cardid={id}
              isRegister={data.isRegister}
              name={data.nickName}
              detail={
                data.isRegister == '1'
                  ? data.url
                  : data.isRegister == '2'
                  ? data.userId + '@' + data.url
                  : data.isRegister == '3'
                  ? data.nickName + '@' + data.url
                  : data.isRegister == '4'
                  ? data.idCard + '@' + data.url
                  : ''
              }
            />
          </Modal>

          <Button
            type="primary"
            onMouseEnter={this.toggleHover(1)}
            onMouseLeave={this.toggleHover(1)}
            style={{
              marginRight: '20px',
              opacity: this.state.hover[1],
              display:
                data.bind === 'false' && data.isBind == '1' ? 'block' : 'none'
            }}
            onClick={() => {
              this.setState({ show2: true })
            }}
          >
            绑定
          </Button>
          <Modal
            width={750}
            title="绑定邮箱"
            visible={show2}
            footer={null}
            maskClosable={false}
            onCancel={() => {
              this.setState({ show2: false })
            }}
          >
            <Emailbind show={show2} swift={this.swift2} />
          </Modal>
          {/* <Button
            onMouseEnter={this.toggleHover(2)}
            onMouseLeave={this.toggleHover(2)}
            onClick={this.herftomailbox}
            style={{
              opacity: this.state.hover[2],
              display: data.Iscas == '1' ? 'block' : 'none'
            }}
          >
            进入邮箱 <Icon type="right" />
          </Button> */}
        </div>
      </div>
    )
  }
}
