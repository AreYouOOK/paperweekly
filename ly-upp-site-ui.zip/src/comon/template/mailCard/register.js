import React, { Component, PropTypes } from 'react'
import { Button, Form, Input, Layout, Tag, TreeSelect, message, Spin, Select, Tree, Icon } from 'antd'

import { connect } from 'react-redux'
import createHistory from 'history/createHashHistory';

import { pwStrength } from '../../../utils/util';
import { emailBinding, emailRegister } from '../../../utils/api';


const TreeNode = Tree.TreeNode;
const history = createHistory();
@connect((state) => {
    const { login } = state
    return { login }
})

@Form.create()

export default class Emailregister extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            emailType: '1',
            deptId: '345',
            color: {
                Lcolor: '#d9d9d9',
                Mcolor: '#d9d9d9',
            Hcolor: '#d9d9d9'
            },
            random: '',
            passMinLen: 8,
            passMaxLen: 50,
            passNum: 0,
            passLetter: 0,
            passSpecial: 0
        }
    }
    
    handleSubmit = (e) => {//提交表单----保存
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if (!err) {
               values.etype=this.props.etype
               values.name=this.props.name
               values.cardid=this.props.cardid
               values.userid? values.userid:values.userid=this.props.detail
                this.setState({
                    detailData: {
                        ...values,
                    }
                }, () => {
                    let _this = this;
                    let params = _this.state.detailData;
                    _this.handleBind(params);
                    
                })
            }
        });
    }

    handleBind = (params) => {//修改
        emailRegister(params).then(res => {
            let { meta, data } = res;
            if (meta.success) {
                if (data == '0') {
                    message.success('邮箱注册成功');
                    this.handleBack();
                }else if(data == '1'){
                    message.success('邮箱注册失败');
                } 
            }else {
                message.error(meta.message);
            }
        });
    }

    handleBack = () => {//返回

       this.props.swift('x')
    }

    //异步校验密码策略
    validatorNewPass = (rule, value, callback) => {
        let { passMinLen, passMaxLen, passNum, passLetter, passSpecial } = this.state;
        let lengthRule = new RegExp("^.{" + passMinLen + "," + passMaxLen + "}$");
        let numRule = new RegExp("^.*\\d{" + passNum + ",}.*$");
        let letterRule = new RegExp("^.*[a-zA-Z]{" + passLetter + ",}.*$");
        let special = new RegExp("^.*[~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]{" + passSpecial + ",}.*$");
        
        if (!lengthRule.test(value)) {
            callback([new Error("密码长度错误,密码长度应在" + passMinLen + "和" + passMaxLen + "之间！")]);
        }
        if (!numRule.test(value)) {
            callback([new Error("密码应至少包含" + passNum + "位数字")]);
        }
        if (!letterRule.test(value)) {
            callback([new Error("密码应至少包含" + passLetter + "位字母")]);
        }
        if (!special.test(value)) {
            callback([new Error("密码应至少包含" + passSpecial + "位特殊字符")]);
        }
        if (/\s/.test(value)) {
            callback([new Error("密码不能包含空格")]);
        }
        callback();
    }

    //校验密码强度
    handleChangePassWord = (e) => {
        let value = e.target.value;
        let color = pwStrength(value);
        this.setState({
            password: value,
            color: color
        })
    }

    validatorComfirmPass = (rule, value, callback) => {
        if (value != null && value != '' && value != undefined) {
          let pass = this.props.form.getFieldValue("password");
          if (value == pass) {
            callback();
          } else {
            callback([new Error("确认密码需要与密码保持一致！")]);
          }
        } else {
          callback();
        }
      }

    componentWillMount() {

        /**queryDeptId().then(res =>{
            let {meta,data} = res;
            if (meta.success) {
                console.log(data)
                let querystring = require("querystring");
                this.setState({
                    deptId: data,
                }) 
            }else{
                message.error(meta.message);
            }
        }); */

    }
    
    render() {
        const { Header, Content, Footer, Sider } = Layout;
        const FormItem = Form.Item;
        const { getFieldDecorator } = this.props.form;
        const {deptId} = this.state;
        return (
           
            <Layout className="main" style={{background:'white'}}>
                <Content className="contentoperateBox">
                    <div className='form_box' style={{display:'flex',justifyContent:'center'}}>
                        <Spin spinning={this.state.loading}>
                            <Form onSubmit={this.handleSubmit}>
    
                               {this.props.isRegister=='1'?<FormItem labelCol={{ span: 5 }}
                                    wrapperCol={{ span: 12 }}
                                    label="邮箱:">
                                    {getFieldDecorator("userid", {
                                        rules: [
                                        {
                                            required: true,
                                            message: "请输入邮箱地址!"
                                        }
                                        ],
                                        validateTrigger: 'submit'
                                    })(<Input style={{ width: 400 }} />)} @ {this.props.detail}
                                </FormItem>:
                                
                                <FormItem labelCol={{ span: 5 }}
                                wrapperCol={{ span: 12 }}
                                label="用户名:">
                                <Input style={{ width: 400 }} disabled value={this.props.detail}/>
                                </FormItem>}

                                <FormItem
                                    labelCol={{ span: 5 }}
                                    wrapperCol={{ span: 12 }}
                                        label="输入密码："
                                        /** extra={
                                            <div>
                                                密码由{passMinLen}-{passMaxLen}个字符组成，区分大小写
                                                （至少含数字{passNum}位、含字母{passLetter}位、含特<br />殊字符{passSpecial}位，不能包含空格）建议使用英文字母加数字或符号的混合密码
                                            </div>
                                        }*/
                                >
                                    {getFieldDecorator("password", {
                                        rules: [
                                        {
                                            required: true,
                                            message: "请输入密码!"
                                        },
                                        {
                                            validator: this.validatorNewPass
                                        }
                                        ],
                                        validateTrigger: 'submit'
                                    })(<Input style={{ width: 400 }} onChange={this.handleChangePassWord} type="password" />)}
                                    <Tag color={this.state.color.Lcolor} style={{ marginLeft: '10px' }}>弱</Tag>
                                    <Tag color={this.state.color.Mcolor}>中</Tag>
                                    <Tag color={this.state.color.Hcolor}>强</Tag>
                                </FormItem>
                                <FormItem labelCol={{ span: 5 }}
                                    wrapperCol={{ span: 12 }} label="确认密码：">
                                    {getFieldDecorator("confirmation", {
                                        rules: [
                                        {
                                            required: true,
                                            message: "与输入密码不一致，请重新输入!"
                                        }, {
                                            validator: this.validatorComfirmPass,
                                        }
                                        ],
                                        validateTrigger: 'submit'
                                    })(<Input style={{ width: 400 }} type="password" />)}
                                </FormItem>
                            </Form>
                            <div className='titleBox_btn' style={{ display:'flex',justifyContent:'center'}}>
                                <Button type="primary" htmlType='submit' onClick={this.handleSubmit} style={{marginRight: '20px'}}>保存</Button>
                                <Button className="commonBtnMarginLeft" onClick={this.handleBack}>返回 </Button>
                            </div>
                        </Spin>
                    </div>
                </Content>
            </Layout>
        )
    }
}
