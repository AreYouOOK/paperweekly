import React, { Component, PropTypes } from 'react'
import { Button, Form, Input, Layout, Switch, TreeSelect, message, Spin, Select, Tree, Icon } from 'antd'

import { connect } from 'react-redux'
import createHistory from 'history/createHashHistory';
import { emailBinding } from '../../../utils/api';



const TreeNode = Tree.TreeNode;
const history = createHistory();
@connect((state) => {
    const { login } = state
    return { login }
})

@Form.create()

export default class Emailbind extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
        }
    }
    
    handleSubmit = (e) => {//提交表单----保存
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if (!err) {
                this.setState({
                    detailData: {
                        ...values,
                    }
                }, () => {
                    let _this = this;
                    let params = _this.state.detailData;
                    _this.handleBind(params);
                    
                })
            }
        });
    }

    handleBind = (params) => {//修改
        emailBinding(params).then(res => {
            let { meta, data } = res;
            if (meta.success) {
                if (data == '0') {
                    message.success('邮箱绑定成功');
                    this.handleBack();
                }else if(data == '1'){
                    message.success('邮箱绑定失败');
                } 
            }else {
                message.error(meta.message);
            }
        });
    }

    handleBack = () => {//返回
        this.props.swift('')
    }

    
    render() {

        const { Header, Content, Footer, Sider } = Layout;
        const FormItem = Form.Item;
        const { getFieldDecorator } = this.props.form;

        return (
           
            <Layout className="main" style={{background:'white'}}>
                <Content className="contentoperateBox">
                    <div className='form_box' style={{display:'flex',justifyContent:'center'}}>
                        <Spin spinning={this.state.loading}>
                            <Form onSubmit={this.handleSubmit}>

                            <FormItem labelCol={{ span: 5 }}
                                    wrapperCol={{ span: 12 }} label="邮箱地址:">
                                {getFieldDecorator("email", {
                                    rules: [
                                    {
                                        required: true,
                                        message: "请输入邮箱地址!"
                                    },{
                                        pattern:/\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/,
                                        message:"邮箱格式不正确"
                                    }
                                    ]
                                })(<Input style={{ width: 400 }} />)}
                            </FormItem>
                            </Form>
                            <div className='titleBox_btn' style={{display:'flex',justifyContent:'center'}}>
                                <Button type="primary" htmlType='submit' onClick={this.handleSubmit} style={{marginRight:'20px'}}>保存</Button>
                                <Button className="commonBtnMarginLeft" onClick={this.handleBack}>返回 </Button>
                            </div>
                        </Spin>
                    </div>
                </Content>
            </Layout>
        )
    }
}
