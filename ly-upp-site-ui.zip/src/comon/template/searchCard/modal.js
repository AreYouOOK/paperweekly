/*
 * @Description: 搜索卡片弹窗
 * @Author: xuqiuting
 * @Date: 2019-08-22 17:31:17
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 14:12:27
 */
import React from "react";
import { connect } from "react-redux";
import Card from "assets/js/lib";
import InerCard from "../index";
import { Scrollbars } from "components";

@connect(state => {
  return { ...state };
})
export default class PoverMadal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {}

  render() {
    const { login, dataSource } = this.props;
    let Component = InerCard[dataSource.commpentName] || Card[dataSource.commpentName];
    return (
        <Scrollbars style={{ height: "400px" }}>
      <Component
        currentLanguage={login.locale}
        modalProps={{}}
        cardProps={dataSource}
        {...this.props}
        {...dataSource}
      />
      </Scrollbars>
    );
  }
}


