/*
 * @Description: 搜索卡片入口
 * @Author: xuqiuting
 * @Date: 2019-08-21 10:30:33
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-03 17:08:23
 */
import React from 'react'
import { connect } from 'react-redux'
import { Input, Popover, message, Modal } from 'antd'
import { downloadApi, searchThemeCard } from 'utils/api'
import PopoverContent from './popover'
import PoverMadal from './modal'
import { getLanguageTitle } from 'utils/util'

const { Search } = Input

@connect(state => {
  return { ...state }
})
export default class SearchCard extends React.Component {
  // 组件要传的参数
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      modalVisible: false,
      hotArr: [],
      searchList: ['服务通知', '待办事项', '我的邮箱', '选课', '课表'],
      searchData: [],
      nodata: [
        {
          typeName: '暂无数据',
          typeLocale: {
            en_US: { typeName: 'No Data' },
            zh_CN: { typeName: '暂无数据' }
          },
          list: []
        }
      ],
      modalProps: {}
    }
  }

  componentDidMount() {
    // 获取搜索数据
    this.getSearchData('')
  }

  // 搜索
  handleSearch = value => {
    this.setState({
      visible: true
    })
    this.search.input.state.value = value
    value = value.replace(/^\s+|\s+$/g, '').trim()
    this.getSearchData(value)
  }

  // 聚焦
  handleFocus = e => {
    let value = this.search.input.state.value || ''
    this.getSearchData(value)
  }

  // 输入改变
  onSearchChange = e => {
    let value = e.target.value
    setTimeout(this.getSearchData(value), 500)
  }

  // 获取数据
  getSearchData = value => {
    const { nodata } = this.state
    let params = {
      pageId: '1',
      searchName: value.replace(/^\s+|\s+$/g, '')
    }
    searchThemeCard(params).then(res => {
      let { data, meta } = res.data
      if (meta.success) {
        // 热门应用
        let arr = this.state.hotArr
        if (value == '' && data) {
          arr = []
          data.map(item => {
            arr = arr.concat(item.list)
          })
          if (arr.length > 5) {
            arr = arr.slice(0, 5)
          }
        }
        this.setState({
          hotArr: arr,
          searchData: data
            ? data.map(item => {
                return {
                  ...item,
                  list: item.list.map(list => {
                    return {
                      imgUrl: list.cardpic
                        ? `${downloadApi}?attachmentId=${list.cardpic}`
                        : null,
                      ...list
                    }
                  })
                }
              })
            : nodata
        })
      } else {
        this.setState({
          searchData: nodata
        })
        message.error(meta.message)
      }
    })
  }

  // 弹窗
  handleModalOk = () => {
    this.setState({
      modalVisible: !this.state.modalVisible
    })
  }

  // 弹窗
  handleModal = item => {
    this.setState({
      modalProps: item,
      modalVisible: true
    })
  }

  // 弹窗显示隐藏控制
  onVisibleChange = visible => {
    this.setState({
      visible: visible
    })
  }

  render() {
    const { visible, searchData, showHistory, hotArr, modalProps } = this.state
    const { localeJson } = this.props.login
    let cardName = getLanguageTitle(
      this.props,
      modalProps.locale,
      'cardName',
      modalProps.cardName
    )
    return (
      <div className="searchCard">
        <Popover
          trigger="click"
          placement="bottom"
          overlayClassName="colorPopover searchCardPopover"
          visible={visible}
          onVisibleChange={this.onVisibleChange}
          content={
            <PopoverContent
              showHistory={showHistory}
              dataSource={searchData}
              handleSearch={this.handleSearch}
              handleModal={this.handleModal}
            />
          }
        >
          <Search
            ref={node => (this.search = node)}
            className={'searchCardInput'}
            placeholder={localeJson.search_card_placeholder}
            onChange={this.onSearchChange}
            onSearch={this.handleSearch}
            onFocus={this.handleFocus}
            onBlur={this.handleBlur}
          />
        </Popover>
        <div className="searchlabel">
          <label className="fixLabel">
            {localeJson.search_card_popular_search}：
          </label>
          {hotArr.map((res, index) => {
            let name = getLanguageTitle(
              this.props,
              res.locale,
              res.cardId ? 'cardName' : 'appName',
              res.cardName || res.appName
            )
            return (
              <label
                className="clickLabel"
                key={index}
                onClick={() => this.handleSearch(name)}
              >
                {name}
              </label>
            )
          })}
        </div>
        <Modal
          title={cardName}
          width={600}
          visible={this.state.modalVisible}
          onOk={this.handleModalOk}
          onCancel={this.handleModalOk}
        >
          <PoverMadal dataSource={modalProps} />
        </Modal>
        <style jsx="true" global="true">{`
          .fixLabel {
            margin-right: 10px;
          }
          .searchCardPopover {
            z-index: 10 !important;
          }
          .searchCard {
            max-width: 600px;
            margin: auto;
          }
          .searchCardInput .ant-input {
            border-radius: 23px;
            height: 46px;
          }
          .searchlabel .clickLabel {
            margin-right: 10px;
            cursor: pointer;
          }
          .searchlabel {
            text-align: center;
            margin: 16px 0;
          }
          .ant-popover-placement-bottom,
          .ant-popover-placement-bottomLeft,
          .ant-popover-placement-bottomRight {
            padding-top: 0;
          }
          .ant-popover-inner {
            border-radius: 20px;
          }
        `}</style>
      </div>
    )
  }
}
