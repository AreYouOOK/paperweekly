/*
 * @Description: 搜索卡片的主题弹窗
 * @Author: xuqiuting
 * @Date: 2019-08-21 19:48:26
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-02 10:38:14
 */
import React from 'react'
import { connect } from 'react-redux'
import { message, Tabs, Tooltip } from 'antd'
import { Scrollbars } from 'components'
import _ from 'lodash'
import { downloadApi } from 'utils/api'
import { getLanguageTitle } from 'utils/util'

const { TabPane } = Tabs

@connect(state => {
  return { ...state }
})
export default class PopoverComponent extends React.Component {
  // 组件要传的参数
  constructor(props) {
    super(props)
    this.state = {
      showHistory: true,
      modalVisible: false,
      tab: 0, // 选择的tab
      dataSource: [
        {
          typeName: '历史搜索',
          typeLocale: {
            en_US: { typeName: 'History Search' },
            zh_CN: { typeName: '历史搜索' }
          },
          list: []
        }
      ]
    }
  }

  // 根据props的值更新state
  static getDerivedStateFromProps(nextProps, prevState) {
    if (!_.isEqual(nextProps.dataSource, prevState.dataSource)) {
      return {
        dataSource: nextProps.dataSource
      }
    }
    return null
  }

  getList = item => {
    const { login } = this.props
    const { localeJson } = login

    return (
      <Scrollbars
        style={{ height: '400px', width: 'calc(100% - 32px)' }}
        autoHide
        className="tabUl"
      >
        {item.list.length > 0 ? (
          item.list.map((res, key) => {
            if (item.type == 'card') {
              return (
                <div
                  key={key}
                  className="searchCardPopverLi"
                  onClick={() => this.props.handleModal(res)}
                >
                  <img
                    className={'iconImg searchCardPopverImg'}
                    src={
                      res.cardIcon
                        ? `${downloadApi}?attachmentId=${res.cardIcon}`
                        : require('assets/images/cardicon.png')
                    }
                    onError={event => {
                      var img = event.nativeEvent.srcElement
                      img.src = require('assets/images/cardicon.png')
                      img.onerror = null
                    }}
                  />
                  <div className="fl searchCardPopverRight">
                    <div>
                      {getLanguageTitle(
                        this.props,
                        res.locale,
                        'cardName',
                        res.cardName
                      )}
                    </div>
                    <Tooltip placement="top" title={res.cardDesc}>
                      <div className="searchCardPopverText textOverflow">
                        {res.cardDesc}
                      </div>
                    </Tooltip>
                  </div>
                </div>
              )
            } else {
              return (
                <div
                  key={key}
                  className="searchCardPopverLi"
                  onClick={() => {
                    // 跳转链接的验证，如果是链接就跳转，不是链接就报出错误
                    let reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/
                    if (reg.test(res.applink) == false) {
                      message.error(localeJson.menu_new_base_url_error)
                    } else {
                      window.open(res.applink, '_blank')
                    }
                  }}
                >
                  <img
                    className={'iconImg searchCardPopverImg'}
                    src={
                      res.appIcon
                        ? `${downloadApi}?attachmentId=${res.appIcon}`
                        : require('assets/images/cardicon.png')
                    }
                    onError={event => {
                      var img = event.nativeEvent.srcElement
                      img.src = require('assets/images/cardicon.png')
                      img.onerror = null
                    }}
                  />
                  <div className="fl searchCardPopverRight">
                    <div>
                      {getLanguageTitle(
                        this.props,
                        res.locale,
                        'appName',
                        res.appName
                      )}
                    </div>
                    <Tooltip placement="top" title={res.remarks}>
                      <div className="searchCardPopverText textOverflow">
                        {res.remarks}
                      </div>
                    </Tooltip>
                  </div>
                </div>
              )
            }
          })
        ) : (
          <div className="nodata">
            <img src={require('assets/images/nodata.png')} />
            <div>{localeJson.nodata}</div>
          </div>
        )}
      </Scrollbars>
    )
  }

  render() {
    const { dataSource } = this.state
    return (
      <div className="searchCardPopver">
        <Tabs defaultActiveKey="0">
          {dataSource.map((item, index) => {
            let titleName = getLanguageTitle(
              this.props,
              item.typeLocale,
              'typeName',
              item.typeName
            )
            return (
              <TabPane tab={titleName} key={index}>
                {this.getList(item)}
              </TabPane>
            )
          })}
        </Tabs>
        <style jsx="true" global="true">{`
          .searchCardPopver .ant-tabs-nav-scroll {
            padding: 0 20px;
          }
          .searchCardPopverRight {
            color: #333;
            font-size: 14px;
            width: calc(100% - 60px);
            padding-top: 5px;
            padding-left: 70px;
          }
          .searchCardPopverRight .searchCardPopverText {
            color: #999;
            font-size: 12px;
          }
          .searchCardPopverLi {
            height: 48px;
            cursor: pointer;
            position: relative;
          }
          .searchCardPopverImg {
            width: 40px;
            height: 40px;
            margin-right: 10px;
            position: absolute;
            left: 0;
          }
          .searchCardPopver {
            width: 600px;
          }
          .searchCardPopver .ant-tabs-nav-wrap {
            min-height: 46px;
          }
          .searchCardPopver .ant-tabs-content {
            margin-bottom: 16px;
            min-height: 200px;
          }
          .searchCardPopverLabel {
            cursor: pointer;
          }
          .tabUl {
            margin-left: 16px;
          }
        `}</style>
      </div>
    )
  }
}
