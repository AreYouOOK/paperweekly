/*
 * @Description: 三列布局
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-14 17:01:06
 */
import React from 'react'
import { Row, Col } from 'antd'
import { DropTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import _ from 'lodash'
import ElementMap from './elementMap'
import { connect } from 'react-redux'

@connect(state => {
  return { ...state }
})
export default class TwoCol extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      component: [],
      pageType: 'home',
      colList: [{ key: 0, span: 8 }, { key: 1, span: 8 }, { key: 2, span: 8 }]
    }
  }

  componentDidMount() {
    this.init(this.props)
  }

  componentWillReceiveProps(nextProps) {
    if (
      !_.isEqual(nextProps.component, this.state.component) ||
      nextProps.pageType != this.state.pageType ||
      nextProps.layout != this.state.layout
    ) {
      this.init(nextProps)
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (
      !_.isEqual(nextProps.component, this.state.component) ||
      nextProps.pageType != this.state.pageType ||
      nextProps.layout != this.props.layout ||
      this.props.page.editPage != nextProps.page.editPage
    ) {
      return true
    } else {
      return false
    }
  }

  // 组件初始化
  init = props => {
    let component = _.cloneDeep(props.component)
    let colList = this.state.colList
    let arr = []
    if (component.length < 1) {
      arr = [
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        }
      ]
    } else if (component.length == 1) {
      arr = [
        {
          componentArea: component[0].componentArea
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        }
      ]
    } else if (component.length == 2) {
      arr = component
      arr.push({ componentArea: [] })
    } else if (component.length > 3) {
      arr = [
        {
          componentArea: component[0].componentArea
        }
      ]
      for (let i = 3; i < component.length; i++) {
        let newComponent = component[i].componentArea.map(res => {
          return {
            ...res,
            parentid: 0
          }
        })
        arr[0].componentArea = [...arr[0].componentArea, ...newComponent]
      }
      arr.push(component[1])
      arr.push(component[2])
    }
    if (arr.length > 0) {
      this.props.operationItem([...arr])
    } else {
      //组装布局
      if (props.layout == 'three_col_3_3_3') {
        colList = [
          { key: 0, span: 8 },
          { key: 1, span: 8 },
          { key: 2, span: 8 }
        ]
      } else if (props.layout == 'three_col_3_4_3') {
        colList = [
          { key: 0, span: 7 },
          { key: 1, span: 10 },
          { key: 2, span: 7 }
        ]
      } else {
        colList = [
          { key: 0, span: 6 },
          { key: 1, span: 12 },
          { key: 2, span: 6 }
        ]
      }

      this.setState({
        colList: colList,
        pageType: props.pageType,
        component: arr.length > 0 ? _.cloneDeep(arr) : _.cloneDeep(component)
      })
    }
  }

  render() {
    const {
      operationItem,
      handleDelete,
      handleHelp,
      handleEdit,
      page
    } = this.props
    const { pageType, component, colList } = this.state
    return (
      <Row style={{ width: '100%', height: '100%' }}>
        {colList.map((res, index) => {
          return (
            <Col key={res.key} span={res.span} style={{ height: '100%' }}>
              <DropTargetWrapper
                pageType={pageType}
                id={res.key}
                page={page}
                // 布局顺序
                dataSource={component}
                areaIndex={res.key}
                style={{ width: '100%' }}
                operationItem={operationItem}
              >
                <ElementMap
                  areaIndex={res.key}
                  dataSource={component}
                  pageType={pageType}
                  handleDelete={handleDelete}
                  handleHelp={handleHelp}
                  handleEdit={handleEdit}
                  operationItem={operationItem}
                />
              </DropTargetWrapper>
            </Col>
          )
        })}
      </Row>
    )
  }
}
