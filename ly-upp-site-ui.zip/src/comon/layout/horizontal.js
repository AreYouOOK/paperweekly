/*
 * @Description: 横向布局
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-20 10:11:11
 */
import React from 'react'
import { Row, Col } from 'antd'
import { connect } from 'react-redux'
import { DropTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import _ from 'lodash'
import ElementMap from './elementMap'

@connect(state => {
  return { ...state }
})
export default class Horizontal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      component: [],
      pageType: 'home',
      modalVisible: false,
      modalType: null,
      modalProps: {}
    }
  }

  componentDidMount() {
    this.init(this.props)
    // console.log("$$$$$$$$$$$$$$$$$$$$$$")
  }

  componentWillReceiveProps(nextPorps) {
    if (
      !_.isEqual(nextPorps.component, this.state.component) ||
      nextPorps.pageType != this.state.pageType
    ) {
      this.init(nextPorps)
      // console.log(")))))))))))))))))))))))))")
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (
      !_.isEqual(nextProps.component, this.state.component) ||
      nextProps.pageType != this.state.pageType ||
      nextProps.layout != this.props.layout ||
      this.props.page.editPage != nextProps.page.editPage
    ) {
      return true
    } else {
      return false
    }
  }

  // 组件初始化
  init = props => {
    let component = _.cloneDeep(props.component)
    let arr = []
    if (component.length < 1) {
      let obj = {
        componentArea: []
      }
      component.push(obj)
    } else if (component.length > 1) {
      arr = [
        {
          componentArea: component[0].componentArea
        }
      ]
      for (let i = 1; i < component.length; i++) {
        let newComponent = component[i].componentArea.map(res => {
          return {
            ...res,
            parentid: 0
          }
        })
        arr[0].componentArea = [...arr[0].componentArea, ...newComponent]
      }
    }
    if (arr.length > 0) {
      this.props.operationItem([...arr])
    } else {
      this.setState({
        pageType: props.pageType,
        component: _.cloneDeep(component)
      })
    }
    // console.log("#####################")
  }

  render() {
    const {
      operationItem,
      handleDelete,
      handleHelp,
      handleEdit,
      page
    } = this.props
    const { pageType, component } = this.state
    return (
      <Row style={{ width: '100%', height: '100%' }}>
        <Col key={1} span={24} style={{ height: '100%' }}>
          <DropTargetWrapper
            pageType={pageType}
            page={page}
            id={0}
            // 布局顺序
            dataSource={component}
            areaIndex={0}
            style={{ width: '100%' }}
            operationItem={operationItem}
          >
            <ElementMap
              areaIndex={0}
              dataSource={component}
              pageType={pageType}
              handleDelete={handleDelete}
              handleHelp={handleHelp}
              handleEdit={handleEdit}
              operationItem={operationItem}
            />
          </DropTargetWrapper>
        </Col>
      </Row>
    )
  }
}
