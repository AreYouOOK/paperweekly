/*
 * @Description: 自由布局
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 13:50:08
 */
import React from "react";
import { connect } from "react-redux";
import { Row } from "antd";
import { DropTargetWrapper } from "comon/DragAndDrop/wrapper_component";
import { WidthProvider, Responsive } from "react-grid-layout";
import _ from "lodash";;
const ResponsiveReactGridLayout = WidthProvider(Responsive);
import systemCard from "comon/template/index";
import { guid } from "utils/util";

@connect(state => {
  return { ...state };
})
export default class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      component: [{ componentArea: [] }],
      pageType: this.props.pageType,
      modalVisible: false,
      modalType: null,
      modalProps: {},
      unique: guid()
    };
  }

  componentDidMount() {
    this.init(this.props);
  }

  componentWillReceiveProps(nextPorps) {
    if (
      !_.isEqual(nextPorps.component, this.state.component) ||
      nextPorps.pageType != this.state.pageType
    ) {
      this.init(nextPorps);
    }
    // 如果编辑状态不太，则重新渲染
    if (nextPorps.page.editPage != this.props.page.editPage) {
      this.setState({
        unique: guid()
      });
    }
  }

  // 组件初始化
  init = props => {
    let component = props.component;
    let arr;
    if (component.length < 1) {
      let obj = {
        componentArea: []
      };
      component.push(obj);
    } else if (component.length > 1) {
      arr = [
        {
          componentArea: component[0].componentArea
        }
      ];
      for (let i = 1; i < component.length; i++) {
        let newComponent = component[i].componentArea.map(res => {
          return {
            ...res,
            parentid: 0
          };
        });
        arr[0].componentArea = [...arr[0].componentArea, ...newComponent];
      }
    }
    if (arr) {
      this.props.operationItem(arr);
    }
    this.setState({
      pageType: props.pageType,
      component: arr ? arr : component
    });
  };

  // 已经放置的组件拖拉回调
  onLayoutChange = (valueArr, oldItem, newItem) => {
    // 防止编辑和删除不能点击
    if (_.isEqual(oldItem, newItem)) {
      return false;
    }
    let id = newItem.i.split("-")[0];
    let parentComponent = this.state.component;
    let component = parentComponent[0].componentArea;
    component.map((item, key) => {
      if (item.id == id) {
        component[key] = {
          ...item,
          ["dataGrid"]: {
            ...newItem,
            i: id
          }
        };
      }
    });
    this.props.operationItem(parentComponent);
  };

  // 屏幕宽度改变，断点改变
  onBreakpointChange = layout => {
  };

  onWidthChange = (containerWidth, margin, cols, containerPadding) => {
  };

  render() {
    const { operationItem, handleDelete, handleEdit,handleHelp, page } = this.props;
    const { pageType, component, unique } = this.state;
    const { editPage } = page;
    return (
      <Row style={{ width: "100%", height: "100%" }}>
        <DropTargetWrapper
          id={0}
          // 布局顺序
          dataSource={component}
          editPage={editPage}
          page={page}
          areaIndex={0}
          style={{ width: "100%", height: "100%" }}
          operationItem={operationItem}
        >
          <ResponsiveReactGridLayout
            className="layout"
            style={{ minHeight: "100%" }}
            key={unique}
            onWidthChange={this.onWidthChange}
            onBreakpointChange={this.onBreakpointChange}
            cols={{ lg: 12, md: 12, sm: 12, xs: 12, xxs: 12 }}
            breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
            onResizeStop={(layout, oldItem, newItem) =>
              this.onLayoutChange(layout, oldItem, newItem)
            }
            onDragStop={(layout, oldItem, newItem) =>
              this.onLayoutChange(layout, oldItem, newItem)
            }
          >
            {this.state.component[0].componentArea.map(res => {
              let Component = systemCard[res.componentName];
              if (
                res.componentName != "SelectCard" &&
                res.componentName != "LayoutCard" &&
                res.componentName != "SelectComponent"
              ) {
                Component = systemCard["CardWraper"];
              }
              let newgrid = {
                ...res.dataGrid,
                isDraggable: editPage ? true : false,
                isResizable: editPage ? true : false
              };
              return (
                <div data-grid={newgrid} key={newgrid.i + "-" + unique}>
                  <Component
                    {...res}
                    editPage={editPage}
                    pageType={pageType}
                    layoutType={"auto"}
                    handleDelete={handleDelete}
                    handleHelp={handleHelp}
                    handleEdit={handleEdit}
                    operationItem={operationItem}
                    areaIndex={0}
                    dataSource={component}
                  ></Component>
                </div>
              );
            })}
          </ResponsiveReactGridLayout>
        </DropTargetWrapper>
      </Row>
    );
  }
}
