/*
 * @Description: 拖曳组件遍历渲染
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-20 10:08:46
 */
import React from 'react'
import { DragSourceTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import { connect } from 'react-redux'
import systemCard from 'comon/template/index'
import _ from 'lodash'

@connect(state => {
  return { ...state }
})
export default class ElementMap extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  shouldComponentUpdate(nextProps, nextState) {
    let object = nextProps.dataSource
    let objectPre = this.props.dataSource
    if (
      this.props.page.editPage != nextProps.page.editPage ||
      !_.isEqual(object, objectPre)
    ) {
      return true
    } else {
      return false
    }
  }

  render() {
    const {
      dataSource,
      areaIndex,
      handleDelete,
      handleHelp,
      pageType,
      handleEdit,
      operationItem,
      page
    } = this.props
    const areaDataSource = dataSource[areaIndex].componentArea
    // 是否禁止编辑
    let editPage = page.editPage
    if (
      dataSource[areaIndex].forbidEdit &&
      dataSource[areaIndex].forbidEdit == '1'
    ) {
      editPage = false
    }
    return (
      <div>
        {areaDataSource.map((res, index) => {
          let newProps = {
            ...res,
            pageType: pageType
          }
          let Component = systemCard[res.componentName]
          if (
            res.componentName != 'SelectCard' &&
            res.componentName != 'LayoutCard' &&
            res.componentName != 'SelectComponent'
          ) {
            Component = systemCard['CardWraper']
          }
          if (
            res.componentName == 'SelectCard' ||
            res.componentName == 'LayoutCard'
          ) {
            return (
              <DragSourceTargetWrapper
                editPage={editPage} // 是否处于编辑状态
                coordinate={['mainArea', index]} // 组件的唯一标志，用于区分其他组件布局
                areaIndex={areaIndex} // 组件的序号
                dataSource={dataSource} // 页面所有组件
                key={res.key} // 组件的key
                props={res} // 组件的属性
                handleDelete={handleDelete} // 删除方法
                handleHelp={handleHelp} // 帮助方法
                operationItem={operationItem} // 操作组件的方法
                handleEdit={handleEdit} // 编辑组件的方法
                pageType={pageType} // 标注属于哪个页面的
              >
                <Component
                  {...newProps}
                  editPage={editPage}
                  coordinate={['mainArea', index]}
                  areaIndex={areaIndex}
                  dataSource={dataSource}
                  key={res.key}
                  handleDelete={handleDelete}
                  handleHelp={handleHelp}
                  operationItem={operationItem}
                  handleEdit={handleEdit}
                />
              </DragSourceTargetWrapper>
            )
          } else {
            return (
              <DragSourceTargetWrapper
                editPage={editPage}
                coordinate={['mainArea', index]}
                areaIndex={areaIndex}
                dataSource={dataSource}
                key={res.key}
                props={res}
                pageType={pageType}
                operationItem={operationItem}
              >
                <Component
                  handleDelete={handleDelete}
                  handleHelp={handleHelp}
                  handleEdit={handleEdit}
                  {...newProps}
                />
              </DragSourceTargetWrapper>
            )
          }
        })}
      </div>
    )
  }
}
