/*
 * @Description: 三行三列布局
 * @Author: xuqiuting
 * @Date: 2019-06-13 15:18:00
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-20 10:09:30
 */
import React from 'react'
import { Row, Col } from 'antd'
import { DropTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import _ from 'lodash'
import { connect } from 'react-redux'
import ElementMap from './elementMap'

@connect(state => {
  return { ...state }
})
export default class ThreeRowThreeCol extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      component: [],
      pageType: 'home',
      colList: [
        { key: 0, span: 8 },
        { key: 1, span: 8 },
        { key: 2, span: 8 }
      ]
    }
  }

  componentDidMount() {
    this.init(this.props)
  }

  componentWillReceiveProps(nextProps) {
    if (
      !_.isEqual(nextProps.component, this.state.component) ||
      nextProps.pageType != this.state.pageType ||
      nextProps.layout != this.props.layout
    ) {
      this.init(nextProps)
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (
      !_.isEqual(nextProps.component, this.state.component) ||
      nextProps.pageType != this.state.pageType ||
      nextProps.layout != this.props.layout ||
      this.props.page.editPage != nextProps.page.editPage
    ) {
      return true;
    } else {
      return false;
    }
  }

  // 组件初始化
  init = props => {
    let component = _.cloneDeep(props.component)
    let colList = this.state.colList
    let arr = []
    if (component.length < 1) {
      arr = [
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        }
      ]
    } else if (component.length == 1) {
      arr = [
        {
          componentArea: component[0].componentArea
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        }
      ]
    } else if (component.length == 2) {
      arr = component
      arr.push({ componentArea: [] })
      arr.push({ componentArea: [] })
      arr.push({ componentArea: [] })
    } else if (component.length == 3) {
      arr = component
      arr.push({ componentArea: [] })
      arr.push({ componentArea: [] })
    } else if (component.length == 4) {
      arr = component
      arr.push({ componentArea: [] })
    }

    //组装布局
    if (props.layout == 'three_row_three_col_3_3_3') {
      colList = [
        { key: 0, span: 8 },
        { key: 1, span: 8 },
        { key: 2, span: 8 }
      ]
    } else if (props.layout == 'three_row_three_col_3_4_3') {
      colList = [
        { key: 0, span: 7 },
        { key: 1, span: 10 },
        { key: 2, span: 7 }
      ]
    } else {
      colList = [
        { key: 0, span: 6 },
        { key: 1, span: 12 },
        { key: 2, span: 6 }
      ]
    }

    if (arr.length > 0) {
      this.props.operationItem(arr)
    } else {
      this.setState({
        colList: colList,
        pageType: props.pageType,
        component: [...component]
      })
    }
  }

  render() {
    const {
      operationItem,
      handleDelete,
      handleHelp,
      handleEdit,
      page
    } = this.props
    const { pageType, colList, component } = this.state
    let style = {}
    // 是都是编辑状态
    if (page.editPage) {
      style = {
        width: '100%',
        minHeight: '100px'
      }
    }
    return (
      <div>
        <Row>
          <Col key={3} span={24}>
            <DropTargetWrapper
              pageType={pageType}
              id={3}
              page={page}
              // 布局顺序
              dataSource={component}
              areaIndex={3}
              style={style}
              operationItem={operationItem}
            >
              <ElementMap
                key={1}
                areaIndex={3}
                dataSource={component}
                pageType={pageType}
                handleDelete={handleDelete}
                handleHelp={handleHelp}
                handleEdit={handleEdit}
                operationItem={operationItem}
              />
            </DropTargetWrapper>
          </Col>
        </Row>
        <Row>
          {colList.map((res, index) => {
            return (
              <Col key={res.key} span={res.span}>
                <DropTargetWrapper
                  pageType={pageType}
                  id={res.key}
                  page={page}
                  // 布局顺序
                  dataSource={component}
                  areaIndex={res.key}
                  style={{ width: '100%', minHeight: '400px' }}
                  operationItem={operationItem}
                >
                  <ElementMap
                    key={res.key}
                    areaIndex={res.key}
                    dataSource={component}
                    pageType={pageType}
                    handleDelete={handleDelete}
                    handleHelp={handleHelp}
                    handleEdit={handleEdit}
                    operationItem={operationItem}
                  />
                </DropTargetWrapper>
              </Col>
            )
          })}
        </Row>
        <Row>
          <Col key={4} span={24}>
            <DropTargetWrapper
              pageType={pageType}
              id={4}
              // 布局顺序
              dataSource={component}
              page={page}
              areaIndex={4}
              style={style}
              operationItem={operationItem}
            >
              <ElementMap
                key={4}
                areaIndex={4}
                dataSource={component}
                pageType={pageType}
                handleDelete={handleDelete}
                handleHelp={handleHelp}
                handleEdit={handleEdit}
                operationItem={operationItem}
              />
            </DropTargetWrapper>
          </Col>
        </Row>
      </div>
    )
  }
}
