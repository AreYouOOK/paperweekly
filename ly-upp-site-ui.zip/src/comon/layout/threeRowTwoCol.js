/*
 * @Description: 三行两列
 * @Author: xuqiuting
 * @Date: 2019-06-13 15:17:28
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-23 18:56:51
 */
import React from "react";
import { Row, Col } from "antd";
import { DropTargetWrapper } from "comon/DragAndDrop/wrapper_component";
import _ from "lodash";
import ElementMap from "./elementMap";
import { connect } from "react-redux";

@connect(state => {
  return { ...state };
})
export default class TwoCol extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      component: [],
      pageType: "home",
      colList: [{ key: 0, span: 12 }, { key: 1, span: 12 }]
    };
  }

  componentDidMount() {
    this.init(this.props);
  }

  componentWillReceiveProps(nextPorps) {
    if (
      !_.isEqual(nextPorps.component, this.state.component) ||
      nextPorps.pageType != this.state.pageType ||
      nextPorps.layout != this.state.layout
    ) {
      this.init(nextPorps);
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (
      !_.isEqual(nextProps.component, this.state.component) ||
      nextProps.pageType != this.state.pageType ||
      nextProps.layout != this.props.layout ||
      this.props.page.editPage != nextProps.page.editPage
    ) {
      return true;
    } else {
      return false;
    }
  }

  // 组件初始化
  init = props => {
    let component = _.cloneDeep(props.component);
    let colList = this.state.colList;
    let arr = [];
    if (component.length < 1) {
      arr = [
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        }
      ];
    } else if (component.length == 1) {
      arr = [
        {
          componentArea: component[0].componentArea
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        },
        {
          componentArea: []
        }
      ];
    } else if (component.length == 2) {
      arr = component;
      arr.push({ componentArea: [] });
      arr.push({ componentArea: [] });
    } else if (component.length == 3) {
      arr = component;
      arr.push({ componentArea: [] });
    } else if (component.length > 4) {
      arr = [
        {
          componentArea: component[0].componentArea
        }
      ];
      for (let i = 4; i < component.length; i++) {
        let newComponent = component[i].componentArea.map(res => {
          return {
            ...res,
            parentid: 0
          };
        });
        arr[0].componentArea = [...arr[0].componentArea, ...newComponent];
      }
      arr.push(component[1]);
      arr.push(component[2]);
      arr.push(component[3]);
    }

    //组装布局
    if (props.layout == "three_row_two_col_3_7") {
      colList = [{ key: 0, span: 7 }, { key: 1, span: 17 }];
    } else if (props.layout == "three_row_two_col_5_5") {
      colList = [{ key: 0, span: 12 }, { key: 1, span: 12 }];
    } else {
      colList = [{ key: 0, span: 17 }, { key: 1, span: 7 }];
    }

    if (arr.length > 0) {
      this.props.operationItem([...arr]);
    }else{
      this.setState({
        colList: colList,
        pageType: props.pageType,
        component: arr.length > 0 ? _.cloneDeep(arr) : _.cloneDeep(component)
      });
    }
  };

  render() {
    const {
      operationItem,
      handleDelete,
      handleHelp,
      handleEdit,
      page
    } = this.props;
    const { pageType, component, colList } = this.state;
    let style = {};
    // 是都处于编辑状态
    if (page.editPage) {
      style = {
        width: "100%",
        minHeight: "100px"
      };
    }
    return (
      <div style={{ width: "100%", height: "100%" }}>
        <Row>
          <Col key={2} span={24}>
            <DropTargetWrapper
              pageType={pageType}
              page={page}
              id={2}
              // 布局顺序
              dataSource={component}
              areaIndex={2}
              style={style}
              operationItem={operationItem}
            >
              <ElementMap
                areaIndex={2}
                dataSource={component}
                pageType={pageType}
                handleDelete={handleDelete}
                handleHelp={handleHelp}
                handleEdit={handleEdit}
                operationItem={operationItem}
              />
            </DropTargetWrapper>
          </Col>
        </Row>
        <Row>
          {colList.map((res, index) => {
            return (
              <Col key={res.key} span={res.span}>
                <DropTargetWrapper
                  pageType={pageType}
                  id={res.key}
                  page={page}
                  // 布局顺序
                  dataSource={component}
                  areaIndex={res.key}
                  style={{ width: "100%", minHeight: "400px" }}
                  operationItem={operationItem}
                >
                  <ElementMap
                    areaIndex={res.key}
                    dataSource={component}
                    pageType={pageType}
                    handleDelete={handleDelete}
                    handleHelp={handleHelp}
                    handleEdit={handleEdit}
                    operationItem={operationItem}
                  />
                </DropTargetWrapper>
              </Col>
            );
          })}
        </Row>
        <Row>
          <Col key={3} span={24}>
            <DropTargetWrapper
              pageType={pageType}
              id={3}
              page={page}
              // 布局顺序
              dataSource={component}
              areaIndex={3}
              style={style}
              operationItem={operationItem}
            >
              <ElementMap
                areaIndex={3}
                dataSource={component}
                pageType={pageType}
                handleDelete={handleDelete}
                handleHelp={handleHelp}
                handleEdit={handleEdit}
                operationItem={operationItem}
              />
            </DropTargetWrapper>
          </Col>
        </Row>
      </div>
    );
  }
}
