/*
 * @Description: 拖曳组件外层包裹
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 13:50:43
 */
import React from "react";
export default class ComponentWraper extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const {
      id,
      children,
      className,
      style,
      onMouseDown,
      onMouseUp,
      onTouchEnd,
      onTouchStart
    } = this.props;
    return (
      <div
        id={id}
        className={className}
        onMouseDown={onMouseDown}
        onMouseUp={onMouseUp}
        onTouchEnd={onTouchEnd}
        onTouchStart={onTouchStart}
        style={style}
      >
        {children}
      </div>
    );
  }
}
