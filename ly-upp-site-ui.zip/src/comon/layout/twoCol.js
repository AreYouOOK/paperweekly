/*
 * @Description: 两列布局
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-20 10:11:19
 */
import React from 'react'
import { Row, Col } from 'antd'
import { DropTargetWrapper } from 'comon/DragAndDrop/wrapper_component'
import _ from 'lodash'
import ElementMap from './elementMap'
import { connect } from 'react-redux'

@connect(state => {
  return { ...state }
})
export default class TwoCol extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      component: [],
      pageType: 'home',
      colList: [
        { key: 0, span: 12 },
        { key: 1, span: 12 }
      ]
    }
  }

  componentDidMount() {
    this.init(this.props)
  }

  componentWillReceiveProps(nextPorps) {
    if (
      !_.isEqual(nextPorps.component, this.state.component) ||
      nextPorps.pageType != this.state.pageType ||
      nextPorps.layout != this.state.layout
    ) {
      this.init(nextPorps)
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (
      !_.isEqual(nextProps.component, this.state.component) ||
      nextProps.pageType != this.state.pageType ||
      nextProps.layout != this.props.layout ||
      this.props.page.editPage != nextProps.page.editPage
    ) {
      return true
    } else {
      return false
    }
  }

  // 组件初始化
  init = props => {
    let colList = this.state.colList
    // 组装组件
    let component = _.cloneDeep(props.component)
    let arr = []
    if (component.length < 1) {
      arr = [
        {
          componentArea: []
        },
        {
          componentArea: []
        }
      ]
    } else if (component.length == 1) {
      arr = [
        {
          componentArea: component[0].componentArea
        },
        {
          componentArea: []
        }
      ]
    } else if (component.length > 2) {
      arr = [
        {
          componentArea: component[0].componentArea
        }
      ]
      for (let i = 2; i < component.length; i++) {
        let newComponent = component[i].componentArea.map(res => {
          return {
            ...res,
            parentid: 0
          }
        })
        arr[0].componentArea = [...arr[0].componentArea, ...newComponent]
      }
      arr.push(component[1])
    }
    if (arr.length > 0) {
      this.props.operationItem([...arr])
    } else {
      //组装布局
      if (props.layout == 'two_col_3_7') {
        colList = [
          { key: 0, span: 7 },
          { key: 1, span: 17 }
        ]
      } else if (props.layout == 'two_col_5_5') {
        colList = [
          { key: 0, span: 12 },
          { key: 1, span: 12 }
        ]
      } else {
        colList = [
          { key: 0, span: 17 },
          { key: 1, span: 7 }
        ]
      }

      this.setState({
        colList: colList,
        pageType: props.pageType,
        component: arr.length > 0 ? _.cloneDeep(arr) : _.cloneDeep(component)
      })
    }
  }

  render() {
    const {
      operationItem,
      handleDelete,
      handleHelp,
      handleEdit,
      page
    } = this.props
    const { pageType, component, colList } = this.state
    return (
      <Row style={{ width: '100%', height: '100%' }}>
        {colList.map((res, index) => {
          return (
            <Col key={res.key} span={res.span} style={{ height: '100%' }}>
              <DropTargetWrapper
                pageType={pageType}
                id={res.key}
                // 布局顺序
                dataSource={component}
                page={page}
                areaIndex={res.key}
                style={{ width: '100%' }}
                operationItem={operationItem}
              >
                <ElementMap
                  areaIndex={res.key}
                  dataSource={component}
                  pageType={pageType}
                  handleDelete={handleDelete}
                  handleHelp={handleHelp}
                  handleEdit={handleEdit}
                  operationItem={operationItem}
                />
              </DropTargetWrapper>
            </Col>
          )
        })}
      </Row>
    )
  }
}
