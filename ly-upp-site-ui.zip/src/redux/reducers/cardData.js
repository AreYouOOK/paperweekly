/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2020-03-20 10:08:13
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-24 11:49:31
 */
import { CARD_REQUEST_DATA, CARD_MODAL_FORM_CHANGE } from '../actions/cardData'

const initState = {
  requestData: {},
  isFormChange: false
}

const cardData = (state = initState, action) => {
  switch (action.type) {
    case CARD_REQUEST_DATA:
      return { ...state, requestData: action.data }
    case CARD_MODAL_FORM_CHANGE:
      return { ...state, isFormChange: action.data }
    default:
      return state
  }
}

export default cardData
