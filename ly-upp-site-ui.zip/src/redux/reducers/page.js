/*
 * @Description: 页面reducers
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-15 17:08:36
 */
import {
  PAGE_ELEMENT,
  CURRENT_PAGE,
  OPEN_SIDER,
  EDIT_PAGE,
  GET_SYSTEM,
  FIRST_MENU,
  SYSTEM_MODE,
  SKIN_DISABLE,
  LAYOUT_DISABLE,
  THEME_DISABLE,
  SAVEAS_DISABLE,
  CARD_DISABLE,
  UPDATE_MY_THEME_LIST,
  PAGE_LOADING
} from '../actions/page'

const initState = {
  //element每个页面的组件、布局以及颜色都在这里配置，每个页面都是一个对象,component表示的是组件，layout是布局，skin是皮肤
  element: sessionStorage.getItem('element')
    ? JSON.parse(sessionStorage.getItem('element'))
    : {},
  // 当前页面
  currentPage: sessionStorage.getItem('currentPage')
    ? sessionStorage.getItem('currentPage')
    : null,
  // 第一个菜单
  firstMenu: sessionStorage.getItem('firstMenu')
    ? sessionStorage.getItem('firstMenu')
    : null,
  // 系统配置，这个系统配置是每个页面的系统配置，由于切换不同页面，系统的导航栏等不一样，用一个全局的变量去切换
  system: sessionStorage.getItem('system')
    ? JSON.parse(sessionStorage.getItem('system'))
    : {},
  // 皮肤是否可以显示
  skinDisable: sessionStorage.getItem('skinDisable')
    ? sessionStorage.getItem('skinDisable')
    : false,
  // 布局是否可以显示
  layoutDisable: sessionStorage.getItem('layoutDisable')
    ? sessionStorage.getItem('layoutDisable')
    : false,
  // 主题是否可以显示
  themeDisable: sessionStorage.getItem('themeDisable')
    ? sessionStorage.getItem('themeDisable')
    : false,
  // 可不可以另存为主题
  saveAsDisable: sessionStorage.getItem('saveAsDisable')
    ? sessionStorage.getItem('saveAsDisable')
    : false,
  // 是否可以添加卡片
  cardDisable: sessionStorage.getItem('cardDisable')
    ? sessionStorage.getItem('cardDisable')
    : false,
  //是否加载中
  loading: false,
  // 打开侧边栏
  openSider: false,
  // 编辑状态
  editPage: false,
  // 设置系统是否是简洁模式
  systemMode: false,
  // 我的主题是否需要更新（删除、编辑、新增）
  myThemeListChange: false
}
const page = (state = initState, action) => {
  switch (action.type) {
    case PAGE_ELEMENT:
      return { ...state, element: action.data }
    case FIRST_MENU:
      return { ...state, firstMenu: action.data }
    case CURRENT_PAGE:
      return { ...state, currentPage: action.data }
    case OPEN_SIDER:
      return { ...state, openSider: action.data }
    case EDIT_PAGE:
      return { ...state, editPage: action.data }
    case GET_SYSTEM:
      return { ...state, system: action.data }
    case SYSTEM_MODE:
      return { ...state, systemMode: action.data }
    case SKIN_DISABLE:
      return { ...state, skinDisable: action.data }
    case LAYOUT_DISABLE:
      return { ...state, layoutDisable: action.data }
    case THEME_DISABLE:
      return { ...state, themeDisable: action.data }
    case SAVEAS_DISABLE:
      return { ...state, saveAsDisable: action.data }
    case CARD_DISABLE:
      return { ...state, cardDisable: action.data }
    case PAGE_LOADING:
      return { ...state, loading: action.data }
    case UPDATE_MY_THEME_LIST:
      return { ...state, myThemeListChange: action.data }
    default:
      return state
  }
}

export default page
