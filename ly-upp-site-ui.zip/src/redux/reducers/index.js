/*
 * @Description: redux文件引入
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-24 09:30:53
 */
import { combineReducers } from 'redux'
import { routerReducer } from 'react-router-redux'

import login from './login'
import page from './page'
import app from './app'
import cardData from './cardData'

const rootReducer = combineReducers({
  routing: routerReducer,
  login,
  page,
  app,
  cardData
})

export default rootReducer
