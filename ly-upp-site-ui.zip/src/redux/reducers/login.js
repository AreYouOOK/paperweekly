/*
 * @Description: file content
 * @Author: liyaochuan
 * @Date: 2019-11-21 17:36:20
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-26 10:08:06
 */
import {
  REQUEST_USERINFO,
  RECEIVE_USERINFO,
  CLEAR_USERINFO,
  GET_MENUS,
  GET_LOCALE,
  GET_LOCALE_JSON,
  GET_SYSTEM_CONFIG,
  SET_SIMULATE_SYSTEM,
  SET_GUIDE_USED,
  RECEIVE_DEFAULTPAGECOLOR
} from '../actions/login'

const initState = {
  // 用户信息
  data: sessionStorage.getItem('userLogin')
    ? JSON.parse(sessionStorage.getItem('userLogin'))
    : null,
  // 菜单
  menus: window.sessionStorage.getItem('menus')
    ? JSON.parse(window.sessionStorage.getItem('menus'))
    : [],
  // 国际化语言
  locale: sessionStorage.getItem('locale')
    ? sessionStorage.getItem('locale')
    : 'zh_CN',
  // 国际化语言对应的JSON
  localeJson: sessionStorage.getItem('localeJson')
    ? JSON.parse(sessionStorage.getItem('localeJson'))
    : window.locale.zh_CN,
  // 系统配置，这个系统配置是后台系统配置，登录的时候拿到后台的配置内容，主要是ico,标题之类
  systemConfig: null,
  // 系统状态，后台系统因为点击模拟系统按钮跳转过来，页面不能操作
  simulateSystem: sessionStorage.getItem('simulateSystem')
    ? sessionStorage.getItem('simulateSystem')
    : false,
  // 是否使用过新手指引
  guideUsed: true
}

const login = (state = initState, action) => {
  switch (action.type) {
    case REQUEST_USERINFO:
      return { ...state, loading: true, data: null }
    case RECEIVE_USERINFO:
      return { ...state, loading: false, data: action.data }
    case CLEAR_USERINFO:
      return { ...state, loading: false, data: null }
    case GET_MENUS:
      return { ...state, menus: action.data }
    case GET_LOCALE:
      return { ...state, locale: action.data }
    case GET_LOCALE_JSON:
      return { ...state, localeJson: action.data }
    case GET_SYSTEM_CONFIG:
      return { ...state, systemConfig: action.data }
    case SET_SIMULATE_SYSTEM:
      return { ...state, simulateSystem: action.data }
    case RECEIVE_DEFAULTPAGECOLOR:
      return { ...state, defaultPageColor: action.data }
    case SET_GUIDE_USED:
      return { ...state, guideUsed: action.data }
    default:
      return state
  }
}

export default login
