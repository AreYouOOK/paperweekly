/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-09-12 18:11:38
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-26 18:17:04
 */
import {
  OPEN_COLLECT_MODAL,
  TOP_FIVE_CHANGE,
  SET_APP_CENTER_COUNT,
  SET_MY_COLLECT_COUNT,
  SET_APP_TYPE_LIST,
  SET_WINDOW_STATE
} from '../actions/app'

const initState = {
  openCollect: false,
  isTopFiveChange: false,
  appCenterCount: 0,
  myCollectCount: 0,
  appType: [],
  ifwinopen: { SelectCard: false, LayoutCard: false }
}

const app = (state = initState, action) => {
  switch (action.type) {
    case OPEN_COLLECT_MODAL:
      return { ...state, openCollect: action.data }
    case TOP_FIVE_CHANGE:
      return { ...state, isTopFiveChange: action.data }
    case SET_APP_CENTER_COUNT:
      return { ...state, appCenterCount: action.data }
    case SET_MY_COLLECT_COUNT:
      return { ...state, myCollectCount: action.data }
    case SET_APP_TYPE_LIST:
      return { ...state, appType: action.data }
    case SET_WINDOW_STATE:
      return { ...state, ifwinopen: action.data }
    default:
      return state
  }
}

export default app
