/*
 * @Description: 登录redux
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-26 10:03:56
 */

export const REQUEST_USERINFO = 'REQUEST_USERINFO'
export const RECEIVE_USERINFO = 'RECEIVE_USERINFO'
export const CLEAR_USERINFO = 'CLEAR_USERINFO'
export const GET_MENUS = 'GET_MENUS'
export const GET_LOCALE = 'GET_LOCALE' // 语言变化
export const GET_LOCALE_JSON = 'GET_LOCALE_JSON' // 语言配置
export const GET_SYSTEM_CONFIG = 'GET_SYSTEM_CONFIG' // 系统配置
export const SET_SIMULATE_SYSTEM = 'SET_SIMULATE_SYSTEM' // 模拟系统
export const RECEIVE_DEFAULTPAGECOLOR = 'RECEIVE_DEFAULTPAGECOLOR' // 默认页面颜色
export const SET_GUIDE_USED = 'SET_GUIDE_USED' // 设置是否已使用过新手指引

// 设置语言
export const setLocale = data => ({
  type: GET_LOCALE,
  data: data
})

// 设置系统配置
export const setSystemConfig = data => ({
  type: GET_SYSTEM_CONFIG,
  data: data
})

// 设置语言配置
export const setLocaleJson = data => ({
  type: GET_LOCALE_JSON,
  data: data
})

// 设置用户模拟状态
export const setSimulateSystem = data => ({
  type: SET_SIMULATE_SYSTEM,
  data: data
})

export const requestUserInfo = () => ({
  type: REQUEST_USERINFO,
  data: null
})

export const clearUserInfo = () => ({
  type: CLEAR_USERINFO,
  data: null
})

export const receiveUserInfo = data => ({
  type: RECEIVE_USERINFO,
  data: data
})

export const receiveDefaultPageColor = data => ({
  type: RECEIVE_DEFAULTPAGECOLOR,
  data: data
})

export const setGuideUsed = data => ({
  type: SET_GUIDE_USED,
  data: data
})

/**
 * @param {Array} data 有权限的菜单集合
 * @returns
 */
export const getMenus = data => {
  return {
    type: GET_MENUS,
    data
  }
}
