/*
 * @Description: 应用相关redux
 * @Author: chenzezhen
 * @Date: 2019-09-12 18:11:34
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-16 15:28:30
 */
export const OPEN_COLLECT_MODAL = 'OPEN_COLLECT_MODAL' // 打开侧边栏我的收藏Modal
export const TOP_FIVE_CHANGE = 'TOP_FIVE_CHANGE' // 左侧收藏列表是否更新
export const SET_APP_CENTER_COUNT = 'SET_APP_CENTER_COUNT' // 应用总数
export const SET_MY_COLLECT_COUNT = 'SET_MY_COLLECT_COUNT' // 收藏总数
export const SET_APP_TYPE_LIST = 'SET_APP_TYPE_LIST' // 设置选中的应用类型（用于服务类型展示卡片点击添加带参）
export const SET_WINDOW_STATE = 'SET_WINDOW_STATE'

export const openCollectModal = data => ({
  type: OPEN_COLLECT_MODAL,
  data
})

export const changeTopFive = data => ({
  type: TOP_FIVE_CHANGE,
  data
})

export const setAppCenterCount = data => ({
  type: SET_APP_CENTER_COUNT,
  data
})

export const setMyCollectCount = data => ({
  type: SET_MY_COLLECT_COUNT,
  data
})

export const setAppTypeList = data => ({
  type: SET_APP_TYPE_LIST,
  data
})

export const setwindowstate = data => ({
  type: SET_WINDOW_STATE,
  data
})
