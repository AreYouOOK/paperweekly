/*
 * @Description: 页面action
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-24 11:49:05
 */

export const CARD_REQUEST_DATA = 'CARD_REQUEST_DATA'
export const CARD_MODAL_FORM_CHANGE = 'CARD_MODAL_FORM_CHANGE'

// 缓存卡片请求数据
export const setCardRequestData = data => ({
  type: CARD_REQUEST_DATA,
  data: data
})
// 卡片弹窗表单改变
export const cardFormChange = data => ({
  type: CARD_MODAL_FORM_CHANGE,
  data: data
})
