/*
 * @Description: 页面action
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-15 17:03:35
 */

export const PAGE_ELEMENT = 'PAGE_ELEMENT'
export const CURRENT_PAGE = 'CURRENT_PAGE'
export const OPEN_SIDER = 'OPEN_SIDER'
export const EDIT_PAGE = 'EDIT_PAGE'
export const GET_SYSTEM = 'GET_SYSTEM' //系统配置
export const FIRST_MENU = 'FIRST_MENU' //第一个菜单
export const SYSTEM_MODE = 'SYSTEM_MODE' //是否简洁模式
export const SKIN_DISABLE = 'SKIN_DISABLE' // 皮肤是否可以显示
export const LAYOUT_DISABLE = 'LAYOUT_DISABLE' // 布局是否可以显示
export const THEME_DISABLE = 'THEME_DISABLE' // 主题是否可以显示
export const SAVEAS_DISABLE = 'SAVEAS_DISABLE' // 可不可以另存为主题
export const CARD_DISABLE = 'CARD_DISABLE' // 是否可以添加组件
export const PAGE_LOADING = 'PAGE_LOADING' // 是否加载中
export const UPDATE_MY_THEME_LIST = 'UPDATE_MY_THEME_LIST'

// 设置当前页面内容
export const setPage = data => ({
  type: PAGE_ELEMENT,
  data: data
})

// 设置第一个菜单
export const setFirstMenu = data => ({
  type: FIRST_MENU,
  data: data
})

// 设置当前页面
export const setCurrentPage = data => ({
  type: CURRENT_PAGE,
  data: data
})

// 设置系统配置
export const setSystem = data => ({
  type: GET_SYSTEM,
  data: data
})

// 设置推移
export const setOpenSider = data => ({
  type: OPEN_SIDER,
  data: data
})

// 设置编辑
export const setEditPage = data => ({
  type: EDIT_PAGE,
  data: data
})

// 简洁模式
export const setMode = data => ({
  type: SYSTEM_MODE,
  data: data
})

// 设置皮肤是否可以编辑
export const setSkinDisable = data => ({
  type: SKIN_DISABLE,
  data: data
})

// 设置布局是否可以编辑
export const setLayoutDisable = data => ({
  type: LAYOUT_DISABLE,
  data: data
})
// 设置主题是否可以编辑
export const setThemeDisable = data => ({
  type: THEME_DISABLE,
  data: data
})

// 设置是否可以另存为主题
export const setSaveASDisable = data => ({
  type: SAVEAS_DISABLE,
  data: data
})

// 设置是否加载中
export const setLoading = data => ({
  type: PAGE_LOADING,
  data: data
})

// 设置是否可以添加组件
export const setCardDisable = data => ({
  type: CARD_DISABLE,
  data: data
})

// 是否更新侧边栏我的主题列表
export const updateMyThemeList = data => ({
  type: UPDATE_MY_THEME_LIST,
  data: data
})
