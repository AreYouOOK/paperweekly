/*
 * @Description: 头部编辑栏
 * @Author: xuqiuting
 * @Date: 2019-06-05 18:20:39
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-05 16:31:34
 */
import React from 'react'
import { connect } from 'react-redux'
import { Modal, Form, message, Button } from 'antd'
import classNames from 'classnames'
import { ImgUpload, LanguageInput } from 'components'
import {
  savePageContent,
  saveTheme,
  getPageContent,
  exitEditPage
} from 'utils/service'
import { setOpenSider, setEditPage } from 'redux/actions/page'
import { async } from 'rxjs/internal/scheduler/async'

const FormItem = Form.Item
@connect(state => {
  return { ...state }
})
@Form.create()
export default class EditTop extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isFullScreen: false, // 是否全屏
      visible: false, // 主题弹窗展示
      locale: {} // 主题国际化属性
    }
  }

  // componentDidMount() {
  //   this.watchFullScreen()
  // }

  // 全屏点击
  handleFullScreen = () => {
    if (!this.state.isFullScreen) {
      this.requestFullScreen()
    } else {
      this.exitFullscreen()
    }
  }

  // 进入全屏
  requestFullScreen = () => {
    // console.log(1111)
    // debugger
    // var de = document.documentElement
    // if (de.requestFullscreen) {
    //   de.requestFullscreen()
    // } else if (de.mozRequestFullScreen) {
    //   de.mozRequestFullScreen()
    // } else if (de.webkitRequestFullScreen) {
    //   de.webkitRequestFullScreen()
    // }
    this.setState({ isFullScreen: true })
    const el = document.documentElement
    const rfs =
      el.requestFullScreen ||
      el.webkitRequestFullScreen ||
      el.mozRequestFullScreen ||
      el.msRequestFullscreen
    if (typeof rfs != 'undefined' && rfs) {
      rfs.call(el)
    }
  }

  // 退出全屏
  exitFullscreen = () => {
    // var de = document
    // if (de.exitFullscreen) {
    //   de.exitFullscreen()
    // } else if (de.mozCancelFullScreen) {
    //   de.mozCancelFullScreen()
    // } else if (de.webkitCancelFullScreen) {
    //   de.webkitCancelFullScreen()
    // }

    this.setState({ isFullScreen: false })
    this.mainExitFullscreen()
  }

  // 主流浏览器退出全屏
  mainExitFullscreen = () => {
    if (document.exitFullscreen) {
      return document.exitFullscreen()
    } else if (document.mozCancelFullScreen) {
      return document.mozCancelFullScreen()
    } else if (document.webkitCancelFullScreen) {
      return document.webkitCancelFullScreen()
    } else if (document.msExitFullscreen) {
      return document.msExitFullscreen()
    }
    return this.ieExitFullscreen()
  }

  // IE低版本浏览器退出全屏
  ieExitFullscreen = () => {
    if (typeof window.ActiveXObject != 'undefined') {
      //这的方法 模拟f11键，使浏览器全屏
      var wscript = new ActiveXObject('WScript.Shell')
      if (wscript != null) {
        wscript.SendKeys('{F11}')
      }
    }
  }

  // 监听fullscreenchange事件
  // watchFullScreen = () => {
  //   const _self = this
  //   document.addEventListener(
  //     'fullscreenchange',
  //     function() {
  //       _self.setState({
  //         isFullScreen: document.fullscreen
  //       })
  //     },
  //     false
  //   )
  //   document.addEventListener(
  //     'mozfullscreenchange',
  //     function() {
  //       _self.setState({
  //         isFullScreen: document.mozFullScreen
  //       })
  //     },
  //     false
  //   )
  //   document.addEventListener(
  //     'webkitfullscreenchange',
  //     function() {
  //       _self.setState({
  //         isFullScreen: document.webkitIsFullScreen
  //       })
  //     },
  //     false
  //   )
  // }

  // 保存页面
  handleSave = () => {
    savePageContent(this.props)
  }

  // 保存主题和页面
  savePageAndTheme = () => {
    const { localeJson } = this.props.login
    this.props.form.validateFields(async (err, values) => {
      if (err) {
        return message.error(localeJson.rules_error)
      } else {
        const isSuccess = await savePageContent(this.props)
        isSuccess && this.saveAsTheme()
      }
    })
  }

  // 仅保存主题
  saveAsTheme = () => {
    const { locale } = this.state
    const { localeJson } = this.props.login
    this.props.form.validateFields((err, values) => {
      if (err) {
        return message.error(localeJson.rules_error)
      } else {
        let newLocale = locale
        newLocale = this.conbineLocale(newLocale, values.nameLocale, 'name')
        newLocale = this.conbineLocale(
          newLocale,
          values.desLocale,
          'description'
        )

        let name = this.checkValueLocale(newLocale, 'name')
        let description = this.checkValueLocale(newLocale, 'description')
        // if (!name || !description) {
        //   message.error(localeJson.theme_description_required)
        //   return
        // }
        values.themeName = name
        values.themeDesc = description

        delete values.nameLocale
        delete values.desLocale
        values.locale = newLocale
        savePageContent(this.props, values, this)
        this.props.form.resetFields()
      }
    })
  }

  // 合并locale
  conbineLocale = (locale, nameLocale, name) => {
    if (!nameLocale) return locale
    let newLocale = locale
    for (let key in nameLocale) {
      if (nameLocale[key] && nameLocale[key][name]) {
        if (newLocale[key]) {
          newLocale[key][name] = nameLocale[key][name]
        } else {
          newLocale[key] = {}
          newLocale[key][name] = nameLocale[key][name]
        }
      }
    }
    return newLocale
  }

  // 主题弹窗展示
  handleTheme = () => {
    this.setState(
      {
        visible: !this.state.visible,
        locale: {}
      },
      () => {
        if (!this.state.visible) {
          this.props.form.resetFields()
        }
      }
    )
  }

  // 退出编辑
  handleExit = () => {
    exitEditPage(this.props) // 退出编辑前先还原
    this.props.dispatch(setEditPage(false))
    this.props.dispatch(setOpenSider(false))
  }

  // 撤回
  handleBack = () => {
    // let pageItem
    // let currentPage = this.props.page.currentPage
    // let menus = JSON.parse(sessionStorage.getItem('menus')) || []
    // for (let i = 0; i < menus.length; i++) {
    //   if (menus[i].pagePath == currentPage) {
    //     pageItem = menus[i]
    //   }
    // }
    // getPageContent(pageItem, this.props)
    exitEditPage(this.props)
  }

  // 验证
  checkValueLocale = (value, type) => {
    const { systemConfig, locale } = this.props.login
    let name
    if (
      value &&
      systemConfig &&
      systemConfig.language &&
      value[systemConfig.language] &&
      value[systemConfig.language][type] &&
      value[systemConfig.language][type] != ''
    ) {
      name = value[systemConfig.language][type]
    } else if (
      value &&
      value[locale] &&
      value[locale][type] &&
      value[locale][type] != ''
    ) {
      name = value[locale][type]
    } else if (
      value &&
      value['zh_CN'] &&
      value['zh_CN'][type] &&
      value['zh_CN'][type] != ''
    ) {
      name = value['zh_CN'][type]
    }
    return name
  }

  render() {
    const { page, login } = this.props
    const { localeJson } = login
    const { isFullScreen, visible } = this.state
    const { getFieldDecorator } = this.props.form
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 16 }
    }
    let languageList = window.locale ? window.locale.list : []

    return (
      <div className={classNames('editTop', { block: page.editPage })}>
        <div className="editTopContent">
          <label onClick={() => this.handleExit()}>
            {localeJson.editTopExit}
          </label>
          <label onClick={() => this.handleBack()}>
            {localeJson.editTopBack}
          </label>
          <label onClick={() => this.handleSave()}>
            {localeJson.editTopSave}
          </label>
          {!page.saveAsDisable && (
            <label style={{ width: 110 }} onClick={() => this.handleTheme()}>
              {localeJson.editTopSaveAsTheme}
            </label>
          )}
          <label onClick={() => this.handleFullScreen()}>
            {isFullScreen
              ? localeJson.editTopExitFullScreen
              : localeJson.editTopFullScreen}
          </label>
        </div>
        <Modal
          width={800}
          destroyOnClose={true}
          title={localeJson.add_theme}
          visible={visible}
          onCancel={this.handleTheme}
          footer={
            <div className="btnContainer">
              <Button onClick={this.handleTheme}>
                {localeJson.add_theme_cancel}
              </Button>
              <Button type="primary" onClick={this.savePageAndTheme}>
                {localeJson.add_theme_save_theme_and_page}
              </Button>
              <Button type="primary" onClick={this.saveAsTheme}>
                {localeJson.add_theme_save_theme_only}
              </Button>
            </div>
          }
        >
          <Form>
            <FormItem {...formItemLayout} label={localeJson.add_theme_name}>
              {getFieldDecorator('nameLocale', {
                initialValue: this.state.locale,
                rules: [
                  {
                    required: true,
                    message: localeJson.add_theme_name_required
                  },
                  {
                    validator: (rule, value, callback) => {
                      console.log(value)
                      let name = this.checkValueLocale(value, 'name')
                      console.log(name)
                      let length = (name && name.length) || 0
                      // let length = name
                      //   ? name.replace(/[^\x00-\xff]/g, '**').length
                      //   : 0
                      if (!length) {
                        callback(localeJson.theme_description_required)
                      }
                      if (length > 50) {
                        callback(localeJson.theme_name_limit)
                      }
                      callback()
                    }
                  }
                ]
              })(
                <LanguageInput
                  localeJson={localeJson}
                  languageList={languageList}
                />
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label={localeJson.add_theme_description}
            >
              {getFieldDecorator('desLocale', {
                initialValue: this.state.locale,
                rules: [
                  // {
                  //   required: true,
                  //   message: localeJson.add_theme_description_required
                  // },
                  {
                    validator: (rule, value, callback) => {
                      let desc = this.checkValueLocale(value, 'description')
                      // let length = name
                      //   ? name.replace(/[^\x00-\xff]/g, '**').length
                      //   : 0
                      let length = (desc && desc.length) || 0
                      // if (!desc) {
                      //   callback(localeJson.theme_description_required)
                      // }
                      if (length > 50) {
                        callback(localeJson.theme_description_limit)
                      }
                      callback()
                    }
                  }
                ]
              })(
                <LanguageInput
                  localeJson={localeJson}
                  languageList={languageList}
                  type="description"
                  inputType="TextArea"
                />
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label={localeJson.add_theme_screenshot}
            >
              {getFieldDecorator('themePic', {})(<ImgUpload imgType="7" />)}
            </FormItem>
          </Form>
        </Modal>
      </div>
    )
  }
}
