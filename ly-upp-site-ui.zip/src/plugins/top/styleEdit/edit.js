/*
 * @Description: 主题高级样式编辑
 * @Author: xuqiuting
 * @Date: 2019-08-19 17:31:57
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-11-07 17:27:56
 */
import React from "react";
import { Row, Col, Form, Select, Checkbox } from "antd";
import { FontList, FontsizeList } from "./../menuSetting/data";
import { ColorInput, CssEditor, ImgUpload } from "components";
import { connect } from "react-redux";

const FormItem = Form.Item;
const Option = Select.Option;

@connect(state => {
  return { ...state };
})
export default class BannerAdd extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      language: "zh_CN", // 当前语言
      locale: {}
    };
  }

  componentDidMount() {
    this.setState({
      language: this.props.login.locale
    });
  }

  render() {
    const { getFieldDecorator } = this.props.form;
    const formItemLayout1 = {
      labelCol: { span: 7 },
      wrapperCol: { span: 17 }
    };
    const { login, page } = this.props;
    const { localeJson } = login;
    const { system } = page;

    return (
      <React.Fragment>
        <Row style={{ fontWeight: 600, marginBottom: 10, marginTop: 20 }}>
          {localeJson.menu_new_advance_bar_style}
        </Row>
        <Row>
          <Col span={8}>
            <FormItem
              {...formItemLayout1}
              label={localeJson.menu_new_advance_fontfamily}
            >
              {getFieldDecorator("navigationFont", {
                initialValue: system.navigationFont
              })(
                <Select>
                  {FontList.map(item => {
                    return (
                      <Option key={item.value} value={item.value}>
                        {localeJson[item.label]}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem
              {...formItemLayout1}
              label={localeJson.menu_new_advance_color}
            >
              {getFieldDecorator("navigationColor", {
                initialValue: system.navigationColor || ""
              })(<ColorInput colorType="hex" />)}
            </FormItem>
          </Col>
          <Col span={8}>
            <FormItem
              {...formItemLayout1}
              label={localeJson.menu_new_advance_size}
            >
              {getFieldDecorator("navigationFontSize", {
                initialValue: system.navigationFontSize
              })(
                <Select>
                  {FontsizeList.map(item => {
                    return (
                      <Option key={item.value} value={item.value}>
                        {item.label}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </FormItem>
          </Col>
        </Row>
        <Row
          style={{
            fontWeight: "600",
            marginBottom: "10px",
            marginTop: "20px"
          }}
        >
          {localeJson.menu_new_advance_backgroud}
        </Row>
        <Row>
          <Col span={4} offset={2}>
            <FormItem>
              {getFieldDecorator("logo", { initialValue: system.logo })(
                <ImgUpload imgType="4" />
              )}
            </FormItem>
            <div style={{ width: "102px", textAlign: "center" }}>
              {localeJson.menu_new_advance_top_logo}
            </div>
          </Col>
          <Col span={4} offset={2}>
            <FormItem>
              {getFieldDecorator("banner", {
                initialValue: system.banner
              })(<ImgUpload imgType="3" />)}
            </FormItem>
            <div style={{ width: "102px", textAlign: "center" }}>
              {localeJson.menu_new_advance_top_banner}
              <FormItem>
                {getFieldDecorator("bannerIsExtend", {
                  valuePropName: "checked",
                  initialValue: ~~system.bannerIsExtend
                })(
                  <Checkbox
                  // checked={this.state.bannerIsExtend == '1' ? true : false}
                  // onChange={e => this.checkBoxChange(e, 'bannerIsExtend')}
                  >
                    {localeJson.menu_new_advance_repeat}
                  </Checkbox>
                )}
              </FormItem>
            </div>
          </Col>
          <Col span={4} offset={2}>
            <FormItem>
              {getFieldDecorator("background", {
                initialValue: system.background
              })(<ImgUpload imgType="5" />)}
            </FormItem>
            <div style={{ width: "102px", textAlign: "center" }}>
              {localeJson.menu_new_advance_main_backgound}
              <FormItem>
                {getFieldDecorator("backgroundIsExtend", {
                  valuePropName: "checked",
                  initialValue: ~~system.backgroundIsExtend
                })(
                  <Checkbox
                  // checked={
                  //   this.state.backgroundIsExtend == '1' ? true : false
                  // }
                  // onChange={e => this.checkBoxChange(e, 'backgroundIsExtend')}
                  >
                    {localeJson.menu_new_advance_repeat}
                  </Checkbox>
                )}
              </FormItem>
            </div>
          </Col>
          <Col span={4} offset={2}>
            <FormItem>
              {getFieldDecorator("footerbackground", {
                initialValue: system.footerbackground
              })(<ImgUpload imgType="8" />)}
            </FormItem>
            <div style={{ width: "102px", textAlign: "center" }}>
              {localeJson.menu_new_advance_footer}
            </div>
          </Col>
        </Row>
        <Row
          style={{
            fontWeight: "600",
            marginBottom: "10px",
            marginTop: "20px"
          }}
        >
          {localeJson.menu_new_advance_custom_style}
        </Row>
        <Row>
          <FormItem>
            {getFieldDecorator("pageMyCss", {
              initialValue: system.pageMyCss || null
            })(<CssEditor />)}
          </FormItem>
        </Row>
        <style jsx="true" global="true">{`
          .ant-form-item {
            margin-bottom: 0 !important;
          }
        `}</style>
      </React.Fragment>
    );
  }
}
