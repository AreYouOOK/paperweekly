/*
 * @Description: 编辑主题高级样式编辑入口
 * @Author: xuqiuting
 * @Date: 2019-08-19 17:37:16
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-15 09:53:42
 */
import React, { Fragment } from 'react'
import { Modal, Form, message, Divider } from 'antd'
import { connect } from 'react-redux'
import { reqSaveThemeAdvanceStyle, reqEditPageCss } from 'utils/api'
import { getThemeContent, getPageContent } from 'utils/service'
import { getHashParam } from 'utils/util'
import _ from 'lodash'
import Edit from './edit'

@connect(state => {
  return { ...state }
})
@Form.create()
export default class StyleEdit extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      width: '90%',
      visible: false,
      loading: false,
      pageId: null // 编辑页面的页面id
    }
  }

  // 高级样式保存
  handleOk = e => {
    e.preventDefault()
    const { loading } = this.state
    if (loading) return
    const { localeJson } = this.props.login
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.setState({ loading: true }, () => {
          this.saveTheme(values)
        })
      } else {
        message.error(localeJson.baseSettingError)
      }
    })
  }

  // 保存主题/页面高级样式
  saveTheme = values => {
    const { backgroundIsExtend, bannerIsExtend, ...rest } = values
    const { login, page } = this.props
    const { localeJson } = login
    const { system } = page
    const pageId = getHashParam('pageId')
    const themeId = getHashParam('themeId')
    // 不传相当于不改，接口会保留之前配置
    let params = {
      // ...system,
      pageTheme: system.pageTheme,
      backgroundIsExtend: ~~backgroundIsExtend ? '1' : '0',
      bannerIsExtend: ~~bannerIsExtend ? '1' : '0',
      ...rest
    }
    if (themeId) {
      reqSaveThemeAdvanceStyle(params).then(res => {
        setTimeout(() => {
          this.setState({ loading: false })
        }, 2000)
        const { data } = res
        if (data.meta.success) {
          message.success(localeJson.api_save_theme_success)
          this.handleCancel()
          getThemeContent(themeId, this.props)
        } else {
          message.error(data.meta.message)
        }
      })
    } else if (pageId) {
      params.pageId = pageId
      reqEditPageCss(params).then(res => {
        setTimeout(() => {
          this.setState({ loading: false })
        }, 2000)
        const { data } = res
        if (data.meta.success) {
          message.success(localeJson.api_save_page_success)
          this.handleCancel()
          getPageContent({ pageId, type: 'editTheme' }, this.props)
        } else {
          message.error(data.meta.message)
        }
      })
    }
  }

  handleCancel = () => {
    this.setState({
      visible: !this.state.visible
    })
  }

  render() {
    const { page, login } = this.props
    const { visible, pageId } = this.state
    const { editPage } = page
    const { localeJson, simulateSystem } = login

    return (
      <Fragment>
        {simulateSystem || editPage ? null : (
          <Fragment>
            <label
              className="label"
              onClick={() => this.setState({ visible: true })}
            >
              <i className={`iconfont topicon iconyemianbianji`} />
              <span className="span">
                {localeJson['menu_new_advance_style']}
              </span>
            </label>
            <Divider type="vertical" />
          </Fragment>
        )}
        <Modal
          className="pageAddModal"
          width={800}
          style={{ animation: 'unset' }}
          bodyStyle={{ padding: '0 24px 12px', height: '710px' }}
          destroyOnClose={true}
          title={localeJson.menu_new_advance_style}
          visible={visible}
          okText={localeJson.editTopSave}
          cancelText={localeJson.back}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <Form>
            <Edit {...this.props} pageId={pageId} />
          </Form>
        </Modal>
      </Fragment>
    )
  }
}
