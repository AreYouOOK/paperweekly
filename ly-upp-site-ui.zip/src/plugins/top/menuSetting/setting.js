/*
 * @Description: 页面列表
 * @Author: xuqiuting
 * @Date: 2019-08-19 17:31:48
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-09 16:44:10
 */
import React, { Fragment } from 'react'
import {
  Icon,
  Row,
  Modal,
  Form,
  Input,
  message,
  Button,
  Tree,
  Tooltip
} from 'antd'
import styles from './index.less'
import { connect } from 'react-redux'
import createHistory from 'history/createHashHistory'
import { reqSavePath, reqDeletePage, reqSortPage } from 'utils/api'
import _ from 'lodash'
import { getPage, setPageStyle } from 'utils/service'
import { arrayMove, getLanguageTitle, guid } from 'utils/util'
import { Scrollbars } from 'components'

const { TreeNode } = Tree
const { confirm } = Modal
var hashHistory = createHistory()

@connect(state => {
  return { ...state }
})
@Form.create()
export default class BannerAdd extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      dataSource: [],
      uuid: guid()
    }
  }

  componentDidMount() {
    this.initData(this.props.login.menus)
  }

  componentWillReceiveProps(nextProps) {
    if (!_.isEqual(nextProps.login.menus, this.state.dataSource)) {
      this.initData(nextProps.login.menus)
    }
  }

  // 初始化数据
  initData = data => {
    let arr = data
      .filter(v => !v.hidden)
      .map(res => {
        return {
          ...res,
          edit: false
        }
      })
    this.setState({
      dataSource: arr,
      uuid: guid()
    })
  }

  onDragEnter = info => {}

  // 排序
  handleSortPgae = values => {
    const { localeJson } = this.props.login
    reqSortPage(values).then(res => {
      const { data } = res
      if (data.meta.success) {
        message.success(localeJson.api_sort_success)
        getPage(this.props.dispatch)
      } else {
        message.error(data.meta.message)
      }
    })
  }

  // 拖曳放置
  onDrop = info => {
    const { localeJson } = this.props.login
    let arr = this.state.dataSource
    const isEdit = arr.find(item => item.edit)
    if (isEdit) {
      return message.warning(localeJson.menu_list_cancel_edit)
    }
    const dropKey = info.node.props.eventKey
    const dragKey = info.dragNode.props.eventKey
    const dropPos = info.node.props.pos.split('-')
    const dropPosition = info.dropPosition - Number(dropPos[dropPos.length - 1])

    // 需求改为不能拖拽成子页面
    let data = [...this.state.dataSource]
    let dragIndex = data.findIndex(item => item.pageId == dragKey)
    let dropIndex = data.findIndex(item => item.pageId == dropKey)

    // 页面拖拽不能越过固定的页面
    let acrossArr = []
    if (dragIndex > dropIndex) {
      acrossArr = data.slice(dropIndex, dragIndex + 1)
    } else if (dragIndex < dropIndex) {
      acrossArr = data.slice(dragIndex, dropIndex + 1)
    }
    if (acrossArr.filter(v => !~~v.isSort).length) {
      return message.warning(localeJson.drag_cross_fixed_page)
    }

    // 不可以拖曳页面
    let dragItem = arr.find(item => item.pageId == dragKey)
    let dropItem = arr.find(item => item.pageId == dropKey)
    if (dragItem.isSort != '1' || dropItem.isSort != '1') {
      // 0是固定 1是可以拖拽
      return message.warning(localeJson.menu_sort_error)
    }

    if (dropPosition == 1 && dragIndex > dropIndex) {
      // 在底部，拖拉源比放置位置后，往上拖
      dropIndex = dropIndex + 1
    } else if (dropPosition != 1 && dragIndex < dropIndex) {
      // 在顶部，拖拉源比放置位置前，往下拖
      dropIndex = dropIndex - 1
    }
    if (dragIndex == dropIndex) {
      return
    }
    data = arrayMove(data, dragIndex, dropIndex)

    this.setState(
      {
        dataSource: data,
        uuid: guid()
      },
      () => {
        let params = data.map((item, index) => {
          return {
            pageId: item.pageId,
            sortNumber: index + 1
          }
        })
        this.handleSortPgae(params)
      }
    )
  }

  // 编辑名字
  handleEdit = item => {
    if (item.isSys == '1') {
      return
    }
    let arr = this.state.dataSource
    const { localeJson } = this.props.login
    const isEdit = arr.find(item => item.edit)
    if (isEdit) {
      return message.warning(localeJson.menu_list_cancel_edit)
    }
    arr.map(res => {
      if (res.pageId == item.pageId) {
        res.edit = res.edit ? false : true
      } else {
        res.edit = false
      }
    })
    this.setState({
      dataSource: arr,
      uuid: guid()
    })
  }

  // 退出编辑名称
  handleCancel = () => {
    let arr = this.state.dataSource.map(res => {
      return {
        ...res,
        edit: false
      }
    })
    this.setState({
      dataSource: arr,
      uuid: guid()
    })
  }

  // 保存编辑名字
  handleSave = item => {
    const value = this.inputRef.state.value
    // 当内容没修改的时候不请求接口
    if (item.pageName == value) {
      this.handleCancel()
    } else {
      const { localeJson } = this.props.login
      if (!value)
        return message.error(localeJson.menu_new_base_pageName_message)
      let param = {
        pageId: item.pageId,
        pageName: value
      }
      reqSavePath(param).then(res => {
        const { data } = res
        if (data.meta.message === 'isPathExist')
          return message.error(localeJson.path_exist_error)
        if (data.meta.message === 'isNameExist')
          return message.error(localeJson.pageName_exist_error)
        if (data.meta.success) {
          message.success(localeJson.api_edit_name_success)
          getPage(this.props.dispatch)
        } else {
          message.error(data.meta.message)
        }
      })
    }
  }

  // 删除
  handleDelete = item => {
    const { localeJson } = this.props.login
    let { firstMenu, element } = this.props.page
    let self = this
    confirm({
      title: localeJson.delete_the_page,
      onOk() {
        let param = {
          pageId: item.pageId
        }
        reqDeletePage(param).then(res => {
          const { data } = res
          if (data.meta.success) {
            message.success(localeJson.api_delete_success)
            getPage(self.props.dispatch)
            hashHistory.push('/' + firstMenu)
            this.props.dispatch(setPageStyle(element[firstMenu]))
          } else {
            message.error(data.meta.message)
          }
        })
      },
      onCancel() {
        console.log('Cancel')
      }
    })
  }

  // 弹窗编辑
  handleModalEdit = id => {
    let arr = this.state.dataSource
    const isEdit = arr.find(item => item.edit)
    const { login } = this.props
    const { localeJson } = login
    if (isEdit) {
      return message.warning(localeJson.menu_list_cancel_edit)
    }
    this.props.addMenu(id)
  }

  render() {
    const { login } = this.props
    const { localeJson } = login
    const { dataSource, uuid } = this.state
    const loop = data =>
      data.map(item => {
        // 要展示的国际化标题
        let localeName = getLanguageTitle(
          this.props,
          item.locales,
          'name',
          item.pageName
        )

        return (
          <TreeNode
            disabled={item.isSort == '0'}
            key={item.pageId}
            title={
              <div>
                <div
                  className={`${styles.flInput} fl`}
                  style={{ width: '60%' }}
                >
                  {item.edit ? (
                    <Fragment>
                      <Icon
                        type={item.isSort == '0' ? 'pushpin' : 'menu'}
                        className="icon"
                        style={{ marginRight: '10px' }}
                      />
                      <Input
                        defaultValue={localeName}
                        style={{ width: 340 }}
                        ref={node => (this.inputRef = node)}
                        onMouseOver={e => e.currentTarget.focus()}
                        suffix={
                          <React.Fragment>
                            <Icon
                              className="icon"
                              type="save"
                              style={{}}
                              onClick={() => this.handleSave(item)}
                            />
                            <Icon
                              className="icon"
                              type="rollback"
                              style={{ marginLeft: '10px' }}
                              onClick={() => this.handleCancel()}
                            />
                          </React.Fragment>
                        }
                      />
                    </Fragment>
                  ) : (
                    <Fragment>
                      <Icon
                        type={item.isSort == '0' ? 'pushpin' : 'menu'}
                        className="icon"
                        style={{ marginRight: '10px' }}
                      />
                      <span
                        style={{ cursor: 'pointer' }}
                        disabled={item.isSort == '1' ? false : true}
                        onClick={() => this.handleEdit(item)}
                      >
                        {localeName}
                      </span>
                    </Fragment>
                  )}
                </div>
                <div
                  className={'fr'}
                  style={{ width: '40%', textAlign: 'right' }}
                >
                  {item.isEdit == '0' ? (
                    <Tooltip
                      placement="top"
                      title={localeJson.page_cannot_edit}
                    >
                      <Icon
                        className="icon grey"
                        type="form"
                        style={{ marginRight: '10px', color: '#999999' }}
                        onClick={() => {}}
                      />
                    </Tooltip>
                  ) : (
                    <Icon
                      className="icon"
                      type="form"
                      style={{ marginRight: '10px' }}
                      onClick={() => this.handleModalEdit(item.pageId)}
                    />
                  )}
                  {item.isDelete == '0' ? (
                    <Tooltip
                      placement="top"
                      title={localeJson.page_cannot_delete}
                    >
                      <Icon
                        className="icon grey"
                        type="delete"
                        style={{ color: '#999999' }}
                        onClick={() => {}}
                      />
                    </Tooltip>
                  ) : (
                    <Icon
                      className="icon"
                      type="delete"
                      onClick={() => this.handleDelete(item)}
                    />
                  )}
                </div>
              </div>
            }
          />
        )
      })
    return (
      <Form className={'sorttingForm'}>
        <Scrollbars style={{ height: 400 }} autoHide>
          <Row style={{ paddingRight: 20 }}>
            <Tree
              className="draggable-tree"
              defaultExpandedKeys={this.state.expandedKeys}
              draggable
              blockNode
              onDragEnter={this.onDragEnter}
              onDrop={this.onDrop}
              key={uuid}
            >
              {loop(dataSource)}
            </Tree>
          </Row>
        </Scrollbars>
        <Row style={{ textAlign: 'center' }}>
          <Button
            className="pageList_addBtn"
            type="primary"
            style={{ marginRight: '20px', marginTop: '20px' }}
            onClick={() => {
              let arr = this.state.dataSource
              const { localeJson } = this.props.login
              const isEdit = arr.find(item => item.edit)
              if (isEdit) {
                return message.warning(localeJson.menu_list_cancel_edit)
              }
              this.props.addMenu('new')
            }}
          >
            {localeJson.menu_add_page}
          </Button>
        </Row>
      </Form>
    )
  }
}
