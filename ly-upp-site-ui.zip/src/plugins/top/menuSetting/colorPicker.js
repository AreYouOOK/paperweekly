/*
 * @Description: 颜色选择器
 * @Author: xuqiuting
 * @Date: 2019-08-19 17:32:13
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-14 18:15:02
 */
import React, { Component } from 'react';
import { SketchPicker } from 'react-color';

export default class ColorPicker extends Component {
    static defaultProps = {
        onChange: () => { },
        onChangeComplete: () => { },
        position: 'bottom',
        handleClose: () => { },
    }

    constructor(props) {
        super();
        this.state = {
            displayColorPicker: false,
            color: props.color,
        };
    }
    componentWillReceiveProps(nextProps) {
        this.setState({
            color: nextProps.color
        });
    }

    handleClick = () => {
        this.setState({ displayColorPicker: !this.state.displayColorPicker });
    };

    handleClose = () => {
        this.props.handleClose();
    };

    handleChange = (color) => {
        this.setState({ color: color.hex });
        this.props.onChange(color.hex, color);
    };

    handleChangeComplete = (color) => {
        this.setState({ color: color.hex });
        this.props.onChangeComplete(color.hex);
    };

    render() {

        return <SketchPicker
            style={{ width: 220 }}
            {...this.props}
            color={this.state.color}
            onChange={this.handleChange}
            onChangeComplete={this.handleChangeComplete}
        />

    }
}
