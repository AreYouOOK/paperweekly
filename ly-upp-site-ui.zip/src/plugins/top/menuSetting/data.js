/*
 * @Description: 新增页面数据配置
 * @Author: xuqiuting
 * @Date: 2019-08-19 17:32:04
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-11-22 15:58:37
 */
// 布局列表
export const layoutList = [
  [
    {
      name: 'horizontal',
      type: 'horizontal',
      img: require('assets/images/layout/horizontal.jpg')
    },
    {
      name: 'two_col_3_7',
      type: 'two_col_3_7',
      img: require('assets/images/layout/two_col_3_7.jpg')
    },
    {
      name: 'two_col_5_5',
      type: 'two_col_5_5',
      img: require('assets/images/layout/two_col_5_5.jpg')
    },
    {
      name: 'two_col_7_3',
      type: 'two_col_7_3',
      img: require('assets/images/layout/two_col_7_3.jpg')
    },
    {
      name: 'three_col_3_3_3',
      type: 'three_col_3_3_3',
      img: require('assets/images/layout/three_col_3_3_3.jpg')
    },
    {
      name: 'three_col_3_4_3',
      type: 'three_col_3_4_3',
      img: require('assets/images/layout/three_col_3_4_3.jpg')
    },
    {
      name: 'three_col_2_5_2',
      type: 'three_col_2_5_2',
      img: require('assets/images/layout/three_col_2_5_2.jpg')
    }
  ],
  [
    {
      name: 'layout_auto',
      type: 'auto',
      img: require('assets/images/layout/auto.jpg')
    },
    {
      name: 'three_row_two_col_3_7',
      type: 'three_row_two_col_3_7',
      img: require('assets/images/layout/three_row_two_col_3_7.jpg')
    },
    {
      name: 'three_row_two_col_5_5',
      type: 'three_row_two_col_5_5',
      img: require('assets/images/layout/three_row_two_col_5_5.jpg')
    },
    {
      name: 'three_row_two_col_7_3',
      type: 'three_row_two_col_7_3',
      img: require('assets/images/layout/three_row_two_col_7_3.jpg')
    },
    {
      name: 'three_row_three_col_3_3_3',
      type: 'three_row_three_col_3_3_3',
      img: require('assets/images/layout/three_row_three_col_3_3_3.jpg')
    },
    {
      name: 'three_row_three_col_3_4_3',
      type: 'three_row_three_col_3_4_3',
      img: require('assets/images/layout/three_row_three_col_3_4_3.jpg')
    },
    {
      name: 'three_row_three_col_2_5_2',
      type: 'three_row_three_col_2_5_2',
      img: require('assets/images/layout/three_row_three_col_2_5_2.jpg')
    }
  ]
]
// 皮肤列表
export const skinList = [
  [
    {
      name: 'technology_blue',
      type: '#1890ff',
      img: require('assets/images/skin/technology_blue.jpg')
    },
    {
      name: 'dawn_blue',
      type: '#69c0ff',
      img: require('assets/images/skin/dawn_blue.jpg')
    },
    {
      name: 'geek_blue',
      type: '#85a5ff',
      img: require('assets/images/skin/geek_blue.jpg')
    },
    {
      name: 'rose_red',
      type: '#f5222d',
      img: require('assets/images/skin/rose_red.jpg')
    },
    {
      name: 'fighting_spirit_red',
      type: '#ff7875',
      img: require('assets/images/skin/fighting_spirit_red.jpg')
    },
    {
      name: 'french_red',
      type: '#ff85c0',
      img: require('assets/images/skin/french_red.jpg')
    },
    {
      name: 'high_gray',
      type: '#262626',
      img: require('assets/images/skin/high_gray.jpg')
    }
  ],
  [
    {
      name: 'vigorous_yellow',
      type: '#ffd666',
      img: require('assets/images/skin/vigorous_yellow.jpg')
    },
    {
      name: 'twilight_yellow',
      type: '#ffc069',
      img: require('assets/images/skin/twilight_yellow.jpg')
    },
    {
      name: 'romantic_purple',
      type: '#b37feb',
      img: require('assets/images/skin/romantic_purple.jpg')
    },
    {
      name: 'lime_green',
      type: '#d3f261',
      img: require('assets/images/skin/lime_green.jpg')
    },
    {
      name: 'aurora_green',
      type: '#95de64',
      img: require('assets/images/skin/aurora_green.jpg')
    },
    {
      name: 'pengmei_orange',
      type: '#ff9c6e',
      img: require('assets/images/skin/pengmei_orange.jpg')
    },
    {
      name: 'hope_green',
      type: '#5cdbd3',
      img: require('assets/images/skin/hope_green.jpg')
    }
  ],
  [
    {
      name: 'skin_auto',
      type: 'auto',
      img: require('assets/images/skin/auto.jpg')
    }
  ]
]
// 字体列表
export const FontList = [
  {
    value: 'SimSun',
    label: 'fontfamily_SimSun'
  },
  {
    value: 'SimHei',
    label: 'fontfamily_SimHei'
  },
  {
    value: 'FangSong',
    label: 'fontfamily_FangSong'
  },
  {
    value: 'KaiTi',
    label: 'fontfamily_KaiTi'
  },
  {
    value: 'Microsoft YaHei',
    label: 'fontfamily_MicrosoftYaHei'
  },
  {
    value: 'LiSu',
    label: 'fontfamily_LiSu'
  },
  {
    value: 'STHeiti',
    label: 'fontfamily_STHeiti'
  },
  {
    value: 'STKaiti',
    label: 'fontfamily_STKaiti'
  },
  {
    value: 'STSong',
    label: 'fontfamily_STSong'
  },
  {
    value: 'STFangsong',
    label: 'fontfamily_STFangsong'
  }
]

// 字体大小列表
export const FontsizeList = [
  {
    value: '12px',
    label: '12px'
  },
  {
    value: '14px',
    label: '14px'
  },
  {
    value: '16px',
    label: '16px'
  },
  {
    value: '18px',
    label: '18px'
  },
  {
    value: '20px',
    label: '20px'
  },
  {
    value: '22px',
    label: '22px'
  }
]
