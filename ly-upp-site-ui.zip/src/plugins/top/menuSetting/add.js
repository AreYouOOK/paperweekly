/*
 * @Description: 添加页面
 * @Author: xuqiuting
 * @Date: 2019-08-19 17:31:57
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-07 11:31:54
 */
import React, { Fragment } from 'react'
import {
  Row,
  Col,
  Form,
  Input,
  message,
  Radio,
  Popover,
  Pagination,
  Select,
  Tabs,
  Checkbox,
  Tooltip,
  Icon
} from 'antd'
import { layoutList, skinList, FontList, FontsizeList } from './data'
import { ColorInput, CssEditor, ImgUpload } from 'components'
import { connect } from 'react-redux'
import ColorPicker from './colorPicker'
import classnames from 'classnames'
import styles from './index.less'
import {
  reqGetAllTheme,
  downloadApi,
  reqGetPageConf,
  reqPagePath
} from 'utils/api'
import { getLanguageTitle } from 'utils/util'

const FormItem = Form.Item
const { TextArea } = Input
const Option = Select.Option
const { TabPane } = Tabs

@connect(state => {
  return { ...state }
})
export default class BannerAdd extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      pageId: this.props.pageId,
      pageType: '1',
      panelType: '1',
      pageTheme: null, //选中的主题
      language: 'zh_CN', // 当前语言
      skin: '', // 选择的皮肤
      layCurrentPage: 1, // 布局分页当前页
      skinCurrentPage: 1, // 布局分页当前页
      pageNum: 1, // 主题分页
      pageSize: 8, //主题分页条数
      themeList: [],
      themeTotal: 0, //主题总共条数
      locale: {}
    }
  }

  componentWillMount() {
    this.setState({
      language: this.props.login.locale
    })
    // 如果有pageId说明是编辑状态
    if (this.props.pageId) {
      this.getPageData()
    } else {
      this.getPagePath()
      this.getThemeList()
    }
  }

  // 点击tab切换
  handleTabChange = e => {
    const value = e.target.value
    if (value == '1') {
      document.querySelector('.pageAddModal .ant-tabs-tab:first-child').click()
    } else if (value == '2') {
      document.querySelector('.pageAddModal .ant-tabs-tab:last-child').click()
    }
  }

  // 获取默认页面路径
  getPagePath = () => {
    const params = {
      type: 1 // 类型(1: 前端路径生成 2:后端路径生成)
    }
    reqPagePath(params).then(async res => {
      const { data, meta } = res.data
      if (!meta.success) throw new Error('获取默认页面路径失败')
      await this.setState({ pagePath: data })
    })
  }

  // 获取页面信息
  getPageData = () => {
    let params = {
      pageId: this.props.pageId
    }
    reqGetPageConf(params).then(res => {
      const { data, meta } = res.data
      if (meta.success) {
        // 设置语言
        let obj = this.setLocale(data.locale)
        this.setState(
          {
            ...data,
            ...obj,
            locale: data.locale || {},
            skin: data.skin ? data.skin : '',
            panelType: data.panelType || '1',
            pageName: data.locale
              ? this.setCurrentName(data.locale)
              : data.pageName
          },
          () => {
            this.getThemeList()
          }
        )
      } else {
        this.getThemeList()
        message.error(meta.message)
      }
    })
  }

  // 设置当前语言页面名称
  setCurrentName = list => {
    for (let key in list) {
      if (key == this.state.language) {
        return list[key].name
      }
    }
  }

  // 设置语言
  setLocale = list => {
    let obj = {}
    for (let key in list) {
      if (list[key]) {
        obj[key] = list[key].name
      }
    }
    return obj
  }

  // 获取主题列表
  getThemeList = () => {
    let params = {
      pageNum: this.state.pageNum,
      pageSize: this.state.pageSize
    }
    reqGetAllTheme(params).then(res => {
      const { data, meta } = res.data
      if (meta.success) {
        this.setState({
          themeList:
            data.list &&
            data.list.map(item => {
              return {
                ...item
              }
            }),
          themeName: this.setThemeName(data) || this.state.themeName,
          themeTotal: data.total
        })
      } else {
        message.error(meta.message)
      }
    })
  }

  // 主题名称转换
  setThemeName = data => {
    let obj =
      data.list &&
      data.list.filter(item => item.themeId == this.state.pageTheme)[0]
    if (obj) {
      let localeName = getLanguageTitle(
        this.props,
        obj.locale,
        'name',
        obj.themeName
      )
      return localeName
    }
  }

  // 页面类型改变
  onChange = e => {
    this.setState({
      pageType: e.target.value
    })
  }

  // 页面面板改变
  handlePanelType = e => {
    this.setState({
      panelType: e.target.value
    })
  }

  handleColorChange = color => {
    this.setState({
      skin: color,
      pageColorName: color
    })
    this.props.form.setFieldsValue({ skin: color })
    this.props.form.setFieldsValue({ pageColorName: color })
  }

  // 是否展示colorPicker
  handleDisplayColor = () => {
    this.setState({
      displayColorPicker: !this.state.displayColorPicker
    })
  }

  // 选择主题
  handleTheme = item => {
    // 特殊判断--当前页面为应用中心页面 只能更改肤色
    const { login } = this.props
    const { localeJson } = login
    const isAppCenterPage = item.pageId === 'lyappCenter'
    if (isAppCenterPage) {
      return message.warning(localeJson.siderBarCurrentPageForbidTheme)
    }

    let localeName = getLanguageTitle(
      this.props,
      item.locale,
      'name',
      item.themeName
    )

    this.setState({
      pageTheme: item.themeId,
      themeName: localeName
    })
    this.props.form.setFieldsValue({ pageTheme: item.themeId })
    this.props.form.setFieldsValue({ themeName: localeName })
  }

  // 改变语言
  handleLanguage = (type, name) => {
    const { locale } = this.state
    this.setState({
      [name]: type
    })
    let value = locale[type] ? locale[type].name : null
    this.props.form.setFieldsValue({ pageName: value })
  }

  // 页面名称改变
  handleInputChange = e => {
    const { language } = this.state
    let value = e.target.value
    let locale = this.state.locale
    locale[language] = locale[language] || {}
    locale[language].name = value
    this.setState({
      locale: locale
    })
  }

  // 设置皮肤
  handleSkin = item => {
    if (item.type == 'auto') {
      this.handleDisplayColor()
    } else {
      this.setState({
        skin: item.type,
        pageColorName: item.name
      })
      this.props.form.setFieldsValue({ skin: item.type })
      this.props.form.setFieldsValue({ pageColorName: item.name })
    }
  }

  // 设置布局
  handleLayout = item => {
    // 特殊判断--当前页面为应用中心页面 只能更改肤色
    const { login } = this.props
    const { localeJson } = login
    const isAppCenterPage = item.pageId === 'lyappCenter'
    if (isAppCenterPage) {
      return message.warning(localeJson.siderBarCurrentPageForbidLayout)
    }
    this.setState({
      layout: item.type,
      layoutName: item.name
    })
    this.props.form.setFieldsValue({ layout: item.type })
    this.props.form.setFieldsValue({ layoutName: item.name })
  }

  // 布局分页
  handleLayPageChange = (current, size) => {
    this.setState({
      layCurrentPage: current
    })
  }

  // 肤色分页
  handleSkinPageChange = (current, size) => {
    this.setState({
      skinCurrentPage: current
    })
  }

  // 主题分页
  handleThemePageChange = (current, size) => {
    this.setState(
      {
        pageNum: current
      },
      () => {
        this.getThemeList()
      }
    )
  }

  // checkbox改变
  checkBoxChange = (e, type) => {
    let value = e.target.checked ? '1' : '0'
    this.setState({
      [type]: value
    })
    this.props.form.setFieldsValue({ [type]: value })
  }

  render() {
    const { getFieldDecorator } = this.props.form
    const {
      pageType,
      panelType,
      language,
      themeList,
      layCurrentPage,
      skinCurrentPage,
      pageColorName
    } = this.state
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 16 }
    }
    const formItemLayout1 = {
      labelCol: { span: 7 },
      wrapperCol: { span: 17 }
    }
    const { login } = this.props
    const { localeJson } = login
    let languageList = window.locale ? window.locale.list : []

    return (
      <Fragment>
        <div style={{ textAlign: 'center' }}>
          <Radio.Group
            onChange={this.handleTabChange}
            buttonStyle="solid"
            defaultValue="1"
          >
            <Radio.Button value="1">
              {localeJson.menu_new_Tab_base}
            </Radio.Button>
            <Radio.Button value="2">
              {localeJson.menu_new_advance_style}
            </Radio.Button>
          </Radio.Group>
        </div>
        <Tabs defaultActiveKey="1" className={styles.themeForm}>
          <TabPane tab={localeJson.menu_new_Tab_base} key="1">
            <FormItem
              {...formItemLayout}
              label={localeJson.menu_new_base_pageName}
              extra={
                <div style={{ marginBottom: '10px' }}>
                  {languageList.map(res => {
                    return (
                      <Tooltip
                        key={res.type}
                        placement="topLeft"
                        title={localeJson[res.tip]}
                      >
                        <div
                          className={'imgdiv'}
                          onClick={() =>
                            this.handleLanguage(res.type, 'language')
                          }
                        >
                          <img src={res.img} />
                          {language == res.type ? (
                            <div className={'circle'} />
                          ) : null}
                        </div>
                      </Tooltip>
                    )
                  })}
                </div>
              }
            >
              {getFieldDecorator('pageName', {
                initialValue: this.state.pageName,
                rules: [
                  {
                    required: true,
                    message: localeJson.menu_new_base_pageName_message
                  }
                ]
              })(
                <Input
                  placeholder={localeJson.menu_new_base_pageName_message}
                  maxLength={25}
                  style={{ width: 380 }}
                  onChange={e => this.handleInputChange(e)}
                />
              )}
            </FormItem>
            <FormItem style={{ display: 'none' }}>
              {getFieldDecorator('locale', {
                initialValue: this.state.locale
              })(<span />)}
            </FormItem>
            {/* {pageType != '3' && ( */}
            <FormItem
              {...formItemLayout}
              label={localeJson.menu_new_base_path}
              // extra={
              //   <div style={{ marginBottom: "10px" }}>
              //     {localeJson.menu_new_base_path_required}
              //   </div>
              // }
            >
              <div style={{ color: 'rgba(0, 0, 0, 0.85)' }}>
                {`${window.location.origin}/#/`}
                {getFieldDecorator('pagePath', {
                  initialValue: this.state.pagePath,
                  rules: [
                    {
                      required: true,
                      message: localeJson.menu_new_base_path_required
                    },
                    {
                      validator: (rule, value, callback) => {
                        if (value.length > 50) {
                          callback(localeJson.menu_new_base_path_length)
                        } else {
                          let reg = /^[0-9a-zA-Z]+$/
                          if (reg.test(value) == false) {
                            callback(localeJson.menu_new_base_path_message)
                          }
                        }
                        callback()
                      }
                    }
                  ]
                })(
                  <Input
                    style={{
                      display: 'inline-block',
                      width: 225,
                      marginLeft: 5
                    }}
                    placeholder={localeJson.menu_new_base_path_placeholder}
                  />
                )}
              </div>
            </FormItem>
            {/* )} */}
            <FormItem
              {...formItemLayout}
              label={localeJson.menu_new_base_pageType}
            >
              {getFieldDecorator('pageType', {
                initialValue: pageType,
                rules: [
                  {
                    required: true
                  }
                ]
              })(
                <Radio.Group onChange={e => this.onChange(e)}>
                  <Radio value="1">
                    {localeJson.menu_new_base_pageType_pannel}
                  </Radio>
                  <Radio value="2">
                    {localeJson.menu_new_base_pageType_iframe}
                  </Radio>
                  <Radio value="3">
                    {localeJson.menu_new_base_pageType_url}
                  </Radio>
                </Radio.Group>
              )}
            </FormItem>
            {pageType == '1' && (
              <FormItem
                {...formItemLayout}
                label={localeJson.menu_new_base_panelType}
              >
                {getFieldDecorator('panelType', {
                  initialValue: panelType || '1',
                  rules: [
                    {
                      required: true
                    }
                  ]
                })(
                  <Radio.Group onChange={e => this.handlePanelType(e)}>
                    <Radio value="1">
                      {localeJson.menu_new_base_panelType_quick}
                    </Radio>
                    <Radio value="2">
                      {localeJson.menu_new_base_panelType_blank}
                    </Radio>
                  </Radio.Group>
                )}
              </FormItem>
            )}
            {/* 快速配置 */}
            {pageType == '1' && panelType == '1' && (
              <Fragment>
                {/* 主题 */}
                <FormItem
                  {...formItemLayout}
                  style={{ display: 'none' }}
                  label={localeJson.theme}
                >
                  {getFieldDecorator('pageTheme', {
                    initialValue: this.state.pageTheme
                  })(<span>{this.state.pageTheme}</span>)}
                </FormItem>
                <FormItem {...formItemLayout} label={localeJson.theme}>
                  {getFieldDecorator('themeName', {
                    initialValue: this.state.themeName,
                    rules: [
                      {
                        required: true,
                        message: themeList.length
                          ? localeJson.menu_new_base_themeName_message
                          : localeJson.menu_new_base_no_theme_message
                      }
                    ]
                  })(
                    <p className="checkInfo">
                      {this.state.themeName ||
                        localeJson.menu_new_base_themeName_message}
                    </p>
                  )}
                </FormItem>
                <div style={{ margin: '0 60px' }}>
                  <ul
                    className={`${styles.containerUl} ${styles.themeUl} containerUl themeUl`}
                  >
                    {themeList.map((res, index) => {
                      // 要展示的国际化标题
                      let localeName = getLanguageTitle(
                        this.props,
                        res.locale,
                        'name',
                        res.themeName
                      )
                      return (
                        <li
                          onClick={() => this.handleTheme(res)}
                          className={classnames(
                            {
                              active: res.themeId == this.state.pageTheme
                            }
                            // "fl"
                          )}
                          key={res.themeId}
                        >
                          {res.themeId == this.state.pageTheme && (
                            <Icon type="check-circle" />
                          )}
                          <img
                            src={
                              res.themePic
                                ? `${downloadApi}?attachmentId=${res.themePic}`
                                : require('assets/images/theme.png')
                            }
                            onError={event => {
                              var img = event.nativeEvent.srcElement
                              img.src = require('assets/images/theme.png')
                              img.onerror = null
                            }}
                          />
                          <Tooltip placement="top" title={localeName}>
                            <div className="textOverflow"> {localeName}</div>
                          </Tooltip>
                          {/* <div > {res.themeName}</div> */}
                        </li>
                      )
                    })}
                  </ul>
                  {themeList.length > 0 && (
                    <div style={{ marginTop: '8px' }}>
                      <Pagination
                        // simple
                        size="small"
                        className="fr"
                        pageSize={this.state.pageSize}
                        style={{ marginRight: '80px' }}
                        defaultCurrent={1}
                        onChange={this.handleThemePageChange}
                        total={this.state.themeTotal}
                      />
                    </div>
                  )}
                </div>
              </Fragment>
            )}
            {/* 空白面板 */}
            {pageType == '1' && panelType == '2' && (
              <Fragment>
                {/* 肤色 */}
                <FormItem
                  {...formItemLayout}
                  label={localeJson.menu_new_base_skin}
                >
                  {getFieldDecorator('pageColorName', {
                    initialValue: pageColorName,
                    rules: [
                      {
                        required: true,
                        message: localeJson.menu_new_base_color_message
                      }
                    ]
                  })(
                    <p className="checkInfo">
                      {pageColorName && pageColorName.indexOf('#') > -1
                        ? // ? pageColorName
                          localeJson.skin_auto
                        : localeJson[pageColorName] ||
                          localeJson.menu_new_base_color_message}
                    </p>
                  )}
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  style={{ display: 'none' }}
                  label="肤色"
                >
                  {getFieldDecorator('skin', { initialValue: this.state.skin })(
                    <span style={{ color: '#3EAAFE' }}>{this.state.skin}</span>
                  )}
                </FormItem>
                <Row>
                  <Col offset={2} span={20}>
                    <ul
                      className={`${styles.containerUl} containerUl clearfix`}
                    >
                      {skinList[skinCurrentPage - 1].map(res => {
                        return (
                          <li
                            onClick={() => this.handleSkin(res)}
                            className="fl"
                            style={{
                              width: '100px'
                            }}
                            key={res.type}
                          >
                            {res.type == 'auto' ? (
                              <Popover
                                overlayClassName="colorPopover"
                                content={
                                  <ColorPicker
                                    type="sketch"
                                    small
                                    color={this.state.skin}
                                    handleClose={() =>
                                      this.handleDisplayColor()
                                    }
                                    presetColors={[
                                      '#F5222D',
                                      '#FA541C',
                                      '#FA8C16',
                                      '#FAAD14',
                                      '#FADB14',
                                      '#A0D911',
                                      '#52C41A',
                                      '#13C2C2',
                                      '#1890FF',
                                      '#2F54EB',
                                      '#722ED1',
                                      '#EB2F96'
                                    ]}
                                    onChangeComplete={color =>
                                      this.handleColorChange(color)
                                    }
                                  />
                                }
                                trigger="click"
                              >
                                <img
                                  className={classnames({
                                    active:
                                      pageColorName &&
                                      pageColorName.indexOf('#') != -1
                                  })}
                                  src={res.img}
                                />
                                <Tooltip
                                  placement="top"
                                  title={localeJson[res.name]}
                                >
                                  <div className="textOverflow">
                                    {' '}
                                    {localeJson[res.name]}
                                  </div>
                                </Tooltip>
                              </Popover>
                            ) : (
                              <Fragment>
                                <img
                                  className={classnames({
                                    active: res.type == this.state.skin
                                  })}
                                  src={res.img}
                                />
                                <Tooltip
                                  placement="top"
                                  title={localeJson[res.name]}
                                >
                                  <div className="textOverflow">
                                    {' '}
                                    {localeJson[res.name]}
                                  </div>
                                </Tooltip>
                              </Fragment>
                            )}
                          </li>
                        )
                      })}
                    </ul>
                    <div style={{ marginTop: '8px' }}>
                      <Pagination
                        // simple
                        size="small"
                        className="fr"
                        style={{ marginRight: '80px' }}
                        defaultCurrent={1}
                        defaultPageSize={5}
                        onChange={this.handleSkinPageChange}
                        total={15}
                      />
                    </div>
                  </Col>
                </Row>
                {/* 布局 */}
                <FormItem {...formItemLayout} label={localeJson.siderBarLayout}>
                  {getFieldDecorator('layoutName', {
                    initialValue: this.state.layoutName,
                    rules: [
                      {
                        required: true,
                        message: localeJson.menu_new_base_layout_message
                      }
                    ]
                  })(
                    <p className="checkInfo">
                      {console.log(this.state.layout)}
                      {localeJson[this.state.layout] ||
                        localeJson.menu_new_base_layout_message}
                    </p>
                  )}
                </FormItem>
                <FormItem
                  {...formItemLayout}
                  style={{ display: 'none' }}
                  label="布局"
                  handleLayout
                >
                  {getFieldDecorator('layout', {
                    initialValue: this.state.layout
                  })(
                    <span style={{ color: '#3EAAFE' }}>
                      {localeJson[this.state.layout]}
                    </span>
                  )}
                </FormItem>
                <Row>
                  <Col offset={2} span={20}>
                    <ul
                      className={`${styles.containerUl} containerUl clearfix`}
                    >
                      {layoutList[layCurrentPage - 1].map(res => {
                        return (
                          <li
                            onClick={() => this.handleLayout(res)}
                            className="fl"
                            key={res.type}
                          >
                            <img
                              className={classnames({
                                active: res.type == this.state.layout
                              })}
                              src={res.img}
                            />
                            <Tooltip
                              placement="top"
                              title={localeJson[res.name]}
                            >
                              <div className="textOverflow">
                                {' '}
                                {localeJson[res.name]}
                              </div>
                            </Tooltip>
                          </li>
                        )
                      })}
                    </ul>
                    <div style={{ marginTop: '8px' }}>
                      <Pagination
                        // simple
                        size="small"
                        className="fr"
                        style={{ marginRight: '80px' }}
                        defaultCurrent={1}
                        defaultPageSize={7}
                        onChange={this.handleLayPageChange}
                        total={14}
                      />
                    </div>
                  </Col>
                </Row>
              </Fragment>
            )}
            {pageType == '2' && (
              <Fragment>
                {/* url地址 */}
                <FormItem
                  {...formItemLayout}
                  label={localeJson.menu_new_base_url}
                >
                  {getFieldDecorator('url', {
                    initialValue: this.state.url,
                    rules: [
                      {
                        required: true,
                        message: localeJson.menu_new_base_url_message
                      },
                      {
                        validator: (rule, value, callback) => {
                          let reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/
                          if (reg.test(value) == false) {
                            callback(localeJson.menu_new_base_url_callback)
                          }
                          callback()
                        }
                      }
                    ]
                  })(<Input maxLength={150} />)}
                </FormItem>
                {/* url地址描述 */}
                <FormItem
                  {...formItemLayout}
                  label={localeJson.menu_new_base_url_description}
                >
                  {getFieldDecorator('urlDes', {
                    initialValue: this.state.urlDes
                  })(<TextArea rows={8} maxLength={50} />)}
                </FormItem>
              </Fragment>
            )}
            {pageType == '3' && (
              <Fragment>
                {/* url地址 */}
                <FormItem
                  {...formItemLayout}
                  label={localeJson.menu_new_base_url}
                >
                  {getFieldDecorator('url', {
                    initialValue: this.state.url,
                    rules: [
                      {
                        required: true,
                        message: localeJson.menu_new_base_url_message
                      },
                      {
                        validator: (rule, value, callback) => {
                          let reg = /(http|ftp|https):\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?/
                          if (reg.test(value) == false) {
                            callback(localeJson.menu_new_base_url_callback)
                          }
                          callback()
                        }
                      }
                    ]
                  })(<Input maxLength={150} />)}
                </FormItem>
                {/* url地址描述 */}
                <FormItem
                  {...formItemLayout}
                  label={localeJson.menu_new_base_url_description}
                >
                  {getFieldDecorator('urlDes', {
                    initialValue: this.state.urlDes
                  })(<TextArea rows={8} maxLength={50} />)}
                </FormItem>
              </Fragment>
            )}
          </TabPane>
          <TabPane tab={localeJson.menu_new_advance_style} key="2">
            <div style={{ padding: '0 90px' }}>
              <Row style={{ fontWeight: '600', marginBottom: '10px' }}>
                {localeJson.menu_new_advance_bar_style}
              </Row>
              <Row>
                <Col span={8}>
                  <FormItem
                    {...formItemLayout1}
                    label={localeJson.menu_new_advance_fontfamily}
                  >
                    {getFieldDecorator('navigationFont', {
                      initialValue: this.state.navigationFont
                    })(
                      <Select>
                        {FontList.map(item => {
                          return (
                            <Option key={item.value} value={item.value}>
                              {localeJson[item.label]}
                            </Option>
                          )
                        })}
                      </Select>
                    )}
                  </FormItem>
                </Col>
                <Col span={8}>
                  <FormItem
                    {...formItemLayout1}
                    label={localeJson.menu_new_advance_color}
                  >
                    {getFieldDecorator('navigationColor', {
                      initialValue: this.state.navigationColor || ''
                    })(<ColorInput colorType="hex" />)}
                  </FormItem>
                </Col>
                <Col span={8}>
                  <FormItem
                    {...formItemLayout1}
                    label={localeJson.menu_new_advance_size}
                  >
                    {getFieldDecorator('navigationFontSize', {
                      initialValue: this.state.navigationFontSize
                    })(
                      <Select>
                        {FontsizeList.map(item => {
                          return (
                            <Option key={item.value} value={item.value}>
                              {item.label}
                            </Option>
                          )
                        })}
                      </Select>
                    )}
                  </FormItem>
                </Col>
              </Row>
              <Row
                style={{
                  fontWeight: '600',
                  marginBottom: '10px',
                  marginTop: '20px'
                }}
              >
                {localeJson.menu_new_advance_backgroud}
              </Row>
              <Row>
                <Col span={4} offset={2}>
                  <FormItem>
                    {getFieldDecorator('logo', {
                      initialValue: this.state.logo
                    })(<ImgUpload imgType="4" />)}
                  </FormItem>
                  <div style={{ width: '102px', textAlign: 'center' }}>
                    {localeJson.menu_new_advance_top_logo}
                  </div>
                </Col>
                <Col span={4} offset={2}>
                  <FormItem>
                    {getFieldDecorator('banner', {
                      initialValue: this.state.banner
                    })(<ImgUpload imgType="3" />)}
                  </FormItem>
                  <div style={{ width: '102px', textAlign: 'center' }}>
                    {localeJson.menu_new_advance_top_banner}
                    <FormItem>
                      {getFieldDecorator('bannerIsExtend', {
                        initialValue: this.state.bannerIsExtend
                      })(
                        <Checkbox
                          checked={
                            this.state.bannerIsExtend == '1' ? true : false
                          }
                          onChange={e =>
                            this.checkBoxChange(e, 'bannerIsExtend')
                          }
                        >
                          {localeJson.menu_new_advance_repeat}
                        </Checkbox>
                      )}
                    </FormItem>
                  </div>
                </Col>
                <Col span={4} offset={2}>
                  <FormItem>
                    {getFieldDecorator('background', {
                      initialValue: this.state.background
                    })(<ImgUpload imgType="5" />)}
                  </FormItem>
                  <div style={{ width: '102px', textAlign: 'center' }}>
                    {localeJson.menu_new_advance_main_backgound}
                    <FormItem>
                      {getFieldDecorator('backgroundIsExtend', {
                        initialValue: this.state.backgroundIsExtend
                      })(
                        <Checkbox
                          checked={
                            this.state.backgroundIsExtend == '1' ? true : false
                          }
                          onChange={e =>
                            this.checkBoxChange(e, 'backgroundIsExtend')
                          }
                        >
                          {localeJson.menu_new_advance_repeat}
                        </Checkbox>
                      )}
                    </FormItem>
                  </div>
                </Col>
                <Col span={4} offset={2}>
                  <FormItem>
                    {getFieldDecorator('footerbackground', {
                      initialValue: this.state.footerbackground
                    })(<ImgUpload imgType="8" />)}
                  </FormItem>
                  <div style={{ width: '102px', textAlign: 'center' }}>
                    {localeJson.menu_new_advance_footer}
                  </div>
                </Col>
              </Row>
              <Row
                style={{
                  fontWeight: '600',
                  marginBottom: '10px',
                  marginTop: '20px'
                }}
              >
                {localeJson.menu_new_advance_custom_style}
              </Row>
              <Row>
                <FormItem>
                  {getFieldDecorator('pageMyCss', {
                    initialValue: this.state.pageMyCss
                      ? this.state.pageMyCss
                      : null
                  })(<CssEditor />)}
                </FormItem>
              </Row>
            </div>
          </TabPane>
        </Tabs>
      </Fragment>
    )
  }
}
