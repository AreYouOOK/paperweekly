/*
 * @Description: 菜单排序
 * @Author: xuqiuting
 * @Date: 2019-08-19 17:37:16
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-15 09:51:06
 */
import React, { Fragment } from 'react'
import { Modal, Form, message, Divider } from 'antd'
import { connect } from 'react-redux'
import { getPage } from 'utils/service'
import { reqSavePath } from 'utils/api'
import _ from 'lodash'

import Add from './add'
import Setting from './setting'

@connect(state => {
  return { ...state }
})
@Form.create()
export default class Banner extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      width: '90%',
      visible: false,
      loading: false,
      settingVisible: false,
      data: [],
      pageId: null, // 编辑页面的页面id
      pageTitle: '新增页面' // 新增页面弹窗标题
    }
  }

  componentDidMount() {
    this.initData(this.props.data)
    if (location.pathname.split('/')[1]) {
      this.props.setTabs(location.pathname.split('/')[1])
    }
  }

  componentWillReceiveProps(nextProps) {
    if (
      !_.isEqual(nextProps.data, this.state.data) ||
      !_.isEqual(nextProps.page.system, this.props.page.system)
    ) {
      this.initData(nextProps.data)
    }
  }

  // 初始化菜单
  initData = data => {
    this.setState({
      data: data
    })
  }

  // 添加菜单
  addMenu = id => {
    const { login } = this.props
    const { localeJson } = login
    let name = localeJson.menu_add_page
    let pageId = null
    if (id != 'new') {
      name = localeJson.menu_edit_page
      pageId = id
    }
    this.setState({
      pageTitle: name,
      pageId: pageId,
      settingVisible: false,
      visible: !this.state.visible
    })
  }

  // 新增页面保存
  handleOk = e => {
    e.preventDefault()
    const { loading } = this.state
    if (loading) return
    const { localeJson } = this.props.login
    this.props.form.validateFields((err, values) => {
      if (!err) {
        // 背景平铺
        if (values.backgroundIsExtend == true) {
          values.backgroundIsExtend = '1'
        } else {
          values.backgroundIsExtend = '0'
        }
        // banner平铺
        if (values.bannerIsExtend == true) {
          values.bannerIsExtend = '1'
        } else {
          values.bannerIsExtend = '0'
        }
        this.setState({ loading: true }, () => {
          this.savePath(values)
        })
      } else {
        message.error(localeJson.baseSettingError)
      }
    })
  }

  // 保存页面
  savePath = values => {
    const {
      skin,
      pageColorName,
      layout,
      layoutName,
      page,
      pageTheme,
      themeName,
      ...rest
    } = values
    const { localeJson } = this.props.login
    // 切换页面面板时用不到的字段需要传空字符串，不传相当于不改，接口会保留之前配置
    let params = {
      ...rest,
      skin: skin || '',
      pageColorName: pageColorName || '',
      layout: layout || '',
      layoutName: layoutName || '',
      page: page || '',
      pageTheme: pageTheme || '',
      themeName: themeName || ''
    }
    if (this.state.pageId) {
      params.pageId = this.state.pageId
    }
    reqSavePath(params).then(res => {
      setTimeout(() => {
        this.setState({ loading: false })
      }, 1000)
      const { data } = res
      if (data.meta.success) {
        if (this.state.pageId) {
          message.success(localeJson.api_edit_page_success)
        } else {
          message.success(localeJson.api_add_page_success)
        }
        this.handleCancel()
        getPage(this.props.dispatch)
      } else {
        if (data.meta.message === 'isPathExist') {
          return message.error(localeJson.path_exist_error)
        } else if (data.meta.message === 'isNameExist') {
          return message.error(localeJson.pageName_exist_error)
        } else {
          message.error(data.meta.message)
        }
      }
    })
  }

  handleCancel = () => {
    this.setState({
      visible: !this.state.visible,
      settingVisible: true
    })
  }

  // 设置
  handleSetting = () => {
    this.setState(
      {
        settingVisible: !this.state.settingVisible
      },
      () => {}
    )
  }

  // 设置保存
  handleSettingOk = () => {}

  render() {
    const { page, login } = this.props
    const { visible, settingVisible, pageTitle, pageId } = this.state
    const { editPage } = page
    const { localeJson, simulateSystem } = login

    return (
      <Fragment>
        {simulateSystem || editPage ? null : (
          <Fragment>
            <label
              id="topBar_pageManage"
              className="label"
              onClick={() => this.handleSetting()}
            >
              <i className={`iconfont topicon iconyemianbianji`} />
              <span className="span">{localeJson['top_page_management']}</span>
            </label>
            <Divider type="vertical" />
          </Fragment>
        )}
        <Modal
          className="pageAddModal"
          width={1030}
          style={{ animation: 'unset' }}
          bodyStyle={{ padding: '0 24px 12px', height: '710px' }}
          destroyOnClose={true}
          visible={visible}
          okText={localeJson.editTopSave}
          cancelText={localeJson.back}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          title={<div className="modalTitle">{pageTitle}</div>}
        >
          <Form>
            <Add {...this.props} pageId={pageId} />
          </Form>
        </Modal>
        <Modal
          width={800}
          className="pageMetuModal"
          destroyOnClose={true}
          title={
            <div className="modalTitle">
              {localeJson.menu_page_list}
              <span
                style={{
                  position: 'absolute',
                  color: '#999',
                  top: 25,
                  left: 20,
                  fontSize: 12
                }}
              >
                ({localeJson.complete_page_sorting})
              </span>
            </div>
          }
          visible={settingVisible}
          onCancel={this.handleSetting}
          footer={null}
          style={{ animation: 'unset' }}
        >
          <Setting {...this.props} addMenu={this.addMenu} />
        </Modal>
      </Fragment>
    )
  }
}
