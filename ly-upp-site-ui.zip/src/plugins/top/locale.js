/*
 * @Description: 语言切换组件
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-14 18:06:10
 */
import React from "react";
import { message, Select } from "antd";
import { connect } from "react-redux";
import { setLocale, setLocaleJson } from "redux/actions/login";
import { reqSaveLocale } from "utils/api";

const { Option } = Select;

@connect(state => {
  return { ...state };
})
export default class Locale extends React.Component {
  constructor() {
    super();
    this.state = {};
  }

  componentDidMount() {
    if (this.props.login && this.props.login.locale) {
      this.setState({
        language: this.props.login.locale
      });
    }
  }

  componentWillReceiveProps(nextprops) {
    if (nextprops.login.locale != this.state.language) {
      this.setState({
        language: nextprops.login.locale
      });
    }
  }

  // 改变语言
  changeLocale = value => {
    this.handleSaveLocale(value);
  };

  // 设置国际化
  handleSaveLocale = name => {
    let params = {
      localeType: name
    };
    let { systemConfig, locale } = this.props.login;
    reqSaveLocale(params).then(res => {
      const { data, meta } = res.data;
      if (meta.success) {
        let localeData = window.locale[name];
        this.props.dispatch(setLocale(name)); //设置语言
        this.props.dispatch(setLocaleJson(localeData)); //设置语言配置
        sessionStorage.setItem("locale", name);
        sessionStorage.setItem("localeJson", JSON.stringify(localeData));
        message.success(localeData.api_locale_success);
        document.title = JSON.parse(systemConfig.mgrTitle)[name];
        systemConfig && JSON.parse(systemConfig.mgrTitle)[name]
          ? JSON.parse(systemConfig.mgrTitle)[name]
          : "服务门户管理平台";
      } else {
        message.error(meta.message);
      }
    });
  };

  render() {
    let dataSource = window.locale ? window.locale.list : [];

    return (
      <Select
        id="topBar_locale"
        size={"small"}
        style={{ marginRight: "10px", width: 78 }}
        onChange={e => this.changeLocale(e)}
        value={this.state.language}
      >
        {dataSource.map(res => {
          return (
            <Option key={res.type} value={res.type}>
              {res.name}
            </Option>
          );
        })}
      </Select>
    );
  }
}
