/*
 * @Description: 顶部信息
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-26 10:19:05
 */
import React from 'react'
import { Menu, Icon, Dropdown, Avatar, Row, Col, Divider, Modal } from 'antd'
import { connect } from 'react-redux'
import classNames from 'classnames'
import { userLogout } from 'utils/service'
import { setMode } from 'redux/actions/page'
import { downloadApi } from 'utils/api'
import { getHashParam, detectAvailableBrowser } from 'utils/util'
import Weather from './weather/index'
import touxiang from '../../../assets/images/Biazfanxmam.png'
import Locale from './locale'
import Setting from './menuSetting/index'
import StyleEdit from './styleEdit/index'
import GuideModal from 'plugins/guide/index.js'

@connect(state => {
  return { ...state }
})
export default class Top extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      username: '',
      isShowTheme: false,
      showGuide: false,
      settingHide: false,
      styleEditShow: false
    }
  }

  componentDidMount() {
    let themeId = getHashParam('themeId')
    let pageId = getHashParam('pageId')
    if (themeId) {
      this.setState({
        settingHide: true
      })
      if (!getHashParam('i')) {
        this.setState({
          styleEditShow: true
        })
      }
    }
    if (pageId) {
      this.setState({
        settingHide: true,
        styleEditShow: true
      })
    }

    // 浏览器第一次访问 检测浏览器弹出提示
    if (!detectAvailableBrowser()){
      // 第一次访问
      if (!sessionStorage.getItem('hasVisitBefore')){
        Modal.warning({
          title: '系统检测到您使用的浏览器或模式不兼容，建议使用谷歌/火狐浏览器或开启极速模式'
        })
        sessionStorage.setItem('hasVisitBefore', '1')
      }   
    }
  }

  componentWillReceiveProps(nextProps) {
    if (
      nextProps.login.guideUsed !== this.props.login.guideUsed &&
      !nextProps.login.guideUsed
    ) {
      this.handleGuide()
    }
  }

  // 退出
  handleClick(e) {
    userLogout(this.props.dispatch)
  }

  // 新手指引
  handleGuide(e) {
    this.setState({ showGuide: true })
  }

  // 我的账号
  handleAccountLocation = url => {
    window.open(url)
  }

  // 简介模式
  handleModle = () => {
    const { systemMode } = this.props.page
    this.props.dispatch(setMode(!systemMode))
  }

  render() {
    const { page, login } = this.props
    const { data, systemConfig, simulateSystem, localeJson } = login
    const { system, systemMode } = page
    const { settingHide, styleEditShow } = this.state
    let backgound = {}
    if (system && system.banner) {
      backgound = {
        backgroundImage: `url(${downloadApi}?attachmentId=${system.banner})`,
        backgroundPosition: 'center center',
        backgroundRepeat:
          system.bannerIsExtend && system.bannerIsExtend == '1'
            ? 'repeat'
            : 'no-repeat'
      }
      if (system.bannerIsExtend != '1') {
        backgound.backgroundSize = '100% 100%'
      }
    }

    const menu = (
      <Menu className="menu">
        {systemConfig && systemConfig.myAccountLocation ? (
          <Menu.Item
            onClick={() =>
              this.handleAccountLocation(systemConfig.myAccountLocation)
            }
          >
            <Icon type="user" />
            {localeJson['top_my_account']}
          </Menu.Item>
        ) : null}
        <Menu.Item key="guide" onClick={() => this.handleGuide()}>
          <Icon type="question-circle" />
          {localeJson['top_guide']}
        </Menu.Item>
        <Menu.Item key="logout" onClick={() => this.handleClick()}>
          <Icon type="logout" />
          {localeJson['top_logout']}
        </Menu.Item>
      </Menu>
    )
    let span =
      system && system.bannerIsExtend && system.bannerIsExtend == '1' ? 24 : 20

    return (
      <React.Fragment>
        <Row className="yui_top">
          {(!(system && system.bannerIsExtend) ||
            (system && system.bannerIsExtend != '1')) && <Col span={2} />}
          <Col span={span}>
            <div
              className={classNames(
                { yui_page_head_banner: system && system.banner },
                'yui_page_head'
              )}
              style={backgound}
            >
              <div className={classNames('clearfix head_top')}>
                <Weather />
                <div className="fr header_right">
                  {systemMode ? (
                    <label
                      id="topBar_conciseMode"
                      onClick={() => this.handleModle()}
                      className="label"
                    >
                      <i className={`iconfont topicon iconputongmoshi`} />
                      <span className="span">
                        {localeJson['top_regular_model']}
                      </span>
                    </label>
                  ) : (
                    <label
                      id="topBar_conciseMode"
                      onClick={() => this.handleModle()}
                      className="label"
                    >
                      <i className={`iconfont topicon iconjianjiemoshi`} />
                      <span className="span">
                        {localeJson['top_concise_model']}
                      </span>
                    </label>
                  )}
                  <Divider type="vertical" />
                  {!settingHide && <Setting />}
                  {styleEditShow && <StyleEdit />}
                  <Locale />
                  <Divider type="vertical" />
                  <Dropdown
                    overlay={simulateSystem || settingHide ? <div></div> : menu}
                  >
                    <span className="avatar_wrap">
                      <Avatar size="small" className="avatar" src={touxiang} />
                      <span className="name">{data && data.userName}</span>
                    </span>
                  </Dropdown>
                </div>
              </div>
              {system && system.banner && (
                <div className="logo">
                  <img
                    src={
                      system && system.logo
                        ? downloadApi + '?attachmentId=' + system.logo
                        : require('assets/images/logo-s.png')
                    }
                    onError={event => {
                      var img = event.nativeEvent.srcElement
                      img.src = require('assets/images/logo-s.png')
                      img.onerror = null
                    }}
                  />
                </div>
              )}
            </div>
          </Col>
          {(!(system && system.bannerIsExtend) ||
            (system && system.bannerIsExtend != '1')) && <Col span={2} />}
        </Row>
        <GuideModal
          visible={this.state.showGuide}
          onClose={() => this.setState({ showGuide: false })}
        />
      </React.Fragment>
    )
  }
}
