/*
 * @Description: 页面尾部
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-15 13:38:28
 */
import React from 'react'
import { connect } from 'react-redux'
import { config } from 'src/app/config/global'

@connect(state => {
  return { ...state }
})
export default class Footer extends React.Component {
  constructor(props) {
    super(props)
    this.state = {}
  }
  render() {
    const { systemConfig } = this.props.login
    // console.log(systemConfig ? systemConfig.mgrFoot : '')
    const content =
      systemConfig &&
      systemConfig.mgrFoot &&
      JSON.parse(systemConfig.mgrFoot)[this.props.login.locale]
        ? JSON.parse(systemConfig.mgrFoot)[this.props.login.locale]
        : `Copyright © 2014-2018 LIANYI TECHNOLOGY CO.,LTD. All Rights Reserved. 联奕科技有限公司(${config.version})`

    return (
      <div
        className="yui-page-footer"
        dangerouslySetInnerHTML={{ __html: content }}
      />
    )
  }
}
