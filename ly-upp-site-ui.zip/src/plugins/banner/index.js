/*
 * @Description: 导航栏
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-14 17:00:58
 */
import React from 'react'
import ReactDOM from 'react-dom'
import { Menu, Row, Col, Form, message, Modal } from 'antd'
import { connect } from 'react-redux'
import classnames from 'classnames'
import _ from 'lodash'
import { getPageContent } from 'utils/service'
import { downloadApi } from 'utils/api'
import { setCurrentPage } from 'redux/actions/page'
import { getLanguageTitle } from 'utils/util'
import { reqGetSystemConfig } from '../../utils/api'

@connect(state => {
  return { ...state }
})
@Form.create()
export default class Banner extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      width: '90%', // 菜单宽度
      paddingLeft: '0',
      data: [], // 菜单列表,
      uppBannerImage: ''
    }
  }

  componentDidMount() {

    this.initData(this.props.data)
    if (location.pathname.split('/')[1]) {
      this.props.setTabs(location.pathname.split('/')[1])
    }
    this.queryForDefaultBannerLogo()
    // this.onWindowResize()
    // window.addEventListener('resize', this.onWindowResize)
  }

  // 对比设置菜单
  componentWillReceiveProps(nextProps) {
    if (
      !_.isEqual(nextProps.data, this.state.data) ||
      !_.isEqual(nextProps.page.system, this.props.page.system)
    ) {
      this.initData(nextProps.data)
      // this.onWindowResize('e', nextProps)
    }
  }

  componentWillUnmount() {
    // window.removeEventListener('resize', this.onWindowResize)
  }

  // 延时获取logo的宽度
  getLogoWidth = () => {
    const { system } = this.props.page
    setTimeout(() => {
      const dom = document.querySelector('.bannerLogo')
      // console.log(111, dom.clientWidth)
      if (dom.clientWidth == 0) {
        setTimeout(() => {
          if (system && !system.banner) {
            this.setState(
              {
                paddingLeft: dom.clientWidth
              },
              () => {
                // console.log('222，加时设置paddingLeft成功')
              }
            )
          }
        }, 100)
      } else {
        if (system && !system.banner) {
          this.setState(
            {
              paddingLeft: dom.clientWidth
            },
            () => {
              // console.log('222，设置paddingLeft成功')
            }
          )
        }
      }
    }, 300)
  }

  queryForDefaultBannerLogo = () => {
    reqGetSystemConfig().then(res => {
      if (res.data.meta) {
        this.setState({
          uppBannerImage:
            res.data.data &&
            res.data.data.filter(item => item.configKey == 'uppBannerImage')
              .length
              ? res.data.data.filter(
                  item => item.configKey == 'uppBannerImage'
                )[0].configValue
              : ''
        })
      }
    })
  }

  // 屏幕宽度改变，重新设置菜单宽度
  onWindowResize = (e, nextProps) => {
    let system = this.props.page.system
    if (nextProps) {
      system = nextProps.page.system
    }
    let width = '90%'
    let paddingLeft = '0'
    // let contentCol = this.refs.contentCol
    // if (contentCol) {
    //   contentCol = ReactDOM.findDOMNode(contentCol)
    //   if (system) {
    //     if (!system.banner) {
    //       // let logoImgContent = this.refs.logoImg
    //       let logoImgContent = this.logoImg
    //       console.log('this.logoImg', this.logoImg.clientWidth)
    //       if (logoImgContent) {
    //         logoImgContent = ReactDOM.findDOMNode(logoImgContent)
    //         width = contentCol.clientWidth - logoImgContent.clientWidth - 60
    //         width = width + 'px'
    //       }
    //     }
    //   } else {
    //     width = contentCol.clientWidth
    //     width = width + 'px'
    //   }
    // }
    if (system) {
      if (!system.banner) {
        // let logoImgContent = this.refs.logoImg
        const logoDom = document.querySelector('.bannerLogo')
        if (logoDom) {
          let logoW = logoDom.clientWidth
          paddingLeft = logoW + 'px'
        }
        width = '100%'
      }
    } else {
      width = contentCol.clientWidth
      width = width + 'px'
    }
    this.setState({
      width: width,
      paddingLeft: paddingLeft
    })
  }

  // 初始化菜单
  initData = data => {
    this.setState({
      data: data
    })
  }

  // 设置当前语言页面名称
  setCurrentName = list => {
    const { locale } = this.props.login
    for (let key in list) {
      if (key == locale) {
        return list[key].name
      }
    }
  }

  // 菜单点击
  handleClick = e => {
    const { page, login } = this.props
    const { editPage } = page
    if (editPage) {
      message.warning(login.localeJson.menu_tab_tip)
    } else {
      const { data } = this.props
      // console.log('menus click', data)
      // 设置当前页面
      this.props.dispatch(setCurrentPage(e.key))
      sessionStorage.setItem('currentPage', e.key)
      this.props.setTabs(e.key)
      for (let i = 0; i < data.length; i++) {
        // 新建的外链页面，pagePath为null
        if (!data[i].pagePath && data[i].pageType == '3') {
          window.open(data[i].url)
          break
        }
        if (data[i].type == e.key) {
          if (data[i].pageType == '3') {
            window.open(data[i].url)
          } else {
            getPageContent(data[i], this.props)
          }
          break
        }
      }
    }
  }

  // 导航栏高度设置
  setBannerStyle = () => {
    const { system, systemMode, editPage } = this.props.page
    // 没有banner的高度的头部为30,有baner的头部120，编辑头部高度为54，菜单高度54；头部包括白条头部和菜单
    let headHeight = 30,
      bannerHeadHeight = 120,
      editHeadHeight = 48,
      menuHeight = 54,
      wrapperTop = 0,
      top
    // 导航栏最外层样式
    let bannerStyle = {}
    // 处于编辑状态
    if (editPage) {
      wrapperTop = editHeadHeight
    }
    // 如果有banner
    if (system && system.banner) {
      top = bannerHeadHeight
      wrapperTop = wrapperTop + bannerHeadHeight + menuHeight
    } else {
      top = headHeight
      wrapperTop = wrapperTop + headHeight + menuHeight
    }
    // 如果有是简洁模式
    if (systemMode) {
      top = -wrapperTop
    } else {
      top = top
    }
    bannerStyle = {
      top: top,
      visibility: this.props.page.loading ? 'hidden' : 'visible'
    }
    return bannerStyle
  }

  render() {
    const { location, page } = this.props
    const { data, width, paddingLeft, uppBannerImage } = this.state
    const { system } = page
    // 菜单父级样式
    let wrapStyle = {
      width: width,
      paddingLeft
    }
    // 如果有顶部banner图片，paddingLeft设为0
    if (system && system.banner) wrapStyle.paddingLeft = 0
    // 菜单样式
    let newClass = {}
    // 菜单item样式
    let menuItemClass = {}
    if (system) {
      newClass = {
        ...newClass,
        fontFamily: system.navigationFont,
        fontSize: system.navigationFontSize
      }
      menuItemClass = {
        color: system.navigationColor
      }
    }
    // 设置导航栏样式
    let bannerStyle = this.setBannerStyle()

    return (
      <div className={classnames('yui_page_banner')} style={bannerStyle}>
        <Row>
          <Col span={2} />
          <Col span={20} ref="contentCol">
            <div style={{ height: '54px' }}>
              {!(system && system.banner) && (
                <img
                  // ref={'logoImg'} // 这种写法已废弃了吧
                  ref={el => (this.logoImg = el)}
                  className="bannerLogo"
                  src={
                    system && system.logo
                      ? downloadApi + '?attachmentId=' + system.logo
                      : uppBannerImage
                      ? downloadApi + '?attachmentId=' + uppBannerImage
                      : require('assets/images/logo-s.png')
                  }
                  onLoad={() => {
                    // this.onWindowResize()
                    // setTimeout(() => {
                    //   const dom = document.querySelector('.bannerLogo')
                    //   console.log(111, dom.clientWidth)
                    //   if (system && !system.banner) {
                    //     this.setState(
                    //       { paddingLeft: dom.clientWidth },
                    //       () => {
                    //         console.log(222)
                    //       },
                    //       500
                    //     )
                    //   }
                    // })
                    this.getLogoWidth()
                  }}
                  onError={event => {
                    var img = event.nativeEvent.srcElement
                    img.src = require('assets/images/logo-s.png')
                    img.onerror = null
                  }}
                />
              )}
              {((system && system.banner) || paddingLeft > 0) && (
                <div style={wrapStyle} className="yui_page_banner_wrapper">
                  <Menu
                    style={newClass}
                    className={classnames('fl', {
                      yui_page_banner_haslogo: system && system.banner
                    })}
                    onClick={this.handleClick}
                    selectedKeys={[location.pathname.split('/')[1]]}
                    mode="horizontal"
                  >
                    {data
                      .filter(item => {
                        return item.isShow !== '0'
                      })
                      .map((item, index) => {
                        // 要展示的国际化标题
                        let localeName = getLanguageTitle(
                          this.props,
                          item.locales,
                          'name',
                          item.pageName
                        )
                        return (
                          <Menu.Item
                            style={{
                              ...menuItemClass,
                              display: item.hidden ? 'none' : '' // hidden为true 是为用户手动输入url访问的隐藏页面
                              // 为false的时候只能设置为'',浏览器作为无效css处理，因为Menu.Item有时为block，有时为inline-block不好判断
                            }}
                            key={item.type}
                          >
                            {localeName}
                          </Menu.Item>
                        )
                      })}
                  </Menu>
                </div>
              )}
            </div>
          </Col>
          <Col span={2} />
        </Row>
        <style jsx="true" global="true">{`
          .yui_page_banner .ant-menu-item,
          .yui_page_banner .ant-menu-submenu-title {
            color: ${system && system.navigationColor};
          }
          .yui_page_banner_wrapper_right {
            color: ${system && system.navigationColor};
          }
          .yui_page_banner .ant-menu-horizontal > .ant-menu-item:hover,
          .yui_page_banner .ant-menu-horizontal > .ant-menu-item-active,
          .yui_page_banner
            .ant-menu-horizontal
            > .ant-menu-submenu
            .ant-menu-submenu-title:hover {
            color: ${system && system.navigationColor};
          }
        `}</style>
      </div>
    )
  }
}
