import IntroJs from './../util/intro.js'
import { Modal, message } from 'antd'
// import './../util/introjs.css'
import 'assets/css/guide.less'
// import { openAppCenter } from "redux/actions/app";

// 通用设置项
const settingOptions = {
  nextLabel: '下一步',
  prevLabel: '上一步',
  skipLabel: '跳过',
  doneLabel: '结束指引',
  showStepNumbers: false,
  disableInteraction: true,
  showProgress: false,
  showBullets: false,
  hideNext: true,
  hidePrev: true,
  hideDone: true,
  exitOnOverlayClick: false,
  keyboardNavigation: false,
  exitOnEsc: false,
  overlayOpacity: 0.65
}

let isSkip = false // 全局变量用于判断是否为跳过操作，避免点击"跳过"按钮触发oncomplete回调函数

// 常用按钮指引
export const commonIntro = (changeItem, exitAllIntro) => {
  let steps = [
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">1/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">编辑：</p>
                            <p class="tooltipText">点击后面页面进入编辑状态，可进行修改卡片、拖拽布局卡片等操作。</p>
                            <span class="introSkipBtn">跳过</span>
                        </div>
                    </div>`,
      position: 'left-top_1'
    },
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">2/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">主题：</p>
                            <p class="tooltipText">一键切换主题、布局、肤色、对页面外观及内容进行一键切换。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'left-top_2'
    },
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">3/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">添加：</p>
                            <p class="tooltipText">点击后可以添加业务卡片到页面中。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'left'
    },
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">4/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">我的收藏入口：</p>
                            <p class="tooltipText">点击进入我的收藏，可进行收藏、排序应用，也可进入应用中心，查找所需应用。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'left-bottom_1'
    },
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">5/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">快捷应用入口：</p>
                            <p class="tooltipText">点击后快速进入收藏应用，也可以在上方“应用中心”自定义快捷入口哦！</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'left-bottom_2'
    },
    {
      element: '#topBar_conciseMode',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">6/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">简洁模式：</p>
                            <p class="tooltipText">点击后进入简洁模式，隐藏页面导航栏以及侧边栏。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'top-right'
    },
    {
      element: '#topBar_pageManage',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">7/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">页面管理：</p>
                            <p class="tooltipText">点击进行页面管理，对网站页面进行新增、修改、删除、排序等操作。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'top-right'
    },
    {
      element: '#topBar_locale',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">8/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">语言切换：</p>
                            <p class="tooltipText">点击进行中英文切换。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'top-right'
    },
    // {
    //     element: '#topBar_message',
    //     intro: `<div class="tooltipDiv">
    //                 <p class="tooltipHeader">
    //                     常用按钮指引
    //                     <span class="tooltipStep">
    //                         <span style="color: #53ABFF;">9/</span>
    //                         10
    //                     </span>
    //                 </p>
    //                 <div class="tooltipContent">
    //                     <p class="tooltipTitle">消息提醒：</p>
    //                     <p class="tooltipText">点击查看系统消息。</p>
    //                     <span class="introSkipBtn" style="right:175px">跳过</span>
    //                 </div>
    //             </div>`,
    //     position: 'top-right'
    // },
    {
      element: '.avatar_wrap',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            常用按钮指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">9/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">我的账号：</p>
                            <p class="tooltipText">账号退出、新手指引等相关信息都在这里哦。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'top-right'
    }
  ]
  return IntroJs()
    .setOptions({
      ...settingOptions,
      steps,
      doneLabel: '下一步'
    })
    .onchange(function() {
      skipBtnAddEvent(commonIntro)
    })
    .oncomplete(function() {
      // setTimeout(function () {
      //     appCenterIntro1().start();
      // },0);
      if (!isSkip) {
        changeItem(2)
        setTimeout(() => {
          appCenterIntro1(changeItem, exitAllIntro).start()
        }, 100)
      }
      isSkip = false
    })
}

// 应用操作指引1
export const appCenterIntro1 = (changeItem, exitAllIntro) => {
  let appCenter = [
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            应用操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">1/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">应用中心入口：</p>
                            <p class="tooltipText">点击进入【应用中心】，可进行应用查询、筛选、收藏等操作。</p>
                            <span class="introSkipBtn">跳过</span>
                        </div>
                    </div>`,
      position: 'left-bottom_1'
    }
  ]
  return IntroJs()
    .setOptions({
      ...settingOptions,
      doneLabel: '下一步',
      steps: appCenter
    })
    .onchange(function() {
      skipBtnAddEvent(appCenterIntro1)
    })
    // .onbeforechange(function() {
    //   if (this._currentStep == 0) {
    //     window.location.href = '#/lyappCenter'
    //     // const dom = document.querySelector('.iconcolllect')
    //     // dom.click()
    //     // const cloneDom = document
    //     // const fixedDom = document.querySelector('.ant-drawer-content-wrapper')
    //     // customIntroOverLay(fixedDom,cloneDom);
    //   }
    //   // return false to stop displaying the next step
    //   // return false;
    // })
    .onbeforechange(function() {
      if (this._currentStep == 0) {
        const dom = document.querySelector('.iconcolllect')
        dom.click()
      }
    })
    .oncomplete(function() {
      if (!isSkip) {
        const dom = document.querySelector(
          '.ant-tabs-nav.ant-tabs-nav-animated .ant-tabs-tab'
        )
        if (dom) {
          const event = document.createEvent('MouseEvents')
          // initEvent接受3个参数： 事件类型，是否冒泡，是否阻止浏览器的默认行为
          event.initEvent('click', true, true)
          //触发document上绑定的click事件
          dom.dispatchEvent(event)
          setTimeout(function() {
            appCenterIntro2(changeItem, exitAllIntro).start()
          }, 1000)
        } else {
          message.warning('应用中心页面不存在，已为你跳过应用中心指引')
          console.log('应用中心页面不存在,跳回原先的页面')
          window.history.go(-1)
          setTimeout(function() {
            // if (document.querySelector('.cardWraper > .floatBtn')) {
            //   changeItem(3)
            //   // setTimeout(function () {
            //   cardIntro1(changeItem, exitAllIntro).start()
            //   // },100);
            // } else {
            //   changeItem(4)
            //   // setTimeout(function () {
            //   pageIntro1(changeItem, exitAllIntro).start()
            //   // },100);
            // }
            changeItem(3)
            cardIntro1(changeItem, exitAllIntro).start()
          }, 1000)
        }
      }
      isSkip = false
    })
}

// 应用操作指引2
export const appCenterIntro2 = (changeItem, exitAllIntro) => {
  let appCenter = [
    {
      element: '#appCenter_search',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            应用操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">2/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">应用中心搜索：</p>
                            <p class="tooltipText">输入您想要的应用名称或关键词，可查询到对应应用。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                            <span class="introPrevBtn" style="right:95px">上一步</span>
                        </div>
                    </div>`,
      position: 'left_2'
    },
    {
      element: '#appCenter_typeBox',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            应用操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">3/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">应用中心筛选：</p>
                            <p class="tooltipText">选择应用相关的服务场景、服务角色、服务部门进行条件筛选。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'left-top_3'
    },
    {
      element: '#appCenter_app',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            应用操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">4/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">应用收藏：</p>
                            <p class="tooltipText">点击卡片中的【收藏】按钮，收藏常用应用。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'left_2'
    },
    {
      element: '.appCenter .ant-tabs-tab:nth-child(2)',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            应用操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">5/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">应用收藏：</p>
                            <p class="tooltipText">在应用中心点击【我的收藏】，进入到收藏列表。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'left_2'
    },
    {
      element: '#appCenter_app',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            应用操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">6/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">设置快捷应用：</p>
                            <p class="tooltipText">我的收藏列表前五个应用会在侧边展示，可以拖动卡片或点击卡片操作栏进行排序。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                        </div>
                    </div>`,
      position: 'left_2'
    }
  ]
  return IntroJs()
    .setOptions({
      ...settingOptions,
      doneLabel: '下一步',
      steps: appCenter
    })
    .onchange(function() {
      skipBtnAddEvent(appCenterIntro2)
      prevBtnAddEvent(appCenterIntro1(changeItem))
    })
    .onbeforechange(function() {
      if (this._currentStep == 0) {
        setTimeout(() => {
          const cloneDom = document
          // const fixedDom = document.querySelector('.ant-drawer-content-wrapper')
          const fixedDom = document.querySelector('.ant-drawer-content')
          // const fixedDom = document.querySelector('.ant-drawer-wrapper-body')
          // const fixedDom = document.querySelector('.ant-drawer-body')
          // customIntroOverLay(fixedDom, cloneDom);
        }, 500)
      }
    })
    .oncomplete(function() {
      if (!isSkip) {
        window.history.back(-1)
        setTimeout(() => {
          // if (document.querySelector('.cardWraper > .floatBtn')) {
          changeItem(3)
          // setTimeout(function () {
          cardIntro1(changeItem, exitAllIntro).start()
          // },100);
          // } else {
          //   changeItem(4)
          //   // setTimeout(function () {
          //   pageIntro1(changeItem, exitAllIntro).start()
          //   // },100);
          // }
        }, 1000)
      }
      isSkip = false
    })
}

// 卡片操作指引1
export const cardIntro1 = (changeItem, exitAllIntro) => {
  let steps = [
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            卡片操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">1/</span>
                                2
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">进入编辑状态：</p>
                            <p class="tooltipText">点击侧边栏【编辑】、【主题】、【添加】按钮皆可进入编辑状态。</p>
                            <span class="introSkipBtn">跳过</span>
                        </div>
                    </div>`,
      position: 'left-top_1'
    }
  ]
  return IntroJs()
    .setOptions({
      ...settingOptions,
      doneLabel: '下一步',
      steps
    })
    .onchange(function() {
      skipBtnAddEvent(cardIntro1)
    })
    .oncomplete(function() {
      if (!isSkip) {
        const dom = document.querySelector('.cardWraper > .floatBtn')
        if (dom) {
          dom.style.display = 'initial'
          const icons = dom.children
          if (icons.length) {
            Array.prototype.map.call(icons, d => {
              d.style.display = 'unset'
            })
          }
          setTimeout(() => {
            cardIntro2(changeItem, exitAllIntro).start()
          })
        } else {
          message.warning('当前页面暂无卡片，已为你跳过卡片指引')
          setTimeout(function() {
            changeItem(4)
            pageIntro1(changeItem, exitAllIntro).start()
          }, 1000)
        }
      }
      isSkip = false
    })
}

// 卡片操作指引2
export const cardIntro2 = (changeItem, exitAllIntro) => {
  let steps = [
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            卡片操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">1/</span>
                                2
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">进入编辑状态：</p>
                            <p class="tooltipText">点击侧边栏【编辑】、【主题】、【添加】按钮皆可进入编辑状态。</p>
                            <span class="introSkipBtn">跳过</span>
                        </div>
                    </div>`,
      position: 'left-top_1'
    }
  ]
  return IntroJs()
    .setOptions({
      ...settingOptions,
      doneLabel: '下一步',
      steps
    })
    .onchange(function() {
      skipBtnAddEvent(cardIntro2)
      prevBtnAddEvent(cardIntro1(changeItem))
    })
    .oncomplete(function() {
      if (!isSkip) {
        const dom = document.querySelector('.cardWraper > .floatBtn')
        dom.style.display = 'none'
        const icons = dom.children
        if (icons.length) {
          Array.prototype.map.call(icons, d => {
            d.style.display = 'none'
          })
        }
        changeItem(4)
        setTimeout(function() {
          pageIntro1(changeItem, exitAllIntro).start()
        }, 100)
      }
      isSkip = false
    })
}

// 页面操作指引1
export const pageIntro1 = (changeItem, exitAllIntro) => {
  let steps = [
    {
      element: '#topBar_pageManage',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            页面操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">1/</span>
                                <span>4</span>
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">页面管理：</p>
                            <p class="tooltipText">在这里进行管理页面，对网站页面进行新增、删除、修改、可拖拽页面排序。</p>
                            <span class="introSkipBtn">跳过</span>
                        </div>
                    </div>`,
      position: 'top-right'
    }
  ]
  const newSettingOptions = { ...settingOptions }
  newSettingOptions.doneLabel = '下一步'
  // newSettingOptions.overlayOpacity = 0
  return IntroJs()
    .setOptions({
      ...settingOptions,
      doneLabel: '下一步',
      steps
    })
    .onbeforechange(function() {
      if (this._currentStep === 0) {
        console.log('pageIntro1_beforechange')
        if (document.querySelector('.pageMetuModal')) {
          document.querySelector('.pageMetuModal .ant-modal-close-x').click()
        }
      }
      // return false to stop displaying the next step
      // return false;
    })
    .onchange(function() {
      skipBtnAddEvent(pageIntro1)
    })
    .oncomplete(function() {
      if (!isSkip) {
        setTimeout(() => {
          if (!document.querySelector('.pageMetuModal')) {
            console.log(888)
            const dom = document.querySelector('.iconyemianbianji')
            const event = document.createEvent('MouseEvents')
            // initEvent接受3个参数：
            // 事件类型，是否冒泡，是否阻止浏览器的默认行为
            event.initEvent('click', true, true)
            //触发document上绑定的click事件
            dom.dispatchEvent(event)
          }
          pageIntro2(changeItem, exitAllIntro).start()
        }, 0)
      }
      isSkip = false
    })
}

// 页面操作指引2
export const pageIntro2 = (changeItem, exitAllIntro) => {
  let steps = [
    {
      element: '.pageMetuModal .ant-modal-content',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            页面操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">2/</span>
                                <span>4</span>
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">页面列表：</p>
                            <p class="tooltipText">在这里可以</p>
                            <p class="tooltipText">①拖拽标题可进行页面排序；</p>
                            <p class="tooltipText">②点击页面标题可修改页面的名称；</p>
                            <p class="tooltipText">③点击右侧图标可完成【编辑】、【删除】等操作。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                            <span class="introPrevBtn" style="right:95px">上一步</span>
                        </div>
                    </div>`,
      position: 'left-top_4'
    }
  ]
  return IntroJs()
    .setOptions({
      ...settingOptions,
      steps,
      doneLabel: '下一步',
      overlayOpacity: 0.1
    })
    .onchange(function() {
      skipBtnAddEvent(pageIntro2)
      prevBtnAddEvent(pageIntro1(changeItem, exitAllIntro), exitAllIntro)
    })
    .oncomplete(function() {
      if (!isSkip) {
        if (!document.querySelector('.pageAddModal')) {
          const dom = document.querySelector('.pageList_addBtn')
          const event = document.createEvent('MouseEvents')
          // initEvent接受3个参数：
          // 事件类型，是否冒泡，是否阻止浏览器的默认行为
          event.initEvent('click', true, true)
          //触发document上绑定的click事件
          dom.dispatchEvent(event)
        }
        setTimeout(() => {
          pageIntro3(changeItem, exitAllIntro).start()
        }, 200)
      }
      isSkip = false
    })
}

// 页面操作指引3
export const pageIntro3 = (changeItem, exitAllIntro) => {
  let steps = [
    {
      element: '.pageAddModal',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            页面操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">3/</span>
                                <span>4</span>
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">编辑页面_基础设置：</p>
                            <p class="tooltipText">在这里您可以对页面名称、路径、页面类型、页面内容等信息进行配置。</p>
                            <span class="introSkipBtn" style="right:175px">跳过</span>
                            <span class="introPrevBtn" style="right:95px">上一步</span>
                        </div>
                    </div>`,
      position: 'left-top_4'
    },
    {
      element: '.pageAddModal',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            页面操作指引
                            <span class="tooltipStep">
                                <span style="color: #53ABFF;">4/</span>
                                <span>4</span>
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">编辑页面_高级配置：</p>
                            <p class="tooltipText">在这里您可以修改导航栏文字样式，上传背景图片。还可以写入css样式修改页面外观。</p>
                            <span class="introPrevBtn" style="right:95px">上一步</span>
                        </div>
                    </div>`,
      position: 'left-top_4'
    }
  ]
  return IntroJs()
    .setOptions({
      ...settingOptions,
      steps,
      overlayOpacity: 0.1
    })
    .onbeforechange(function() {
      if (this._currentStep === 0) {
        if (document.querySelector('.pageAddModal')) {
          document
            .querySelector('.pageAddModal .ant-tabs-tab:nth-of-type(1)')
            .click()
        }
      }
      if (this._currentStep === 1) {
        if (document.querySelector('.pageAddModal')) {
          document
            .querySelector('.pageAddModal .ant-tabs-tab:nth-of-type(2)')
            .click()
        }
      }
      // return false to stop displaying the next step
      // return false;
    })
    .onchange(function() {
      prevBtnAddEvent(pageIntro2(changeItem, exitAllIntro), exitAllIntro)
      skipBtnAddEvent(pageIntro3)
    })
    .oncomplete(function() {
      // if(!isSkip){
      setTimeout(() => {
        const addModal = document.querySelector(
          '.pageAddModal .ant-modal-close-x'
        )
        if (addModal) addModal.click()
        setTimeout(() => {
          const menuModal = document.querySelector(
            '.pageMetuModal .ant-modal-close-x'
          )
          if (menuModal) menuModal.click()
        }, 100)
      }, 100)
      setTimeout(() => {
        lastIntro().start()
      }, 200)
      // }
      // isSkip = false;
    })
    .onbeforeexit(function() {})
    .onexit(function() {})
}

// 新手指引
export const lastIntro = () => {
  let steps = [
    {
      // element: '.avatar_wrap',
      element: '.ant-dropdown-placement-bottomLeft',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">新手指引</p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle">新手指引：</p>
                            <p class="tooltipText">在这里可以查看网站的新手指引，更快掌握网站功能。</p>
                        </div>
                    </div>`,
      position: 'top-right'
    }
  ]
  return IntroJs()
    .setOptions({
      ...settingOptions,
      steps,
      doneLabel: '知道了'
    })
    .onbeforechange(function() {
      if (this._currentStep === 0) {
        document
          .querySelector(
            '.ant-dropdown.ant-dropdown-placement-bottomLeft.ant-dropdown-hidden'
          )
          .classList.remove('ant-dropdown-hidden')
      }
    })
    .onchange(function() {})
    .oncomplete(function() {
      const dom = document.querySelector('#guideModal_close')
      if (dom) dom.click()
    })
    .onexit(function() {
      document
        .querySelector('.ant-dropdown.ant-dropdown-placement-bottomLeft')
        .classList.add('ant-dropdown-hidden')
      Modal.destroyAll()
    })
}

// 增加跳过按钮事件
function skipBtnAddEvent() {
  Modal.destroyAll()
  setTimeout(function() {
    let skipButton = document.querySelector('.introSkipBtn')
    if (skipButton) {
      skipButton.addEventListener('click', function(e) {
        e.preventDefault()
        setTimeout(function() {
          document.querySelector('.introjs-skipbutton').click()
          lastIntro().start()
        }, 0)
        isSkip = true
      })
    }
  }, 500)
}

// 增加上一步按钮事件
function prevBtnAddEvent(intro, exitAllIntro) {
  setTimeout(function() {
    let prevButton = document.querySelector('.introPrevBtn')
    if (prevButton) {
      prevButton.addEventListener('click', function(e) {
        e.preventDefault()
        setTimeout(function() {
          exitAllIntro()
          setTimeout(() => {
            const addModal = document.querySelector(
              '.pageAddModal .ant-modal-footer .ant-btn'
            )
            if (addModal) addModal.click()
            intro.start()
          }, 100)
        }, 0)
        isSkip = false
      })
    }
  }, 500)
}

// 跳到指定指引
function jumpToNewIntro(intro, exitAllIntro) {
  setTimeout(function() {
    let prevButton = document.querySelector('.introPrevBtn')
    if (prevButton) {
      prevButton.addEventListener('click', function(e) {
        e.preventDefault()
        setTimeout(function() {
          exitAllIntro()
          setTimeout(() => {
            const addModal = document.querySelector(
              '.pageAddModal .ant-modal-footer .ant-btn'
            )
            if (addModal) addModal.click()
            intro.start()
          }, 100)
        }, 0)
        isSkip = false
      })
    }
  }, 500)
}

// 增加小提示
function addTip(ele, html, className, position) {
  let eleOffset = getOffset(ele)
  ele.classList.add('introjs-showElement')

  let tooltip = document.createElement('div')
  tooltip.innerHTML = html
  tooltip.classList.add('simpleTip', className)

  let simpleTipArrow = document.createElement('div')
  simpleTipArrow.classList.add('simpleTipArrow')

  tooltip.appendChild(simpleTipArrow)
  document.body.appendChild(tooltip)

  switch (position) {
    case 'right':
      simpleTipArrow.classList.add('right')
      tooltip.classList.add('right')
      tooltip.style.top = eleOffset.top + eleOffset.height / 2 + 'px'
      tooltip.style.left = eleOffset.left + eleOffset.width + 10 + 'px'
      break
    default:
      tooltip.style.top = eleOffset.top + eleOffset.height + 10 + 'px'
      tooltip.style.left = eleOffset.left + eleOffset.width / 2 + 'px'
      break
  }
}

// 获取元素的绝对位置
function getOffset(element) {
  let body = document.body
  let docEl = document.documentElement
  let scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop
  let scrollLeft = window.pageXOffset || docEl.scrollLeft || body.scrollLeft
  let x = element.getBoundingClientRect()
  return {
    top: x.top + scrollTop,
    width: x.width,
    height: x.height,
    left: x.left + scrollLeft
  }
}

// 移除提示
function removeTip(classArr) {
  classArr.map(item => {
    let tip = document.getElementsByClassName(item)[0]
    if (tip) {
      document.body.removeChild(tip)
    }
  })
}

// 增加Div
function addDiv(className, style) {
  let div = document.createElement('div')
  div.style.height = style.height
  div.style.width = style.width
  div.style.left = style.left
  div.style.top = style.top
  div.style.right = style.right
  div.style.bottom = style.bottom
  div.style.position = 'absolute'
  div.style.zIndex = '9999999'
  div.style.background = `url(${style.background})`

  div.classList.add(className)
  let imgContainer = document.getElementsByClassName('imgContainer')[0]
  imgContainer.appendChild(div)
  return div
}

// 移除Div
function removeDiv(classArr) {
  let imgContainer = document.getElementsByClassName('imgContainer')[0]
  classArr.map(item => {
    let div = document.getElementsByClassName(item)[0]
    if (div) {
      imgContainer.removeChild(div)
    }
  })
}

// 自定义引导组件遮罩层位置，用于解决目标父元素为fixed定位的目标z-index无效问题
function customIntroOverLay(fixParent, cloneParent) {
  console.log('++++++++++++++++')
  // let overlayOrigin = cloneParent.getElementsByClassName('introjs-overlay')[0]
  // let helperLayerOrigin = cloneParent.getElementsByClassName(
  //   'introjs-helperLayer'
  // )[0]
  let overlayOrigin = document.getElementsByClassName('introjs-overlay')[0]
  let helperLayerOrigin = document.getElementsByClassName(
    'introjs-helperLayer'
  )[0]  

  let overlayClone = overlayOrigin.cloneNode(true)
  let helperLayerClone = helperLayerOrigin.cloneNode(true)
  let overlayExist = fixParent.querySelector('.introjs-overlay')
  let helperLayerExist = fixParent.querySelector('.introjs-helperLayer')

  if (overlayExist) {
    fixParent.removeChild(overlayExist)
  }
  if (helperLayerExist) {
    fixParent.removeChild(helperLayerExist)
  }
  
  fixParent.appendChild(overlayClone)
  fixParent.appendChild(helperLayerClone)

  document.body.removeChild(overlayOrigin)
  document.body.removeChild(helperLayerOrigin)
  // cloneParent.removeChild(overlayOrigin)
  // cloneParent.removeChild(helperLayerOrigin)
}

// 触发window.resize事件
function windowResize() {
  let myEvent = new Event('resize')
  window.dispatchEvent(myEvent)
}

// 检测元素加载完成
function checkElementMounted(targetName, callback) {
  let timer = setInterval(function() {
    let element = document.querySelector(targetName)
    if (element) {
      clearInterval(timer)
      callback()
    }
  }, 100)
}

// 调整提示框位置,为解决加大字体设置导致的位置不准确问题
function adjustHelperLayerPosition(distance) {
  // let helperLayer = document.body.querySelector('.introjs-helperLayer');
  // helperLayer.style.top = parseInt(helperLayer.style.top) - distance + 'px';
}
