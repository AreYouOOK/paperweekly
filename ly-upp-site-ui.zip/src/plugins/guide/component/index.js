/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-09-06 15:21:42
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-16 17:42:57
 */
import IntroJs from './../util/intro.js'
import { Modal, message } from 'antd'
// import './../util/introjs.css'
import 'assets/css/guide.less'
// import { openAppCenter } from "redux/actions/app";

// 通用设置项
const settingOptions = {
  showStepNumbers: false,
  disableInteraction: true,
  showProgress: false,
  showBullets: false,
  hideNext: true,
  hidePrev: true,
  hideDone: true,
  exitOnOverlayClick: false,
  keyboardNavigation: false,
  exitOnEsc: false,
  overlayOpacity: 0.65
}

let isSkip = false // 全局变量用于判断是否为跳过操作，避免点击"跳过"按钮触发oncomplete回调函数

// 常用按钮指引
export const commonIntro = (changeItem, exitAllIntro, hideNav, locale) => {
  let steps = [
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                         ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">1/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].edit}：</p>
                            <p class="tooltipText">${window.locale[locale].Click_to_edit}</p>
                            <span class="introSkipBtn">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left-top_1'
    },
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">2/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].theme}：</p>
                            <p class="tooltipText">${window.locale[locale].Theme_swift_edit}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left-top_2'
    },
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">3/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].add}：</p>
                            <p class="tooltipText">${window.locale[locale].Add_card_into_page}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left'
    },
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">4/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].My_favorite_entrance}:</p>
                            <p class="tooltipText">${window.locale[locale].Collect_apps}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left-bottom_1'
    },
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">5/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont"> ${window.locale[locale].App_shortcut}：</p>
                            <p class="tooltipText">${window.locale[locale].Collect_fast_entrance}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left-bottom_2'
    },
    {
      element: '#topBar_conciseMode',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">6/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].top_concise_model}：</p>
                            <p class="tooltipText">${window.locale[locale].Click_to_concise_model}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'top-right'
    },
    {
      element: '#topBar_pageManage',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">7/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont"> ${window.locale[locale].top_page_management}：</p>
                            <p class="tooltipText">${window.locale[locale].Edit_pages}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'top-right'
    },
    {
      element: '#topBar_locale',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">8/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].Language_switch}：</p>
                            <p class="tooltipText">${window.locale[locale].Click_to_switch_languages}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'top-right'
    },
    // {
    //     element: '#topBar_message',
    //     intro: `<div class="tooltipDiv">
    //                 <p class="tooltipHeader">
    //                     常用按钮指引
    //                     <span class="tooltipStep">
    //                         <span class="themeFont"">9/</span>
    //                         10
    //                     </span>
    //                 </p>
    //                 <div class="tooltipContent">
    //                     <p class="tooltipTitle themeFont">消息提醒：</p>
    //                     <p class="tooltipText">点击查看系统消息。</p>
    //                     <span class="introSkipBtn" style="right:175px">跳过</span>
    //                 </div>
    //             </div>`,
    //     position: 'top-right'
    // },
    {
      element: '.avatar_wrap',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Common_button_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">9/</span>
                                9
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].top_my_account}：</p>
                            <p class="tooltipText">${window.locale[locale].My_account_details}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'top-right'
    }
  ]
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      steps,
      doneLabel: window.locale[locale].Next
    })
    .onbeforechange(function() {
      if (this._currentStep == 8) {
        isSkip = false
      }
    })
    .onchange(function() {
      skipBtnAddEvent('commonIntro', hideNav, locale)
    })
    .oncomplete(function() {
      if (!isSkip) {
        changeItem(2)
        setTimeout(() => {
          appCenterIntro1(changeItem, exitAllIntro, hideNav, locale).start()
        }, 100)
      }
      isSkip = false
    })
}

// 应用操作指引1
export const appCenterIntro1 = (changeItem, exitAllIntro, hideNav, locale) => {
  let appCenter = [
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Application_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">1/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].Appcenter_shortcut}：</p>
                            <p class="tooltipText">${window.locale[locale].Click_to_appcenter}</p>
                            <span class="introSkipBtn">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left-bottom_1'
    }
  ]
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      doneLabel: window.locale[locale].Next,
      steps: appCenter
    })
    .onchange(function() {
      skipBtnAddEvent('appCenterIntro1', hideNav, locale)
    })
    .onbeforechange(function() {
      if (this._currentStep == 0) {
        window.location.href = '#/lyappCenter'
        // const dom = document.querySelector('.iconcolllect')
        // dom.click()
        // const cloneDom = document
        // const fixedDom = document.querySelector('.ant-drawer-content-wrapper')
        // customIntroOverLay(fixedDom,cloneDom);
      }
      // return false to stop displaying the next step
      // return false;
    })
    .oncomplete(function() {
      if (!isSkip) {
        const dom = document.querySelector(
          '.ant-tabs-nav.ant-tabs-nav-animated .ant-tabs-tab'
        )
        if (dom) {
          const event = document.createEvent('MouseEvents')
          // initEvent接受3个参数： 事件类型，是否冒泡，是否阻止浏览器的默认行为
          event.initEvent('click', true, true)
          //触发document上绑定的click事件
          dom.dispatchEvent(event)
          setTimeout(function() {
            appCenterIntro2(changeItem, exitAllIntro, hideNav, locale).start()
          }, 1000)
        } else {
          message.warning(window.locale[locale].Warning_of_apppage)
          console.log('应用中心页面不存在,跳回原先的页面')
          window.history.go(-1)
          setTimeout(function() {
            // if (document.querySelector('.cardWraper > .floatBtn')) {
            //   changeItem(3)
            //   // setTimeout(function () {
            //   cardIntro1(changeItem, exitAllIntro, hideNav).start()
            //   // },100);
            // } else {
            //   changeItem(4)
            //   // setTimeout(function () {
            //   pageIntro1(changeItem, exitAllIntro, hideNav).start()
            //   // },100);
            // }
            changeItem(3)
            cardIntro1(changeItem, exitAllIntro, hideNav, locale).start()
          }, 1000)
        }
      }
      isSkip = false
    })
}

// 应用操作指引2
export const appCenterIntro2 = (changeItem, exitAllIntro, hideNav, locale) => {
  let appCenter = [
    {
      element: '#appCenter_search',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Application_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">2/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont"> ${window.locale[locale].Search_of_apps}：</p>
                            <p class="tooltipText">${window.locale[locale].Input_to_search_apps}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                            <span class="introPrevBtn" style="right:95px">${window.locale[locale].Previous}</span>
                        </div>
                    </div>`,
      position: 'left_2'
    },
    {
      element: '#appCenter_typeBox',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Application_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">3/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].Filter_of_apps}：</p>
                            <p class="tooltipText">${window.locale[locale].Filter_of_apps_details}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      // position: 'left-top_3'
      position: 'top-right'
    },
    {
      element: '#appCenter_app',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Application_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">4/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].App_collections}：</p>
                            <p class="tooltipText">${window.locale[locale].Click_to_appcollections}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left_2'
    },
    {
      element: '.appCenter .ant-tabs-tab:nth-child(2)',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Application_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">5/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont"> ${window.locale[locale].App_collections}：</p>
                            <p class="tooltipText">${window.locale[locale].Click_myfavorite_into_list}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left_2'
    },
    {
      element: '#appCenter_app',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Application_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">6/</span>
                                6
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont"> ${window.locale[locale].Convenient_appsettings}：</p>
                            <p class="tooltipText">${window.locale[locale].Convenient_apps_showleft}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left_2'
    }
  ]
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      doneLabel: window.locale[locale].Next,
      steps: appCenter
    })
    .onchange(function() {
      skipBtnAddEvent('appCenterIntro2', hideNav, locale)
      prevBtnAddEvent(
        appCenterIntro1(changeItem, exitAllIntro, hideNav, locale),
        exitAllIntro
      )
    })
    .oncomplete(function() {
      if (!isSkip) {
        // window.location.href = '#/themeA';
        // window.location.href = '#/index';
        window.history.back(-1)
        setTimeout(() => {
          // if (document.querySelector('.cardWraper > .floatBtn')) {
          changeItem(3)
          // setTimeout(function () {
          cardIntro1(changeItem, exitAllIntro, hideNav, locale).start()
          // },100);
          // } else {
          //   changeItem(4)
          //   // setTimeout(function () {
          //   pageIntro1(changeItem, exitAllIntro, hideNav).start()
          //   // },100);
          // }
        }, 1000)
      }
      isSkip = false
    })
}

// 卡片操作指引1
export const cardIntro1 = (changeItem, exitAllIntro, hideNav, locale) => {
  let steps = [
    {
      element: '.siderWraperUl',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                            卡片操作指引
                            <span class="tooltipStep">
                                <span class="themeFont"">1/</span>
                                2
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont"> ${window.locale[locale].Into_edit_state}:</p>
                            <p class="tooltipText"> ${window.locale[locale].Click_into_edit_state}</p>
                            <span class="introSkipBtn">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'left-top_1'
    }
  ]
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      doneLabel: window.locale[locale].Next,
      steps
    })
    .onchange(function() {
      skipBtnAddEvent('cardIntro1', hideNav, locale)
    })
    .oncomplete(function() {
      if (!isSkip) {
        const dom = document.querySelector('.cardWraper > .floatBtn')
        if (dom) {
          console.log('当前页面有卡片')
          dom.style.display = 'initial'
          const icons = dom.children
          if (icons.length) {
            Array.prototype.map.call(icons, d => {
              d.style.display = 'unset'
            })
          }
          setTimeout(() => {
            cardIntro2(changeItem, exitAllIntro, hideNav, locale).start()
          }, 500)
        } else {
          message.warning(window.locale[locale].Nocard_warning)
          setTimeout(function() {
            changeItem(4)
            pageIntro1(changeItem, exitAllIntro, hideNav, locale).start()
          }, 1000)
        }
      }
      isSkip = false
    })
}

// 卡片操作指引2
export const cardIntro2 = (changeItem, exitAllIntro, hideNav, locale) => {
  let steps = [
    {
      element: '.cardWraper',
      intro: `<div class="tooltipDiv">
                  <p class="tooltipHeader">
                  ${window.locale[locale].Card_operation_guide}
                      <span class="tooltipStep">
                          <span class="themeFont"">2/</span>
                          <span>2</span>
                      </span>
                  </p>
                  <div class="tooltipContent">
                      <p class="tooltipTitle themeFont">${window.locale[locale].Card_edit}：</p>
                      <p class="tooltipText">${window.locale[locale].Card_selections}</p>
                      <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                      <span class="introPrevBtn" style="right:95px">${window.locale[locale].Previous}</span>
                  </div>
              </div>`,
      position: 'top-right'
    }
  ]
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      doneLabel: window.locale[locale].Next,
      steps
    })
    .onchange(function() {
      skipBtnAddEvent('cardIntro2', hideNav, locale)
      prevBtnAddEvent(
        cardIntro1(changeItem, exitAllIntro, hideNav, locale),
        exitAllIntro
      )
    })
    .oncomplete(function() {
      if (!isSkip) {
        const dom = document.querySelector('.cardWraper > .floatBtn')
        dom.style.display = 'none'
        const icons = dom.children
        if (icons.length) {
          Array.prototype.map.call(icons, d => {
            d.style.display = 'none'
          })
        }
        changeItem(4)
        setTimeout(function() {
          pageIntro1(changeItem, exitAllIntro, hideNav, locale).start()
        }, 100)
      }
      isSkip = false
    })
}

// 页面操作指引1
export const pageIntro1 = (changeItem, exitAllIntro, hideNav, locale) => {
  let steps = [
    {
      element: '#topBar_pageManage',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Page_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">1/</span>
                                <span>4</span>
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].top_page_management}：</p>
                            <p class="tooltipText">${window.locale[locale].Page_edit_operation}</p>
                            <span class="introSkipBtn">${window.locale[locale].Skip}</span>
                        </div>
                    </div>`,
      position: 'top-right'
    }
  ]
  const newSettingOptions = { ...settingOptions }
  newSettingOptions.doneLabel = window.locale[locale].Next
  // newSettingOptions.overlayOpacity = 0
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      doneLabel: window.locale[locale].Next,
      steps
    })
    .onbeforechange(function() {
      if (this._currentStep === 0) {
        console.log('pageIntro1_beforechange')
        if (document.querySelector('.pageMetuModal')) {
          document.querySelector('.pageMetuModal .ant-modal-close-x').click()
        }
      }
      // return false to stop displaying the next step
      // return false;
    })
    .onchange(function() {
      skipBtnAddEvent('pageIntro1', hideNav, locale)
    })
    .oncomplete(function() {
      if (!isSkip) {
        setTimeout(() => {
          if (!document.querySelector('.pageMetuModal')) {
            console.log(888)
            const dom = document.querySelector('.iconyemianbianji')
            const event = document.createEvent('MouseEvents')
            // initEvent接受3个参数：
            // 事件类型，是否冒泡，是否阻止浏览器的默认行为
            event.initEvent('click', true, true)
            //触发document上绑定的click事件
            dom.dispatchEvent(event)
          }
          pageIntro2(changeItem, exitAllIntro, hideNav, locale).start()
        }, 0)
      }
      isSkip = false
    })
}

// 页面操作指引2
export const pageIntro2 = (changeItem, exitAllIntro, hideNav, locale) => {
  let steps = [
    {
      element: '.pageMetuModal .ant-modal-content',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Page_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">2/</span>
                                <span>4</span>
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${
                              window.locale[locale].menu_page_list
                            }：</p>
                            <p class="tooltipText">${
                              window.locale[locale].Page_edit_details.split(
                                ';'
                              )[0]
                            }</p>
                            <p class="tooltipText">${
                              window.locale[locale].Page_edit_details.split(
                                ';'
                              )[1]
                            }</p>
                            <p class="tooltipText">${
                              window.locale[locale].Page_edit_details.split(
                                ';'
                              )[2]
                            }</p>
                            <p class="tooltipText">${
                              window.locale[locale].Page_edit_details.split(
                                ';'
                              )[3]
                            }</p>
                            <span class="introSkipBtn" style="right:175px">${
                              window.locale[locale].Skip
                            }</span>
                            <span class="introPrevBtn" style="right:95px">${
                              window.locale[locale].Previous
                            }</span>
                        </div>
                    </div>`,
      position: 'left-top_4'
    }
  ]
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      steps,
      doneLabel: window.locale[locale].Next,
      overlayOpacity: 0.1
    })
    .onchange(function() {
      skipBtnAddEvent('pageIntro2', hideNav, locale)
      prevBtnAddEvent(
        pageIntro1(changeItem, exitAllIntro, hideNav, locale),
        exitAllIntro
      )
    })
    .oncomplete(function() {
      if (!isSkip) {
        if (!document.querySelector('.pageAddModal')) {
          const dom = document.querySelector('.pageList_addBtn')
          const event = document.createEvent('MouseEvents')
          // initEvent接受3个参数：
          // 事件类型，是否冒泡，是否阻止浏览器的默认行为
          event.initEvent('click', true, true)
          //触发document上绑定的click事件
          dom.dispatchEvent(event)
        }
        setTimeout(() => {
          pageIntro3(changeItem, exitAllIntro, hideNav, locale).start()
        }, 200)
      }
      isSkip = false
    })
}

// 页面操作指引3
export const pageIntro3 = (changeItem, exitAllIntro, hideNav, locale) => {
  let steps = [
    {
      element: '.pageAddModal',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Page_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">3/</span>
                                <span>4</span>
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].menu_edit_page}_${window.locale[locale].cardBaseSetting}：</p>
                            <p class="tooltipText">${window.locale[locale].Page_basic_settins}</p>
                            <span class="introSkipBtn" style="right:175px">${window.locale[locale].Skip}</span>
                            <span class="introPrevBtn" style="right:95px">${window.locale[locale].Previous}</span>
                        </div>
                    </div>`,
      position: 'left-top_4'
    },
    {
      element: '.pageAddModal',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">
                        ${window.locale[locale].Page_operation_guide}
                            <span class="tooltipStep">
                                <span class="themeFont"">4/</span>
                                <span>4</span>
                            </span>
                        </p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].menu_edit_page}_${window.locale[locale].Advanced_configuration}：</p>
                            <p class="tooltipText">${window.locale[locale].Css_for_page}</p>
                            <span class="introPrevBtn" style="right:95px">${window.locale[locale].Previous}</span>
                        </div>
                    </div>`,
      position: 'left-top_4'
    }
  ]
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      steps,
      overlayOpacity: 0.1
    })
    .onbeforechange(function() {
      if (this._currentStep === 0) {
        if (document.querySelector('.pageAddModal')) {
          document
            .querySelector('.pageAddModal .ant-tabs-tab:nth-of-type(1)')
            .click()
        }
      }
      if (this._currentStep === 1) {
        if (document.querySelector('.pageAddModal')) {
          document
            .querySelector('.pageAddModal .ant-tabs-tab:nth-of-type(2)')
            .click()
        }
      }
      // return false to stop displaying the next step
      // return false;
    })
    .onchange(function() {
      prevBtnAddEvent(
        pageIntro2(changeItem, exitAllIntro, hideNav, locale),
        exitAllIntro
      )
      skipBtnAddEvent('pageIntro3', hideNav, locale)
    })
    .oncomplete(function() {
      // if(!isSkip){
      console.log('page oncomplete', isSkip)
      hideNav()
      setTimeout(() => {
        const addModal = document.querySelector(
          '.pageAddModal .ant-modal-close-x'
        )
        if (addModal) addModal.click()
        setTimeout(() => {
          const menuModal = document.querySelector(
            '.pageMetuModal .ant-modal-close-x'
          )
          if (menuModal) menuModal.click()
        }, 100)
      }, 100)
      setTimeout(() => {
        lastIntro(locale).start()
      }, 200)
      // }
      // isSkip = false;
    })
    .onbeforeexit(function() {})
    .onexit(function() {})
}

// 新手指引
export const lastIntro = locale => {
  let steps = [
    {
      // element: '.avatar_wrap',
      element: '.ant-dropdown-placement-bottomLeft',
      intro: `<div class="tooltipDiv">
                        <p class="tooltipHeader">${window.locale[locale].top_guide}</p>
                        <div class="tooltipContent">
                            <p class="tooltipTitle themeFont">${window.locale[locale].top_guide}：</p>
                            <p class="tooltipText">${window.locale[locale].Click_start_guide}</p>
                        </div>
                    </div>`,
      position: 'top-right'
    }
  ]
  return IntroJs()
    .setOptions({
      nextLabel: window.locale[locale].Next,
      prevLabel: window.locale[locale].Previous,
      skipLabel: window.locale[locale].Skip,
      doneLabel: window.locale[locale].End,
      ...settingOptions,
      steps,
      doneLabel: window.locale[locale].Known
    })
    .onbeforechange(function() {
      if (this._currentStep === 0) {
        const hiddenDom = document.querySelector(
          '.ant-dropdown.ant-dropdown-placement-bottomLeft.ant-dropdown-hidden'
        )
        hiddenDom && hiddenDom.classList.remove('ant-dropdown-hidden')
      }
    })
    .onchange(function() {})
    .oncomplete(function() {
      const guideDom = document.querySelector('#guideModal_close')
      if (guideDom) guideDom.click()
    })
    .onexit(function() {
      const dom = document.querySelector(
        '.ant-dropdown.ant-dropdown-placement-bottomLeft'
      )
      dom && dom.classList.add('ant-dropdown-hidden')
      Modal.destroyAll()
    })
}

// 增加跳过按钮事件
function skipBtnAddEvent(introName, hideNav, locale) {
  Modal.destroyAll()
  setTimeout(function() {
    let skipButton = document.querySelector('.introSkipBtn')
    if (skipButton) {
      skipButton.addEventListener('click', function(e) {
        // 当跳过的指引是应用指引时，需要返回上一个页面
        if (
          introName === 'appCenterIntro1' ||
          introName === 'appCenterIntro2'
        ) {
          window.history.go(-1)
        }
        // 当跳过的指引是卡片指引时，需要将卡片显示的操作按钮隐藏回去
        if (introName === 'cardIntro1' || introName === 'cardIntro2') {
          const cardBtnDom = document.querySelector('.cardWraper > .floatBtn')
          if (cardBtnDom) {
            cardBtnDom.style.display = 'none'
            const icons = cardBtnDom.children
            if (icons.length) {
              Array.prototype.map.call(icons, d => {
                d.style.display = 'none'
              })
            }
          }
        }
        // 当跳过的指引是页面指引时，需要将打开的弹出框关闭掉
        if (introName === 'pageIntro2' || introName === 'pageIntro3') {
          console.log('skip page step 4?')
          const pageAddCloseBtn = document.querySelector(
            '.pageAddModal .ant-modal-close'
          )
          pageAddCloseBtn && pageAddCloseBtn.click()
          setTimeout(() => {
            const pageListCloseBtn = document.querySelector(
              '.pageMetuModal .ant-modal-close'
            )
            pageListCloseBtn && pageListCloseBtn.click()
          }, 500)
        }
        e.preventDefault()
        hideNav()
        setTimeout(function() {
          document.querySelector('.introjs-skipbutton').click()
          lastIntro(locale).start()
        }, 0)
        isSkip = true
      })
    }
  }, 500)
}

// 增加上一步按钮事件
function prevBtnAddEvent(intro, exitAllIntro) {
  setTimeout(function() {
    let prevButton = document.querySelector('.introPrevBtn')
    if (prevButton) {
      prevButton.addEventListener('click', function(e) {
        e.preventDefault()
        setTimeout(function() {
          exitAllIntro()
          setTimeout(() => {
            const addModal = document.querySelector(
              '.pageAddModal .ant-modal-footer .ant-btn'
            )
            if (addModal) addModal.click()
            intro.start()
          }, 100)
        }, 0)
        isSkip = false
      })
    }
  }, 500)
}

// 增加小提示
function addTip(ele, html, className, position) {
  let eleOffset = getOffset(ele)
  ele.classList.add('introjs-showElement')

  let tooltip = document.createElement('div')
  tooltip.innerHTML = html
  tooltip.classList.add('simpleTip', className)

  let simpleTipArrow = document.createElement('div')
  simpleTipArrow.classList.add('simpleTipArrow')

  tooltip.appendChild(simpleTipArrow)
  document.body.appendChild(tooltip)

  switch (position) {
    case 'right':
      simpleTipArrow.classList.add('right')
      tooltip.classList.add('right')
      tooltip.style.top = eleOffset.top + eleOffset.height / 2 + 'px'
      tooltip.style.left = eleOffset.left + eleOffset.width + 10 + 'px'
      break
    default:
      tooltip.style.top = eleOffset.top + eleOffset.height + 10 + 'px'
      tooltip.style.left = eleOffset.left + eleOffset.width / 2 + 'px'
      break
  }
}

// 获取元素的绝对位置
function getOffset(element) {
  let body = document.body
  let docEl = document.documentElement
  let scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop
  let scrollLeft = window.pageXOffset || docEl.scrollLeft || body.scrollLeft
  let x = element.getBoundingClientRect()
  return {
    top: x.top + scrollTop,
    width: x.width,
    height: x.height,
    left: x.left + scrollLeft
  }
}

// 移除提示
function removeTip(classArr) {
  classArr.map(item => {
    let tip = document.getElementsByClassName(item)[0]
    if (tip) {
      document.body.removeChild(tip)
    }
  })
}

// 增加Div
function addDiv(className, style) {
  let div = document.createElement('div')
  div.style.height = style.height
  div.style.width = style.width
  div.style.left = style.left
  div.style.top = style.top
  div.style.right = style.right
  div.style.bottom = style.bottom
  div.style.position = 'absolute'
  div.style.zIndex = '9999999'
  div.style.background = `url(${style.background})`

  div.classList.add(className)
  let imgContainer = document.getElementsByClassName('imgContainer')[0]
  imgContainer.appendChild(div)
  return div
}

// 移除Div
function removeDiv(classArr) {
  let imgContainer = document.getElementsByClassName('imgContainer')[0]
  classArr.map(item => {
    let div = document.getElementsByClassName(item)[0]
    if (div) {
      imgContainer.removeChild(div)
    }
  })
}

// 自定义引导组件遮罩层位置，用于解决目标父元素为fixed定位的目标z-index无效问题
function customIntroOverLay(fixParent, cloneParent) {
  let overlayOrigin = cloneParent.getElementsByClassName('introjs-overlay')[0]
  let helperLayerOrigin = cloneParent.getElementsByClassName(
    'introjs-helperLayer'
  )[0]

  let overlayClone = overlayOrigin.cloneNode(true)
  let helperLayerClone = helperLayerOrigin.cloneNode(true)

  fixParent.appendChild(overlayClone)
  fixParent.appendChild(helperLayerClone)

  cloneParent.removeChild(overlayOrigin)
  cloneParent.removeChild(helperLayerOrigin)
}

// 触发window.resize事件
function windowResize() {
  let myEvent = new Event('resize')
  window.dispatchEvent(myEvent)
}

// 检测元素加载完成
function checkElementMounted(targetName, callback) {
  let timer = setInterval(function() {
    let element = document.querySelector(targetName)
    if (element) {
      clearInterval(timer)
      callback()
    }
  }, 100)
}

// 调整提示框位置,为解决加大字体设置导致的位置不准确问题
function adjustHelperLayerPosition(distance) {
  // let helperLayer = document.body.querySelector('.introjs-helperLayer');
  // helperLayer.style.top = parseInt(helperLayer.style.top) - distance + 'px';
}
