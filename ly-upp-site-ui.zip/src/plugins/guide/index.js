/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-09-06 14:39:48
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-16 17:59:30
 */
// 首页引导弹窗
import React from 'react'
import { Modal, Button } from 'antd'
import styles from './index.less'
import {
  commonIntro,
  appCenterIntro1,
  appCenterIntro2,
  cardIntro1,
  cardIntro2,
  pageIntro1,
  pageIntro2,
  pageIntro3,
  lastIntro
} from './component/index.js'
import { reqGuideHasUsed } from 'utils/api'
import { setGuideUsed } from 'redux/actions/login'
import { connect } from 'react-redux'
import classNames from 'classnames'

@connect(state => {
  return { ...state }
})
export default class GuideModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      introNav: false,
      currentIndex: '',
      locale: 'zh_CN'
    }
  }

  componentDidMount() {
    this.initIntro()
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.visible && !this.props.visible) {
      this.setState({ currentIndex: 1 })
    }
    if (nextProps.login.locale !== this.props.locale) {
      this.setState({ locale: nextProps.login.locale }, () => {
        this.initIntro()
      })
    }
  }

  render() {
    let { locale } = this.state
    const introArr = [
      window.locale[locale].Common_button_guide,
      window.locale[locale].Application_operation_guide,
      window.locale[locale].Card_operation_guide,
      window.locale[locale].Page_operation_guide
    ]
    return (
      <div>
        <Modal
          // className="introModal"
          className={styles.introModal}
          visible={this.props.visible}
          footer={null}
          width={620}
          destroyOnClose={true}
          centered={true}
          title={
            // <div className="modalTitle">
            <div className={styles.modalTitle}>
              <span>{window.locale[locale].top_guide}</span>
            </div>
          }
          onCancel={this.closeIntroModal}
        >
          <div className={styles.introDiv}>
            <div className={styles.introText}>
              <p>{window.locale[locale].Welcome_modal}</p>
              <p>{window.locale[locale].Welcome_title}</p>
              <p>
                <Button type="primary" size="large" onClick={this.toIntro}>
                  {window.locale[locale].Open_guide}
                </Button>
                {/* <span onClick={this.toIntro}>开启指引</span> */}
              </p>
            </div>
          </div>
        </Modal>
        {/* <div className={styles.introNav} style={{display:this.state.introNav ? 'block' : 'none'}}> */}
        {this.state.introNav && (
          <div className={styles.introNav}>
            <div
              id="guideModal_close"
              className={styles.closeIcon}
              onClick={this.cancelNav}
            ></div>
            {introArr.map((item, index) => {
              return (
                <p
                  onClick={e => {
                    this.selectItem(e, index + 1)
                  }}
                  key={item}
                  className={classNames(styles.introNavItem, 'guide_' + index)}
                >
                  <span
                    className={styles.arrowIcon}
                    style={{
                      display:
                        this.state.currentIndex == index + 1
                          ? 'inline-block'
                          : 'none'
                    }}
                  ></span>
                  <span>{item}</span>
                </p>
              )
            })}
          </div>
        )}
      </div>
    )
  }

  // 初始化引导
  initIntro = () => {
    let { locale } = this.state
    let common = commonIntro(
      this.changeItem,
      this.exitAllIntro,
      this.hideNav,
      locale
    )
    let last = lastIntro(locale)
    let appCenter1 = appCenterIntro1(
      this.changeItem,
      this.exitAllIntro,
      this.hideNav,
      locale
    )
    let appCenter2 = appCenterIntro2(
      this.changeItem,
      this.exitAllIntro,
      this.hideNav,
      locale
    )
    let page1 = pageIntro1(
      this.changeItem,
      this.exitAllIntro,
      this.hideNav,
      locale
    )
    let page2 = pageIntro2(
      this.changeItem,
      this.exitAllIntro,
      this.hideNav,
      locale
    )
    let page3 = pageIntro3(
      this.changeItem,
      this.exitAllIntro,
      this.hideNav,
      locale
    )
    let card1 = cardIntro1(
      this.changeItem,
      this.exitAllIntro,
      this.hideNav,
      locale
    )
    let card2 = cardIntro2(
      this.changeItem,
      this.exitAllIntro,
      this.hideNav,
      locale
    )
    this.setState({
      common,
      last,
      appCenter1,
      appCenter2,
      page1,
      page2,
      page3,
      card1,
      card2
    })
  }

  // 点击开始简单或详细引导
  toIntro = e => {
    e.preventDefault()
    this.props.onClose()
    const { guideUsed } = this.props.login
    // console.log('guideUsed?')
    if (!guideUsed) {
      reqGuideHasUsed().then(res => {
        const { meta } = res.data
        if (!meta.success) console.log('reqGuideHasUsed error!')
        this.props.dispatch(setGuideUsed(true))
      })
    }
    // window.location.href = '#/index';
    // window.location.href = '#/classPage';
    // window.location.href = '#/test11';
    setTimeout(() => {
      // document.body.removeEventListener(
      //   'DOMSubtreeModified',
      //   this.listenOverlay
      // )
      this.state.common.start()
      this.setState({ introNav: true, currentIndex: 1 })
    }, 500)
  }

  // 关闭引导弹窗
  closeIntroModal = () => {
    this.props.onClose()
    this.setState({
      introNav: false,
      currentIndex: 1
    })
    this.state.last.start()
  }

  // 取消侧边引导导航
  cancelNav = () => {
    this.exitAllIntro()
    this.setState({
      introNav: false,
      currentIndex: 1
    })
  }

  // 指引跳过时，需要把指引导航modal隐藏掉，此时切换指引会出问题
  hideNav = item => {
    this.setState({ introNav: false })
  }

  // 更改引导选项
  changeItem = item => {
    this.setState({ currentIndex: item })
  }

  // 强制退出所有引导
  exitAllIntro = () => {
    let {
      appCenter1,
      appCenter2,
      page1,
      page2,
      page3,
      card1,
      card2
    } = this.state
    Modal.destroyAll()
    appCenter1.exit()
    appCenter2.exit()
    page1.exit()
    page2.exit()
    page3.exit()
    card1.exit()
    card2.exit()
  }

  // 选择引导选项
  selectItem = (e, key) => {
    if (e) e.preventDefault()
    // 如果从应用指引切换到其他指引，需要从应用指引页面返回到原来的页面
    if (this.state.currentIndex == 2) {
      console.log('从应用指引切换到其他指引')
      window.history.go(-1)
    }
    // 如果从页面操作指引切换到其他指引，需要关闭打开的弹出框
    if (this.state.currentIndex == 4) {
      console.log('从页面操作指引切换到其他指引')
      const pageListCloseBtn = document.querySelector(
        '.pageMetuModal .ant-modal-close'
      )
      const pageAddCloseBtn = document.querySelector(
        '.pageAddModal .ant-modal-close'
      )
      pageListCloseBtn && pageListCloseBtn.click()
      pageAddCloseBtn && pageAddCloseBtn.click()
    }
    this.setState({ currentIndex: key })
    this.exitAllIntro()
    // if (window.location.hash == '#/index') {
    this.delaySwitch(key, 500)
    // } else {
    //     window.location.href = '#/index';
    //     this.delaySwitch(key, 1000);
    // }
  }

  // 延迟执行相应选项
  delaySwitch(key, time) {
    let { appCenter1, page1, common, card1 } = this.state
    const _this = this
    setTimeout(function() {
      switch (key) {
        // 常用按钮指引
        case 1:
          common.start()
          break
        // 应用操作指引
        case 2:
          appCenter1.start()
          break
        // 卡片操作指引
        case 3:
          // if (document.querySelector('.cardWraper')) {
          //   card1.start()
          // } else {
          //   _this.setState({ currentIndex: 4 })
          //   page1.start()
          // }
          card1.start()
          break
        case 4:
          page1.start()
          break
      }
    }, time)
  }

  // 监听遮罩层变化,控制导航是否显示
  listenOverlay = () => {
    let that = this
    let overlay = document.querySelector('.introjs-overlay')
    if (overlay) {
      if (document.querySelector('.introjs-tooltiptext')) {
        let tooltip = document.querySelector('.introjs-tooltiptext').innerText
        if (tooltip.indexOf('新手') == -1) {
          that.setState({ introNav: true })
        } else {
          that.setState({ introNav: false })
        }
      }
    } else {
      that.setState({ introNav: false })
    }
  }
}
