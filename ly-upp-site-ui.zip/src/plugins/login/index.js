/*
 * @Description: 登录页面
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-15 14:09:01
 */
import React from 'react'
import { Form, Icon, Modal, Input, Button } from 'antd'
import { connect } from 'react-redux'
import { userLogin } from 'utils/service'
import login_logo from 'assets/images/login_logo.png'
import { LyPassword } from 'components'
import Footer from '../footer/index'
import styles from './index.css'
import bg from 'assets/images/bg.jpg'
const FormItem = Form.Item

@connect(state => {
  return { ...state }
})
@Form.create()
export default class LoginPage extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      type: 'tab1',
      active: {},
      count: 0,
      loginLogo: ''
    }
  }

  componentWillMount() {
    document.getElementsByTagName('title')[0].innerText =
      this.props.login.pageInfo &&
      JSON.parse(this.props.login.pageInfo[0].value)[this.props.login.locale]
        ? this.props.login.pageInfo[0].value[this.props.login.locale]
        : '服务门户管理平台'
  }

  handleAccountSubmit = e => {
    e.preventDefault()
    const { dispatch } = this.props
    if (this.state.type === 'tab1') {
      this.props.form.validateFields((err, values) => {
        if (!err) {
          // userLogin(values.userName, strPass, dispatch);
          userLogin(values.userName, values.password, dispatch)
        } else {
          Modal.error({ title: '登录', content: '用户账号、密码不能为空！' })
        }
      })
    }
  }

  render() {
    const { getFieldDecorator } = this.props.form
    return (
      <div
        className={styles.container}
        style={{ backgroundImage: `url(${bg})` }}
      >
        <div className={styles.content}>
          <div className={styles.loginLogo}>
            <img
              src={login_logo}
              onError={e => {
                e.target.src = login_logo
              }}
            />
          </div>
          <div className={styles.main}>
            <Form onSubmit={this.handleAccountSubmit}>
              <FormItem>
                {getFieldDecorator('userName', {
                  rules: [{ required: true, message: '请输入您的账号！' }]
                })(
                  <Input
                    size="large"
                    prefix={
                      <Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />
                    }
                    placeholder="请输入用户名"
                  />
                )}
              </FormItem>
              <FormItem>
                {getFieldDecorator('password', {
                  rules: [{ required: true, message: '请输入密码！' }]
                })(
                  <LyPassword
                    encryptMark="*"
                    placeholder="请输入密码"
                    onChange={password => {
                      this.props.form.setFieldsValue({ password })
                    }}
                  />
                )}
              </FormItem>
              <FormItem>
                <Button
                  className={styles.submit}
                  size="large"
                  htmlType="submit"
                >
                  登录
                </Button>
              </FormItem>
            </Form>
          </div>
        </div>
        <div style={{ margin: '48px 0 24px' }}>
          <Footer
            content={
              this.props.login.pageInfo
                ? this.props.login.pageInfo[1].value
                : ''
            }
          />
        </div>
      </div>
    )
  }
}
