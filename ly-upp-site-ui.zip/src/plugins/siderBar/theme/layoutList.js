import React from "react";
import { Icon, message } from "antd";
import { Scrollbars } from "components";
import { connect } from "react-redux";
import { layoutList } from "./data";
import { setPage } from "redux/actions/page";
import classnames from "classnames";
import _ from "lodash";

@connect(state => {
  return { ...state };
})
export default class LayoutList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: layoutList,
      type: null
    };
  }

  componentDidMount() {
    this.setSelectLayout(this.props);
  }

  componentWillReceiveProps(nextProp) {
    // 侧边栏图标变化
    let nextElement = nextProp.page.element[nextProp.page.currentPage];
    let propsElement = this.props.page.element[this.props.page.currentPage];
    if (
      !_.isEqual(nextElement, propsElement) ||
      nextProp.page.currentPage != this.props.page.currentPage
    ) {
      this.setSelectLayout(nextProp);
    }
  }

  // 设置选中的布局
  setSelectLayout = nextProp => {
    const { element, currentPage } = nextProp.page;
    // 系统总的页面布局
    let newElement = element;
    // 本菜单下的页面布局
    let object = newElement[currentPage];
    if (object && object.layout) {
      this.setState({
        type: object.layout
      });
    }
  };

  // 设置布局
  setElement = item => {
    // 特殊判断--当前页面为应用中心页面 只能更改肤色
    const { page, login } = this.props;
    const { system } = page;
    const { localeJson } = login;
    const isAppCenterPage = system.pageId === "lyappCenter";
    if (isAppCenterPage) {
      return message.warning(localeJson.siderBarCurrentPageForbidLayout);
    }

    this.setState({
      type: item.type
    });
    // 系统总的页面布局
    let element = this.props.page.element;
    let currentPage = this.props.page.currentPage;
    // 本菜单下的页面布局
    let object = this.props.page.element[currentPage];

    object = {
      ...object,
      layout: item.type,
      layoutName: item.name
    };
    element = {
      ...element,
      [currentPage]: object
    };
    sessionStorage.setItem("element", JSON.stringify(element));
    this.props.dispatch(setPage(element));
  };

  render() {
    const { list } = this.state;
    const { login } = this.props;
    const { localeJson } = login;
    return (
      <div>
        <Scrollbars style={{ height: 444, textAlign: "center" }}>
          <ul className={"ulContent"}>
            {list.map(item => {
              return (
                <li
                  className={classnames({
                    active: item.type == this.state.type
                  })}
                  key={item.type}
                  onClick={() => this.setElement(item)}
                >
                  {item.type == this.state.type && (
                    <div className="successIcon">
                      <img src={require("assets/images/success.png")} />
                    </div>
                  )}
                  <img src={item.img} />
                  <p>{localeJson[item.name]}</p>
                </li>
              );
            })}
          </ul>
        </Scrollbars>
        <div
          className="blue"
          style={{
            margin: "8px 0 10px",
            textAlign: "center",
            cursor: "pointer"
          }}
          onClick={() => this.props.handleThemeModal("siderBarLayout")}
        >
          {localeJson.moreLayout}
          <Icon style={{ marginLeft: "4px" }} type="right" />
        </div>
      </div>
    );
  }
}
