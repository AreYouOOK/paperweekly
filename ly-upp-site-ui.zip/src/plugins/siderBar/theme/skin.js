/*
 * @Description: 侧边栏肤色设置
 * @Author: xuqiuting
 * @Date: 2019-06-05 17:11:16
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-10-29 11:33:39
 */
import React from "react";
import { message, Icon } from "antd";
import { Scrollbars } from "components";
import { connect } from "react-redux";
import { skinList } from "./data";
import { setPage } from "redux/actions/page";
import classnames from "classnames";
import ColorPicker from "./colorPicker";
import _ from "lodash";

@connect(state => {
  return { ...state };
})
export default class Skin extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: skinList,
      displayColorPicker: false,
      color: "#F5222D",
      type: null
    };
  }

  componentDidMount() {
    this.setSelectLayout(this.props);
  }

  componentWillReceiveProps(nextProp) {
    // 侧边栏图标变化
    let nextElement = nextProp.page.element[nextProp.page.currentPage];
    let propsElement = this.props.page.element[this.props.page.currentPage];
    if (
      !_.isEqual(nextElement, propsElement) ||
      nextProp.page.currentPage != this.props.page.currentPage
    ) {
      this.setSelectLayout(nextProp);
    }
  }

  // 设置选中的皮肤
  setSelectLayout = nextProp => {
    const { element, currentPage } = nextProp.page;
    // 系统总的页面布局
    let newElement = element;
    // 本菜单下的页面布局
    let object = newElement[currentPage];
    if (object && object.skin) {
      this.setState({
        type: object.skin
      });
    }
  };

  // 是否展示colorPicker
  handleDisplayColor = () => {
    this.setState({
      displayColorPicker: !this.state.displayColorPicker
    });
  };

  // 设置换肤
  handleSkin = item => {
    this.setState({
      type: item.type
    });
    if (item.type == "auto") {
      this.handleDisplayColor();
    } else {
      let initialTheme = { "@primary-color": item.type };
      window.less
        .modifyVars(initialTheme)
        .then(() => {
          this.setElement(item.type, item.name);
        })
        .catch(error => {
          message.error(`更新主题失败`);
        });
    }
  };

  // 颜色选择变化
  handleColorChange = color => {
    this.setState({
      color: color
    });
    let initialTheme = { "@primary-color": color };
    window.less
      .modifyVars(initialTheme)
      .then(() => {
        this.setElement(color, color);
      })
      .catch(error => {
        message.error(`更新主题失败`);
      });
  };

  // 设置布局
  setElement = (value, name) => {
    // 系统总的页面布局
    let element = this.props.page.element;
    let currentPage = this.props.page.currentPage;
    // 本菜单下的页面布局
    let object = this.props.page.element[currentPage];
    object = {
      ...object,
      skin: value,
      pageColorName: name
    };
    element = {
      ...element,
      [currentPage]: object
    };
    sessionStorage.setItem("element", JSON.stringify(element));
    this.props.dispatch(setPage(element));
  };

  render() {
    const { list } = this.state;
    const { login } = this.props;
    const { localeJson } = login;
    return (
      <div>
        {this.state.displayColorPicker ? (
          <ColorPicker
            type="sketch"
            small
            color={this.state.color}
            handleClose={() => this.handleDisplayColor()}
            presetColors={[
              "#F5222D",
              "#FA541C",
              "#FA8C16",
              "#FAAD14",
              "#FADB14",
              "#A0D911",
              "#52C41A",
              "#13C2C2",
              "#1890FF",
              "#2F54EB",
              "#722ED1",
              "#EB2F96"
            ]}
            onChangeComplete={color => this.handleColorChange(color)}
          />
        ) : null}
        <Scrollbars style={{ height: 444, textAlign: "center" }}>
          <ul className={"ulContent"}>
            {list.map(item => {
              return (
                <li
                  key={item.type}
                  className={classnames({
                    active: item.type == this.state.type
                  })}
                  onClick={() => this.handleSkin(item)}
                >
                  {item.type == this.state.type && (
                    <div className="successIcon">
                      <img src={require("assets/images/success.png")} />
                    </div>
                  )}
                  <img src={item.img} />
                  <p>{localeJson[item.name]}</p>
                </li>
              );
            })}
          </ul>
        </Scrollbars>
        <div
          className="blue"
          style={{
            margin: "8px 0 10px",
            textAlign: "center",
            cursor: "pointer"
          }}
          onClick={() => this.props.handleThemeModal("siderBarSkin")}
        >
          {localeJson.moreSkin}
          <Icon style={{ marginLeft: "4px" }} type="right" />
        </div>
      </div>
    );
  }
}
