/*
 * @Description: 颜色选择器
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-14 16:57:48
 */
import React, { Component } from "react";
import { SketchPicker } from "react-color";

export default class ColorPicker extends Component {
  static defaultProps = {
    onChange: () => {},
    onChangeComplete: () => {},
    position: "bottom",
    handleClose: () => {}
  };

  constructor(props) {
    super();
    this.state = {
      displayColorPicker: false,
      color: props.color
    };
  }
  componentWillReceiveProps(nextProps) {
    this.setState({
      color: nextProps.color
    });
  }

  // 点击
  handleClick = () => {
    this.setState({ displayColorPicker: !this.state.displayColorPicker });
  };

  // 关闭弹窗
  handleClose = () => {
    this.props.handleClose();
  };

  // 颜色选择改变
  handleChange = color => {
    this.setState({ color: color.hex });
    this.props.onChange(color.hex, color);
  };

  // 颜色选择改变
  handleChangeComplete = color => {
    this.setState({ color: color.hex });
    this.props.onChangeComplete(color.hex);
  };

  render() {
    const { small } = this.props;
    const styles = {
      color: {
        width: small ? "16px" : "120px",
        height: small ? "16px" : "24px",
        borderRadius: "2px",
        background: this.state.color
      },
      swatch: {
        padding: "4px",
        background: "#fff",
        borderRadius: "2px",
        boxShadow: "0 0 0 1px rgba(0,0,0,.1)",
        display: "inline-block",
        cursor: "pointer"
      },
      popover: {
        position: "absolute",
        zIndex: "2"
      },
      cover: {
        position: "fixed",
        top: "0px",
        right: "0px",
        bottom: "0px",
        left: "0px"
      },
      wrapper: {
        position: "inherit",
        zIndex: "100"
      }
    };

    return (
      <div style={styles.popover}>
        <div style={styles.cover} onClick={this.handleClose} />
        <div style={styles.wrapper}>
          <SketchPicker
            width={230}
            {...this.props}
            color={this.state.color}
            onChange={this.handleChange}
            onChangeComplete={this.handleChangeComplete}
          />
        </div>
      </div>
    );
  }
}
