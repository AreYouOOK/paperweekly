/*
 * @Description: 侧边栏主题入口
 * @Author: xuqiuting
 * @Date: 2019-06-05 16:00:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-14 16:42:37
 */
import React, { Fragment } from "react";
import { Divider } from "antd";
import classnames from "classnames";
import { connect } from "react-redux";
import DressUp from "./dressUp";
import LayoutList from "./layoutList";
import Skin from "./skin";
import { themeTab } from "./data";
import { getHashParam } from "utils/util";

@connect(state => {
  return { ...state };
})
export default class Theme extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      activeKey: "siderBarDressUp",
      tabList: []
    };
  }

  componentDidMount() {
    this.setTablist(this.props);
  }

  componentWillReceiveProps(nextProps) {
    if (
      this.props.page.skinDisable != nextProps.page.skinDisable ||
      this.props.page.layoutDisable != nextProps.page.layoutDisable ||
      this.props.page.themeDisable != nextProps.page.themeDisable
    ) {
      this.setTablist(nextProps);
    }
  }

  // 设置tabList
  setTablist = props => {
    let tabList = [];
    const { skinDisable, layoutDisable, themeDisable } = props.page;
    const editTheme = getHashParam('themeId')
    if (!themeDisable && !editTheme) {
      tabList.push(themeTab[0]);
    }
    if (!layoutDisable) {
      tabList.push(themeTab[1]);
    }
    if (!skinDisable) {
      tabList.push(themeTab[2]);
    }
    this.setState({
      tabList: tabList,
      activeKey: tabList.length>0?tabList[0].type:""
    });
  };

  // tab改变
  handleTab = res => {
    this.setState({
      activeKey: res.type
    });
    this.props.handleThemeTab(res.type);
  };

  // 生成内容
  generateContent = () => {
    const { activeKey } = this.state;
    let component = <DressUp handleThemeModal={this.props.handleThemeModal} />;
    switch (activeKey) {
      case "siderBarDressUp":
        component = <DressUp handleThemeModal={this.props.handleThemeModal} />;
        break;
      case "siderBarLayout":
        component = (
          <LayoutList handleThemeModal={this.props.handleThemeModal} />
        );
        break;
      case "siderBarSkin":
        component = <Skin handleThemeModal={this.props.handleThemeModal} />;
        break;
    }
    return component;
  };

  render() {
    const { login } = this.props;
    const { localeJson } = login;
    const { tabList, activeKey } = this.state;
    return (
      <div className="siderBarTheme" key={activeKey}>
        <ul className={"themeTab"}>
          {tabList.map((res, index) => {
            return (
              <Fragment key={res.type}>
                <li
                  className={classnames({ active: res.type == activeKey })}
                  onClick={() => this.handleTab(res)}
                  key={res.type}
                >
                  {localeJson[res.type]}
                </li>
                {index != tabList.length - 1 && <Divider type="vertical" />}
              </Fragment>
            );
          })}
        </ul>
        {this.generateContent()}
      </div>
    );
  }
}
