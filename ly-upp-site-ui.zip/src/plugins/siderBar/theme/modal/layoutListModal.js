/*
 * @Description: 侧边栏布局弹窗
 * @Author: xuqiuting
 * @Date: 2019-06-28 14:35:43
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-14 16:58:59
 */
import React from 'react'
import { Icon, Pagination } from 'antd';
import classnames from 'classnames';
import { drawerLayoutList, } from '../data'
import { setPage } from 'redux/actions/page';
import { connect } from 'react-redux';

@connect(state => {
    return { ...state };
})
export default class LayoutListModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            layoutTab: [
                {
                    title: '布局中心',
                    key: "layoutCenter"
                },
            ],
            tab: "layoutCenter",
            activeKeyType: "official",
            dataSource: drawerLayoutList[0],
            selectTheme: null,
            total: 14,
        };
    }

    componentDidMount() {
        this.setSelectLayout()
    }

    // 设置选中的布局
    setSelectLayout = () => {
        const { element, currentPage } = this.props.page;
        // 系统总的页面布局
        let newElement = element;
        // 本菜单下的页面布局
        let object = newElement[currentPage];
        if (object && object.layout) {
            this.setState({
                type: object.layout
            })
        }
    }

    // 切换tab
    hanldeTab = (key) => {
        this.setState({
            tab: key
        })
    }

    // 切换搜索条件
    handleTypeChange = (type) => {
        this.setState({
            activeKeyType: type
        })
    }

    //页数改变
    pageChange = (current) => {
        this.setState({
            dataSource: drawerLayoutList[current - 1]
        })
    }

    //选择主题
    setElement = (item) => {
        this.setState({
            type: item.type
        })
        // 系统总的页面布局
        let element = this.props.page.element;
        let currentPage = this.props.page.currentPage;
        // 本菜单下的页面布局
        let object = this.props.page.element[currentPage];

        object = {
            ...object,
            layout: item.type,
            layoutName: item.name
        }
        element = {
            ...element,
            [currentPage]: object,
        }
        sessionStorage.setItem("element", JSON.stringify(element));
        this.props.dispatch(setPage(element))
    }

    render() {
        const { login } = this.props;
        const { localeJson } = login;
        const { layoutTab, dataSource } = this.state;
        return <div className="themeDrawerWrapper">
            <div className="clearfix themeDrawerTab">
                <ul className="fl">
                    {
                        layoutTab.map(res => {
                            return <li
                                key={res.key}
                                onClick={() => this.hanldeTab(res.key)}
                                className={classnames({ active: res.key == this.state.tab })}
                            >
                                {res.title}
                            </li>
                        })
                    }
                </ul>
                <Icon
                    type="close"
                    className="fr"
                    style={{
                        cursor: "pointer"
                    }}
                    onClick={this.props.handleThemeModal}
                />
            </div>
            <ul className={"drawerlayoutList"}>
                {
                    dataSource.map(item => {
                        return <li
                            className={classnames({ active: item.type == this.state.type })}
                            key={item.type}
                            onClick={() => this.setElement(item)}>
                            {
                                (item.type == this.state.type) && <div className="successIcon">
                                    <img src={require("assets/images/success.png")} />
                                </div>
                            }
                            <img src={item.img} />
                            <p>
                                {localeJson[item.name]}
                            </p>
                        </li>
                    })
                }
            </ul>
            <Pagination
                size="small"
                className={"pagination"}
                defaultCurrent={1}
                total={this.state.total}
                onChange={this.pageChange} />
        </div>;
    }
}