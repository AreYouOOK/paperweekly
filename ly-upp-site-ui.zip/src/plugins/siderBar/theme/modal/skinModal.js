/*
 * @Description: 肤色弹窗
 * @Author: xuqiuting
 * @Date: 2019-06-28 14:35:54
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-14 16:59:49
 */
import React from "react";
import { Icon, Pagination } from "antd";
import classnames from "classnames";
import { drawerSkinList } from "../data";
import { setPage } from "redux/actions/page";
import { connect } from "react-redux";
import ColorPicker from "../colorPicker";

@connect(state => {
  return { ...state };
})
export default class SkinModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      layoutTab: [
        {
          title: "肤色中心",
          key: "siderBarSkinCenter"
        }
      ],
      tab: "siderBarSkinCenter",
      activeKeyType: "official",
      dataSource: drawerSkinList[0],
      selectTheme: null,
      total: 14
    };
  }

  componentDidMount() {
    this.setSelectLayout();
  }

  // 设置选中的皮肤
  setSelectLayout = () => {
    const { element, currentPage } = this.props.page;
    // 系统总的页面布局
    let newElement = element;
    // 本菜单下的页面布局
    let object = newElement[currentPage];
    if (object && object.skin) {
      this.setState({
        type: object.skin
      });
    }
  };

  // 切换tab
  hanldeTab = key => {
    this.setState({
      tab: key
    });
  };

  // 切换搜索条件
  handleTypeChange = type => {
    this.setState({
      activeKeyType: type
    });
  };

  //页数改变
  pageChange = current => {
    this.setState({
      dataSource: drawerSkinList[current - 1]
    });
  };

  // 是否展示colorPicker
  handleDisplayColor = () => {
    this.setState({
      displayColorPicker: !this.state.displayColorPicker
    });
  };

  // 设置换肤
  handleSkin = item => {
    this.setState({
      type: item.type
    });
    if (item.type == "auto") {
      this.handleDisplayColor();
    } else {
      let initialTheme = { "@primary-color": item.type };
      window.less
        .modifyVars(initialTheme)
        .then(() => {
          this.setElement(item.type, item.name);
        })
        .catch(error => {
          message.error(`更新主题失败`);
        });
    }
  };

  // 肤色选择变化
  handleColorChange = color => {
    this.setState({
      color: color
    });
    let initialTheme = { "@primary-color": color };
    window.less
      .modifyVars(initialTheme)
      .then(() => {
        this.setElement(color, color);
      })
      .catch(error => {
        message.error(`更新主题失败`);
      });
  };

  // 设置布局
  setElement = (value, name) => {
    // 系统总的页面布局
    let element = this.props.page.element;
    let currentPage = this.props.page.currentPage;
    // 本菜单下的页面布局
    let object = this.props.page.element[currentPage];
    object = {
      ...object,
      skin: value,
      pageColorName: name
    };
    element = {
      ...element,
      [currentPage]: object
    };
    sessionStorage.setItem("element", JSON.stringify(element));
    this.props.dispatch(setPage(element));
  };

  render() {
    const { login } = this.props;
    const { localeJson } = login;
    const { layoutTab, dataSource } = this.state;
    return (
      <div className="themeDrawerWrapper">
        {this.state.displayColorPicker ? (
          <ColorPicker
            type="sketch"
            small
            color={this.state.color}
            handleClose={() => this.handleDisplayColor()}
            presetColors={[
              "#F5222D",
              "#FA541C",
              "#FA8C16",
              "#FAAD14",
              "#FADB14",
              "#A0D911",
              "#52C41A",
              "#13C2C2",
              "#1890FF",
              "#2F54EB",
              "#722ED1",
              "#EB2F96"
            ]}
            onChangeComplete={color => this.handleColorChange(color)}
          />
        ) : null}
        <div className="clearfix themeDrawerTab">
          <ul className="fl">
            {layoutTab.map(res => {
              return (
                <li
                  key={res.key}
                  onClick={() => this.hanldeTab(res.key)}
                  className={classnames({ active: res.key == this.state.tab })}
                >
                  {localeJson[res.key]}
                </li>
              );
            })}
          </ul>
          <Icon
            type="close"
            className="fr"
            style={{
              cursor: "pointer"
            }}
            onClick={this.props.handleThemeModal}
          />
        </div>
        <ul className={"drawerlayoutList"}>
          {dataSource.map(item => {
            return (
              <li
                className={classnames({ active: item.type == this.state.type })}
                key={item.type}
                onClick={() => this.handleSkin(item)}
              >
                {item.type == this.state.type && (
                  <div className="successIcon">
                    <img src={require("assets/images/success.png")} />
                  </div>
                )}
                <img src={item.img} />
                <p>{localeJson[item.name]}</p>
              </li>
            );
          })}
        </ul>
        <Pagination
          size="small"
          className={"pagination"}
          defaultCurrent={1}
          total={this.state.total}
          onChange={this.pageChange}
        />
      </div>
    );
  }
}
