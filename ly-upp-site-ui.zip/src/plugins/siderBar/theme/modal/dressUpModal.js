/*
 * @Description: 侧边栏主题弹窗入口
 * @Author: xuqiuting
 * @Date: 2019-06-28 14:35:20
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-14 16:58:32
 */
import React from 'react'
import { Icon } from 'antd';
import classnames from 'classnames';
import { connect } from 'react-redux';
import ThemeCenterContent from './themeCenterContent'
import MyThemeContent from './myThemeContent'

@connect(state => {
    return { ...state };
})
export default class DressUpModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            themeTab: [
                {
                    title: '主题中心',
                    key: "siderBarThemeCenter"
                },
                {
                    title: '我的主题',
                    key: "siderBarMyTheme"
                },
            ],
            tab: "siderBarThemeCenter",
        };
    }

    // 切换tab
    hanldeTab = (key) => {
        this.setState({
            tab: key
        })
    }
    
    render() {
        const { login } = this.props;
        const { localeJson } = login;
        const { themeTab, tab } = this.state;
        return <div className="themeDrawerWrapper">
            <div className="clearfix themeDrawerTab">
                <ul className="fl">
                    {
                        themeTab.map(res => {
                            return <li
                                key={res.key}
                                onClick={() => this.hanldeTab(res.key)}
                                className={classnames({ active: res.key == this.state.tab })}
                            >
                                {
                                    localeJson[res.key]
                                }
                            </li>
                        })
                    }
                </ul>
                <Icon
                    type="close"
                    className="fr"
                    style={{
                        cursor: "pointer"
                    }}
                    onClick={this.props.handleThemeModal}
                />
            </div>
            {
                tab == "siderBarThemeCenter" ? <ThemeCenterContent /> : <MyThemeContent />
            }
        </div>;
    }
}