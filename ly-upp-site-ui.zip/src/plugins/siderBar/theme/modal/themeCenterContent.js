/*
 * @Description: 侧边栏主题-主题中心弹窗
 * @Author: xuqiuting
 * @Date: 2019-06-29 12:45:08
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-10-29 12:04:02
 */
import React, { Fragment } from 'react'
import {
  Input,
  Button,
  Divider,
  Pagination,
  message,
  Tooltip,
  Spin
} from 'antd'
import _ from 'lodash'
import classnames from 'classnames'
import { connect } from 'react-redux'
import { getThemeContent } from 'utils/service'
import { reqGetThemeList, downloadApi } from 'utils/api'
import { getLanguageTitle } from 'utils/util'

@connect(state => {
  return { ...state }
})
export default class ThemeCenterContent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      // 查询tag列表
      searchList: [
        {
          title: '全部',
          key: 'all',
          type: 'siderBarMythemeType1'
        },
        {
          title: '官方',
          key: '1',
          type: 'siderBarThemeCenterType1'
        },
        {
          title: '共享',
          key: '2',
          type: 'siderBarThemeCenterType2'
        },
        {
          title: '推荐',
          key: '3',
          type: 'siderBarThemeCenterType3'
        },
        {
          title: '最新',
          key: '4',
          type: 'siderBarThemeCenterType4'
        }
      ],
      activeKeyType: 'all', // 当前选中的tag
      dataSource: [], // 数据列表
      selectTheme: null, // 选中的主题
      total: 0, // 数据总共条数
      pageNum: 1, // 当前页
      themeName: null, // 查询名称
      loading: true
    }
  }

  componentDidMount() {
    this.getThemeList()
  }

  componentWillReceiveProps(nextProp) {
    // 侧边栏图标变化
    let nextElement = nextProp.page.element[nextProp.page.currentPage]
    let propsElement = this.props.page.element[this.props.page.currentPage]
    if (
      !_.isEqual(nextElement, propsElement) ||
      nextProp.page.currentPage != this.props.page.currentPage
    ) {
      if (this.state.dataSource.length > 0) {
        this.setSelectTheme(nextProp)
      }
    }
  }

  // 获取主题列表
  getThemeList = () => {
    let params = {
      pageNum: this.state.pageNum,
      pageSize: 6,
      themeName: this.state.themeName,
      themeType:
        this.state.activeKeyType == 'all' ? null : this.state.activeKeyType
    }
    reqGetThemeList(params).then(res => {
      const { data } = res
      if (data.meta.success) {
        this.setState(
          {
            loading: false,
            dataSource: data.data.list.map(item => {
              return {
                ...item,
                themeTip: this.changeType(item.themeTip)
              }
            }),
            total: data.data.total
          },
          () => {
            this.setSelectTheme(this.props)
          }
        )
      } else {
        message.error(data.meta.message)
      }
    })
  }

  // 类型转换
  changeType = type => {
    let name = null
    switch (type) {
      case '1':
        name = 'siderBarThemeCenterType4'
        break
      case '2':
        name = 'siderBarThemeCenterType3'
        break
    }
    return name
  }

  // 设置选中的主题
  setSelectTheme = nextProp => {
    const { element, currentPage } = nextProp.page
    // 本菜单下的页面布局
    let object = element[currentPage]
    if (object && object.pageTheme) {
      this.setState({
        selectTheme: object.pageTheme
      })
    }
  }

  // 切换搜索条件
  handleTypeChange = type => {
    this.setState(
      {
        activeKeyType: type,
        pageNum: 1,
        loading: true
      },
      () => {
        this.getThemeList()
      }
    )
  }

  //页数改变
  pageChange = current => {
    this.setState(
      {
        pageNum: current,
        loading: true
      },
      () => {
        this.getThemeList()
      }
    )
  }

  //选择主题
  handleSelectTheme = res => {
    this.setState({
      selectTheme: res.themeId
    })
    getThemeContent(res.themeId, this.props)
  }

  // 搜索
  onSearch = () => {
    this.setState(
      {
        pageNum: 1,
        loading: true
      },
      () => {
        this.getThemeList()
      }
    )
  }

  // 输入框改变
  onInputChange = e => {
    this.setState({
      themeName: e.target.value.replace(/^\s+|\s+$/g, '')
    })
  }

  // 重置
  handleReset = () => {
    this.setState(
      {
        themeName: null,
        pageNum: 1,
        loading: true
      },
      () => {
        this.getThemeList()
      }
    )
  }

  render() {
    const { login } = this.props
    const { localeJson } = login
    const { searchList, dataSource, themeName, loading } = this.state

    return (
      <div>
        <div className="clearfix themeDrawerSearch">
          <div className="fl">
            <Input
              style={{ width: '250px', marginRight: '10px', borderRadius: 8 }}
              placeholder={localeJson.siderBarThemeSearchPlaceholder}
              onChange={this.onInputChange}
              onPressEnter={() => this.onSearch()}
              value={themeName}
            />
            <Button
              type="primary"
              style={{ marginRight: '10px', borderRadius: 8 }}
              onClick={() => this.onSearch()}
            >
              {localeJson.search}
            </Button>
            <Button
              style={{ borderRadius: 8 }}
              onClick={() => this.handleReset()}
            >
              {localeJson.reset}
            </Button>
          </div>
          <ul className="fr">
            {searchList.map((res, index) => {
              return (
                <Fragment key={res.key}>
                  <li
                    className={classnames({
                      active: res.key == this.state.activeKeyType
                    })}
                    onClick={() => this.handleTypeChange(res.key)}
                  >
                    {localeJson[res.type]}
                  </li>
                  {index != searchList.length - 1 && (
                    <Divider type="vertical" />
                  )}
                </Fragment>
              )
            })}
          </ul>
        </div>
        <ul className="themeDrawerUl clearfix">
          <Spin spinning={loading}>
            {dataSource.map(res => {
              // 要展示的国际化标题
              let localeName = getLanguageTitle(
                this.props,
                res.locale,
                'name',
                res.themeName
              )
              let themeDec = res.themeDec || ' '
              //  要展示的国际化描述
              let decription = getLanguageTitle(
                this.props,
                res.locale,
                'description',
                themeDec
              )
              return (
                <li
                  key={res.themeId}
                  className={classnames({
                    active: res.themeId == this.state.selectTheme
                  })}
                >
                  <div className="themeDrawerli">
                    {res.themeId == this.state.selectTheme && (
                      <div className="successIcon">
                        <img src={require('assets/images/success.png')} />
                      </div>
                    )}
                    {res.themeTip ? (
                      <div className="trangleIconWrapper">
                        <div className="trangleText">
                          {localeJson[res.themeTip]}
                        </div>
                      </div>
                    ) : null}

                    <img
                      onClick={() => this.handleSelectTheme(res)}
                      src={
                        res.themePic
                          ? `${downloadApi}?attachmentId=${res.themePic}`
                          : require('assets/images/theme.png')
                      }
                      style={{
                        width: '100%',
                        height: '160px',
                        padding: '8px 8px',
                        cursor: 'pointer'
                      }}
                      onError={event => {
                        var img = event.nativeEvent.srcElement
                        img.src = require('assets/images/theme.png')
                        img.onerror = null
                      }}
                    />
                    <div className="clearfix" style={{ margin: '8px' }}>
                      <div className="fl themeTitle textOverflow">
                        <Tooltip placement="top" title={localeName}>
                          {localeName}
                        </Tooltip>
                      </div>
                      <div className="fr">
                        <label className="mgr8">
                          <img
                            src={require('assets/images/hot.png')}
                            style={{ marginRight: '2px' }}
                          />
                          <i
                            className={`icon iconfont iconfire-fill`}
                            style={{ color: '#E15D5D' }}
                          />
                          {res.hotNum ? res.hotNum : 0}
                        </label>
                        <label>
                          <i
                            className={`icon iconfont icontimer--fill`}
                            style={{ color: '#56A0F6' }}
                          />
                          {res.createDate
                            ? String(res.createDate).substr(0, 10)
                            : null}
                        </label>
                      </div>
                    </div>
                    <div
                      className="myThemeLi themeCenter"
                      style={{
                        borderRadius: 8,
                        height: 100,
                        fontSize: 14
                      }}
                    >
                      <div>
                        {localeJson.themeDecription}：{decription}
                      </div>
                    </div>
                  </div>
                </li>
              )
            })}
            {dataSource.length == 0 && (
              <div className="nodata">
                <img src={require('assets/images/nodata.png')} />
                <div>{localeJson.nodata}</div>
              </div>
            )}
          </Spin>
        </ul>
        <Pagination
          size="small"
          className={'pagination'}
          current={this.state.pageNum}
          // defaultCurrent={1}
          pageSize={6}
          showTotal={total => `共 ${total} 条`}
          total={this.state.total}
          onChange={this.pageChange}
        />
      </div>
    )
  }
}
