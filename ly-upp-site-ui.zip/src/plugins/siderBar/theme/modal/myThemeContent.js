/*
 * @Description: 侧边栏主题-我的主题弹窗
 * @Author: xuqiuting
 * @Date: 2019-06-29 12:44:49
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-15 17:20:33
 */
import React, { Fragment } from 'react'
import {
  Icon,
  Input,
  Button,
  Divider,
  Pagination,
  message,
  Modal,
  Tooltip,
  Form,
  Spin
} from 'antd'
import classnames from 'classnames'
import _ from 'lodash'
import { connect } from 'react-redux'
import { ImgUpload, LanguageInput } from 'components'
import { getThemeContent } from 'utils/service'
import { getLanguageTitle } from 'utils/util'
import { updateMyThemeList } from 'redux/actions/page'
import {
  reqGetMyTheme,
  downloadApi,
  reqDeleteTheme,
  reqSaveThemeDec,
  reqSaveThemeShare
} from 'utils/api'

const FormItem = Form.Item
const { confirm } = Modal

@connect(state => {
  return { ...state }
})
@Form.create()
export default class ThemeCenterContent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      // 查询tag列表
      searchList: [
        {
          title: '全部',
          key: 'all',
          type: 'siderBarMythemeType1'
        },
        {
          title: '审核通过',
          key: '1',
          type: 'siderBarMythemeType2'
        },
        {
          title: '审核不通过',
          key: '0',
          type: 'siderBarMythemeType3'
        }
      ],
      activeKeyType: 'all', // 当前选中的tag
      dataSource: [], // 数据列表
      selectTheme: null, // 选中的主题
      total: 0, // 数据总共条数
      pageNum: 1, // 当前页
      themeName: '', // 查询名称
      visibleDec: false, // 描述弹窗展示
      language: 'zh_CN', // 名称的当前语言
      languageDesc: 'zh_CN', // 描述的当前语言
      decItem: {}, // 存储当前主题信息
      loading: true
    }
  }

  componentDidMount() {
    this.getMyThemeList()
    this.setState({
      language: this.props.login.locale,
      languageDesc: this.props.login.locale
    })
  }

  componentWillReceiveProps(nextProp) {
    // 侧边栏图标变化
    let nextElement = nextProp.page.element[nextProp.page.currentPage]
    let propsElement = this.props.page.element[this.props.page.currentPage]
    if (
      !_.isEqual(nextElement, propsElement) ||
      nextProp.page.currentPage != this.props.page.currentPage
    ) {
      if (this.state.dataSource.length > 0) {
        this.setSelectTheme(nextProp)
      }
    }
  }

  // 获取我的主题
  getMyThemeList = () => {
    let params = {
      pageNum: this.state.pageNum,
      pageSize: 6,
      themeName: this.state.themeName,
      themeType:
        this.state.activeKeyType == 'all' ? '' : this.state.activeKeyType
    }
    reqGetMyTheme(params).then(res => {
      const { data } = res
      if (data.meta.success) {
        this.setState(
          {
            loading: false,
            total: data.data.total,
            dataSource: data.data.list.map(item => {
              return {
                ...item,
                status: this.addInternational(item.auditSta),
                statusName: this.addInternational(item.auditSta, 'name'),
                color: this.addInternational(item.auditSta, 'color')
              }
            })
          },
          () => {
            this.setSelectTheme(this.props)
          }
        )
      } else {
        message.error(data.meta.message)
      }
    })
  }

  //添加审核国际化
  addInternational = (type, statusName) => {
    let id = 'unShare'
    let name = '未分享'
    let color = 'grey'
    switch (type) {
      case '-1':
        id = 'notApproved'
        name = '未审核'
        color = 'yellow'
        break
      case '0':
        id = 'unApproved'
        name = '审核未通过'
        color = 'red'
        break
      case '1':
        id = 'approved'
        name = '审核通过'
        color = 'green'
        break
      case '2':
        id = 'hadShare'
        name = '已分享'
        color = 'blue'
        break
      default:
        id = 'unShare'
        name = '未分享'
        color = 'grey'
        break
    }
    if (statusName == 'name') {
      return name
    } else if (statusName == 'color') {
      return color
    } else {
      return id
    }
  }

  // 设置选中的主题
  setSelectTheme = nextProp => {
    const { element, currentPage } = nextProp.page
    // 系统总的页面布局
    let newElement = element
    // 本菜单下的页面布局
    let object = newElement[currentPage]
    if (object && object.pageTheme) {
      this.setState({
        selectTheme: object.pageTheme
      })
    }
  }

  // 切换搜索条件
  handleTypeChange = type => {
    this.setState(
      {
        activeKeyType: type,
        pageNum: 1,
        loading: true
      },
      () => {
        this.getMyThemeList()
      }
    )
  }

  //页数改变
  pageChange = current => {
    this.setState(
      {
        pageNum: current,
        loading: true
      },
      () => {
        this.getMyThemeList()
      }
    )
  }

  //选择主题
  handleSelectTheme = res => {
    this.setState({
      selectTheme: res.themeId
    })
    getThemeContent(res.themeId, this.props)
  }

  // 搜索
  onSearch = () => {
    this.setState(
      {
        pageNum: 1,
        loading: true
      },
      () => {
        this.getMyThemeList()
      }
    )
  }

  // 输入框改变
  onInputChange = e => {
    this.setState({
      themeName: e.target.value.replace(/^\s+|\s+$/g, '')
    })
  }

  // 重置
  handleReset = () => {
    this.setState(
      {
        themeName: '',
        pageNum: 1,
        loading: true
      },
      () => {
        this.getMyThemeList()
      }
    )
  }

  // 分享
  handleShare = item => {
    const { localeJson } = this.props.login
    if (item.auditSta == '0') {
      message.error(localeJson.siderBarMythemeUnapproval)
      return false
    }
    let params = {
      themeId: item.themeId,
      themeRelease: item.auditSta == '-1' ? '0' : '1'
    }
    reqSaveThemeShare(params).then(res => {
      const { data, meta } = res.data
      if (meta.success) {
        if (item.auditSta == '-1') {
          message.success(localeJson.api_cancle_share_success)
        } else {
          message.success(localeJson.api_share_success)
        }

        this.getMyThemeList()
      } else {
        message.success(meta.message)
      }
    })
  }

  //描述
  handleDecription = item => {
    const { localeJson } = this.props.login
    if (item.auditSta == '1') {
      message.error(localeJson.siderBarMyThemeUnmodify)
      return false
    }
    this.setState({
      visibleDec: true,
      decItem: item
    })
  }

  // 编辑
  handleEdit = item => {
    let url = '/#/editTheme?themeId=' + item.themeId
    window.open(url)
  }

  // 删除
  hanldeDelete = item => {
    const { localeJson } = this.props.login
    let self = this
    if (item.auditSta == '1') {
      message.error(localeJson.siderBarMyThemeUndelete)
      return false
    }
    confirm({
      title: localeJson.sure_to_delete_theme,
      onOk() {
        let params = {
          themeId: item.themeId
        }
        reqDeleteTheme(params).then(res => {
          const { data, meta } = res.data
          if (meta.success) {
            message.success(localeJson.api_delete_success)
            self.setState(
              {
                pageNum: 1
              },
              () => {
                self.getMyThemeList()
                self.props.dispatch(updateMyThemeList(true))
              }
            )
          } else {
            message.success(meta.message)
          }
        })
      },
      onCancel() {
        console.log('Cancel')
      }
    })
  }

  // 描述弹窗取消
  handleDecCancel = () => {
    this.setState({
      visibleDec: !this.state.visibleDec
    })
  }

  // 弹窗保存
  handleDecSave = () => {
    const { localeJson } = this.props.login
    const { decItem } = this.state
    this.props.form.validateFields((err, values) => {
      if (!err) {
        let locale = decItem.locale
        locale = this.conbineLocale(locale, values.nameLocale, 'name')
        locale = this.conbineLocale(locale, values.desLocale, 'description')

        let name = this.checkValueLocale(locale, 'name')
        let description = this.checkValueLocale(locale, 'description')

        let params = {
          themeId: decItem.themeId,
          locale: locale,
          themePic: values.themePic,
          themeName: name,
          themeDesc: description
        }
        reqSaveThemeDec(params).then(res => {
          const { meta } = res.data
          if (meta.success) {
            message.success(localeJson.api_save_success)
            this.handleDecCancel()
            this.getMyThemeList()
            this.props.dispatch(updateMyThemeList(true))
          } else {
            message.success(meta.message)
          }
        })
      }
    })
  }

  // 验证
  checkValueLocale = (value, type) => {
    const { systemConfig, locale } = this.props.login
    let name
    if (
      value &&
      systemConfig &&
      systemConfig.language &&
      value[systemConfig.language] &&
      value[systemConfig.language][type] &&
      value[systemConfig.language][type] != ''
    ) {
      name = value[systemConfig.language][type]
    } else if (
      value &&
      value[locale] &&
      value[locale][type] &&
      value[locale][type] != ''
    ) {
      name = value[locale][type]
    } else if (
      value &&
      value['zh_CN'] &&
      value['zh_CN'][type] &&
      value['zh_CN'][type] != ''
    ) {
      name = value['zh_CN'][type]
    }
    return name
  }

  // 合并locale
  conbineLocale = (locale, nameLocale, name) => {
    if (!nameLocale) return locale
    let newLocale = locale || {}
    for (let key in nameLocale) {
      if (nameLocale[key] && nameLocale[key][name]) {
        if (newLocale[key]) {
          newLocale[key][name] = nameLocale[key][name]
        } else {
          newLocale[key] = {}
          newLocale[key][name] = nameLocale[key][name]
        }
      }
    }
    return newLocale
  }

  // 改变语言
  handleLanguage = (type, name) => {
    const { decItem } = this.state
    this.setState({
      [name]: type
    })
    if (name == 'language') {
      let value = decItem.locale[type] ? decItem.locale[type].name : null
      this.props.form.setFieldsValue({ themeName: value })
    } else {
      let value = decItem.locale[type] ? decItem.locale[type].description : null
      this.props.form.setFieldsValue({ themeDesc: value })
    }
  }

  // 页面名称改变
  handleInputChange = (e, type) => {
    const { language, languageDesc } = this.state
    let value = e.target.value
    let decItem = this.state.decItem
    if (type == 'themeName') {
      decItem.locale[language] = decItem.locale[language] || {}
      decItem.locale[language].name = value
    } else {
      decItem.locale[languageDesc] = decItem.locale[languageDesc] || {}
      decItem.locale[languageDesc].description = value
    }
    this.setState({
      decItem: decItem
    })
  }

  // 验证
  checkValueLocale = (value, type) => {
    const { systemConfig, locale } = this.props.login
    let name
    if (
      value &&
      systemConfig &&
      systemConfig.language &&
      value[systemConfig.language] &&
      value[systemConfig.language][type] &&
      value[systemConfig.language][type] != ''
    ) {
      name = value[systemConfig.language][type]
    } else if (
      value &&
      value[locale] &&
      value[locale][type] &&
      value[locale][type] != ''
    ) {
      name = value[locale][type]
    } else if (
      value &&
      value['zh_CN'] &&
      value['zh_CN'][type] &&
      value['zh_CN'][type] != ''
    ) {
      name = value['zh_CN'][type]
    }
    return name
  }

  render() {
    const { login } = this.props
    const { localeJson } = login
    const {
      searchList,
      dataSource,
      themeName,
      visibleDec,
      decItem,
      loading
    } = this.state
    const { getFieldDecorator } = this.props.form
    const formItemLayout = {
      labelCol: { span: 4 },
      wrapperCol: { span: 16 }
    }

    let languageList = window.locale ? window.locale.list : []

    return (
      <div>
        <div className="clearfix themeDrawerSearch">
          <div className="fl">
            <Input
              style={{ width: '250px', marginRight: '10px', borderRadius: 8 }}
              placeholder={localeJson.siderBarThemeSearchPlaceholder}
              onChange={this.onInputChange}
              onPressEnter={() => this.onSearch()}
              value={themeName}
            />
            <Button
              type="primary"
              style={{ marginRight: '10px', borderRadius: 8 }}
              onClick={() => this.onSearch()}
            >
              {localeJson.search}
            </Button>
            <Button
              style={{ borderRadius: 8 }}
              onClick={() => this.handleReset()}
            >
              {localeJson.reset}
            </Button>
          </div>
          <ul className="fr">
            {searchList.map((res, index) => {
              return (
                <Fragment key={res.key}>
                  <li
                    className={classnames({
                      active: res.key == this.state.activeKeyType
                    })}
                    onClick={() => this.handleTypeChange(res.key)}
                  >
                    {localeJson[res.type]}
                  </li>
                  {index != searchList.length - 1 && (
                    <Divider type="vertical" />
                  )}
                </Fragment>
              )
            })}
          </ul>
        </div>
        <ul className="themeDrawerUl clearfix">
          <Spin spinning={loading}>
            {dataSource.map(res => {
              // 要展示的国际化标题
              let localeName = getLanguageTitle(
                this.props,
                res.locale,
                'name',
                res.themeName
              )
              //  要展示的国际化描述
              let themeDec = res.themeDec || ' '
              let decription = getLanguageTitle(
                this.props,
                res.locale,
                'description',
                themeDec
              )

              return (
                <li
                  key={res.themeId}
                  className={classnames({
                    active: res.themeId == this.state.selectTheme
                  })}
                >
                  <div className="themeDrawerli">
                    {res.themeId == this.state.selectTheme && (
                      <div className="successIcon">
                        <img src={require('assets/images/success.png')} />
                      </div>
                    )}
                    <img
                      onClick={() => this.handleSelectTheme(res)}
                      src={
                        res.themePic
                          ? `${downloadApi}?attachmentId=${res.themePic}`
                          : require('assets/images/theme.png')
                      }
                      onError={event => {
                        var img = event.nativeEvent.srcElement
                        img.src = require('assets/images/theme.png')
                        img.onerror = null
                      }}
                      style={{
                        width: '100%',
                        height: '160px',
                        padding: '8px 8px 0',
                        cursor: 'pointer'
                      }}
                    />
                    <div className="clearfix" style={{ margin: '8px' }}>
                      <div className="fl themeTitle textOverflow">
                        <Tooltip placement="top" title={localeName}>
                          {localeName}
                        </Tooltip>
                      </div>
                      <div className="fr">
                        <label className="mgr8">
                          <img
                            src={require('assets/images/hot.png')}
                            style={{ marginRight: '2px' }}
                          />
                          <i
                            className={`icon iconfont iconfire-fill`}
                            style={{ color: '#E15D5D' }}
                          />
                          {res.hotNum ? res.hotNum : 0}
                        </label>
                        <label>
                          <i
                            className={`icon iconfont icontimer--fill`}
                            style={{ color: '#56A0F6' }}
                          />
                          {res.createDate
                            ? String(res.createDate).substr(0, 10)
                            : null}
                        </label>
                      </div>
                    </div>
                    <div className="myThemeLi">
                      <div className="themeDec textOverflow">
                        {localeJson.themeDecription}：
                        <Tooltip placement="top" title={decription}>
                          {decription}
                        </Tooltip>
                      </div>
                      <div className="themeAction">
                        <div className="clearfix">
                          <div className="fl themeStatus">
                            <div className={`myThemeIcon ${res.color}`}>
                              {localeJson[res.status]}
                            </div>
                          </div>
                          <div className="fr myThemeButton">
                            {!res.auditSta ? (
                              <label
                                className="myThemeButton"
                                onClick={() => this.handleShare(res)}
                              >
                                <Tooltip
                                  placement="top"
                                  title={localeJson.share}
                                >
                                  <Icon type="share-alt" />
                                </Tooltip>
                              </label>
                            ) : null}
                            {res.auditSta == '-1' ? (
                              <label
                                className="myThemeButton"
                                onClick={() => this.handleShare(res)}
                              >
                                <Tooltip
                                  placement="top"
                                  title={localeJson.cancleShare}
                                >
                                  <Icon type="share-alt" />
                                </Tooltip>
                              </label>
                            ) : null}
                            {!res.auditSta || res.auditSta == '-1' ? (
                              <Fragment>
                                <label
                                  onClick={() => this.handleDecription(res)}
                                >
                                  <Tooltip
                                    placement="top"
                                    title={localeJson.description}
                                  >
                                    <Icon type="select" />
                                  </Tooltip>
                                </label>
                                <label onClick={() => this.handleEdit(res)}>
                                  <Tooltip
                                    placement="top"
                                    title={localeJson.edit}
                                  >
                                    <Icon type="form" />
                                  </Tooltip>
                                </label>
                              </Fragment>
                            ) : null}
                            {!res.auditSta ||
                            res.auditSta == '-1' ||
                            res.auditSta == '0' ? (
                              <label onClick={() => this.hanldeDelete(res)}>
                                <Tooltip
                                  placement="top"
                                  title={localeJson.delete}
                                >
                                  <Icon type="delete" />
                                </Tooltip>
                              </label>
                            ) : null}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              )
            })}
            {dataSource.length == 0 && (
              <div className="nodata">
                <img src={require('assets/images/nodata.png')} />
                <div>{localeJson.nodata}</div>
              </div>
            )}
          </Spin>
        </ul>
        <Pagination
          size="small"
          className={'pagination'}
          current={this.state.pageNum}
          pageSize={6}
          // defaultCurrent={1}
          showTotal={total => `共 ${total} 条`}
          total={this.state.total}
          onChange={this.pageChange}
        />
        <Modal
          visible={visibleDec}
          destroyOnClose
          width={800}
          title={localeJson.edit_theme}
          onOk={this.handleDecSave}
          onCancel={() => this.handleDecCancel()}
        >
          <Form>
            <FormItem {...formItemLayout} label={localeJson.add_theme_name}>
              {getFieldDecorator('nameLocale', {
                initialValue: decItem.locale,
                rules: [
                  {
                    required: true,
                    message: localeJson.add_theme_name_required
                  },
                  {
                    validator: (rule, value, callback) => {
                      let name = this.checkValueLocale(value, 'name')
                      // let length = name
                      //   ? name.replace(/[^\x00-\xff]/g, '**').length
                      //   : 0
                      let length = (name && name.length) || 0
                      if (!name) {
                        callback(localeJson.theme_description_required)
                      }
                      if (length > 50) {
                        callback(localeJson.theme_name_limit)
                      }
                      callback()
                    }
                  }
                ]
              })(
                <LanguageInput
                  localeJson={localeJson}
                  languageList={languageList}
                />
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label={localeJson.add_theme_description}
            >
              {getFieldDecorator('desLocale', {
                initialValue: decItem.locale,
                rules: [
                  // {
                  //   required: true,
                  //   message: localeJson.add_theme_description_required
                  // },
                  {
                    validator: (rule, value, callback) => {
                      let name = this.checkValueLocale(value, 'description')
                      // let length = name
                      //   ? name.replace(/[^\x00-\xff]/g, '**').length
                      //   : 0
                      let length = (name && name.length) || 0
                      // if (!name) {
                      //   callback(localeJson.theme_description_required)
                      // }
                      if (length > 50) {
                        callback(localeJson.theme_description_limit)
                      }
                      callback()
                    }
                  }
                ]
              })(
                <LanguageInput
                  localeJson={localeJson}
                  languageList={languageList}
                  type="description"
                  inputType="TextArea"
                />
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label={localeJson.add_theme_screenshot}
            >
              {getFieldDecorator('themePic', {
                initialValue: decItem.themePic
              })(<ImgUpload imgType="7" />)}
            </FormItem>
          </Form>
        </Modal>
      </div>
    )
  }
}
