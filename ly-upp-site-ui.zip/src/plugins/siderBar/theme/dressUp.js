/*
 * @Description: 侧边栏主题页面
 * @Author: xuqiuting
 * @Date: 2019-06-05 16:10:19
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-15 17:22:00
 */
import React from 'react'
import { message, Radio, Icon, Spin } from 'antd'
import { Scrollbars } from 'components'
import { connect } from 'react-redux'
import classnames from 'classnames'
import { getThemeContent } from 'utils/service'
import { getLanguageTitle } from 'utils/util'
import { reqGetThemeList, downloadApi, reqGetMyTheme } from 'utils/api'
import { updateMyThemeList } from 'redux/actions/page'
import _ from 'lodash'

@connect(state => {
  return { ...state }
})
export default class DressUp extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      list: [],
      type: 'siderBarThemeCenter',
      pageTheme: null, //选中的主题
      pageNum: 1,
      pageSize: 4,
      loading: true
    }
  }

  componentDidMount() {
    this.getThemeList()
  }

  componentWillReceiveProps(nextProps) {
    // 侧边栏图标变化
    let nextElement = nextProps.page.element[nextProps.page.currentPage]
    let propsElement = this.props.page.element[this.props.page.currentPage]
    if (
      !_.isEqual(nextElement, propsElement) ||
      nextProps.page.currentPage != this.props.page.currentPage
    ) {
      if (this.state.list.length > 0) {
        this.setSelectTheme(nextProps)
      }
    }
    // 若我的主题（删除、编辑），需要重新请求我的主题列表
    if (
      this.state.type !== 'siderBarThemeCenter' &&
      this.props.page.myThemeListChange !== nextProps.page.myThemeListChange &&
      nextProps.page.myThemeListChange
    ) {
      this.getMyThemeList()
      this.props.dispatch(updateMyThemeList(false))
    }
  }

  // 获取主题列表
  getThemeList = () => {
    let params = {
      pageNum: 1,
      pageSize: 0
    }
    reqGetThemeList(params).then(res => {
      const { data } = res
      if (data.meta.success) {
        this.setState(
          {
            loading: false,
            list: data.data.list
          },
          () => {
            this.setSelectTheme(this.props)
          }
        )
      } else {
        message.error(data.meta.message)
      }
    })
  }

  // 设置选中的主题
  setSelectTheme = nextProp => {
    const { element, currentPage } = nextProp.page
    // 系统总的页面布局
    let newElement = element
    // 本菜单下的页面布局
    let object = newElement[currentPage]
    if (object && object.pageTheme) {
      this.setState({
        pageTheme: object.pageTheme
      })
    }
  }

  // 获取我的主题
  getMyThemeList = () => {
    let params = {
      pageNum: 1,
      pageSize: 0
    }
    reqGetMyTheme(params).then(res => {
      const { data } = res
      if (data.meta.success) {
        this.setState({
          list: data.data.list,
          loading: false
        })
      } else {
        message.error(data.meta.message)
      }
    })
  }

  // tab切换
  onTabChange = e => {
    this.setState({ type: e.target.value })
    this.setState({
      loading: true
    })
    if (e.target.value == 'siderBarThemeCenter') {
      this.getThemeList()
    } else {
      this.getMyThemeList()
    }
  }

  // 选择主题
  handleTheme = item => {
    // 特殊判断--当前页面为应用中心页面 只能更改肤色
    const { page, login } = this.props
    const { system } = page
    const { localeJson } = login
    const isAppCenterPage = system.pageId === 'lyappCenter'
    if (isAppCenterPage) {
      return message.warning(localeJson.siderBarCurrentPageForbidDressUp)
    }

    this.setState({
      pageTheme: item.themeId,
      themeName: item.themeName
    })
    getThemeContent(item.themeId, this.props)
  }

  handleColorChange = color => {
    this.setState({
      color: color
    })
    let initialTheme = { '@primary-color': color }
    window.less
      .modifyVars(initialTheme)
      .then(() => {
        this.setElement(color)
      })
      .catch(error => {
        message.error(`更新主题失败`)
      })
  }

  render() {
    const { login } = this.props
    const { localeJson } = login
    const { list, type, loading } = this.state
    return (
      <div className={'dressup'}>
        <Radio.Group
          value={type}
          onChange={this.onTabChange}
          style={{ textAlign: 'center', width: '100%', marginBottom: '10px' }}
        >
          <Radio.Button value="siderBarThemeCenter">
            {localeJson.siderBarThemeCenter}
          </Radio.Button>
          <Radio.Button value="siderBarMyTheme">
            {localeJson.siderBarMyTheme}
          </Radio.Button>
        </Radio.Group>
        <Scrollbars style={{ height: 410, textAlign: 'center' }} autoHide>
          <ul style={{ paddingTop: 5 }}>
            <Spin spinning={loading}>
              {list.length > 0 ? (
                list.map(res => {
                  // 要展示的国际化标题
                  let localeName = getLanguageTitle(
                    this.props,
                    res.locale,
                    'name',
                    res.themeName
                  )
                  return (
                    <li
                      className={classnames({
                        active: res.themeId == this.state.pageTheme
                      })}
                      onClick={() => this.handleTheme(res)}
                      key={res.themeId}
                    >
                      {res.themeId == this.state.pageTheme && (
                        // <div className="successIcon">
                        //   <img src={require("assets/images/success.png")} />
                        // </div>
                        <Icon type="check-circle" />
                      )}
                      <img
                        src={
                          res.themePic
                            ? `${downloadApi}?attachmentId=${res.themePic}`
                            : require('assets/images/theme.png')
                        }
                        onError={event => {
                          var img = event.nativeEvent.srcElement
                          img.src = require('assets/images/theme.png')
                          img.onerror = null
                        }}
                      />
                      <p>{localeName}</p>
                    </li>
                  )
                })
              ) : !loading ? (
                <div className="nodata">
                  <img src={require('assets/images/nodata.png')} />
                  <div>{localeJson.nodata}</div>
                </div>
              ) : (
                <div className="nodata"></div>
              )}
            </Spin>
          </ul>
        </Scrollbars>
        <div
          className="blue"
          style={{
            margin: '8px 0 10px',
            textAlign: 'center',
            cursor: 'pointer'
          }}
          onClick={() => this.props.handleThemeModal('siderBarDressUp')}
        >
          {localeJson.siderBarMoreTheme}
          <Icon style={{ marginLeft: '4px' }} type="right" />
        </div>
      </div>
    )
  }
}
