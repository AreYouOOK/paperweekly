/*
 * @Description: 侧边栏卡片搜索组件
 * @Author: xuqiuting
 * @Date: 2019-07-03 14:39:20
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-19 17:35:02
 */
import React from 'react'
import { Scrollbars } from 'components'
import { Button, message, Popover, Tooltip } from 'antd'
import { DragSourceWrapper } from 'comon/DragAndDrop/wrapper_component'
import { reqGetCardSearchList } from 'utils/api'
import { connect } from 'react-redux'
import _ from 'lodash'
import { downloadApi } from 'utils/api'
import classnames from 'classnames'
import { getLanguageTitle } from 'utils/util'

@connect(state => {
  return { ...state }
})
export default class SearchList extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      dataSource: [], // 查询拿到的数据
      searchData: [], // 接口拿到的搜索列表
      type: 0, // 卡片类型
      isFocus: false // 输入框是否是聚焦
    }
  }

  componentDidMount() {
    this.getData()
    this.setState({
      isFocus: this.props.isFocus
    })
  }

  componentWillReceiveProps(nextProps) {
    if (!_.isEqual(nextProps.searchData, this.state.dataSource)) {
      this.setState({
        dataSource: nextProps.searchData,
        searchData: nextProps.searchData
      })
    }
    if (nextProps.isFocus != this.state.isFocus) {
      if (nextProps.isFocus) {
        this.getData()
      } else {
        this.setState({
          isFocus: false
        })
      }
    }
  }

  // 获取最近搜索数据
  getData = () => {
    reqGetCardSearchList().then(res => {
      const { data, meta } = res.data
      if (meta.success) {
        this.setState({
          dataSource: data ? data : [],
          isFocus: true
        })
      } else {
        message.error(meta.message)
      }
    })
  }

  // 添加
  handleAdd = (e, res) => {
    this.props.handleAdd(e, res)
  }

  // 卡片类型改变，控制展开收缩
  handleTypeChange = key => {
    this.setState({
      type: this.state.type == key ? null : key
    })
  }

  render() {
    const { login } = this.props
    const { localeJson } = login
    const { dataSource, isFocus } = this.state
    return (
      <div>
        <div style={{ marginLeft: '10px' }}>
          {isFocus
            ? localeJson.siderbarCardSearchNewest
            : localeJson.siderbarCardSearchResult}
        </div>
        <Scrollbars style={{ height: 420 }} autoHide>
          <ul className="siderBar_search_ul tablist">
            {dataSource.length > 0 ? (
              isFocus ? (
                dataSource.map((res, index) => {
                  return (
                    <span
                      key={index}
                      className="siderBar_search_label"
                      onClick={() => this.props.handleSearch(res)}
                    >
                      {res}
                    </span>
                  )
                })
              ) : (
                dataSource.map((item, index) => {
                  // 要展示的国际化标题
                  let typeName = getLanguageTitle(
                    this.props,
                    item.typeLocale,
                    'typeName',
                    item.typeName
                  )
                  return (
                    <li
                      key={index}
                      className={classnames(
                        // { border_bottom: this.state.type != index },
                        'tab_title'
                      )}
                    >
                      <div
                        className="clearfix tabTitle"
                        style={{ margin: 0 }}
                        onClick={() => this.handleTypeChange(index)}
                      >
                        <div className={`${'fl tab_text'} `}>{typeName}</div>
                        <div
                          className={`${
                            index == this.state.type ? 'arrow_up' : 'arrow_down'
                          } fr`}
                        />
                      </div>
                      {this.state.type == index && (
                        <ul className="tab_item">
                          {item.list.map((res, key) => {
                            // 要展示的国际化标题
                            let cardName = getLanguageTitle(
                              this.props,
                              res.locale,
                              'cardName',
                              res.cardName
                            )
                            return (
                              <DragSourceWrapper
                                key={key} //表示类型
                                componentName={res.commpentName} // 表示组件类型
                                cardProps={res}
                                {...res}
                              >
                                <li key={res.commpentName} className="clearfix">
                                  <div className="fl" style={{ width: '70%' }}>
                                    <img
                                      src={
                                        res.cardIcon
                                          ? `${downloadApi}?attachmentId=${res.cardIcon}`
                                          : require('assets/images/cardicon.png')
                                      }
                                      onError={event => {
                                        var img = event.nativeEvent.srcElement
                                        img.src = require('assets/images/cardicon.png')
                                        img.onerror = null
                                      }}
                                      className="iconImg"
                                    />
                                    <span className="tab_item_span">
                                      <Tooltip placement="top" title={cardName}>
                                        {cardName}
                                      </Tooltip>
                                    </span>
                                  </div>
                                  <div className="fr">
                                    <Popover
                                      content={
                                        <img
                                          style={{
                                            width: '120px',
                                            height: '110px'
                                          }}
                                          src={
                                            res.imgUrl
                                              ? res.imgUrl
                                              : require('assets/images/cardpic.png')
                                          }
                                          onError={event => {
                                            var img =
                                              event.nativeEvent.srcElement
                                            img.src = require('assets/images/cardpic.png')
                                            img.onerror = null
                                          }}
                                        />
                                      }
                                      placement="right"
                                      trigger="hover"
                                    >
                                      <Button
                                        type="primary"
                                        ghost
                                        size="small"
                                        disabled={
                                          res.isUse == '1' &&
                                          res.isSingleton == '1'
                                        }
                                        onClick={e => this.handleAdd(e, res)}
                                      >
                                        {res.isUse == '1' &&
                                        res.isSingleton == '1'
                                          ? localeJson.added
                                          : localeJson.add}
                                      </Button>
                                    </Popover>
                                  </div>
                                </li>
                              </DragSourceWrapper>
                            )
                          })}
                        </ul>
                      )}
                    </li>
                  )
                })
              )
            ) : (
              <div className="nodata">
                <img src={require('assets/images/nodata.png')} />
                <div>{localeJson.nodata}</div>
              </div>
            )}
          </ul>
        </Scrollbars>
        <div
          style={{ textAlign: 'center', lineHeight: '40px', cursor: 'pointer' }}
          className="blue"
          onClick={() => this.props.goBack()}
        >
          {localeJson.back}
        </div>
      </div>
    )
  }
}
