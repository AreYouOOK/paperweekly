/*
 * @Description: 侧边栏卡片热门tab
 * @Author: xuqiuting
 * @Date: 2019-06-05 17:38:20
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-09 16:02:44
 */
import React from 'react'
import { Scrollbars } from 'components'
import { Button, message, Popover, Tooltip, Spin } from 'antd'
import { DragSourceWrapper } from 'comon/DragAndDrop/wrapper_component'
import { connect } from 'react-redux'
import { reqGetCardList } from 'utils/api'
import { downloadApi } from 'utils/api'
import classnames from 'classnames'
import { getLanguageTitle } from 'utils/util'

@connect(state => {
  return { ...state }
})
export default class PopularList extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      dataSource: [],
      type: 0,
      cardArr: [],
      loading: true
    }
  }

  componentDidMount() {
    const { page } = this.props
    const { element, currentPage } = page
    let object = element[currentPage]
    // 如果有获取到的页面数据有卡片列表，可以用来对比是否可以再次拖进去
    if (object && object.cardArr) {
      this.setState({
        cardArr: object.cardArr
      })
    }
    this.getData()
  }

  componentWillReceiveProps(nextProps) {
    const { page } = nextProps
    const { element, currentPage } = page
    let object = element[currentPage]
    if (object && object.cardArr) {
      this.changeData(object.cardArr)
    }
  }

  // 对比渲染数据，已添加
  changeData = arr => {
    let data = this.state.dataSource
    data.map(item => {
      item.list.map(list => {
        for (let i = 0; i < arr.length; i++) {
          if (list.cardId == arr[i].cardId) {
            if (arr[i].isUse == '1') {
              list.isUse = '1'
            } else {
              list.isUse = '0'
            }
          }
        }
      })
    })
    this.setState({
      dataSource: data,
      cardArr: arr
    })
  }

  // 获取数据
  getData = () => {
    const { page } = this.props
    const { element, currentPage } = page
    // 获取当前页面的数据，是否有卡片列表，便于对比是否可以再次添加进页面
    let arr = []
    let object = element[currentPage]
    if (object && object.cardArr) {
      arr = object.cardArr
    }
    let pageId
    let menus = JSON.parse(sessionStorage.getItem('menus')) || []
    // 如果没有菜单，则不请求数据，因为请求卡片是需要知道页面的pageId的
    if (!menus) {
      return false
    }
    for (let i = 0; i < menus.length; i++) {
      if (menus[i].pagePath == currentPage) {
        pageId = menus[i].pageId
      }
    }
    let params = {
      pageId: pageId,
      recommendType: '2'
    }
    reqGetCardList(params).then(res => {
      const { data, meta } = res.data
      if (meta.success) {
        this.setState(
          {
            loading: false,
            dataSource: data
              ? data.map(item => {
                  return {
                    ...item,
                    list: item.list.map(list => {
                      for (let i = 0; i < arr.length; i++) {
                        if (list.cardId == arr[i].cardId) {
                          if (arr[i].isUse == '1') {
                            list.isUse = '1'
                          } else {
                            list.isUse = '0'
                          }
                        }
                      }
                      return {
                        imgUrl: list.cardpic
                          ? `${downloadApi}?attachmentId=${list.cardpic}`
                          : null,
                        ...list
                      }
                    })
                  }
                })
              : []
          },
          () => console.log(this.state.dataSource)
        )
      } else {
        message.error(meta.message)
      }
    })
  }

  // 卡片类型改变，控制展开收缩
  handleTypeChange = key => {
    this.setState({
      type: this.state.type == key ? null : key
    })
  }

  // 添加
  handleAdd = (e, res) => {
    this.props.handleAdd(e, res)
  }

  render() {
    const { login } = this.props
    const { localeJson } = login
    const { dataSource, loading } = this.state
    const list = dataSource.reduce((acc, v) => acc.concat(v.list), [])
    list.length = list.length > 10 ? 10 : list.length
    return (
      <div>
        <Scrollbars style={{ height: 420 }} autoHide>
          <ul className="tablist">
            <Spin spinning={loading}>
              {dataSource.length > 0 ? (
                <li
                  // key={index}
                  className={classnames(
                    // { border_bottom: this.state.type != index },
                    'tab_title'
                  )}
                >
                  <ul className="tab_item">
                    {list.map(res => {
                      // 要展示的国际化标题
                      let cardName = getLanguageTitle(
                        this.props,
                        res.locale,
                        'cardName',
                        res.cardName
                      )
                      return (
                        <DragSourceWrapper
                          key={res.commpentName} //表示类型
                          componentName={res.commpentName} // 表示组件类型
                          cardProps={res}
                          {...res}
                        >
                          <li key={res.commpentName} className="clearfix">
                            <div className="fl" style={{ width: '70%' }}>
                              <img
                                src={
                                  res.cardIcon
                                    ? `${downloadApi}?attachmentId=${res.cardIcon}`
                                    : require('assets/images/cardicon.png')
                                }
                                onError={event => {
                                  var img = event.nativeEvent.srcElement
                                  img.src = require('assets/images/cardicon.png')
                                  img.onerror = null
                                }}
                                className="iconImg"
                              />
                              <span className="tab_item_span">
                                <Tooltip placement="top" title={cardName}>
                                  {cardName}
                                </Tooltip>
                              </span>
                            </div>
                            <div className="fr">
                              <Popover
                                content={
                                  <img
                                    style={{
                                      width: '120px',
                                      height: '110px'
                                    }}
                                    src={
                                      res.imgUrl
                                        ? res.imgUrl
                                        : require('assets/images/cardpic.png')
                                    }
                                    onError={event => {
                                      var img = event.nativeEvent.srcElement
                                      img.src = require('assets/images/cardpic.png')
                                      img.onerror = null
                                    }}
                                  />
                                }
                                placement="right"
                                trigger="hover"
                              >
                                <Button
                                  type="primary"
                                  ghost
                                  size="small"
                                  disabled={
                                    res.isUse == '1' && res.isSingleton == '1'
                                  }
                                  onClick={e => this.handleAdd(e, res)}
                                >
                                  {res.isUse == '1' && res.isSingleton == '1'
                                    ? localeJson.added
                                    : localeJson.add}
                                </Button>
                              </Popover>
                            </div>
                          </li>
                        </DragSourceWrapper>
                      )
                    })}
                  </ul>
                </li>
              ) : !loading ? (
                <div className="nodata">
                  <img src={require('assets/images/nodata.png')} />
                  <div>{localeJson.nodata}</div>
                </div>
              ) : (
                <div className="nodata"></div>
              )}
            </Spin>
          </ul>
        </Scrollbars>
      </div>
    )
  }
}
