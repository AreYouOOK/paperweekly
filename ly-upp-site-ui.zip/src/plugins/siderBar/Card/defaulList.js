/*
 * @Description: 侧边栏卡片默认tab
 * @Author: xuqiuting
 * @Date: 2019-06-05 17:33:22
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-10-29 11:17:03
 */
import React from "react";
import { Button, message, Popover, Tooltip, Spin } from "antd";
import { Scrollbars } from "components";
import { reqGetCardList } from "utils/api";
import { connect } from "react-redux";
import { downloadApi } from "utils/api";
import _ from "lodash";
import classnames from "classnames";
import { DragSourceWrapper } from "comon/DragAndDrop/wrapper_component";
import { getLanguageTitle } from "utils/util";

@connect(state => {
  return { ...state };
})
export default class DefaulList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      tab: "card", //卡片tab标志
      type: 0,
      dataSource: [
        // {
        //   typeLocale: {
        //     en_US: { typeName: "Census" },
        //     zh_CN: { typeName: "统计卡片" }
        //   },
        //   typeName: "统计卡片",
        //   list: [
        //     {
        //       cardIcon: null,
        //       cardId: "b16e9ec7e94b443aa399ee3205ace152",
        //       cardName: "测试卡1",
        //       cardpic: "e1a650f5-809c-4248-9ad2-c9e28b87d253",
        //       commpentName: "SelectComponent",
        //       config: {
        //         serviceShowType: null,
        //         contentType: null,
        //         minShowWidth: null,
        //         minShowHight: null,
        //         rollDirection: null,
        //         rollSpace: null,
        //         serviceShowType: null,
        //         showCount: null
        //       },
        //       isSingleton: "1",
        //       isUse: "0",
        //       locale: {
        //         en_US: { cardName: "text-absent" },
        //         zh_CN: { cardName: "测试卡1" }
        //       },
        //       tabList: [
        //         {
        //           cardId: "7155b8c13e304f1ab7370689809e2030",
        //           componentName: "ServiceComponent",
        //           locale: { zh_CN: { name: "卡2" } },
        //           title: "新增卡片"
        //         },
        //         {
        //           cardId: "7155b8c13e304f1ab7370689809e2030",
        //           componentName: "ServiceComponent",
        //           locale: { zh_CN: { name: "卡1" } },
        //           title: "新增卡片"
        //         },
        //         {
        //           cardId: "7155b8c13e304f1ab7370689809e2030",
        //           componentName: "ServiceComponent",
        //           locale: { zh_CN: { name: "卡2" } },
        //           title: "新增卡片"
        //         }
        //       ]
        //     },
        //     {
        //       cardIcon: null,
        //       cardId: "09abb9b89b20456e8ecba01e81db785c",
        //       cardName: "教师服务卡",
        //       cardpic: null,
        //       commpentName: "ServiceComponent",
        //       config: {
        //         serviceShowType: null,
        //         contentType: null,
        //         minShowWidth: null,
        //         minShowHight: null,
        //         rollDirection: null
        //       },
        //       isSingleton: "0",
        //       isUse: "0",
        //       locale: {
        //         en_US: { cardName: "text-absent" },
        //         zh_CN: { cardName: "教师服务卡" }
        //       },
        //       en_US: { cardName: "text-absent" },
        //       zh_CN: { cardName: "教师服务卡" }
        //     }
        //   ]
        // }
      ],
      cardArr: []
    };
  }

  componentDidMount() {
    this.getData();
  }

  componentWillReceiveProps(nextProps) {
    const { page } = nextProps;
    const { element, currentPage } = page;
    let object = element[currentPage];
    // 如果有获取到的页面数据有卡片列表，可以用来对比是否可以再次拖进去
    if (object && object.cardArr) {
      this.changeData(object.cardArr);
    }
  }

  // 对比渲染数据，已添加
  changeData = arr => {
    let data = this.state.dataSource;
    data.map(item => {
      item.list.map(list => {
        for (let i = 0; i < arr.length; i++) {
          if (list.cardId == arr[i].cardId) {
            if (arr[i].isUse == "1") {
              list.isUse = "1";
            } else {
              list.isUse = "0";
            }
          }
        }
      });
    });
    this.setState({
      dataSource: data,
      cardArr: arr
    });
  };

  // 获取数据
  getData = () => {
    const { page } = this.props;
    const { element, currentPage } = page;
    // 获取当前页面的数据，是否有卡片列表，便于对比是否可以再次添加进页面
    let arr = [];
    let object = element[currentPage];
    if (object && object.cardArr) {
      arr = object.cardArr;
    }
    let pageId;
    let menus = JSON.parse(sessionStorage.getItem("menus")) || [];
    // 如果没有菜单，则不请求数据，因为请求卡片是需要知道页面的pageId的
    if (!menus) {
      return false;
    }
    for (let i = 0; i < menus.length; i++) {
      if (menus[i].pagePath == currentPage) {
        pageId = menus[i].pageId;
      }
    }
    let params = {
      pageId: pageId
    };
    reqGetCardList(params).then(res => {
      let { data, meta } = res.data;
      if (meta.success) {
        if (!data) {
          data = [];
        }
        this.setState({
          loading: false,
          dataSource: data.map(item => {
            return {
              ...item,
              list: item.list.map(list => {
                for (let i = 0; i < arr.length; i++) {
                  if (list.cardId == arr[i].cardId) {
                    if (arr[i].isUse == "1") {
                      list.isUse = "1";
                    } else {
                      list.isUse = "0";
                    }
                  }
                }
                return {
                  imgUrl: list.cardpic
                    ? `${downloadApi}?attachmentId=${list.cardpic}`
                    : null,
                  ...list
                };
              })
            };
          })
        });
      } else {
        message.error(meta.message);
      }
    });
  };

  // 卡片类型改变，控制展开收缩
  handleTypeChange = key => {
    this.setState({
      type: this.state.type == key ? null : key
    });
  };

  // 添加
  handleAdd = (e, res) => {
    this.props.handleAdd(e, res);
  };

  render() {
    const { dataSource, loading } = this.state;
    const { login } = this.props;
    const { localeJson } = login;
    return (
      <div>
        <Scrollbars style={{ height: 420 }} autoHide>
          <ul className="tablist">
            <Spin spinning={loading}>
              {dataSource.length > 0 ? (
                dataSource.map((item, index) => {
                  // 要展示的国际化标题
                  let typeName = getLanguageTitle(
                    this.props,
                    item.typeLocale,
                    "typeName",
                    item.typeName
                  );
                  return (
                    <li
                      key={index}
                      className={classnames(
                        // { border_bottom: this.state.type != index },
                        "tab_title"
                      )}
                    >
                      <div
                        className="clearfix tabTitle"
                        onClick={() => this.handleTypeChange(index)}
                      >
                        <div className={`${"fl tab_text"} `}>{typeName}</div>
                        <div
                          className={`${
                            index == this.state.type ? "arrow_up" : "arrow_down"
                          } fr`}
                        />
                      </div>
                      {this.state.type == index && (
                        <ul className="tab_item">
                          {item.list.map((res, key) => {
                            // 要展示的国际化标题
                            let cardName = getLanguageTitle(
                              this.props,
                              res.locale,
                              "cardName",
                              res.cardName
                            );
                            return (
                              <DragSourceWrapper
                                key={key} //表示类型
                                componentName={res.commpentName} // 表示组件类型
                                cardProps={res}
                                login={login}
                                {...res}
                              >
                                <li key={res.commpentName} className="clearfix">
                                  <div className="fl" style={{ width: "70%" }}>
                                    <img
                                      src={
                                        res.cardIcon
                                          ? `${downloadApi}?attachmentId=${res.cardIcon}`
                                          : require("assets/images/cardicon.png")
                                      }
                                      onError={event => {
                                        var img = event.nativeEvent.srcElement;
                                        img.src = require("assets/images/cardicon.png");
                                        img.onerror = null;
                                      }}
                                      className="iconImg"
                                    />
                                    <span className="tab_item_span">
                                      <Tooltip placement="top" title={cardName}>
                                        {cardName}
                                      </Tooltip>
                                    </span>
                                  </div>
                                  <div className="fr">
                                    <Popover
                                      content={
                                        <img
                                          style={{
                                            width: "120px",
                                            height: "110px"
                                          }}
                                          src={
                                            res.imgUrl
                                              ? res.imgUrl
                                              : require("assets/images/cardpic.png")
                                          }
                                          onError={event => {
                                            var img =
                                              event.nativeEvent.srcElement;
                                            img.src = require("assets/images/cardpic.png");
                                            img.onerror = null;
                                          }}
                                        />
                                      }
                                      placement="right"
                                      trigger="hover"
                                    >
                                      <Button
                                        type="primary"
                                        ghost
                                        size="small"
                                        disabled={
                                          res.isUse == "1" &&
                                          res.isSingleton == "1"
                                        }
                                        onClick={e => this.handleAdd(e, res)}
                                      >
                                        {res.isUse == "1" &&
                                        res.isSingleton == "1"
                                          ? localeJson.added
                                          : localeJson.add}
                                      </Button>
                                    </Popover>
                                  </div>
                                </li>
                              </DragSourceWrapper>
                            );
                          })}
                        </ul>
                      )}
                    </li>
                  );
                })
              ) : !loading ? (
                <div className="nodata">
                  <img src={require("assets/images/nodata.png")} />
                  <div>{localeJson.nodata}</div>
                </div>
              ) : (
                <div className="nodata"></div>
              )}
            </Spin>
          </ul>
        </Scrollbars>
      </div>
    );
  }
}
