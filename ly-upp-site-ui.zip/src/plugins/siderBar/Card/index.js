/*
 * @Description: 侧边栏卡片入口
 * @Author: xuqiuting
 * @Date: 2019-06-05 17:27:37
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-27 15:14:18
 */
import React from 'react'
import { Input, message } from 'antd'
import { connect } from 'react-redux'
import { guid } from 'utils/util'
import { setPage } from 'redux/actions/page'
import { reqGetCardList, downloadApi, addSearchLog } from 'utils/api'
import classnames from 'classnames'
import antdUI from 'assets/js/lib'
import systemCard from 'comon/template/index'
import DefaulList from './defaulList'
import RecommendList from './recommendList'
import PopularList from './popularList'
import SearchList from './searchList'

const Search = Input.Search

@connect(state => {
  return { ...state }
})
export default class Card extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      type: 'siderBarCardTypeDefault',
      isFocus: false,
      searchData: [],
      cardArr: [],
      height: 450,
      tabList: [
        {
          name: '默认',
          type: 'siderBarCardTypeDefault'
        },
        {
          name: '推荐',
          type: 'siderBarCardTypeRecommend'
        },
        {
          name: '热门',
          type: 'siderBarCardTypeHot'
        }
      ]
    }
  }

  componentDidMount() {
    this.setHeight()
  }

  componentWillReceiveProps(nextProps) {
    const { page } = nextProps
    const { element, currentPage } = page
    let object = element[currentPage]
    if (object && object.cardArr) {
      this.changeData(object.cardArr)
    }
    if (nextProps.login.locale != this.props.login.locale) {
      this.setHeight()
    }
  }
  // 设置高度
  setHeight = () => {
    let element = this.contenthead
    if (element) {
      this.setState({
        height: 540 - element.clientHeight - 28 - 10
      })
    }
  }

  // 对比渲染数据，已添加
  changeData = arr => {
    let data = this.state.searchData
    data.map(item => {
      item.list.map(list => {
        for (let i = 0; i < arr.length; i++) {
          if (list.cardId == arr[i].cardId) {
            if (arr[i].isUse == '1') {
              list.isUse = '1'
            } else {
              list.isUse = '0'
            }
          }
        }
      })
    })
    this.setState({
      searchData: data,
      cardArr: arr
    })
  }

  //tab改变
  onChange = res => {
    this.setState({ type: res.type })
  }

  // 生成组件
  generateComponet = () => {
    const { type, isFocus, searchData, height } = this.state
    let Component = <DefaulList />
    switch (type) {
      case 'siderBarCardTypeDefault':
        Component = <DefaulList handleAdd={this.handleAdd} height={height} />
        break
      case 'siderBarCardTypeRecommend':
        Component = <RecommendList handleAdd={this.handleAdd} height={height} />
        break
      case 'siderBarCardTypeHot':
        Component = <PopularList handleAdd={this.handleAdd} height={height} />
        break
      case 'search':
        Component = (
          <SearchList
            handleSearch={this.onSearch}
            handleAdd={this.handleAdd}
            goBack={this.goBack}
            isFocus={isFocus}
            searchData={searchData}
          />
        )
        break
    }
    return Component
  }

  // 搜索返回
  goBack = () => {
    this.setState({
      type: 'siderBarCardTypeDefault'
    })
    // 清空输入框
    this.input.input.state.value = ''
  }

  // 搜索框聚焦
  onSearchFocus = () => {
    if (this.state.type != 'search') {
      this.setState({
        type: 'search',
        isFocus: true
      })
    } else {
      this.setState({
        type: 'search'
      })
    }
  }

  // 搜索
  onSearch = value => {
    this.input.input.state.value = value
    var searchName = value.replace(/^\s+|\s+$/g, '').trim()
    if (searchName) {
      addSearchLog(searchName).then(res => {})
    }
    this.getSearchData(value)
  }

  // 获取数据
  getSearchData = value => {
    // debugger
    let arr = []
    const { page } = this.props
    const { element, currentPage } = page
    let object = element[currentPage]
    if (object.cardArr) {
      arr = object.cardArr
    }
    const { type } = this.state
    let pageId, typeValue
    let menus = JSON.parse(sessionStorage.getItem('menus')) || []
    if (!menus) {
      return false
    }
    for (let i = 0; i < menus.length; i++) {
      if (menus[i].pagePath == currentPage) {
        pageId = menus[i].pageId
      }
    }
    switch (type) {
      case 'siderBarCardTypeDefault':
        typeValue = null
        break
      case 'siderBarCardTypeRecommend':
        typeValue = '1'
        break
      case 'siderBarCardTypeHot':
        typeValue = '3'
        break
    }
    let params = {
      pageId: pageId,
      recommendType: typeValue,
      searchName: value.replace(/^\s+|\s+$/g, '')
    }
    reqGetCardList(params).then(res => {
      let { data, meta } = res.data
      if (meta.success) {
        this.setState({
          searchData: data
            ? data.map(item => {
                return {
                  ...item,
                  list: item.list.map(list => {
                    for (let i = 0; i < arr.length; i++) {
                      if (list.commpentName == arr[i].commpentName) {
                        if (arr[i].isUse == '1') {
                          list.isUse = '1'
                        } else {
                          list.isUse = '0'
                        }
                      }
                    }
                    return {
                      imgUrl: list.cardpic
                        ? `${downloadApi}?attachmentId=${list.cardpic}`
                        : null,
                      ...list
                    }
                  })
                }
              })
            : [],
          isFocus: false
        })
      } else {
        message.error(meta.message)
      }
    })
  }

  // 输入改变
  onSearchChange = e => {
    // console.log(e.target.value, "value");
    let value = e.target.value
    // this.input.input.state.value = value;
    // this.getSearchData(value);
    setTimeout(this.getSearchData(value), 500)
  }

  // 添加卡片
  handleAdd = (e, res) => {
    e.stopPropagation()
    e.cancelBubble = true
    // debugger;
    const { localeJson } = this.props.login
    if (!systemCard[res.commpentName] && !antdUI[res.commpentName]) {
      message.error(localeJson.card_not_exist)
      return
    }
    // 系统总的页面布局
    let element = this.props.page.element
    // 本菜单下的页面布局
    let object = this.props.page.element[this.props.page.currentPage]
    if (!object.component) {
      let layout = object.layout || 'horizontal'
      let type = layout
      if (layout.length == 11 && layout.indexOf('two_col') != -1) {
        type = 'two_col'
      } else if (layout.length == 15 && layout.indexOf('three_col') != -1) {
        type = 'three_col'
      } else if (
        layout.length == 21 &&
        layout.indexOf('three_row_two_col') != -1
      ) {
        type = 'three_row_two_col'
      } else if (
        layout.length == 25 &&
        layout.indexOf('three_row_three_col') != -1
      ) {
        type = 'three_row_three_col'
      }
      switch (type) {
        case 'horizontal':
          object.component = [
            {
              componentArea: []
            }
          ]
          break
        case 'two_col':
          object.component = [
            {
              componentArea: []
            },
            {
              componentArea: []
            }
          ]
          break
        case 'three_col':
          object.component = [
            {
              componentArea: []
            },
            {
              componentArea: []
            },
            {
              componentArea: []
            }
          ]
          break
        case 'three_row_two_col':
          object.component = [
            {
              componentArea: []
            },
            {
              componentArea: []
            },
            {
              componentArea: []
            },
            {
              componentArea: []
            }
          ]
          break
        case 'three_row_three_col':
          object.component = [
            {
              componentArea: []
            },
            {
              componentArea: []
            },
            {
              componentArea: []
            },
            {
              componentArea: []
            },
            {
              componentArea: []
            }
          ]
          break
        case 'auto':
          object.component = [
            {
              componentArea: []
            }
          ]
          break
      }
    }
    let uid = guid()
    let newprops = {
      // 用于渲染是什么组件
      componentName: res.commpentName,
      // key值用来自由布局
      key: uid,
      // 用来标志是在那个target里面的
      parentid: 0,
      // 默认id
      id: uid,
      // 自由布局必须要的
      dataGrid: {
        i: uid.toString(),
        x: 0,
        y: 0,
        w: 3,
        h: 1,
        isDraggable: true,
        isResizable: true
      },
      // 组件是否只能添加一次
      isSingleton: res.isSingleton,
      cardProps: res,
      config: res.config
    }
    if (res.commpentName == 'SelectCard') {
      newprops.defaultActiveKey = 0
      newprops.tabList = [
        {
          title: '选项卡1',
          uuid: guid(),
          content: []
        },
        {
          title: '选项卡2',
          uuid: guid(),
          content: []
        },
        {
          title: '选项卡3',
          uuid: guid(),
          content: []
        }
      ]
      newprops['dataGrid'] = {
        i: uid.toString(),
        x: 0,
        y: 0,
        w: 4,
        h: 2,
        isDraggable: true,
        isResizable: true
      }
    } else if (res.commpentName == 'LayoutCard') {
      newprops.layout = 'two_col_5_5'
      newprops.component = [{ subComponent: [] }, { subComponent: [] }]
      newprops['dataGrid'] = {
        i: uid.toString(),
        x: 0,
        y: 0,
        w: 4,
        h: 2,
        isDraggable: true,
        isResizable: true
      }
    }
    // 从菜单栏拖出来的，设置菜单栏卡片是否已经添加
    // 只能添加一次的卡片
    if (res.isSingleton == '1') {
      let cardArr = []
      if (object.cardArr) {
        cardArr = object.cardArr
        let remarkUser
        cardArr.map(item => {
          if (item.cardId == res.cardId) {
            item.isUse = '1'
            remarkUser = '1'
          }
        })
        if (!remarkUser) {
          let remarkObj = {
            ...res,
            isUse: '1'
          }
          cardArr.push(remarkObj)
        }
      } else {
        let newObj = {
          ...res,
          isUse: '1'
        }
        cardArr.push(newObj)
      }
      object.cardArr = cardArr
    }

    object.component[0].componentArea.push(newprops)
    object = {
      ...object
    }
    element = {
      ...element,
      [this.props.page.currentPage]: object
    }
    sessionStorage.setItem('element', JSON.stringify(element))
    this.props.dispatch(setPage(element))
  }

  render() {
    const { login } = this.props
    const { localeJson } = login
    const { type, tabList } = this.state
    return (
      <div className="siderBarCard">
        <div ref={node => (this.contenthead = node)}>
          <div style={{ margin: '18px 10px 10px' }}>
            <Search
              ref={node => (this.input = node)}
              placeholder={localeJson.siderBarCardSearchPlaceholder}
              onChange={e => this.onSearchChange(e)}
              onSearch={e => this.onSearch(e)}
              onFocus={e => this.onSearchFocus(e)}
            />
          </div>
          {type != 'search' && (
            <table className="siderBarCardButton">
              <tbody>
                <tr>
                  {tabList.map(res => {
                    return (
                      <td
                        key={res.type}
                        className={classnames({ active: res.type == type })}
                        onClick={() => this.onChange(res)}
                      >
                        {localeJson[res.type]}
                      </td>
                    )
                  })}
                </tr>
              </tbody>
            </table>
          )}
        </div>
        {this.generateComponet()}
      </div>
    )
  }
}
