/*
 * @Description: 侧边栏入口
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:50:57
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-17 14:20:05
 */
import React, { Fragment } from 'react'
import { Divider, Drawer, Tooltip, message, Modal } from 'antd'
import { connect } from 'react-redux'
import classnames from 'classnames'
import _ from 'lodash'
import { setOpenSider, setEditPage } from 'redux/actions/page'
import {
  changeTopFive,
  openCollectModal,
  setAppTypeList
} from 'redux/actions/app'
import { reqMyAppList, reqAppLog } from 'utils/api'
import { handleImageUrl, getHashParam } from 'utils/util'
import { exitEditPage } from 'utils/service'
import { themeData } from 'utils/themeData'

// 添加
import Add from './Card/index'
import Theme from './theme/index.js'
// theme的弹窗
import DressUpModal from './theme/modal/dressUpModal'
import LayoutListModal from './theme/modal/layoutListModal'
import SkinModal from './theme/modal/skinModal'
// 应用中心
import AppCenter from 'src/app/layout/apply/appCenter'

const { confirm } = Modal
const addIconList = [
  {
    name: '添加',
    appId: 'addIcon1',
    isIcon: true
  },
  {
    name: '添加',
    appId: 'addIcon2',
    isIcon: true
  },
  {
    name: '添加',
    appId: 'addIcon3',
    isIcon: true
  },
  {
    name: '添加',
    appId: 'addIcon4',
    isIcon: true
  },
  {
    name: '添加',
    appId: 'addIcon5',
    isIcon: true
  }
]

@connect(state => {
  return { ...state }
})
export default class SiderBar extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isShowTheme: false, // 是否展示主题
      collectVisible: false, //收藏展开
      skinVisible: false, // 皮肤展开
      addVisible: false, //添加展开
      editVisible: false, // 编辑展开
      activeKey: null, //选中的值
      themeVisible: false, // 主题弹窗张开
      themeTab: 'siderBarDressUp', //主题选中的tab
      fixList: [
        // 侧边栏固定列表
        {
          name: '编辑',
          type: 'edit',
          img: 'iconbianji'
        },
        {
          name: '主题',
          type: 'theme',
          img: 'icontheme'
        },
        {
          name: '新增',
          type: 'add',
          img: 'icontianjia'
        },
        {
          name: '收藏',
          type: 'collect',
          img: 'iconcolllect'
        }
      ],
      collectList: [] // 收藏列表
    }
  }

  componentDidMount() {
    const { data } = this.props.login
    if (data) {
      this.getCollectList()
    }
    this.changeIcon(this.props)
  }

  componentWillReceiveProps(nextProp) {
    const { app, dispatch, page, login } = nextProp
    if (page.editPage == false) {
      this.setState({
        isShowTheme: false,
        skinVisible: false, // 皮肤展开
        addVisible: false, //添加展开
        editVisible: false, // 编辑展开
        activeKey: null, //选中的值
        themeVisible: false // 主题弹窗展开
      })
    }
    if (!_.isEqual(login.data, this.props.login.data)) {
      this.getCollectList()
    }
    // 更新侧边栏的应用
    if (app.isTopFiveChange) {
      this.getCollectList()
      dispatch(changeTopFive(false))
    }

    // 触发侧边栏我的收藏modal打开
    if (app.openCollect && app.openCollect !== this.props.app.openCollect) {
      this.setState({ collectVisible: true })
    }

    // 侧边栏图标变化
    let nextElement = nextProp.page.element[nextProp.page.currentPage]
    let propsElement = this.props.page.element[this.props.page.currentPage]
    if (
      !_.isEqual(nextElement, propsElement) ||
      nextProp.page.currentPage != this.props.page.currentPage ||
      nextProp.siderBarHidden != this.props.siderBarHidden ||
      nextProp.page.cardDisable != this.props.page.cardDisable
    ) {
      this.changeIcon(nextProp)
    }
  }

  // 换图标
  changeIcon = nextProp => {
    const { type, siderBarHidden, page } = nextProp
    let arr = themeData.default
    // 如果是编辑主题，则收藏图标等不展示
    if (type == 'editTheme') {
      // 编辑主题的时候，没有数据不能编辑
      if (siderBarHidden) {
        arr = []
      } else {
        let themeId = getHashParam('themeId')
        if (themeData[themeId]) {
          themeData[themeId].splice(3, 1)
          arr = themeData[themeId]
        } else {
          themeData.default.splice(3, 1)
          arr = themeData.default
        }
      }
    } else {
      let object = nextProp.page.element[nextProp.page.currentPage]
      // 如果是主题1，图标不同
      if (object && themeData[object.pageTheme]) {
        arr = themeData[object.pageTheme]
      }

      // // 写死一个A主题风格页面
      // if (object && (object.pageId === 'e8df508edc534ee18f52d0783f4d333e' || object.pageId === '24d11e16858340858bd58cbc0985f8ce')) {
      //   arr = themeData['lyThemeA']
      // }

      // 如果是嵌入式，则不显示添加卡片图标
      if (page.cardDisable) {
        let arrCopy = [...arr]
        arrCopy.splice(2, 1)
        arr = [...arrCopy]
      }
    }
    this.setState({
      fixList: arr
    })
  }

  // 获取收藏列表
  getCollectList = () => {
    reqMyAppList().then(res => {
      const { data, meta } = res.data
      if (!meta.success) return message.error(meta.message)
      let collectList = (data || []).concat(addIconList)
      collectList.length = 5
      this.setState({ collectList })
    })
  }

  // 固定图标点击
  handleTabChange = item => {
    let self = this
    const {
      activeKey,
      editVisible,
      addVisible,
      skinVisible,
      collectVisible,
      themeTab
    } = this.state
    // 编辑是否展开
    let isEditVis = editVisible
    // 添加是否展开
    let isAddVis = addVisible
    // 主题是否展开
    let isSkinVis = skinVisible
    // 收藏是否展开
    let isCollectVis = collectVisible
    // 活跃tab
    let actKey = item.type
    // 主题弹窗默认标签
    let themeTabNew = themeTab

    // 特殊判断--当前页面为应用中心页面 不能更改布局、主题、添加皮肤，只能更改肤色
    const { page, login } = this.props
    const { system } = page
    const { localeJson, menus } = login
    const isAppCenterPage = system.pageId === 'lyappCenter'
    if (item.type == 'add' && isAppCenterPage) {
      return message.warning(localeJson.siderBarCurrentPageForbidAddCard)
    }

    // 当前页面不能编辑时， 侧边栏不允许编辑, 应用中心可以改肤色，需要特殊判断
    // 另外如果是主题编辑时，是允许编辑的
    const { currentPage } = page
    const pageIndex = menus.findIndex(v => v.pagePath === currentPage)
    let isEdit = '0'
    if (pageIndex > -1) {
      // isEdit = menus.length ? menus[pageIndex].isEdit : '0'
      // isEdit为1 且不为隐藏页面时，才可编辑
      isEdit = menus.length
        ? ~~menus[pageIndex].isEdit && !menus[pageIndex].hidden
        : '0'
    }
    const themeId = getHashParam('themeId')
    if (
      !~~isEdit &&
      ['edit', 'theme', 'add'].includes(item.type) &&
      !isAppCenterPage
    ) {
      // 当当前为主题编辑的时候
      if ((themeId && !getHashParam('i')) || getHashParam('pageId')) {
      } else {
        return message.warning(localeJson.edit_forbid_current_page)
      }
    }

    // 如果点击的是编辑
    if (item.type == 'edit' && activeKey == 'edit') {
      isAddVis = false
      isSkinVis = false
      isEditVis = false
      actKey = null
      themeTabNew = 'siderBarDressUp'
    } else if (item.type == 'edit' && activeKey != 'edit') {
      isEditVis = true
      isAddVis = false
      isSkinVis = false
    } else if (item.type == 'theme' && activeKey == 'theme') {
      isSkinVis = false
      actKey = null
      themeTabNew = 'siderBarDressUp'
    } else if (item.type == 'theme' && activeKey != 'theme') {
      isAddVis = false
      isEditVis = true
      isSkinVis = true
    } else if (item.type == 'add' && activeKey == 'add') {
      isAddVis = false
      actKey = null
    } else if (item.type == 'add' && activeKey != 'add') {
      isSkinVis = false
      isEditVis = true
      isAddVis = true
      themeTabNew = 'siderBarDressUp'
    } else if (item.type == 'collect' && activeKey == 'collect') {
      isCollectVis = false
      actKey = null
    } else if (item.type == 'collect' && activeKey != 'collect') {
      isAddVis = false
      isSkinVis = false
      isCollectVis = true
      themeTabNew = 'siderBarDressUp'
      this.props.dispatch(setOpenSider(false))
    }
    if (isEditVis) {
      this.props.dispatch(setEditPage(isEditVis))
    } else if (item.type != 'collect') {
      confirm({
        title: localeJson.exit_message,
        content: localeJson.exit_tip,
        onOk() {
          exitEditPage(self.props) // 退出编辑时还原设置
          self.props.dispatch(setEditPage(false))
        },
        onCancel() {
          console.log('Cancel')
        }
      })
    }
    if (item.type == 'theme') {
      this.props.dispatch(setOpenSider(isSkinVis))
    } else {
      this.props.dispatch(setOpenSider(isAddVis))
    }
    this.setState({
      activeKey: actKey,
      editVisible: isEditVis,
      addVisible: isAddVis,
      skinVisible: isSkinVis,
      collectVisible: isCollectVis,
      themeTab: themeTabNew
    })
  }

  // 取消收藏
  onCollectClose = () => {
    this.setState({
      collectVisible: false,
      activeKey: null
    })
    this.props.dispatch(openCollectModal(false))
    this.props.dispatch(setAppTypeList([]))
  }

  // 打开应用页面
  linkToAppPage = item => {
    const { appLink, appId, isOpen } = item
    reqAppLog({ appId }).then(res => {
      const { meta } = res.data
      if (!meta.success) return message.error(meta.message)
    })
    if (~~isOpen) {
      window.open(appLink, '_blank').location
    } else {
      window.open(appLink, '_self')
    }
  }

  // 添加收藏
  addCollect = item => {
    this.setState({
      activeKey: item.type,
      collectVisible: !this.state.collectVisible
    })
  }

  // 主题tab切换
  handleThemeTab = key => {
    this.setState({
      themeTab: key
    })
  }

  // 主题弹窗
  onThemeClose = themeTab => {
    this.setState({
      themeVisible: !this.state.themeVisible,
      themeTab: themeTab ? themeTab : this.state.themeTab
    })
  }

  // 生成主题弹窗
  generateTheme = () => {
    const { themeTab } = this.state
    let component = <div />
    switch (themeTab) {
      case 'siderBarDressUp':
        component = <DressUpModal handleThemeModal={this.onThemeClose} />
        break
      case 'siderBarLayout':
        component = <LayoutListModal handleThemeModal={this.onThemeClose} />
        break
      case 'siderBarSkin':
        component = <SkinModal handleThemeModal={this.onThemeClose} />
        break
      default:
        component = <div />
    }
    return component
  }

  // 生成侧边栏
  generateSider = () => {
    let component = <div className="siderBarBlank" />
    if (this.state.skinVisible) {
      component = (
        <Theme
          handleThemeTab={this.handleThemeTab}
          handleThemeModal={this.onThemeClose}
        />
      )
    } else if (this.state.addVisible) {
      component = <Add />
    }
    return component
  }

  render() {
    const { collectList, activeKey, fixList } = this.state
    const { page, type, login } = this.props
    const {
      system,
      systemMode,
      skinDisable,
      layoutDisable,
      themeDisable
    } = page
    const { localeJson, locale, simulateSystem } = login
    return (
      <div
        className={classnames('yui_page_siderBar', {
          themeTop: system && system.banner,
          yui_page_siderBar_hide: systemMode
        })}
        style={{ visibility: page.loading ? 'hidden' : 'visible' }}
      >
        <div className="clearfix siderWraper">
          <ul className="fl siderWraperUl">
            {!simulateSystem &&
              fixList.map((res, index) => {
                // 如果皮肤，主题，布局都不显示，则不显示tab
                if (
                  res.type == 'theme' &&
                  skinDisable &&
                  layoutDisable &&
                  themeDisable
                ) {
                  return null
                }
                return (
                  <Fragment key={res.type}>
                    <Tooltip
                      key={res.type}
                      placement="right"
                      title={localeJson[res.type]}
                    >
                      <li
                        onClick={() => this.handleTabChange(res)}
                        className={classnames({
                          active: activeKey == res.type
                        })}
                      >
                        <i className={`icon iconfont ${res.img}`} />
                      </li>
                    </Tooltip>
                    {index == fixList.length - 2 && type != 'editTheme' && (
                      <Divider />
                    )}
                  </Fragment>
                )
              })}
            {type != 'editTheme' &&
              collectList.map((item, index) => {
                const itemLocale = item.locale ? JSON.parse(item.locale) : {}
                return (
                  <Tooltip
                    key={index}
                    placement="right"
                    title={
                      item.isIcon
                        ? localeJson.siderBarCardAddcollect
                        : (itemLocale[locale] && itemLocale[locale].appName) ||
                          (itemLocale.zh_CN && itemLocale.zh_CN.appName) ||
                          (itemLocale.en_US && itemLocale.en_US.appName) ||
                          localeJson.No_text
                    }
                  >
                    <li
                      onClick={() =>
                        item.appLink
                          ? this.linkToAppPage(item)
                          : this.addCollect(item)
                      }
                      className={classnames({
                        active: activeKey == item.appId
                      })}
                    >
                      {item.isIcon ? (
                        <i className={`icon iconfont iconthemeA_tianjia`} />
                      ) : (
                        <div className="appIcon">
                          <img
                            alt=""
                            src={handleImageUrl(item.appIcon)}
                            onError={event => {
                              var img = event.nativeEvent.srcElement
                              img.src = require('assets/images/defaultAppIcon.png')
                              img.onerror = null
                            }}
                          />
                        </div>
                      )}
                    </li>
                  </Tooltip>
                )
              })}
          </ul>
          <div
            className={classnames('fl siderWraperRight', {
              openSider: page.openSider
            })}
          >
            {this.generateSider()}
          </div>
        </div>
        <Drawer
          placement={'left'}
          destroyOnClose={true}
          closable={false}
          width={'auto'}
          className={'drawer'}
          onClose={this.onCollectClose}
          visible={this.state.collectVisible}
        >
          <AppCenter
            type="inner"
            hasIcon={true}
            onClose={this.onCollectClose}
          />
        </Drawer>
        <Drawer
          placement={'left'}
          destroyOnClose={true}
          closable={false}
          width={900}
          className={classnames('themeDrawer', {
            themeDrawerTop: system && system.banner
          })}
          onClose={this.onThemeClose}
          visible={this.state.themeVisible}
        >
          {this.generateTheme()}
        </Drawer>
      </div>
    )
  }
}
