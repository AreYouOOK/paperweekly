/*
 * @Description: 总路由页面
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-09 11:58:30
 */
import React from 'react'
import { Route, Router, Redirect, Switch } from 'react-router-dom'
import createHistory from 'history/createHashHistory'
import { connect } from 'react-redux'
import { LocaleProvider, message } from 'antd'
import { receiveUserInfo, setSimulateSystem } from '@redux/actions/login'
import { changeTopFive } from 'redux/actions/app'
import {
  reqFirstLogin,
  reqGetCasLogin,
  downloadApi,
  reqCheckBrowseUser,
  reqCheckEditPage,
  reqAddOnlineUsersRecord,
  reqDefalutAppList
} from 'utils/api'
import { getLocale, getSystemConfig, getPage } from 'utils/service'
import { getHashParam, getDpi, getBrowser, getOS, getDevice } from 'utils/util'
import zhCN from 'antd/lib/locale-provider/zh_CN'
import 'moment/locale/zh-cn'

/************************************************************页面组件开始*******************************************************/
// 路由
import AppRoute from './appRoute'
//登录
import Login from '../login/index'
// 拖曳编辑页面
import EditPage from 'src/app/layout/EditPage/index'
/************************************************************页面组件结束*******************************************************/

var history = createHistory()

@connect(state => {
  return { ...state }
})
export default class Container extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      lang: 'zh_CN' // 当前语言
    }
  }

  componentWillMount() {
    const { locale, systemConfig } = this.props.login
    this.setState({
      lang: locale
    })
    if (window.location.hash.indexOf('Authorization') !== -1) {
      // 单点
      this.casLogin()
    } else if (getHashParam('u')) {
      // 后台系统跳转
      this.getCookie()
    }
    // 具有系统配置信息
    if (systemConfig) {
      this.setSystemConfig(systemConfig)
    } else {
      getSystemConfig(this.props)
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.login.locale != nextProps.login.locale) {
      this.setState({
        lang: nextProps.login.locale
      })
    }
  }
  // 配置系统信息
  setSystemConfig = systemConfig => {
    document.title =
      systemConfig.mgrTitle &&
      JSON.parse(systemConfig.mgrTitle)[this.props.login.locale]
        ? JSON.parse(systemConfig.mgrTitle)[this.props.login.locale]
        : '服务门户管理平台'
    let icoEle = document.getElementById('linkIco')
    icoEle.href = systemConfig.casFootImage
      ? downloadApi + '?attachmentId=' + systemConfig.casFootImage
      : 'favicon.ico'
    let keyEle = document.getElementById('keywordMeta')
    keyEle.content = systemConfig.keyWord
  }

  getCookie = () => {
    const { dispatch, login } = this.props
    const { localeJson } = login
    // 后台系统跳转过来，查看系统，编辑主题
    // 先判断cookie里面是否有与后台系统协商好存的字段
    var arrStr = document.cookie.split('; ')
    let tokenId = null
    let remark = false
    for (var i = 0; i < arrStr.length; i++) {
      var temp = arrStr[i].split('=')
      if (temp[0] == 'userId') {
        remark = true
      } else if (temp[0] == 'tokenId') {
        tokenId = unescape(temp[1])
      }
    }
    // 如果浏览器的cookie中不存在userId则表明，链接是在后台没有登录的情况中跳转的
    if (remark) {
      // 主题
      let t = getHashParam('t')
      // 用户账号
      let u = getHashParam('u')
      // 组织编号
      let o = getHashParam('o')
      // 用户名名称
      let n = getHashParam('n')
      // 密文加密串
      let s = getHashParam('s')
      // 主题浏览,主要用于前端，判断主题浏览页面，不显示工具
      let i = getHashParam('i')
      // 编辑主题
      let p = getHashParam('p')
      // 模拟用户
      let ts = getHashParam('ts')
      // 要传的参数
      let obj = { u, n, o, s, tokenId, ts }
      if (t) {
        // 如果有主题，密文加密串不一样，要传的字段也不一样
        obj.t = t
      } else if (p) {
        obj.p = p
      } else {
        // 没有主题没有页面，就是后台点击模拟系统跳转而来，设置模拟系统
        dispatch(setSimulateSystem(true))
        sessionStorage.setItem('simulateSystem', true)
      }
      // 主题浏览
      if (i) {
        obj.i = i
      }
      // 验证用户浏览和编辑主题的接口
      sessionStorage.setItem('userCode', JSON.stringify(obj))

      // 用于获取权限 从后台跳转过的页面没有权限
      let Authorization = getHashParam('tokenId')
      reqGetCasLogin(Authorization).then(async res => {
        const { data, meta } = res.data
        if (!meta.success)
          return message.error(localeJson.api_request_user_info_error)
        await sessionStorage.setItem('userLogin', JSON.stringify(data))
        await dispatch(receiveUserInfo(data))
        if (p) {
          this.checkBrowseUser(obj, 1)
        } else {
          this.checkBrowseUser(obj, 0)
        }
      })
    } else {
      history.push('/login')
    }
  }

  // 后台跳转验证参数
  checkBrowseUser = (obj, i) => {
    const { dispatch } = this.props
    const reqFn = [reqCheckBrowseUser, reqCheckEditPage]
    reqFn[i](obj).then(async res => {
      const { data, meta } = res.data
      if (meta.success) {
        // sessionStorage.setItem('userLogin', JSON.stringify(data))
        // dispatch(receiveUserInfo(data))
        await getLocale(dispatch)
        let url = ''
        // 页面
        if (obj.p) {
          url = `/editTheme?pageId=${data.pageId}`
          await history.push(url)
        } else if (obj.t) {
          // 主题
          url = `/editTheme?themeId=${data.themeId}`
          // 主题浏览
          if (obj.i) {
            url = `/editTheme?themeId=${data.themeId}&i=${obj.i}`
          }
          await history.push(url)
        } else {
          // 获取菜单
          await getPage(dispatch, 'login')
        }
      } else {
        history.push('/login')
        message.error(meta.message)
      }
    })
  }

  // 尝试登录
  casLogin = () => {
    const { dispatch } = this.props
    reqGetCasLogin().then(async res => {
      let { meta, data } = res.data
      if (meta.success) {
        sessionStorage.setItem('userLogin', JSON.stringify(data))
        dispatch(receiveUserInfo(data))
        //登录添加在线用户记录
        const params = {
          userName: data.userName,
          operaCategory: data.userType,
          nickName: data.userNickname,
          ip: data.host,
          email: data.email,
          departmentId: data.departmentId,
          browser: getBrowser(), // 浏览器
          screenSize: getDpi(), // 屏幕分辨率
          loginCategory: getDevice(), // 手机端还是pc端
          operation: getOS() // 操作系统
        }
        // 获取登录情况：1.是否第一次登录 2.是否已使用新手指引
        reqFirstLogin().then(res => {
          const { data, meta } = res.data
          console.log('reqFirstLogin', data)
          if (!meta.success) console.log('reqFirstLogin error')
          if (data.guideUsed === '0') {
            dispatch(setGuideUsed(false))
          }
          if (data.firLogin === '1') {
            // 第一次登录插入默认订阅数据
            reqDefalutAppList().then(() => {
              dispatch(changeTopFive(true))
            })
          }
        })
        reqAddOnlineUsersRecord(params).then(res => {
          const { meta } = res.data
          if (!meta.success) return message.error(meta.message)
        })
        // 获取系统配置
        await getSystemConfig(this.props)
        // 获取菜单
        await getPage(dispatch, 'login')
        // 获取国际语言
        await getLocale(dispatch)
        // await history.push("/");
      } else {
        message.error(meta.message)
      }
    })
  }

  render() {
    const { lang } = this.state
    let { firstMenu } = this.props.page
    firstMenu = firstMenu || 'index'
    return (
      <LocaleProvider locale={lang === 'zh_CN' ? zhCN : null}>
        <Router history={history}>
          <Route
            render={({ location }) => {
              return (
                <div
                  style={{
                    width: '100%',
                    height: '100%',
                    minWidth: '1200px'
                  }}
                >
                  <Switch location={location}>
                    <Route
                      location={location}
                      path="/editTheme"
                      component={EditPage}
                    />
                    <Route
                      location={location}
                      exact
                      path="/"
                      render={() => {
                        // debugger;
                        if (!this.props.login.data) {
                          if (
                            window.location.hash.indexOf('Authorization') == -1
                          ) {
                            if (window.casStatus) {
                              if (!getHashParam('tokenId')) {
                                window.location.href =
                                  '/auth?service=' +
                                  encodeURIComponent(
                                    window.location.origin +
                                      window.location.pathname +
                                      window.location.hash
                                  )
                              }
                              return null
                            } else {
                              return <Redirect to="/login" />
                            }
                          } else {
                            return <Redirect from="/" to={firstMenu} />
                          }
                        } else {
                          return <Redirect from="/" to={firstMenu} />
                        }
                      }}
                    />
                    <Route
                      location={location}
                      path="/login"
                      render={() => {
                        if (!window.casStatus) {
                          return <Login />
                        } else {
                          if (
                            window.location.hash.indexOf('Authorization') == -1
                          ) {
                            if (!getHashParam('tokenId')) {
                              window.location.href =
                                '/auth?service=' +
                                encodeURIComponent(
                                  window.location.origin +
                                    window.location.pathname +
                                    window.location.hash
                                )
                            }
                            return null
                          }
                        }
                      }}
                    />

                    <Route
                      location={location}
                      render={({ location }) => {
                        if (!window.casStatus) {
                          if (!this.props.login.data) {
                            return <Redirect to="/login" />
                          } else {
                            return (
                              <AppRoute location={location} history={history} />
                            )
                          }
                        } else {
                          if (
                            !this.props.login.data &&
                            window.location.hash.indexOf('Authorization') == -1
                          ) {
                            if (!getHashParam('tokenId')) {
                              window.location.href =
                                '/auth?service=' +
                                encodeURIComponent(
                                  window.location.origin +
                                    window.location.pathname +
                                    window.location.hash
                                )
                            }
                            return null
                          } else {
                            return (
                              <AppRoute location={location} history={history} />
                            )
                          }
                        }
                      }}
                    />
                  </Switch>
                </div>
              )
            }}
          />
        </Router>
      </LocaleProvider>
    )
  }
}
