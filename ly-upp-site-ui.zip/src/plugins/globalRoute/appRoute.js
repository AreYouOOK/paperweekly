/*
 * @Description: 页面入口
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-02 10:09:39
 */
import React from 'react'
import { connect } from 'react-redux'
import { Row, Col, Spin, message } from 'antd'
import { Route, Switch } from 'react-router-dom'
import createHistory from 'history/createHashHistory'
import DragDropContext from 'comon/DragAndDrop/DragDropContext'
import classNames from 'classnames'
import _ from 'lodash'
import asyncComponent from 'utils/asyncComponent' //按需加载组件
// import { menuData, formatter } from 'src/app/route/menu'
import { formatter, scheduleMenus } from 'src/app/route/menu'
import { getSize } from 'utils/util'
import { Scrollbars, ErrorBoundary } from 'components'
import { downloadApi, reqPageConfigByPagePath } from 'utils/api'
import {
  setPage,
  setSystem,
  setLoading,
  setCurrentPage
} from 'redux/actions/page'
import { getMenus } from 'redux/actions/login'
import { handleSpecialTheme, setPageStyle, getPageContent } from 'utils/service'

/*公用组件*/
import Top from '../top/index'
import Banner from '../banner/index'
import EditTop from '../editTop/index'
import SiderBar from '../siderBar'

// 日程
import ScheduleManage from 'src/app/layout/schedule/index'
import ScheduleManagePublish from 'src/app/layout/schedule/publish'
import ScheduleManageDetail from 'src/app/layout/schedule/detail'

/********** 新增页面 **********/
const NewPage = asyncComponent({
  loader: () => import('src/app/layout/newPage/index')
})
//iframe面板
const IframeRouter = asyncComponent({
  loader: () => import('src/app/layout/iframe/index')
})
// 应用中心
const Apply = asyncComponent({
  loader: () => import('src/app/layout/apply/index')
})

var hashHistory = createHistory()

@DragDropContext
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class AppRoute extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      height: getSize().windowH,
      // menuList: menuData, // 内置的菜单
      menuList: [], // 内置的菜单
      width: getSize().windowW,
      isTheme: false, //特别的主题，内容的宽度为1200
      openSider: false // 侧边栏打开
    }
  }

  componentWillMount() {
    window.addEventListener('resize', this.onWindowResize)
  }

  componentDidMount() {
    window.addEventListener('resize', this.onWindowResize)
    this.contactMenu(this.props.login.menus)
    window.addEventListener('hashchange', () => {
      // console.log('hashchange')
      const currPath = window.location.hash.replace('#/', '')
      // this.getPageConfigByPath(currPath)
      this.props.dispatch(setCurrentPage(currPath))
      sessionStorage.setItem('currentPage', currPath)
    })
  }
  componentWillReceiveProps(nextProps) {
    if (!_.isEqual(nextProps.login.menus, this.props.login.menus)) {
      this.contactMenu(nextProps.login.menus)
    }
    // 如果某页面对用户设置了隐藏并进行了授权，该页面不会显示在菜单上，当仍可以通过路径输入访问到该隐藏页面
    if (!_.isEqual(nextProps.page.currentPage, this.props.page.currentPage)) {
      // console.log('currentPageChange')
      // const currPath = window.location.hash.replace('#/', '')
      this.getPageConfigByPath(nextProps.page.currentPage)
    }
  }

  // 屏幕宽高改变
  onWindowResize = () => {
    this.setState({
      height: getSize().windowH,
      width: getSize().windowW
    })
  }
  // 用户手动输入url访问的页面配置
  getPageConfigByPath = async path => {
    if (
      path === 'login' ||
      path === 'index' ||
      path === 'lyappCenter' ||
      !path ||
      path === 'null'
    )
      return
    const { localeJson } = this.props.login
    let { element, firstMenu } = this.props.page
    const menus = [...this.props.login.menus]
    if (!menus.length) return
    // 如果当前路径为日程发布管理页面
    if (
      path === 'schedule' ||
      /^schedulePublish$|^schedulePublish\?|^scheduleDetail\?/.test(path)
    ) {
      // 菜单中是否已存在该日程发布页面
      let scheduleIndex = menus.findIndex(v => v.pageId === 'schedule')
      let newMenus = [...menus]
      if (scheduleIndex === -1) {
        newMenus = menus.concat(scheduleMenus)
      }
      this.props.dispatch(getMenus(newMenus))
      return sessionStorage.setItem('menus', JSON.stringify(newMenus))
    }
    // console.log('路由变化时的', menus)
    // 如果输入的url页面已存在菜单里
    const pageIndex = await menus.findIndex(v => v.pagePath === path)
    if (pageIndex > -1) {
      // 如果页面是外链页面，需要让页面回到菜单第一项页面
      if (menus[pageIndex].pageType === '3') {
        hashHistory.push('/' + firstMenu)
        // console.log(element[firstMenu])
        return this.props.dispatch(setPageStyle(element[firstMenu]))
      }
      // 先判断是否已存在element内
      if (element[path]) {
        console.log('exist in element')
        // 如果已存在element，仅需要刷新布局颜色即可
        setPageStyle(element[path])
      } else {
        console.log('not exist in element, but exist in menus')
        // 若不存在，需要请求页面详情接口
        const currentPageItem = menus.filter(v => v.pagePath === path)[0]
        getPageContent(currentPageItem, this.props)
      }
    } else {
      console.log('currnent page is hidden page')
      // 如果输入的url页面不存在菜单里， 即为访问隐藏页面
      await this.props.dispatch(setLoading(true))
      await reqPageConfigByPagePath({ url: path }).then(res => {
        const { data, meta } = res.data
        if (!meta.success) {
          this.props.dispatch(setLoading(false))
          hashHistory.push('/' + firstMenu)
          this.props.dispatch(setSystem(element[firstMenu]))
          // return console.log('通过当前页面路径获取页面配置失败')
          return message.error(localeJson.menu_page_not_found)
        }

        // let pageContent = data.pageContent || {};
        // const pageItem = {
        //   pageId: pageContent.pageId,
        //   type: pageContent.pageId
        // }

        this.props.dispatch(setCurrentPage(path))
        sessionStorage.setItem('currentPage', path)
        // getPageContent(menus[i], this.props);
        // 系统总的页面布局
        let pageContent = data.pageContent || {}
        element = {
          ...element,
          [path]: pageContent
        }
        this.props.dispatch(setPage(element))
        sessionStorage.setItem('element', JSON.stringify(element))
        let hiddenItem = {
          pageId: pageContent.pageId,
          pageName: pageContent.pageName,
          pagePath: pageContent.pagePath,
          key: pageContent.pagePath,
          type: pageContent.pagePath,
          locales: pageContent.locale,
          hidden: true
        }
        // 菜单中是否已存在该隐藏页面
        let hiddenIndex = menus.findIndex(v => v.pageId === pageContent.pageId)
        if (hiddenIndex > -1) {
          menus[hiddenIndex] = hiddenItem
        } else {
          menus.push(hiddenItem)
        }
        this.props.dispatch(getMenus(menus))
        sessionStorage.setItem('menus', JSON.stringify(menus))
        // 特殊主题处理
        let themeId = pageContent && pageContent.pageTheme
        handleSpecialTheme(themeId, this.props.dispatch, pageContent)
        // 设置系统配置
        this.props.dispatch(setSystem(pageContent))
        setPageStyle(pageContent)
        this.props.dispatch(setLoading(false))
      })
    }
  }

  //拼接菜单
  contactMenu = menuList => {
    let currentPage = this.props.page.currentPage
    let currentPageItem
    // 没有拿到接口返回的菜单
    if (menuList.length < 1) {
      // menuList = menuData
      // this.handleCurrentMenu(menuData)
      return
    } else {
      menuList.map(res => {
        // 用于路由渲染唯一标识符
        res.type = res.pagePath
        // 获取当前页面
        if (currentPage && currentPage == res.pagePath) {
          currentPageItem = res
        }
      })
      // 如果没有设置当前页面
      if (!currentPage) {
        this.handleCurrentMenu(menuList, 'currentPage')
      } else {
        this.handleCurrentMenu(menuList, 'currentPage', currentPageItem)
      }
    }
    this.setState(
      {
        menuList: formatter(menuList)
      }
      // () => console.log('处理后的menuList', this.state.menuList)
    )
  }

  // 设置当前页面
  handleCurrentMenu = (menuList, type, pageItem) => {
    let currentPageItem =
      pageItem || menuList.filter(item => item.isShow !== '0')[0]
    this.props.dispatch(setCurrentPage(currentPageItem.pagePath))
    sessionStorage.setItem('currentPage', currentPageItem.pagePath)
    // 如果不是系统页面，则请求页面接口
    if (type && !currentPageItem.isBuiltIn) {
      getPageContent(currentPageItem, this.props)
    }
  }

  // 遍历生成路由
  getRouter = (item, location) => {
    // console.log('遍历生成路由')
    if (item.children && item.children.length) {
      return item.children.map(itemM => {
        return this.getRouter(itemM, location)
      })
    } else {
      // 如果是嵌入式的
      if (item.pageType && item.pageType == '2') {
        return (
          <Route
            exact
            key={item.type}
            location={location}
            path={item.pagePath}
            render={() => <IframeRouter url={item.url} />}
          />
        )
        // 如果是跳转系统的
      } else if (item.pageType && item.pageType == '3') {
        return null
      } else {
        // 应用中心渲染的页面不一样
        // if (item.pageId === "lyappCenter") {
        if (item.pagePath === '/lyappCenter') {
          return (
            <Route
              exact
              key={item.type}
              location={location}
              path={item.pagePath}
              component={Apply}
            />
          )
        } else if (item.pagePath === '/schedule') {
          return (
            <Route
              exact
              key={item.type}
              location={location}
              path={item.pagePath}
              component={ScheduleManage}
            />
          )
        } else if (item.pagePath === '/schedulePublish') {
          return (
            <Route
              exact
              key={item.type}
              location={location}
              path={item.pagePath}
              component={ScheduleManagePublish}
            />
          )
        } else if (item.pagePath === '/scheduleDetail') {
          return (
            <Route
              exact
              key={item.type}
              location={location}
              path={item.pagePath}
              component={ScheduleManageDetail}
            />
          )
        } else {
          return (
            <Route
              exact
              key={item.type}
              location={location}
              path={item.pagePath}
              render={() => <NewPage pageType={item.type} />}
            />
          )
        }
      }
    }
  }

  // 切换一级菜单,设置二级菜单数据
  setTabs = activeKey => {
    hashHistory.push(`/${activeKey}`)
  }

  // 设置页面样式
  setStyle = () => {
    const { page } = this.props
    const { system, editPage, systemMode } = page
    const { height } = this.state
    // 没有banner的高度的头部为30,有baner的头部120，编辑头部高度为48，菜单高度54；头部包括白条头部和菜单
    let headHeight = 30,
      bannerHeadHeight = 120,
      editHeadHeight = 48,
      menuHeight = 54,
      wrapperTop = 0,
      wrapperHeight
    //头部样式
    let topWrapperStyle = {}
    //滚动条样式
    let scrollStyle = {}
    // 如果处于编辑状态
    if (editPage) {
      wrapperTop = editHeadHeight
    }
    // 如果有banner
    if (system && system.banner) {
      // 如果处于简洁模式
      if (systemMode) {
        wrapperHeight = bannerHeadHeight
      } else {
        wrapperHeight = bannerHeadHeight + menuHeight
      }
    } else {
      if (systemMode) {
        wrapperHeight = headHeight
      } else {
        wrapperHeight = headHeight + menuHeight
      }
    }
    topWrapperStyle = {
      width: '100%',
      top: wrapperTop,
      height: wrapperHeight
    }
    scrollStyle = {
      position: 'absolute',
      top: wrapperTop + wrapperHeight,
      height: height - wrapperTop - wrapperHeight
    }

    // 背景图片设置
    let backgroudStyle = {}
    if (system && system.background) {
      backgroudStyle = {
        backgroundImage: `url(${downloadApi}?attachmentId=${system.background})`,
        backgroundPosition: 'center center',
        backgroundRepeat:
          system.backgroundIsExtend && system.backgroundIsExtend == '1'
            ? 'repeat'
            : 'no-repeat'
      }
      if (system.backgroundIsExtend != '1') {
        backgroudStyle.backgroundSize = 'cover'
      }
      scrollStyle = {
        ...scrollStyle,
        ...backgroudStyle
      }
    }

    // 页脚图片
    let footerStyle = {}
    if (system && system.footerbackground) {
      footerStyle = {
        backgroundImage: `url(${downloadApi}?attachmentId=${system.footerbackground})`,
        backgroundPosition: 'center center',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
        minWidth: page.openSider ? 1400 : 1200
      }
    }
    return { topWrapperStyle, scrollStyle, footerStyle }
  }

  render() {
    const { location, history, page } = this.props
    const { systemConfig } = this.props.login
    const { loading, element } = page
    const { menuList, width } = this.state
    let { topWrapperStyle, scrollStyle, footerStyle } = this.setStyle()
    const antIcon = (
      <img
        src={require('assets/images/loading.gif')}
        style={{ width: '60px', height: '60px' }}
      />
    )
    return (
      <div className="yui_Wrapper" style={{ height: '100%' }}>
        {/* 头部公用组件 */}
        <EditTop />
        <SiderBar />
        <div className={classNames('yui_top_wrapper')} style={topWrapperStyle}>
          <Top />
          <Banner
            data={menuList}
            history={history}
            location={location}
            setTabs={this.setTabs}
          />
        </div>
        <Scrollbars
          style={scrollStyle}
          className={'yui_main_container_scrollbars'}
        >
          <div className={classNames('yui_main_container')}>
            <Spin spinning={loading} indicator={antIcon}>
              <Row
                className={classNames('yui_main_container_wrapper', {
                  yui_main_container_pdl: page.openSider
                })}
                style={{
                  minHeight:
                    scrollStyle.height - 120 > 680
                      ? scrollStyle.height - 120
                      : 680,
                  paddingTop: '5px'
                }}
              >
                <Col span={2} />
                <Col
                  span={20}
                  style={{
                    height: '100%',
                    minWidth: page.openSider ? 1400 : 1200,
                    margin: '0 auto'
                  }}
                  className={classNames({
                    yui_main_container_col_pdl: Number(width) < 1310
                  })}
                >
                  <Switch location={location}>
                    {menuList.map(item => this.getRouter(item, location))}
                  </Switch>
                </Col>
              </Row>
              <div
                style={footerStyle}
                className="yui_contain_footer"
                dangerouslySetInnerHTML={{
                  __html:
                    systemConfig &&
                    systemConfig.mgrFoot &&
                    JSON.parse(systemConfig.mgrFoot)[this.props.login.locale]
                      ? JSON.parse(systemConfig.mgrFoot)[
                          this.props.login.locale
                        ]
                      : `Copyright © 2014-2018 LIANYI TECHNOLOGY CO.,LTD. All Rights Reserved. 联奕科技有限公司`
                }}
              />
            </Spin>
          </div>
        </Scrollbars>
      </div>
    )
  }
}
