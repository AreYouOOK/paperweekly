/*
 * @Description: 公用拖曳页面
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-23 16:08:45
 */
import React from 'react'
import { connect } from 'react-redux'
import { Modal, Form } from 'antd'
import { setPage } from 'redux/actions/page'
import _ from 'lodash'
import Horizontal from 'comon/layout/horizontal'
import Auto from 'comon/layout/auto'
import TwoCol from 'comon/layout/twoCol'
import ThreeCol from 'comon/layout/threeCol'
import ThreeRowTwoCol from 'comon/layout/threeRowTwoCol'
import ThreeRowThreeCol from 'comon/layout/threeRowThreeCol'
import SelectCardModal from 'comon/modal/selectCard'
import LayoutCard from 'comon/modal/layoutCard'
import CommonCard from 'comon/modal/commonCard/index'
import HelpModal from 'comon/modal/helpModal'
import { cardFormList } from 'comon/data'
import classNames from 'classnames'
import { setwindowstate } from '../../../redux/actions/app'
// import { ifWindow } from '../../../redux/actions/login'

const confirm = Modal.confirm

@connect(state => {
  return { ...state }
})
@Form.create()
export default class Home extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      component: [],
      layout: 'horizontal',
      pageType: this.props.pageType,
      modalVisible: false,
      helpVislble: false,
      helpProps: null
    }
  }

  componentDidMount() {
    let object = this.props.page.element[this.state.pageType]
    if (object) {
      this.init(object)
    }
  }

  componentWillReceiveProps(nextProps) {
    let object = nextProps.page.element[this.state.pageType]
    if (
      object &&
      (object.layout != this.state.layout ||
        !_.isEqual(object.component, this.state.component))
    ) {
      this.init(object)
    } else if (!object) {
      this.init({})
    }
  }

  // 组件初始化
  init = object => {
    this.setState({
      layout: object.layout ? object.layout : 'horizontal',
      component: object.component ? _.cloneDeep(object.component) : [],
      skin: object && object.skin ? object.skin : '#249FFE'
    })
  }

  // 添加组件
  operationItem = (component, dragItem, type) => {
    // 系统总的页面布局
    let element = { ...this.props.page.element }
    // 本菜单下的页面布局
    let obj = this.props.page.element[this.state.pageType]
    let object = { ...obj }
    // 已经添加的卡片
    let cardArr = []
    object = {
      ...object,
      component: [...component],
      layout: this.state.layout,
      skin: object && object.skin ? object.skin : '#249FFE'
    }
    // console.log('删除？？')
    // 删除已经存在的
    if (type && object.cardArr) {
      let remark = false
      cardArr = object.cardArr
      // 还未保存页面，操作卡片
      for (let i = 0; i < cardArr.length; i++) {
        if (dragItem.cardProps.cardId == cardArr[i].cardId) {
          cardArr[i].isUse = '0'
          remark = true
        }
      }
      // 接口拿回来的卡片
      if (!remark && dragItem.isSingleton == '1') {
        let obj = {
          ...dragItem.cardProps,
          isSingleton: '1',
          isUse: '0'
        }
        cardArr.push(obj)
      }
    } else {
      // 从菜单栏拖出来的，设置菜单栏卡片是否已经添加
      if (dragItem && dragItem.cardProps) {
        if (object.cardArr) {
          cardArr = object.cardArr
        }
        // 只能添加一次的卡片
        if (dragItem.cardProps.isSingleton == '1') {
          let remarkUser
          cardArr.map(item => {
            if (item.cardId == dragItem.cardProps.cardId) {
              item.isUse = '1'
              remarkUser = '1'
            }
          })
          if (!remarkUser) {
            let dragObj = {
              ...dragItem.cardProps,
              isUse: '1'
            }
            cardArr.push(dragObj)
          }
        }
        object.cardArr = cardArr
      }
    }
    element = {
      ...element,
      [this.state.pageType]: { ...object }
    }
    sessionStorage.setItem('element', JSON.stringify(element))
    this.props.dispatch(setPage(element))
  }

  // 编辑
  handleEdit = props => {
    this.setState({
      modalType: props.componentName,
      modalProps: _.cloneDeep(props)
    })
    this.handleModalCancel()
  }

  // 弹窗确定
  handleModalOk = e => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        if (this.state.modalType == 'SelectCard') {
          this.setSelectCardModal(values, true)
        } else if (this.state.modalType == 'LayoutCard') {
          this.setLayoutCardModal(values, true)
        } else {
          this.setCommonCardModal(values)
        }
      }
    })
  }

  // 保存普通卡片
  setCommonCardModal = (values, option) => {
    const { modalProps } = this.state
    // console.log('保存卡片拿到的参数', modalProps)
    let base = {}
    let card = {}
    if (modalProps.config) {
      base = (modalProps.config && modalProps.config.base) || {}
      card = (modalProps.config && modalProps.config.card) || {}
    }

    // 系统配置
    for (let key in values) {
      let remark = false
      cardFormList.map(item => {
        if (item.name === key) {
          remark = true
        }
      })
      if (remark) {
        base[key] = values[key]
      } else {
        card[key] = values[key]
      }
    }

    // 配置信息分为基本配置信息和卡片配置信息
    let config = {
      base: {
        ...base
      },
      card: {
        ...card
      }
    }
    let parentComponent = _.cloneDeep(this.state.component)
    let component = parentComponent[modalProps.parentid].componentArea
    component.some(function(item, i) {
      if (item.id == modalProps.id) {
        item.config = config
        return true
      } else {
        return false
      }
    })
    this.operationItem(parentComponent)
    this.handleModalCancel(option)
  }

  // 保存布局选项卡
  setLayoutCardModal = (values, option) => {
    const { modalProps } = this.state
    let parentComponent = _.cloneDeep(this.state.component)
    let component = parentComponent[modalProps.parentid].componentArea
    component.some(function(item, i) {
      if (item.id == modalProps.id) {
        item.layout = values.layout
        item.config = { ...values }
        return true
      } else {
        return false
      }
    })

    this.operationItem(parentComponent)
    this.handleModalCancel(option)
  }

  // 保存选项卡弹窗option
  setSelectCardModal = (values, option) => {
    const { modalProps } = this.state
    let parentComponent = _.cloneDeep(this.state.component)
    let component = parentComponent[modalProps.parentid].componentArea
    component.some(function(item, i) {
      if (item.id == modalProps.id) {
        item.tabList = values.tabList
        item.defaultActiveKey = values.defaultActiveKey
        item.config = { ...values }
        return true
      } else {
        return false
      }
    })
    this.operationItem(parentComponent)
    this.handleModalCancel(option)
  }

  // 弹窗取消
  handleModalCancel = option => {
    this.setState(
      {
        modalVisible: !this.state.modalVisible
      },
      () => {
        this.props.dispatch(
          setwindowstate(
            Object.assign({
              ...this.props.app.ifwinopen,
              [this.state.modalType]: option ? true : false
            })
          )
        )
      }
    )
  }

  // 删除
  handleDelete = props => {
    // handleDelete = async props => {
    const { localeJson } = this.props.login
    let self = this
    let parentComponent = _.cloneDeep(this.state.component)
    let component = parentComponent[props.parentid].componentArea
    // 被删除的卡片id(解决卡片不能被删除问题)
    // const itemId = props.id
    // const parentId = await parentComponent.findIndex(item =>
    //   (item.componentArea || []).some(v => v.id === itemId)
    // )
    // let component = parentComponent[parentid].componentArea
    confirm({
      title: localeJson.sure_to_delete_card,
      okType: 'danger',
      onOk() {
        component.some(function(item, i) {
          if (item.id == props.id) {
            component.splice(i, 1)
            return true
          } else {
            return false
          }
        })
        self.operationItem(parentComponent, props, 'delete')
      },
      onCancel() {}
    })
  }

  // 提示弹窗
  handleHelp = props => {
    this.setState({
      helpProps: props.cardProps,
      helpVislble: !this.state.helpVislble
    })
  }

  // 渲染不同弹窗
  generateModal = () => {
    const { modalType, modalProps } = this.state
    switch (modalType) {
      case 'SelectCard':
        return <SelectCardModal {...this.props} modalProps={modalProps} />
      case 'LayoutCard':
        return (
          <LayoutCard
            {...this.props}
            modalProps={modalProps}
            modalVisible={this.state.modalVisible}
          />
        )
      default:
        return (
          <CommonCard
            {...this.props}
            modalProps={modalProps}
            modalVisible={this.state.modalVisible}
          />
        )
    }
  }

  // 渲染不同布局
  gennerateElement = () => {
    const { layout, component } = this.state
    let newComponent = _.cloneDeep(component)
    let type = layout
    if (layout.length == 11 && layout.indexOf('two_col') != -1) {
      type = 'two_col'
    } else if (layout.length == 15 && layout.indexOf('three_col') != -1) {
      type = 'three_col'
    } else if (
      layout.length == 21 &&
      layout.indexOf('three_row_two_col') != -1
    ) {
      type = 'three_row_two_col'
    } else if (
      layout.length == 25 &&
      layout.indexOf('three_row_three_col') != -1
    ) {
      type = 'three_row_three_col'
    }
    switch (type) {
      case 'horizontal':
        return (
          <Horizontal
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
            handleEdit={this.handleEdit}
            operationItem={this.operationItem}
            component={newComponent}
            pageType={this.state.pageType}
          />
        )
      case 'auto':
        return (
          <Auto
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
            handleEdit={this.handleEdit}
            operationItem={this.operationItem}
            component={newComponent}
            pageType={this.state.pageType}
          />
        )
      case 'two_col':
        return (
          <TwoCol
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
            layout={layout}
            handleEdit={this.handleEdit}
            operationItem={this.operationItem}
            component={newComponent}
            pageType={this.state.pageType}
          />
        )
      case 'three_col':
        return (
          <ThreeCol
            layout={layout}
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
            handleEdit={this.handleEdit}
            operationItem={this.operationItem}
            component={newComponent}
            pageType={this.state.pageType}
          />
        )
      case 'three_row_two_col':
        return (
          <ThreeRowTwoCol
            layout={layout}
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
            handleEdit={this.handleEdit}
            operationItem={this.operationItem}
            component={newComponent}
            pageType={this.state.pageType}
          />
        )
      case 'three_row_three_col':
        return (
          <ThreeRowThreeCol
            layout={layout}
            handleDelete={this.handleDelete}
            handleHelp={this.handleHelp}
            handleEdit={this.handleEdit}
            operationItem={this.operationItem}
            component={newComponent}
            pageType={this.state.pageType}
          />
        )
      default:
        return null
    }
  }

  render() {
    const { page, login } = this.props
    const { element, currentPage, editPage } = page
    const { localeJson } = login
    //根据主题设置内容宽度
    let isTheme = false
    let object = element[currentPage]
    if (
      object &&
      (object.pageTheme == 'lyThemeA' || object.pageTheme == 'lyThemeB')
    ) {
      isTheme = true
    }
    return (
      <div
        style={{
          height: '100%',
          minWidth: editPage ? 1400 : 1200,
          margin: '0 auto'
        }}
        className={classNames({
          yui_main_container_theme_width: isTheme
        })}
      >
        {this.gennerateElement()}
        <Modal
          title={localeJson.edit}
          width={800}
          bodyStyle={{ padding: '12px' }}
          visible={this.state.modalVisible}
          onOk={this.handleModalOk}
          destroyOnClose
          onCancel={e => {
            this.handleModalCancel()
          }}
        >
          <Form>{this.generateModal()}</Form>
        </Modal>
        <Modal
          title={localeJson.cardHelp}
          width={800}
          bodyStyle={{ padding: '24px' }}
          visible={this.state.helpVislble}
          footer={null}
          destroyOnClose
          onCancel={this.handleHelp}
        >
          <HelpModal cardProps={this.state.helpProps} />
        </Modal>
      </div>
    )
  }
}
