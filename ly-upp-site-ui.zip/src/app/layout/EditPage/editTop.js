/*
 * @Description: 编辑主题&页面的头部
 * @Author: xuqiuting
 * @Date: 2019-07-11 15:01:25
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-05 10:53:24
 */
import React from 'react'
import { connect } from 'react-redux'
import { Form, message, Checkbox, Modal } from 'antd'
import classNames from 'classnames'
import {
  reqUpdateTheme,
  reqSavePageAndRestore,
  reqSavePageContent
} from 'utils/api'
import { setEditPage, setOpenSider } from 'redux/actions/page'
// import { savePageContent } from "utils/service";
import { getHashParam } from 'utils/util'

const { confirm } = Modal

@connect(state => {
  return { ...state }
})
@Form.create()
export default class EditTop extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isFullScreen: false,
      visible: false,
      isPageRestore: false,
      loading: false
    }
  }

  // 全屏点击
  handleFullScreen = () => {
    if (!this.state.isFullScreen) {
      this.requestFullScreen()
    } else {
      this.exitFullscreen()
    }
  }

  // 进入全屏
  requestFullScreen = () => {
    this.setState({ isFullScreen: true })
    const el = document.documentElement
    const rfs =
      el.requestFullScreen ||
      el.webkitRequestFullScreen ||
      el.mozRequestFullScreen ||
      el.msRequestFullscreen
    if (typeof rfs != 'undefined' && rfs) {
      rfs.call(el)
    }
  }

  // 退出全屏
  exitFullscreen = () => {
    this.setState({ isFullScreen: false })
    this.mainExitFullscreen()
  }

  // 主流浏览器退出全屏
  mainExitFullscreen = () => {
    if (document.exitFullscreen) {
      return document.exitFullscreen()
    } else if (document.mozCancelFullScreen) {
      return document.mozCancelFullScreen()
    } else if (document.webkitCancelFullScreen) {
      return document.webkitCancelFullScreen()
    } else if (document.msExitFullscreen) {
      return document.msExitFullscreen()
    }
    return this.ieExitFullscreen()
  }

  // IE低版本浏览器退出全屏
  ieExitFullscreen = () => {
    if (typeof window.ActiveXObject != 'undefined') {
      //这的方法 模拟f11键，使浏览器全屏
      var wscript = new ActiveXObject('WScript.Shell')
      if (wscript != null) {
        wscript.SendKeys('{F11}')
      }
    }
  }

  // 保存页面Modal checkbox
  onCheckBoxChange = e => {
    this.setState({
      isPageRestore: e.target.checked
    })
  }

  // 主题保存/页面保存
  handleTheme = () => {
    const _this = this
    const { loading } = this.state
    const { page, login } = this.props
    const { userId } = login.data
    const { localeJson } = login
    let element = page.element
    // 本菜单下的页面布局
    let object = element['editTheme']
    let params = {
      ...object
    }
    const pageId = getHashParam('pageId')
    if (pageId) {
      confirm({
        title: localeJson.menu_if_save_page,
        content: (
          <div>
            <Checkbox onChange={_this.onCheckBoxChange}>
              {localeJson.menu_if_restore_page}
            </Checkbox>
          </div>
        ),
        onOk() {
          if (loading) return
          _this.setState({ loading: true })
          if (_this.state.isPageRestore) {
            reqSavePageAndRestore(params).then(res => {
              const { meta } = res.data
              _this.setState({ loading: false })
              if (meta.success) {
                message.success(localeJson.api_save_page_success)
              } else {
                message.success(meta.message)
              }
            })
          } else {
            // 从后台跳转过来的编辑页面，保存页面接口需要更改请求头的loginUserId
            // 用于后端判断是后台点编辑页面跳转前台的页面保存
            params.isRestore = true
            reqSavePageContent(params).then(res => {
              const { meta } = res.data
              _this.setState({ loading: false })
              if (meta.success) {
                message.success(localeJson.api_save_page_success)
              } else {
                message.success(meta.message)
              }
            })
          }
        },
        onCancel() {
          console.log('Cancel')
        }
      })
    } else {
      if (loading) return
      this.setState({ loading: true })
      reqUpdateTheme(params).then(res => {
        this.setState({ loading: false })
        const { meta } = res.data
        if (meta.success) {
          message.success(localeJson.api_save_theme_success)
        } else {
          message.success(meta.message)
        }
      })
    }
  }

  // 退出编辑
  handleExit = () => {
    // this.props.dispatch(setEditPage(false));
    const pageId = getHashParam('pageId')
    const themeId = getHashParam('themeId')
    if (pageId) {
      this.props.getPageData && this.props.getPageData()
    } else if (themeId) {
      this.props.getPageData && this.props.getThemeData()
    }
    this.props.dispatch(setEditPage(false))
    this.props.dispatch(setOpenSider(false))
  }

  // 撤回
  handleBack = () => {
    // this.props.getThemeData()
    const pageId = getHashParam('pageId')
    const themeId = getHashParam('themeId')
    if (pageId) {
      this.props.getPageData && this.props.getPageData()
    } else if (themeId) {
      this.props.getPageData && this.props.getThemeData()
    }
  }

  render() {
    const { page, login } = this.props
    const { localeJson } = login
    const { isFullScreen } = this.state
    return (
      <div className={classNames('editTop', { block: page.editPage })}>
        <div className="editTopContent">
          <label onClick={() => this.handleExit()}>
            {localeJson.editTopExit}
          </label>
          <label onClick={() => this.handleBack()}>
            {localeJson.editTopBack}
          </label>
          <label onClick={() => this.handleTheme()}>
            {localeJson.editTopSave}
          </label>
          <label onClick={() => this.handleFullScreen()}>
            {isFullScreen
              ? localeJson.editTopExitFullScreen
              : localeJson.editTopFullScreen}
          </label>
        </div>
      </div>
    )
  }
}
