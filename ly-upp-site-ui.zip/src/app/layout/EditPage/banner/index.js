import React from 'react'
import { Menu, Row, Col, Form } from 'antd'
import { connect } from 'react-redux'
import { downloadApi } from 'utils/api'
import { getLanguageTitle } from 'utils/util'
import classnames from 'classnames'
import _ from 'lodash'
// import ReactDOM from "react-dom";

@connect(state => {
  return { ...state }
})
@Form.create()
export default class Banner extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      settingVisible: false,
      data: [],
      pageId: null, // 编辑页面的页面id
      pageTitle: '新增页面' // 新增页面弹窗标题
    }
  }

  componentDidMount() {
    this.setState({
      data: this.props.data,
      pageId: this.props.pageId
    })
    // this.onWindowResize();
    // window.addEventListener("resize", this.onWindowResize);
  }

  componentWillReceiveProps(nextProps) {
    if (
      !_.isEqual(nextProps.data, this.state.data) ||
      this.props.pageId != nextProps.pageId
    ) {
      this.setState({
        data: nextProps.data,
        pageId: nextProps.pageId
      })
    }
    // if (!_.isEqual(nextProps.page.system, this.props.page.system)) {
    //   this.onWindowResize("e", nextProps);
    // }
  }

  // componentWillUnmount() {
  //   window.removeEventListener("resize", this.onWindowResize);
  // }

  // onWindowResize = (e, nextProps) => {
  //   console.log('%c获取logo的宽度', 'font-size: 16px;color: rgba(9,97, 81)')
  //   let system = this.props.page.system;
  //   if (nextProps) {
  //     system = nextProps.page.system;
  //   }
  //   let width = "90%";
  //   let contentCol = this.refs.contentCol;
  //   if (contentCol) {
  //     contentCol = ReactDOM.findDOMNode(contentCol);
  //     if (system) {
  //       if (!system.banner) {
  //         let logoImgContent = this.refs.logoImg;
  //         if (logoImgContent) {
  //           console.log(logoImgContent.clientWidth)
  //           logoImgContent = ReactDOM.findDOMNode(logoImgContent);
  //           width = contentCol.clientWidth - logoImgContent.clientWidth - 60;
  //           width = width + "px";
  //         }
  //       }
  //     } else {
  //       width = contentCol.clientWidth;
  //       width = width + "px";
  //     }
  //   }
  //   this.setState({
  //     width: width
  //   });
  // };

  // 菜单点击
  handleClick = e => {}

  render() {
    const { location, page, login } = this.props
    const { data, width } = this.state
    const { system } = page
    let wrapStyle = {
      // width: width
      flexGrow: 1
    }
    let newClass = {}
    let menuItemClass = {}
    if (system) {
      newClass = {
        ...newClass,
        fontFamily: system.navigationFont,
        fontSize: system.navigationFontSize
      }
      menuItemClass = {
        color: system.navigationColor
      }
    }
    return (
      <div className="yui_page_banner">
        <Row>
          <Col span={2} />
          <Col span={20} ref="contentCol">
            <div
              style={{ height: '54px', display: 'flex', flexWrap: 'nowrap' }}
            >
              {!(system && system.banner) && (
                <div className="fl" style={{ marginRight: '10px' }}>
                  <img
                    ref={'logoImg'}
                    src={
                      system && system.logo
                        ? downloadApi + '?attachmentId=' + system.logo
                        : require('assets/images/logo-s.png')
                    }
                    onError={event => {
                      var img = event.nativeEvent.srcElement
                      img.src = require('assets/images/logo-s.png')
                      img.onerror = null
                    }}
                  />
                </div>
              )}
              <div style={wrapStyle} className="yui_page_banner_wrapper">
                <Menu
                  style={newClass}
                  className={classnames('fl', {
                    yui_page_banner_haslogo: system && system.banner
                  })}
                  onClick={this.handleClick}
                  selectedKeys={[location.pathname.split('/')[1]]}
                  mode="horizontal"
                >
                  {data.map(item => {
                    let localeName = getLanguageTitle(
                      this.props,
                      item.locales,
                      'name',
                      item.pageName
                    )
                    return (
                      <Menu.Item key={item.type} style={menuItemClass}>
                        {localeName}
                      </Menu.Item>
                    )
                  })}
                </Menu>
              </div>
            </div>
          </Col>
          <Col span={2} />
        </Row>
        <style jsx="true" global="true">{`
          .yui_page_banner .ant-menu-item,
          .yui_page_banner .ant-menu-submenu-title {
            color: ${system && system.navigationColor};
          }
          .yui_page_banner_wrapper_right {
            color: ${system && system.navigationColor};
          }
          .yui_page_banner .ant-menu-horizontal > .ant-menu-item:hover,
          .yui_page_banner .ant-menu-horizontal > .ant-menu-item-active,
          .yui_page_banner
            .ant-menu-horizontal
            > .ant-menu-submenu
            .ant-menu-submenu-title:hover {
            color: ${system && system.navigationColor};
          }
        `}</style>
      </div>
    )
  }
}
