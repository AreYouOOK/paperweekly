/*
 * @Description: 编辑主题
 * @Author: xuqiuting
 * @Date: 2019-07-09 10:14:08
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-14 17:39:56
 */
import React from 'react'
import { connect } from 'react-redux'
import { Row, Col, message, Spin } from 'antd'
import { Scrollbars, ErrorBoundary } from 'components'
import DragDropContext from 'comon/DragAndDrop/DragDropContext'
import classNames from 'classnames'
import _ from 'lodash'
import { getSize, getHashParam } from 'utils/util'
import { downloadApi, reqGetThemeContent } from 'utils/api'
import { setPageStyle, handleSpecialTheme, getPageContent } from 'utils/service'
import { getMenus } from 'redux/actions/login'
import {
  setPage,
  setSystem,
  setCurrentPage,
  setFirstMenu,
  setThemeDisable
} from 'redux/actions/page'

/*公用组件*/
import Top from 'plugins/top/index'
import Banner from './banner/index'
import EditTop from './editTop'
import SiderBar from 'plugins/siderBar'
import NewPage from 'src/app/layout/newPage/index'

@DragDropContext
@connect(state => {
  return { ...state }
})
@ErrorBoundary
export default class AppRoute extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      height: getSize().windowH,
      width: getSize().windowW,
      openSider: false,
      menuList: [],
      disableShow: false,
      siderBarHidden: false
    }
  }

  componentWillMount() {
    window.addEventListener('resize', this.onWindowResize)
  }

  componentDidMount() {
    window.addEventListener('resize', this.onWindowResize)
    let themeId = getHashParam('themeId')
    let pageId = getHashParam('pageId')
    let isShow = getHashParam('i')
    this.setState(
      {
        themeId,
        pageId,
        disableShow: isShow ? true : false
      },
      () => {
        if (themeId) {
          this.getThemeData()
        }
        if (pageId) {
          this.getPageData()
          this.setState({ menuList: this.props.login.menus })
        }
      }
    )
  }

  componentWillReceiveProps(nextProps) {
    if (!_.isEqual(nextProps.login.menus, this.props.login.menus)) {
      this.setState({ menuList: nextProps.login.menus })
    }
  }

  // 窗口改变
  onWindowResize = () => {
    this.setState({
      height: getSize().windowH,
      width: getSize().windowW
    })
  }

  // 获取页面数据
  getPageData = () => {
    const { pageId } = this.state
    // 设置当前页面
    this.props.dispatch(setCurrentPage('editTheme'))
    sessionStorage.setItem('currentPage', 'editTheme')
    this.props.dispatch(setFirstMenu('editTheme'))
    sessionStorage.setItem('firstMenu', 'editTheme')
    getPageContent({ pageId, type: 'editTheme' }, this.props)
  }
  // 获取主题数据
  getThemeData = () => {
    const { dispatch, login } = this.props
    let params = {
      themeId: this.state.themeId
    }
    reqGetThemeContent(params).then(res => {
      const { data, meta } = res.data
      if (meta.success) {
        // 系统总的页面布局
        let element = this.props.page.element
        if (!data.pageContent) {
          this.setState({
            siderBarHidden: true
          })
          this.props.dispatch(setThemeDisable(true))
          sessionStorage.setItem('saveAsDisathemeDisablele', true)
          message.error(login.localeJson.theme_message_warning)
        } else {
          let menuList = [
            {
              pageId: data.pageContent.pageId,
              pageName: data.pageContent.pageName,
              pagePath: 'editTheme',
              key: 'editTheme',
              type: 'editTheme',
              locales: data.pageContent.locale
            }
          ]

          this.setState({
            pageId: data.pageContent.pageId,
            menuList: menuList
          })
          element = {
            ...element,
            editTheme: data.pageContent
          }
          dispatch(getMenus(menuList))
          sessionStorage.setItem('menus', JSON.stringify(menuList))
          dispatch(setCurrentPage('editTheme'))
          sessionStorage.setItem('currentPage', 'editTheme')
          dispatch(setFirstMenu('editTheme'))
          sessionStorage.setItem('firstMenu', 'editTheme')
          dispatch(setPage(element))
          sessionStorage.setItem('element', JSON.stringify(element))
          // 设置系统配
          dispatch(setSystem(data.pageContent))
          // 设置样式
          setPageStyle(data.pageContent, this.state.themeId)
          handleSpecialTheme(this.state.themeId, this.props.dispatch)
          this.props.dispatch(setThemeDisable(true))
          sessionStorage.setItem('saveAsDisathemeDisablele', true)
        }
      } else {
        this.setState({
          siderBarHidden: true
        })
        this.props.dispatch(setThemeDisable(true))
        sessionStorage.setItem('saveAsDisathemeDisablele', true)
        message.error(meta.message)
      }
    })
  }

  // 设置tab
  setTabs = () => {}

  // 设置页面样式
  setStyle = () => {
    const { page } = this.props
    const { system, editPage, systemMode } = page
    const { height } = this.state
    // 没有banner的高度的头部为30,有baner的头部120，编辑头部高度为48，菜单高度54；头部包括白条头部和菜单
    let headHeight = 30,
      bannerHeadHeight = 120,
      editHeadHeight = 48,
      menuHeight = 54,
      wrapperTop = 0,
      wrapperHeight

    let topWrapperStyle = {} //头部样式
    let scrollStyle = {} //滚动条样式
    // 如果处于编辑状态
    if (editPage) {
      wrapperTop = editHeadHeight
    }
    // 如果有banner
    if (system && system.banner) {
      // 如果处于简洁模式
      if (systemMode) {
        wrapperHeight = bannerHeadHeight
      } else {
        wrapperHeight = bannerHeadHeight + menuHeight
      }
    } else {
      if (systemMode) {
        wrapperHeight = headHeight
      } else {
        wrapperHeight = headHeight + menuHeight
      }
    }
    topWrapperStyle = {
      width: '100%',
      top: wrapperTop,
      height: wrapperHeight
    }
    scrollStyle = {
      position: 'absolute',
      top: wrapperTop + wrapperHeight,
      height: height - wrapperTop - wrapperHeight
    }

    // 背景图片设置
    let backgroudStyle = {}
    if (system && system.background) {
      backgroudStyle = {
        backgroundImage: `url(${downloadApi}?attachmentId=${system.background})`,
        backgroundPosition: 'center center',
        backgroundRepeat:
          system.backgroundIsExtend && system.backgroundIsExtend == '1'
            ? 'repeat'
            : 'no-repeat'
      }
      if (system.backgroundIsExtend != '1') {
        backgroudStyle.backgroundSize = 'cover'
      }
      scrollStyle = {
        ...scrollStyle,
        ...backgroudStyle
      }
    }

    // 页脚图片
    let footerStyle = {}
    if (system && system.footerbackground) {
      footerStyle = {
        backgroundImage: `url(${downloadApi}?attachmentId=${system.footerbackground})`,
        backgroundPosition: 'center center',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover'
      }
    }
    return { topWrapperStyle, scrollStyle, footerStyle }
  }

  render() {
    const { location, history, page } = this.props
    const { loading } = page
    const { menuList, pageId, disableShow, width, siderBarHidden } = this.state
    const { systemConfig } = this.props.login
    let { topWrapperStyle, scrollStyle, footerStyle } = this.setStyle()

    const antIcon = (
      <img
        src={require('assets/images/loading.gif')}
        style={{ width: '60px', height: '60px' }}
      />
    )
    return (
      <div className="yui_Wrapper" style={{ height: '100%' }}>
        {/* 头部公用组件 */}
        <EditTop
          data={menuList[0]}
          getThemeData={this.getThemeData}
          getPageData={this.getPageData}
        />
        {/* 主题浏览去掉侧边栏 */}
        {!disableShow && (
          <SiderBar type="editTheme" siderBarHidden={siderBarHidden} />
        )}
        <div className={classNames('yui_top_wrapper')} style={topWrapperStyle}>
          <Top />
          <Banner
            data={menuList}
            history={history}
            location={location}
            setTabs={this.setTabs}
            pageId={pageId}
          />
        </div>
        <Scrollbars
          style={scrollStyle}
          className={'yui_main_container_scrollbars'}
        >
          <div className={classNames('yui_main_container')}>
            <Spin spinning={loading} indicator={antIcon}>
              <Row
                className={classNames('yui_main_container_wrapper', {
                  yui_main_container_pdl: page.openSider
                })}
                style={{
                  minHeight:
                    scrollStyle.height - 120 > 680
                      ? scrollStyle.height - 120
                      : 680,
                  paddingTop: '5px'
                }}
              >
                <Col span={2} />
                <Col
                  span={20}
                  style={{
                    height: '100%',
                    minWidth: page.openSider ? 1400 : 1200,
                    margin: '0 auto'
                  }}
                  className={classNames({
                    yui_main_container_col_pdl: Number(width) < 1310
                  })}
                >
                  <NewPage pageType={'editTheme'} />
                </Col>
              </Row>
              <div
                style={footerStyle}
                className="yui_contain_footer"
                dangerouslySetInnerHTML={{
                  __html:
                    systemConfig &&
                    systemConfig.mgrFoot &&
                    JSON.parse(systemConfig.mgrFoot)[this.props.login.locale]
                      ? JSON.parse(systemConfig.mgrFoot)[
                          this.props.login.locale
                        ]
                      : `Copyright © 2014-2018 LIANYI TECHNOLOGY CO.,LTD. All Rights Reserved. 联奕科技有限公司`
                }}
              />
            </Spin>
          </div>
        </Scrollbars>
      </div>
    )
  }
}
