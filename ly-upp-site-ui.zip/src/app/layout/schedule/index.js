/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-12-17 15:55:48
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-19 17:59:23
 */
import React from 'react'
import { connect } from 'react-redux'
import { ScheduleManage } from 'ly-calendar-card'
@connect(state => {
  return { ...state }
})
export default class ScheduleList extends React.Component {
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      locale: 'zh_CN'
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.login.locale !== this.props.login.locale) {
      this.setState({ locale: nextProps.login.locale })
    }
  }

  componentDidMount() {
    this.setState({ locale: this.props.login.locale })
  }

  render() {
    const { locale } = this.state
    return <ScheduleManage language={locale} lang={locale} />
  }
}
