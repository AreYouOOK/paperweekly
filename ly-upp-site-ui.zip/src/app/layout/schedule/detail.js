/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-12-17 15:55:48
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2019-12-19 17:59:10
 */
import React from 'react'
import { connect } from 'react-redux'
import { ScheduleManageDetail } from 'ly-calendar-card'
@connect(state => {
  return { ...state }
})
export default class ScheduleDetail extends React.Component {
  static defaultProps = {}
  constructor(props) {
    super(props)
    this.state = {
      locale: 'zh_CN'
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.login.locale !== this.props.login.locale) {
      this.setState({ locale: nextProps.login.locale })
    }
  }

  componentDidMount() {
    this.setState({ locale: this.props.login.locale })
  }

  render() {
    const { locale } = this.state
    return <ScheduleManageDetail lang={locale} language={locale} />
  }
}
