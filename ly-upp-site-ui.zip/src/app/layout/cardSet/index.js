import React, { Component } from "react";
import { Tabs } from "antd";
import CardOut from "./cardOut"; // 卡片外观设置

const { TabPane } = Tabs;

import styles from "./index.less";

export default class CardSet extends Component {
    render() {
        return (
            <div>
                <div className={styles.box}>
                    <Tabs defaultActiveKey="out">
                        <TabPane tab="卡片外观设置" key="out">
                            <CardOut />
                        </TabPane>
                    </Tabs>
                </div>
            </div>
        );
    }
}
