// 字体
export const fontFamilyData = [
    {
        label: "宋体",
        value: "SimSun"
    },
    {
        label: "楷体",
        value: "KaiTi"
    },
    {
        label: "黑体",
        value: "SimHei"
    },
    {
        label: "微软雅黑",
        value: "Microsoft Yahei"
    }
];

// 字体大小
export const fontSizeData = [
    {
        label: "0.1em",
        value: "0.1em"
    },
    {
        label: "0.2em",
        value: "0.2em"
    },
    {
        label: "0.3em",
        value: "0.3em"
    },
    {
        label: "0.5em",
        value: "0.5em"
    },
    {
        label: "0.7em",
        value: "0.7em"
    },
    {
        label: "1em",
        value: "1em"
    },
    {
        label: "2em",
        value: "2em"
    }
];

// 行高
export const lineHeightData = [
    {
        label: "0.5em",
        value: "0.5em"
    },
    {
        label: "0.6em",
        value: "0.6em"
    },
    {
        label: "0.7em",
        value: "0.7em"
    },
    {
        label: "0.8em",
        value: "0.8em"
    },
    {
        label: "1em",
        value: "1em"
    },
    {
        label: "1.5em",
        value: "1.5em"
    },
    {
        label: "2em",
        value: "2em"
    }
];

// 字间距
export const letterSpacingData = [
    {
        label: "0.5em",
        value: "0.5em"
    },
    {
        label: "0.6em",
        value: "0.6em"
    },
    {
        label: "0.7em",
        value: "0.7em"
    },
    {
        label: "0.8em",
        value: "0.8em"
    },
    {
        label: "1em",
        value: "1em"
    },
    {
        label: "1.5em",
        value: "1.5em"
    },
    {
        label: "2em",
        value: "2em"
    }
];

// 突出显示
export const fontOtherData = [
    {
        label: "粗体",
        value: "bold" // font-weight
    },
    {
        label: "斜体",
        value: "italic" // font-style
    }
];

// 单位
export const unitData = [
    {
        label: "px",
        value: "px"
    },
    {
        label: "em",
        value: "em"
    },
    {
        label: "%",
        value: "%"
    }
];

// 边框样式
export const borderStyleData = [
    {
        label: "虚线",
        value: "dashed"
    },
    {
        label: "双横线",
        value: "double"
    },
    {
        label: "加点",
        value: "dotted"
    },
    {
        label: "惯例",
        value: "inherit"
    },
    {
        label: "隐藏",
        value: "hidden"
    },
    {
        label: "插页",
        value: "inset"
    },
    {
        label: "开始",
        value: "outset"
    },
    {
        label: "Ridge",
        value: "ridge"
    }
];
