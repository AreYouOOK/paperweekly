import React, { Component } from "react";
import { Form, Checkbox, Input, Select, Row, Col, Button } from "antd";
import { UnitInput, ColorBtn, ColorInput, CssEditor } from "components";
import { styleInject } from "utils/util";
import {
    fontFamilyData,
    fontSizeData,
    lineHeightData,
    letterSpacingData,
    fontOtherData,
    unitData,
    borderStyleData
} from "./data";

const { Option } = Select;

import styles from "./index.less";

@Form.create()
export default class CardOut extends Component {
    constructor(props) {
        super(props);
        this.state = {
            checked: false // 是否显示卡片外框
        };
    }

    // 提交
    handleSubmit = () => {
        this.props.form.validateFields((err, values) => {
            if (!err) {
                console.log("Received values of form: ", values);
                // 存在高级样式，尝试设置
                const myStyle =
                    values.myStyle ||
                    ".app-layout-cardSet-index-box-3fFTC {border-radius: 16px;}";
                styleInject(myStyle, "1");
            }
        });
    };

    // 切换是否显示卡片外框
    onChange = e => {
        this.setState({
            checked: e.target.checked
        });
    };

    // 检查是否是数字
    checkNumber = (rule, value, callback) => {
        if (value.number >= 0) {
            callback();
            return;
        }
        callback("必须是数字");
    };

    render() {
        const { getFieldDecorator } = this.props.form;
        const { checked } = this.state;

        const formItemLayout = {
            labelCol: {
                span: 6
            },
            wrapperCol: {
                span: 14
            }
        };

        const formItemLayout2 = {
            labelCol: {
                span: 2
            },
            wrapperCol: {
                span: 13
            }
        };

        return (
            <div className={styles.box}>
                <Form>
                    <div className={styles.item}>
                        <div className={styles.itemTitle}>标题</div>
                        <Form.Item {...formItemLayout2} label="标题名称">
                            <div className="fl">
                                {getFieldDecorator("name", {
                                    rules: [
                                        {
                                            required: true,
                                            message: "请输入标题"
                                        }
                                    ]
                                })(<Input placeholder="请输入标题" />)}
                            </div>
                            <div className="ml20 fl">
                                <Checkbox
                                    checked={checked}
                                    onChange={this.onChange}
                                >
                                    是否显示卡片外框
                                </Checkbox>
                            </div>
                        </Form.Item>
                    </div>
                    <div className={styles.item}>
                        <div className={styles.itemTitle}>字体</div>
                        <Row gutter={16}>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="字体">
                                    {getFieldDecorator("fontFamily")(
                                        <Select>
                                            {fontFamilyData.map(item => {
                                                return (
                                                    <Option
                                                        key={item.value}
                                                        value={item.value}
                                                    >
                                                        {item.label}
                                                    </Option>
                                                );
                                            })}
                                        </Select>
                                    )}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="大小">
                                    {getFieldDecorator("fontSize")(
                                        <Select>
                                            {fontSizeData.map(item => {
                                                return (
                                                    <Option
                                                        key={item.value}
                                                        value={item.value}
                                                    >
                                                        {item.label}
                                                    </Option>
                                                );
                                            })}
                                        </Select>
                                    )}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="行号">
                                    {getFieldDecorator("lineHeight")(
                                        <Select>
                                            {lineHeightData.map(item => {
                                                return (
                                                    <Option
                                                        key={item.value}
                                                        value={item.value}
                                                    >
                                                        {item.label}
                                                    </Option>
                                                );
                                            })}
                                        </Select>
                                    )}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="颜色">
                                    {getFieldDecorator("color", {
                                        initialValue: "#624dcd"
                                    })(<ColorBtn colorType="hex" />)}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="行号">
                                    {getFieldDecorator("letterSpacing")(
                                        <Select>
                                            {letterSpacingData.map(item => {
                                                return (
                                                    <Option
                                                        key={item.value}
                                                        value={item.value}
                                                    >
                                                        {item.label}
                                                    </Option>
                                                );
                                            })}
                                        </Select>
                                    )}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="突出显示">
                                    {getFieldDecorator("fontOther")(
                                        <Select>
                                            {fontOtherData.map(item => {
                                                return (
                                                    <Option
                                                        key={item.value}
                                                        value={item.value}
                                                    >
                                                        {item.label}
                                                    </Option>
                                                );
                                            })}
                                        </Select>
                                    )}
                                </Form.Item>
                            </Col>
                        </Row>
                    </div>
                    <div className={styles.item}>
                        <div className={styles.itemTitle}>边框样式</div>
                        <Row gutter={16}>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="描边宽度">
                                    {getFieldDecorator("borderWidth", {
                                        initialValue: { number: 0, unit: "px" },
                                        rules: [{ validator: this.checkNumber }]
                                    })(<UnitInput unitData={unitData} />)}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="描边样式">
                                    {getFieldDecorator("borderStyle")(
                                        <Select>
                                            {borderStyleData.map(item => {
                                                return (
                                                    <Option
                                                        key={item.value}
                                                        value={item.value}
                                                    >
                                                        {item.label}
                                                    </Option>
                                                );
                                            })}
                                        </Select>
                                    )}
                                </Form.Item>
                            </Col>
                        </Row>
                        <Row gutter={16}>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="描边颜色">
                                    {getFieldDecorator("borderColor", {
                                        initialValue: {
                                            a: 1,
                                            h: 356.87203791469193,
                                            l: 0.5470588235294118,
                                            s: 0.9134199134199136
                                        }
                                    })(<ColorBtn colorType="hsl" />)}
                                </Form.Item>
                            </Col>
                            <Col span={8}>
                                <Form.Item {...formItemLayout} label="填充颜色">
                                    {getFieldDecorator("backgroundColor", {
                                        initialValue: undefined
                                    })(<ColorInput />)}
                                </Form.Item>
                            </Col>
                        </Row>
                        <Row gutter={16}>
                            <Form.Item {...formItemLayout2} label="高级样式">
                                {getFieldDecorator("myStyle", {
                                    initialValue: ""
                                })(<CssEditor />)}
                            </Form.Item>
                        </Row>
                    </div>
                    <div className={styles.btnBox}>
                        <Button type="primary" onClick={this.handleSubmit}>
                            保存
                        </Button>
                        <Button className="ml20">恢复默认</Button>
                        <Button className="ml20">返回</Button>
                    </div>
                </Form>
            </div>
        );
    }
}
