/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-07-17 09:39:13
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-11-13 09:56:57
 */
import React from "react";
import classNames from "classnames";
import { Tabs, Icon, message } from "antd";
import styles from "./index.less";
import TabApp from "./tab/tabApp";
import TabCollect from "./tab/tabCollect";
import { connect } from "react-redux";
import { reqGetAppList, reqMyAppList } from "utils/api";
// import { openAppCenter } from "redux/actions/app";
import { setAppCenterCount, setMyCollectCount, setAppTypeList } from "redux/actions/app";
const { TabPane } = Tabs;

@connect(state => ({
  ...state
}))
export default class AppCenter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      activeKey: "collect"
    };
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.app.showAppCenter) {
      this.onChange("app");
    }
  }

  componentWillMount() {
    this.getAppList();
    this.getMyAppList();
  }

  // 获取应用中心应用数量
  getAppList = () => {
    const params = {
      pageNum: 1,
      pageSize: 999
    };
    reqGetAppList(params).then(res => {
      let { data, meta } = res.data;
      if (!meta.success) return message.error(meta.message);
      const appCount = data ? data.length : 0;
      this.props.dispatch(setAppCenterCount(appCount));
    });
  };

  // 获取我的收藏应用数量
  getMyAppList = () => {
    const params = {
      isPersonal: "0"
    };
    reqMyAppList(params).then(res => {
      let { data, meta } = res.data;
      if (!meta.success) return message.error(meta.message);
      const myAppCount = data ? data.length : 0;
      this.props.dispatch(setMyCollectCount(myAppCount));
    });
  };

  onChange = activeKey => {
    this.setState({ activeKey }, () => {
      if (activeKey == "app") {
        if (this.appTab) {
          this.appTab.getAppList();
        }
      }
      if (activeKey == "collect") {
        this.collectTab.getMyAppList();
      }
      this.props.dispatch(setAppTypeList([]))
    });
  };

  render() {
    const { type, login, onClose, hasIcon, app } = this.props;
    const { activeKey } = this.state;
    const { appCenterCount, myCollectCount } = app;
    return (
      <div
        className={classNames(styles.box, "appCenter", {
          [styles.boxInner]: type == "inner" // 内嵌入其他页面
        })}
      >
        {hasIcon ? <Icon type="close" onClick={onClose} /> : null}

        <div className={styles.card}>
          <Tabs activeKey={activeKey} onChange={this.onChange}>
            <TabPane
              tab={
                window.locale[login.locale].applicationCenter +
                " " +
                appCenterCount
              }
              key="app"
            >
              <TabApp
                getCount={this.getMyAppList}
                onRef={ref => (this.appTab = ref)}
              />
            </TabPane>
            <TabPane
              tab={
                window.locale[login.locale].myFavorite + " " + myCollectCount
              }
              key="collect"
            >
              <TabCollect
                getCount={this.getMyAppList}
                onRef={ref => (this.collectTab = ref)}
              />
            </TabPane>
          </Tabs>
        </div>
      </div>
    );
  }
}
