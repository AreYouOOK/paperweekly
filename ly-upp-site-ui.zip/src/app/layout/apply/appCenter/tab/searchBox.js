import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { AutoComplete, Input } from 'antd';
import { connect } from 'react-redux';
import { debounce } from 'utils/util';
const { Option, OptGroup } = AutoComplete;
const { Search } = Input;

@connect(state => {
  return { ...state };
})
export default class SearchBox extends Component {
  static defaultProps = {
    handleSearch: () => {},
    searchHistory: []
  };

  static propTypes = {
    handleSearch: PropTypes.func,
    searchHistory: PropTypes.array
  };

  renderTitle = title => {
    return <span>{title}</span>;
  };

  render() {
    const { searchHistory, handleSearch, value, ...restProps } = this.props;
    let { login } = this.props;
    const getOptions = () => {
      return searchHistory.map(group => (
        <OptGroup key={group.title} label={this.renderTitle(group.title)}>
          {group.children.map(opt => (
            <Option key={opt.title} value={opt.title}>
              {opt.title}
              {/* <span className="certain-search-item-count">
								{opt.count} people
							</span> */}
            </Option>
          ))}
        </OptGroup>
      ));
    };

    return (
      <AutoComplete
        dropdownMatchSelectWidth={false}
        // dataSource={getOptions()}
        placeholder={window.locale[login.locale].siderBarCardSearchPlaceholder}
        optionLabelProp="value"
        onChange={debounce(value => handleSearch(value.trim()))}
        {...restProps}
      >
        <Search
          value={value}
          // 改成了即时搜索
          // onChange={e => handleSearch(e.currentTarget.value)}
          // onSearch={value => handleSearch(value)}
        />
      </AutoComplete>
    );
  }
}
