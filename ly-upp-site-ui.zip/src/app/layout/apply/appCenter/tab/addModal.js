/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-06-26 11:09:06
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-02-27 18:47:53
 */
import React, { Component } from 'react'
import { Modal, Form, Input, Checkbox } from 'antd'
import { handleImageUrl } from 'utils/util'
import styles from '../index.less'
import UploadModal from './uploadModal.js'
import ChooseLanguage from './chooseLanguage.js'
import { connect } from 'react-redux'
import classNames from 'classnames'
import _ from 'lodash'

const { TextArea } = Input
function initState() {
  return {
    showUploadModal: false,
    data: {},
    loading: false,
    appIcon: '',
    language: 'zh_CN', // 服务名称的国际化
    language1: 'zh_CN', // 服务描述的国际化
    appName: '',
    desc: '',
    locale: {}
  }
}

@connect(state => ({
  ...state
}))
@Form.create()
export default class AddModal extends Component {
  constructor(props) {
    super(props)
    this.state = initState()
  }

  componentWillMount() {
    const { locale } = this.props.login
    this.setState({ language: locale, language1: locale })
  }

  componentWillReceiveProps(nextProps) {
    // if (nextProps.data.appIcon !== this.props.data.appIcon) {
    //     this.setState({ appIcon: nextProps.data.appIcon })
    // }
    if (!_.isEqual(nextProps.data, this.props.data)) {
      const { locale, appName, appIcon, remarks } = nextProps.data
      let newLocale = locale ? JSON.parse(locale) : {}
      this.setState({
        locale: newLocale,
        appName,
        desc: remarks,
        appIcon
      })
    }
    // this.props.form.setFieldsValue({ appIcon: nextProps.data.appIcon })
  }

  handleOk = () => {
    const { handleOk } = this.props
    const { appName, desc, locale } = this.state
    this.props.form.validateFields(async (err, values) => {
      if (!err) {
        // const { file } = this.state
        // delete values.icon
        // values.appIcon = appIcon
        // console.log("Received values of form: ", values)
        let data = { ...values }
        delete data.appName
        delete data.desc
        data.appName = appName && appName.trim()
        data.desc = desc
        data.locale = (locale && JSON.stringify(locale)) || {}
        handleOk && handleOk(data)
        // await this.setState(() => initState())
        // await this.props.form.resetFields()
      }
    })
  }

  handleCancel = async () => {
    const { handleCancel } = this.props
    handleCancel && handleCancel()
    // await this.setState(() => initState())
    // await this.props.form.resetFields()
  }

  handleUpload = appIcon => {
    this.props.form.setFieldsValue({ appIcon })
    this.setState({ appIcon, showUploadModal: false })
  }

  // 处理国际化
  addJson = lang => e => {
    const { locale } = this.state
    const language = this.state[lang]
    const prop = e.target.id
    const value = e.target.value
    if (language == 'zh_CN') {
      this.setState({ [prop]: value })
    }
    let json = locale
    if (!json[language]) {
      json[language] = {}
    }
    json[language][prop] = value || ''
    this.setState({ locale: json })
  }

  // 切换语言
  handleLanguage = (prop, lang) => language => {
    const { locale } = this.state
    let json = locale
    if (language == 'zh_CN') {
      this.props.form.setFieldsValue({ [prop]: this.state[prop] })
    }
    if (!json[language]) {
      json[language] = {}
    }
    this.props.form.setFieldsValue({
      [prop]: json[language][prop] ? json[language][prop] : ''
    })
    this.setState({ locale: json, [lang]: language })
  }

  render() {
    const {
      login,
      visible,
      loading,
      handleOk,
      form,
      data,
      ...restProps
    } = this.props
    const { localeJson } = this.props.login
    const { getFieldDecorator } = form
    const { appIcon, showUploadModal, language, language1, locale } = this.state
    const appName =
      locale[this.props.login.locale] && locale[this.props.login.locale].appName
    const desc =
      locale[this.props.login.locale] && locale[this.props.login.locale].desc

    const formItemLayout = {
      labelCol: {
        span: 6
      },
      wrapperCol: {
        span: 16
      }
    }

    return (
      <Modal
        visible={visible}
        destroyOnClose={true}
        wrapClassName={styles.addModalBox}
        confirmLoading={loading}
        onOk={this.handleOk}
        onCancel={this.handleCancel}
        {...restProps}
      >
        <Form {...formItemLayout}>
          <Form.Item
            label={localeJson.serverName}
            style={{ marginBottom: 10 }}
            extra={
              <ChooseLanguage
                language={language}
                onChange={this.handleLanguage('appName', 'language')}
              />
            }
          >
            {getFieldDecorator('appName', {
              initialValue: appName,
              rules: [
                // {
                //   // required: true,
                //   // (locale[language] && locale[language].appName) ||
                //   required: !(
                //     (locale[this.props.login.locale] &&
                //       locale[this.props.login.locale].appName) ||
                //     (locale.zh_CN && locale.zh_CN.appName)
                //   ),
                //   message: localeJson.theme_description_required
                // },
                {
                  validator: (rule, value, callback) => {
                    if (
                      !(
                        (locale[this.props.login.locale] &&
                          locale[this.props.login.locale].appName) ||
                        (locale.zh_CN && locale.zh_CN.appName)
                      )
                    ) {
                      // 既不是当前系统语言，也不是中文
                      callback(localeJson.theme_description_required)
                    } else {
                      callback()
                    }
                  }
                }
              ]
              // getValueFromEvent: e => {
              //   return e.target.value.trim()
              // }
            })(
              <Input
                maxLength={25}
                placeholder={localeJson.app_new_server_message}
                onChange={this.addJson('language')}
              />
            )}
          </Form.Item>
          <Form.Item label={localeJson.serverlink}>
            {getFieldDecorator('appLink', {
              initialValue: data.applink,
              rules: [
                {
                  required: true,
                  message: localeJson.app_new_server_link_message
                },
                {
                  type: 'url',
                  message: localeJson.rules_url
                }
              ]
            })(<Input placeholder={localeJson.app_new_server_message} />)}
          </Form.Item>
          <Form.Item
            label={localeJson.serverRemarks}
            style={{ marginBottom: 10 }}
            extra={
              <ChooseLanguage
                language={language1}
                onChange={this.handleLanguage('desc', 'language1')}
              />
            }
          >
            {getFieldDecorator('desc', {
              initialValue: desc
            })(
              <TextArea
                maxLength={50}
                autosize={{ minRows: 4, maxRows: 4 }}
                placeholder={localeJson.app_new_server_message}
                onChange={this.addJson('language1')}
              />
            )}
          </Form.Item>
          <Form.Item label={localeJson.serverIcon}>
            {getFieldDecorator('appIcon', {
              initialValue: appIcon,
              rules: [
                {
                  required: true,
                  message: localeJson.app_new_server_icon_message
                }
              ]
            })(
              appIcon ? (
                <div
                  className={styles.iconBox}
                  onClick={() => this.setState({ showUploadModal: true })}
                >
                  <img src={handleImageUrl(appIcon)} />
                </div>
              ) : (
                <div
                  className={classNames(styles.uploadBox, 'uploadBox')}
                  onClick={() => this.setState({ showUploadModal: true })}
                >
                  +
                </div>
              )
            )}
          </Form.Item>
          <Form.Item>
            {getFieldDecorator('isOpen', {
              valuePropName: 'checked',
              initialValue: ~~data.isOpen
            })(
              <Checkbox style={{ marginLeft: 118 }}>
                {localeJson.openNewPage}
              </Checkbox>
            )}
          </Form.Item>
        </Form>
        <UploadModal
          visible={showUploadModal}
          onOk={this.handleUpload}
          onCancel={() => this.setState({ showUploadModal: false })}
        />
      </Modal>
    )
  }
}
