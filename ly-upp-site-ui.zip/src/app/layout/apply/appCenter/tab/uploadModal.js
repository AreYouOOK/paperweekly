/*
 * @Description: file description
 * @Author: xuqiuting
 * @Date: 2019-07-11 13:58:25
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-03 18:03:52
 */
import React from 'react'
import { Icon, Button, Modal, Upload, message } from 'antd'
import { reqAppIconList, uploadImg } from 'utils/api'
import { handleImageUrl } from 'utils/util'
import { connect } from 'react-redux'

const type = 2

@connect(state => ({
  ...state
}))
export default class UploadModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      appIcon: '',
      imageList: []
    }
    this.localeJson = this.props.login.localeJson
  }

  componentWillReceiveProps(nextProps) {
    this.setState({
      appIcon: nextProps.appIcon,
      visible: nextProps.visible
    })
  }

  componentWillMount() {
    this.setState({
      appIcon: this.props.appIcon
    })
    this.queryImagelist()
  }

  queryImagelist = () => {
    const params = {
      type: this.props.type,
      pageNum: 1,
      pageSize: 999,
      type: 2
    }
    reqAppIconList(params).then(res => {
      const { meta, data } = res.data
      if (!meta.success)
        return message.error(this.localeJson.app_icon_list_error)
      this.setState({
        imageList: data.list
      })
    })
  }

  onOk = e => {
    this.props.onOk && this.props.onOk(this.state.appIcon)
  }

  onChange = info => {
    // console.log(info)
    if (!info.file.response) return
    const { success } = info.file.response.meta
    if (success) {
      message.success(this.localeJson.app_icon_upload_success)
      this.queryImagelist()
    } else {
      message.error(this.localeJson.app_icon_upload_error)
    }
  }

  beforeUpload = file => {
    // this.setState({ file })
    // const isIPGPNG = file.type === 'image/jpeg' || file.type === 'image/png'
    const imgList = [
      // 'image/tiff',
      // 'image/pjp',
      // 'image/pjpeg',
      // 'image/jfif',
      'image/tif',
      'image/gif',
      // 'image/svg',
      'image/bmp',
      'image/png',
      'image/jpeg',
      // 'image/svgz',
      'image/jpg'
      // 'image/webp',
      // 'image/ico',
      // 'image/xbm',
      // 'image/dib'
    ]
    const isImg = imgList.includes(file.type)
    if (!isImg) {
      message.error(this.localeJson.app_icon_image_type_error)
    }
    const isLt2M = file.size / 1024 / 1024 < 2
    if (!isLt2M) {
      message.error(this.localeJson.app_icon_image_size_error)
    }
    // this.setState({ file })
    return isLt2M && isImg
  }

  chooseIcon = appIcon => e => {
    // console.log(appIcon)
    this.setState({ appIcon })
  }

  render() {
    const { imageList, appIcon } = this.state
    const { visible, onCancel } = this.props

    const props = {
      className: 'upload-list-inline',
      action: uploadImg,
      multiple: false,
      showUploadList: false,
      onChange: this.onChange,
      accept: 'image/*',
      data: { type },
      beforeUpload: this.beforeUpload,
      headers: {
        loginUserId: this.props.login.data.userId,
        loginUserOrgId: this.props.login.data.orgId
      }
    }

    return (
      <Modal
        width={740}
        centered
        title={this.localeJson.app_icon_select}
        visible={visible}
        destroyOnClose={true}
        onOk={this.onOk}
        onCancel={onCancel}
      >
        <div
          style={{
            background: 'white',
            borderRadius: '4px',
            padding: '0px 10px'
          }}
        >
          <Upload {...props}>
            <Button>
              <Icon type="plus" />
              {this.localeJson.app_icon_upload}
            </Button>
          </Upload>
          <div className="imageListBox">
            {imageList.map((item, index) => {
              return (
                <div
                  key={index}
                  className="imageBox"
                  onClick={this.chooseIcon(item.id)}
                >
                  <img
                    className={item.id == appIcon ? 'active' : ''}
                    src={handleImageUrl(item.id)}
                  ></img>
                </div>
              )
            })}
          </div>
        </div>
      </Modal>
    )
  }
}
