/*
 * @Description: file description
 * @Author: xuqiuting
 * @Date: 2019-07-17 09:39:13
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-11-01 14:30:49
 */
import React, { Component } from "react";
import classNames from "classnames";
import { Icon, Tooltip, message } from "antd";
import styles from "../index.less";
import { handleImageUrl } from "utils/util";
import { connect } from "react-redux";
import { reqAppLog } from "utils/api";
@connect(state => ({
  ...state
}))
export default class Item extends Component {
  // 打开应用页面
  linkToAppPage = data => {
    const { appId, appLink, isOpen } = data;
    reqAppLog({ appId }).then(res => {
      const { meta } = res.data;
      if (!meta.success) return message.error(meta.message);
    });
    setTimeout(() => {
      if (~~isOpen) {
        window.open(appLink, "_blank").location;
      } else {
        window.open(appLink, "_self");
      }
    }, 300);
  };

  render() {
    const {
      login,
      children,
      className,
      data,
      type = "",
      style = {},
      isRecommend,
      isNew,
      hasCollect,
      onCollect,
      ...rest
    } = this.props;
    const appName =
      data.locale[login.locale] && data.locale[login.locale].appName
        ? data.locale[login.locale].appName
        : (data.locale.zh_CN && data.locale.zh_CN.appName) ||
          (data.locale.en_US && data.locale.en_US.appName);
    const desc =
      data.locale[login.locale] && data.locale[login.locale].desc
        ? data.locale[login.locale].desc
        : (data.locale.zh_CN && data.locale.zh_CN.desc) ||
          (data.locale.en_US && data.locale.en_US.desc) ||
          window.locale[login.locale].noDesc;

    return (
      <div
        className={classNames(className, "appListItem", styles.appListItem, {
          [styles.appListItemMove]: type === "move"
        })}
        style={style}
        {...rest}
      >
        <div className={styles.appListCon}>
          <div className={styles.appListConL}>
            {/* <div className={classNames(styles.appListConImg, !data.appIcon && styles.appListNoConImg)}> */}
            <div className={styles.appListConImg}>
              {/* <img src={handleImageUrl(data.appIcon)} alt=""/> */}
              <img
                src={
                  data.appIcon
                    ? handleImageUrl(data.appIcon)
                    : require("assets/images/defaultAppIcon.png")
                }
                onClick={e => this.linkToAppPage(data)}
                onError={event => {
                  const img = event.nativeEvent.srcElement;
                  img.src = require("assets/images/defaultAppIcon.png");
                  img.onerror = null;
                }}
              />
              {data.isRecommend == "1" && (
                <sup className={styles.status}>
                  {window.locale[login.locale].reco}
                </sup>
              )}
              {data.isNew == "1" && (
                <sup className={styles.status}>
                  {window.locale[login.locale].new}
                </sup>
              )}
              {isRecommend == "1" && (
                <sup className={styles.status}>
                  {window.locale[login.locale].reco}
                </sup>
              )}
              {isNew == "1" && (
                <sup className={styles.status}>
                  {window.locale[login.locale].new}
                </sup>
              )}
            </div>
          </div>
          <div className={styles.appListConR}>
            <Tooltip title={appName}>
              <div className={styles.appListConTitle}>{appName}</div>
            </Tooltip>
            <Tooltip title={desc}>
              <div
                className={classNames(styles.appListConInfo, "textOverflowTwo")}
              >
                {desc}
              </div>
            </Tooltip>
          </div>
        </div>
        <div className={styles.appListBtn}>{children}</div>
        {hasCollect && (
          <div className={styles.appListIcon} onClick={onCollect}>
            <Icon
              type="heart"
              style={{ color: "#ccc", fontSize: 21 }}
              theme={data.isStore == "1" && "filled"}
              className={data.isStore == "1" && styles.redHeart}
            />
          </div>
        )}
      </div>
    );
  }
}
