/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-07-16 14:38:47
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-16 10:40:57
 */
import React from 'react'
import { connect } from 'react-redux'
import { Button, Icon, Modal, Tooltip, message, Checkbox } from 'antd'
import classNames from 'classnames'
import {
  SortableContainer,
  SortableElement,
  SortableHandle
} from 'react-sortable-hoc'
import { arrayMove } from 'utils/util'
import {
  reqMyAppList,
  reqAddApp,
  reqCollectApp,
  reqAppDetail,
  reqEditApp,
  reqDeleteApp,
  reqAppToTopOrBottom,
  // reqAppToTop,
  // reqAppToBottom,
  reqDragApp
} from 'utils/api'
import SearchBox from './searchBox' // 搜索
import AddModal from './addModal'
import AppItem from './appItem'
import { searchHistory } from '../data'
import styles from '../index.less'
import { changeTopFive } from 'redux/actions/app'

const confirm = Modal.confirm

@connect(state => ({
  ...state
}))
export default class TabCollect extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isEdit: false,
      isPersonal: '0',
      appName: undefined,
      isDrag: true, // 是否可拖拽排序
      searchHistory, // 搜索历史
      addVisible: false, // 弹窗
      addLoading: false, // 弹窗-loading
      allAppData: [], // 所有应用数据列表
      appData: [], // 应用数据列表 可能是全部应用数据也可能是自建服务数据，根据当前是否勾选了自建服务
      appDetail: {} // 应用详情
    }
  }

  componentWillMount() {
    this.props.onRef(this)
  }

  componentDidMount() {
    this.getMyAppList()
  }

  // 搜索
  onSearch = appName => {
    this.setState({ appName }, () => {
      this.getMyAppList()
    })
  }

  // checkbox是否自建服务
  onCheckBoxChange = e => {
    const isPersonal = e.target.checked ? '1' : '0'
    this.setState({ isPersonal }, () => {
      this.getMyAppList()
    })
  }

  // 弹窗确认
  handleOk = form => {
    const { localeJson } = this.props.login
    const { isEdit, appDetail } = this.state
    this.setState(
      {
        addLoading: true
      },
      () => {
        const { isOpen, desc, ...rest } = form
        const params = {
          isOpen: ~~isOpen,
          desc: desc || undefined,
          ...rest
        }
        if (isEdit) {
          params.appId = appDetail.appId
          reqEditApp(params).then(res => {
            const { meta } = res.data
            if (!meta.success) {
              this.setState({ addLoading: false })
              return message.error(meta.message)
            }
            message.success(localeJson.app_edit_success)
            this.setState(
              {
                isEdit: false,
                addVisible: false,
                addLoading: false,
                appDetail: {}
              },
              () => {
                this.getMyAppList()
              }
            )
          })
        } else {
          reqAddApp(params).then(res => {
            const { meta } = res.data
            if (!meta.success) {
              this.setState({ addLoading: false })
              return message.error(meta.message)
            }
            message.success(localeJson.app_add_success)
            this.setState(
              {
                isEdit: false,
                addVisible: false,
                addLoading: false,
                appDetail: {}
              },
              () => {
                this.getMyAppList()
                this.props.getCount && this.props.getCount()
              }
            )
          })
        }
      }
    )
  }

  // 打开弹窗
  showModal = index => {
    if (index || index === 0) {
      const { appId } = this.state.appData[index]
      if (appId) {
        reqAppDetail(appId).then(res => {
          const { data, meta } = res.data
          if (!meta.success) return message.error(meta.message)
          this.setState({
            isEdit: true,
            appDetail: data
          })
        })
      }
    }
    this.setState({
      addVisible: true
    })
  }

  // 关闭弹窗
  handleCancel = () => {
    this.setState({
      addVisible: false,
      isEdit: false,
      appDetail: {}
    })
  }

  onSortStart = ({ node, index, collection }) => {
    // if (document.all) {
    //     document.onselectstart = function() {
    //         return false;
    //     }; //for ie
    // } else {
    //     document.onmousedown = function() {
    //         return false;
    //     };
    //     document.onmouseup = function() {
    //         return true;
    //     };
    // }
    // document.onselectstart = new Function("event.returnValue=false;");
    //劫持开始选择事件和（或）鼠标按下、抬起事件。
    // console.log('开始拖拽')
  }

  // 拖拽排序 oldIndex、newIndex为拖拽起始位置和终点位置的appId
  onSortEnd = ({ oldIndex, newIndex, type }) => {
    if (oldIndex === newIndex) return
    const prevAppData = this.state.appData
    const { allAppData } = this.state
    const { localeJson } = this.props.login
    this.setState(
      { appData: arrayMove(prevAppData, oldIndex, newIndex) },
      () => {
        // 获取当前拖拽起始位置和终点位置的在appId
        const beginId = prevAppData[oldIndex].appId
        const endId = prevAppData[newIndex].appId
        // 获取当前拖拽起始位置和终点位置的在allAppData的index
        const beginIndex = allAppData.findIndex(v => v.appId === beginId)
        const endIndex = allAppData.findIndex(v => v.appId === endId)
        // 更新allAppData， 生成后台需要的字段
        const len = allAppData.length
        let arr = arrayMove(allAppData, beginIndex, endIndex).map((v, i) => {
          return {
            appName: v.appName,
            appId: v.appId,
            isBottom: '0',
            isTop: '0',
            order: len - i,
            userId: v.userId
          }
        })
        reqDragApp(arr).then(res => {
          const { meta } = res.data
          if (!meta.success) {
            this.setState({ appData: prevAppData })
            return message.error(meta.message)
          }
          if (type === 'up') {
            message.success(localeJson.app_to_prev_success)
          } else if (type === 'down') {
            message.success(localeJson.app_to_next_success)
          } else {
            message.success(localeJson.app_drap_success)
          }
          this.getMyAppList()
        })
      }
    )
  }

  // 手动排序-点击按钮
  manualMove = (index, type) => {
    const { localeJson } = this.props.login
    const prevAppData = this.state.appData
    const { appId, orderId, userId, storeTime } = prevAppData[index]
    let params = {
      appId,
      isBottom: '0', // 该字段已无意义，保留写死传0
      isTop: '0', // 该字段已无意义，保留写死传0,
      orderId,
      userId,
      storeTime
    }
    const len = prevAppData.length
    // 向上移动
    if (type === 'up') {
      // 排序已为最前
      if (index === 0) return message.warning(localeJson.app_top_up_tip)
      if (index > 0) {
        // const oldIndex = prevAppData[index].appId;
        // const newIndex = prevAppData[index - 1].appId;
        // this.onSortEnd({ oldIndex, newIndex });
        this.onSortEnd({ oldIndex: index, newIndex: index - 1, type: 'up' })
      }
    }
    // 向下移动
    if (type === 'down') {
      // 排序已为最后
      if (index === len - 1)
        return message.warning(localeJson.app_bottom_down_tip)
      if (index < len - 1) {
        // const oldIndex = prevAppData[index].appId;
        // const newIndex = prevAppData[index + 1].appId;
        // this.onSortEnd({ oldIndex, newIndex });
        this.onSortEnd({ oldIndex: index, newIndex: index + 1, type: 'down' })
      }
    }
    // 置顶
    if (type === 'top') {
      params.operate = '1'
      reqAppToTopOrBottom(params).then(res => {
        const { meta } = res.data
        if (!meta.success) return message.error(meta.message)
        message.success(localeJson.app_to_top_success)
        this.getMyAppList()
      })
    }
    // 置底
    if (type === 'bottom') {
      params.operate = '0'
      reqAppToTopOrBottom(params).then(res => {
        const { meta } = res.data
        if (!meta.success) return message.error(meta.message)
        message.success(localeJson.app_to_bottom_success)
        this.getMyAppList()
      })
    }
  }

  // 删除
  deleteApp = index => {
    const { localeJson } = this.props.login
    // const { appData } = this.state;
    // appData.splice(index, 1);
    // this.setState({
    //     appData: [...appData]
    // });
    const {
      appId,
      isBottom,
      isStore,
      isTop,
      orderId,
      userId
    } = this.state.appData[index]
    const params = { appId, isBottom, isStore, isTop, orderId, userId }
    reqDeleteApp(params).then(res => {
      const { meta } = res.data
      if (!meta.success) return message.error(meta.message)
      message.success(localeJson.app_delete_success)
      this.getMyAppList()
      this.props.getCount && this.props.getCount()
    })
  }

  // 删除确认
  onDelete = index => {
    const { localeJson } = this.props.login
    confirm({
      title: localeJson.app_delete_tip,
      okType: 'danger',
      onOk: () => {
        this.deleteApp(index)
      },
      onCancel: () => {}
    })
  }

  // 取消收藏
  onCollect = item => {
    const { localeJson } = this.props.login
    const { appId, isBottom, isTop, orderId, userId } = item
    const params = {
      appId,
      userId,
      isBottom,
      isStore: '1',
      isTop,
      orderId
    }
    reqCollectApp(params).then(res => {
      const { meta } = res.data
      if (!meta.success) return message.error(meta.message)
      message.success(localeJson.app_cancel_collect_success)
      this.getMyAppList()
      this.props.getCount && this.props.getCount()
    })
  }

  // 获取我的收藏列表
  getMyAppList = () => {
    const { isPersonal, appName } = this.state
    const params = {
      appName,
      isPersonal: '0'
    }
    // 为解决排序存在的问题，通过获取所有服务列表筛选自建服务，不通过传isPersonal为1获取自建服务列表
    reqMyAppList(params).then(res => {
      let { data, meta } = res.data
      if (!meta.success) return message.error(meta.message)
      this.props.dispatch(changeTopFive(true)) // 通知左侧收藏栏top5已更新
      data = data.map(item => {
        return {
          ...item,
          locale: item.locale ? JSON.parse(item.locale) : {}
        }
      })
      this.setState({ allAppData: data })

      if (~~isPersonal) {
        data = data.filter(item => item.isPersonal === '1')
      }
      this.setState({ appData: data })
    })
  }

  render() {
    const {
      isDrag,
      // searchHistory,
      addVisible,
      addLoading,
      appData,
      appDetail
    } = this.state
    const { localeJson } = this.props.login
    // 可拖动手柄
    const DragHandle = SortableHandle(({}) => {
      return (
        <Icon
          className={classNames(styles.dragIcon, 'dragIcon')}
          title={localeJson.dragSort}
          type="menu"
        />
      )
    })

    // 可拖动子项
    const SortableItem = SortableElement(({ value, sortIndex }) => {
      return (
        <AppItem
          data={value}
          type="move"
          onMouseOver={e => {
            let dom = e.currentTarget.getElementsByClassName('appBtnCollect')[0]
            dom ? (dom.style.display = 'inline-block') : null
          }}
          onMouseLeave={e => {
            let dom = e.currentTarget.getElementsByClassName('appBtnCollect')[0]
            dom ? (dom.style.display = 'none') : null
          }}
        >
          <div
            className={classNames('appBtnCollect')}
            style={{ display: 'none' }}
          >
            <Tooltip title={localeJson.toTop}>
              <Icon
                type="vertical-align-top"
                // className={value.isTop == "1" ? "active" : ""}
                onClick={() => this.manualMove(sortIndex, 'top')}
              />
            </Tooltip>
            <Tooltip title={localeJson.toBottom}>
              <Icon
                type="vertical-align-bottom"
                // className={value.isBottom == "1" ? "active" : ""}
                onClick={() => this.manualMove(sortIndex, 'bottom')}
              />
            </Tooltip>
            <Tooltip title={localeJson.toPrev}>
              <Icon
                type="arrow-up"
                onClick={() => this.manualMove(sortIndex, 'up')}
              />
            </Tooltip>
            <Tooltip title={localeJson.toNext}>
              <Icon
                type="arrow-down"
                onClick={() => this.manualMove(sortIndex, 'down')}
              />
            </Tooltip>
            {value.isPersonal == '1' ? (
              <React.Fragment>
                <Tooltip title={localeJson.edit}>
                  <Icon type="form" onClick={() => this.showModal(sortIndex)} />
                </Tooltip>
                <Tooltip title={localeJson.delete}>
                  <Icon
                    type="delete"
                    onClick={() => this.onDelete(sortIndex)}
                  />
                </Tooltip>
              </React.Fragment>
            ) : (
              <Tooltip title={localeJson.cancelCollect}>
                <Icon
                  type="heart"
                  theme="filled"
                  className={styles.redHeart}
                  onClick={() => this.onCollect(value)}
                />
              </Tooltip>
            )}
          </div>
          {/* 拖拽按钮 */}
          {isDrag ? <DragHandle value={value} /> : null}
        </AppItem>
      )
    })

    // 可拖动列表
    const SortableList = SortableContainer(({ items }) => {
      return (
        <div>
          {items.map((value, index) => {
            return (
              <SortableItem
                key={`item-${index}`}
                index={index}
                sortIndex={index}
                value={value}
              />
            )
          })}
        </div>
      )
    })

    return (
      <div className={styles.tabcollect}>
        {/* 搜索 */}
        <div>
          <SearchBox
            value={this.state.appName}
            handleSearch={this.onSearch}
            // searchHistory={searchHistory}
          />
          <Button
            className="ml20 borderRadius8"
            onClick={() => this.showModal()}
          >
            <Icon type="plus" style={{ color: '#ccc' }} />
            {localeJson.addCustomService}
          </Button>
          <div className={styles.list}>
            <div className={styles.checkbox}>
              <Checkbox onChange={this.onCheckBoxChange}>
                {localeJson.buildService}
              </Checkbox>
            </div>
            <div className={styles.appListTip}>
              {localeJson.defaultList}
              <span className={styles.sub}>{localeJson.defaultListdrag}</span>
            </div>
            <SortableList
              axis="xy"
              helperClass={classNames(styles.cardDraging, 'cardDraging')}
              useDragHandle
              useWindowAsScrollContainer
              items={appData}
              onSortStart={this.onSortStart}
              onSortEnd={this.onSortEnd}
            />
            {!appData.length && (
              <div style={{ textAlign: 'center', paddingTop: 80 }}>
                <img src={require('assets/images/absent.png')} alt="" />
                <p>{localeJson.nodata}</p>
              </div>
            )}
          </div>
          {/* 添加 */}
          {addVisible && (
            <AddModal
              visible={addVisible}
              loading={addLoading}
              data={appDetail}
              handleOk={this.handleOk}
              handleCancel={this.handleCancel}
            />
          )}
        </div>
      </div>
    )
  }
}
