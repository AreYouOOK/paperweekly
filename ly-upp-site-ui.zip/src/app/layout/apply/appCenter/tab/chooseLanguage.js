/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-07-16 16:15:18
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-07-16 16:15:18
 */
import React from 'react';
import { message, Tooltip } from 'antd';
import { reqLanguage } from 'utils/api';
import { connect } from 'react-redux';
@connect(state => ({
  ...state
}))
export default class ChooseLanguage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      language: 'zh_CN',
      languageList: []
    };
  }

  componentDidMount() {
    this.setState({ language: this.props.login.locale });
    reqLanguage().then(res => {
      const { meta, data } = res.data;
      const { localeJson } = this.props.login;
      if (!meta.success) return message.error(localeJson.app_language_error);
      let languageList = [];
      Object.keys(data).map(key => {
        languageList.push({
          key,
          name: data[key]
        });
      });
      this.setState({ languageList });
    });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.language !== this.props.language) {
      this.setState({ language: nextProps.language });
    }
  }

  handleLanguage = language => {
    this.setState({ language }, () => {
      this.props.onChange && this.props.onChange(language);
    });
  };

  render() {
    const { localeJson } = this.props.login;
    const { language, languageList } = this.state;
    return (
      <div>
        {languageList.map(item => {
          const title =
            item.key == 'en_US'
              ? localeJson.language_en_US
              : localeJson.language_zh_CN;
          return (
            <Tooltip placement="bottom" title={title} key={item.key}>
              <div
                className={'imgdiv'}
                onClick={() => this.handleLanguage(item.key)}
              >
                <img src={require(`assets/images/language/${item.key}.png`)} />
                {language == item.key && <div className={'circle'}></div>}
              </div>
            </Tooltip>
          );
        })}
      </div>
    );
  }
}
