/*
 * @Description: file description
 * @Author: chenzezhen
 * @Date: 2019-07-17 09:39:13
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-03-05 10:25:09
 */
import React from 'react'
import classNames from 'classnames'
import { Icon, Checkbox, message } from 'antd'
import styles from '../index.less'
import SearchBox from './searchBox' // 搜索
import AppItem from './appItem'
import { reqGetAppList, reqCollectApp, reqAppFilterList } from 'utils/api'
import { searchHistory, checkData } from '../data' // /appManageList
import { connect } from 'react-redux'
import { changeTopFive } from 'redux/actions/app'
import _ from 'lodash'
@connect(state => ({
  ...state
}))
export default class TabApp extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      searchHistory,
      checkData, // 多选
      checkActive: [], // 多选-激活
      appName: undefined,
      isRecommend: '0',
      isNew: '0',
      appData: [], // 应用数据列表
      selectList: [], // 标签类型列表
      typeList: [], // 应用类型列表
      selectLabelList: [], // 选择的标签列表
      type: undefined, // 0为应用类型，1为标签
      appType: [] // 多选的应用类型列表
    }
  }

  componentWillMount() {
    this.getAppList()
    this.getAppFilterList()
    this.props.onRef(this)
  }

  componentWillReceiveProps(nextProps) {
    if (
      nextProps.app.appType.length &&
      !_.isEqual(nextProps.app.appType, this.props.app.appType)
    ) {
      this.setState({ appType: nextProps.app.appType }, () => this.getAppList())
    }
  }

  // 搜索
  onSearch = appName => {
    this.setState({ appName }, () => {
      this.getAppList()
    })
  }

  // 切换标签类型
  onSelectLabel = (index, id) => {
    let { selectLabelList } = this.state
    let list = [...selectLabelList[index]]
    // 选全部
    if (!id) {
      list = []
    } else {
      // 多选
      const i = list.indexOf(id)
      if (i > -1) {
        list.splice(i, 1)
      } else {
        list.push(id)
      }
    }
    selectLabelList[index] = list
    this.setState(
      {
        selectLabelList
      },
      () => this.getAppList()
    )
  }

  // 选择应用类型，可多选
  onSelectType = id => {
    let { appType } = this.state
    if (id) {
      if (appType.includes(id)) {
        appType = appType.filter(v => v !== id)
      } else {
        appType.push(id)
      }
    } else {
      appType = []
    }
    this.setState({ appType }, () => {
      this.getAppList()
    })
  }

  // 多选切换
  onCheckboxGroupChange = checkedValues => {
    this.setState(
      {
        checkActive: checkedValues
      },
      async () => {
        await checkData.map(item => {
          if (this.state.checkActive.includes(item.value)) {
            this.setState({ [item.value]: '1' })
          } else {
            this.setState({ [item.value]: '0' })
          }
        })
        this.getAppList()
      }
    )
  }

  // 收藏应用
  handleCollect = item => e => {
    const { appId, isBottom, isStore, isTop, orderId } = item
    const { userId } = this.props.login.data
    const { localeJson } = this.props.login
    const params = {
      appId,
      userId,
      isBottom,
      isStore,
      isTop,
      orderId
    }
    reqCollectApp(params).then(res => {
      const { meta } = res.data
      if (!meta.success) return message.error(meta.message)
      if (isStore == '0') {
        message.success(localeJson.app_collect_success)
      } else if (isStore == '1') {
        message.success(localeJson.app_cancel_collect_success)
      }
      this.getAppList()
      this.props.getCount && this.props.getCount()
      this.props.dispatch(changeTopFive(true)) // 通知左侧收藏栏top5已更新
    })
  }

  // 获取应用列表
  getAppList = () => {
    let {
      selectLabelList,
      isRecommend,
      isNew,
      isStore,
      appName,
      appType
    } = this.state
    let condition = selectLabelList.map(v => v.toString()).join(';')
    let appTypes = appType.join(',')
    let params = {
      pageNum: 1,
      pageSize: 999,
      appName,
      condition,
      isRecommend,
      isNew,
      isStore,
      appType: appTypes
    }
    reqGetAppList(params).then(res => {
      let { data, meta } = res.data
      if (!meta.success) return message.error(meta.message)
      data = data.map(item => {
        return {
          ...item,
          locale: item.locale ? JSON.parse(item.locale) : {}
        }
      })
      this.setState({ appData: data })
    })
  }

  // 获取应用标签/类型列表
  getAppFilterList = () => {
    reqAppFilterList().then(res => {
      const { data, meta } = res.data
      if (!meta.success) return message.error(meta.message)
      const selectList = data.lstLabel.map(item => {
        return {
          ...item,
          locale: item.locale ? JSON.parse(item.locale) : {}
        }
      })

      let selectLabelList = Array(data.lstLabel.length).fill([])
      const typeList = data.lstType.map(item => {
        return {
          ...item,
          locale: item.locale ? JSON.parse(item.locale) : {}
        }
      })
      this.setState({ selectList, selectLabelList, typeList, type: data.type })
    })
  }

  render() {
    const {
      checkData,
      checkActive,
      selectList,
      typeList,
      selectLabelList,
      appType,
      appData,
      isRecommend,
      isNew,
      appName
    } = this.state

    const { login } = this.props
    const { localeJson } = login
    return (
      <div className={styles.tabapp}>
        {/* 搜索 */}
        <div>
          <SearchBox
            id="appCenter_search"
            style={{ display: 'inline-block' }}
            handleSearch={this.onSearch}
            value={appName}
            // searchHistory={searchHistory}
          />
        </div>
        {/* 类型检索 */}
        <div className={styles.typeBox} id="appCenter_typeBox">
          {selectList.map((selectItem, index) => {
            return (
              <div key={selectItem.labelType} className={styles.typeList}>
                <div className={styles.typeListL}>
                  {selectItem.locale[login.locale] &&
                  selectItem.locale[login.locale].labelName
                    ? selectItem.locale[login.locale].labelName
                    : (selectItem.locale.zh_CN &&
                        selectItem.locale.zh_CN.labelName) ||
                      (selectItem.locale.en_US &&
                        selectItem.locale.en_US.labelName)}
                </div>
                <div className={styles.typeListR}>
                  <div
                    className={classNames(styles.typeItem, 'typeItem', {
                      active: !selectLabelList[index].length
                    })}
                    onClick={() => this.onSelectLabel(index, '')}
                  >
                    {localeJson.siderBarMythemeType1}
                  </div>
                  {selectItem.lstLabel.map(item => {
                    const labelLocale = item.locale
                      ? JSON.parse(item.locale)
                      : {}
                    return (
                      <div
                        key={item.labelType}
                        className={classNames(styles.typeItem, 'typeItem', {
                          active: selectLabelList[index].includes(
                            item.labelType
                          )
                        })}
                        onClick={() =>
                          this.onSelectLabel(index, item.labelType)
                        }
                      >
                        {labelLocale[login.locale] &&
                        labelLocale[login.locale].labelName
                          ? labelLocale[login.locale].labelName
                          : (labelLocale.zh_CN &&
                              labelLocale.zh_CN.labelName) ||
                            (labelLocale.en_US && labelLocale.en_US.labelName)}
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })}
          {typeList.length > 0 && (
            <div className={styles.typeList}>
              <div className={styles.typeListL}>{localeJson.appType}</div>
              <div className={styles.typeListR}>
                <div
                  className={classNames(styles.typeItem, 'typeItem', {
                    active: !appType.length
                  })}
                  onClick={() => this.onSelectType()}
                >
                  {localeJson.siderBarMythemeType1}
                </div>
                {typeList.map(item => {
                  return (
                    <div
                      key={item.typeId}
                      className={classNames(styles.typeItem, 'typeItem', {
                        active: appType.includes(item.typeId)
                      })}
                      onClick={() => this.onSelectType(item.typeId)}
                    >
                      {item.locale[login.locale] &&
                      item.locale[login.locale].typeName
                        ? item.locale[login.locale].typeName
                        : (item.locale.zh_CN && item.locale.zh_CN.typeName) ||
                          (item.locale.en_US && item.locale.en_US.typeName)}
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </div>
        {/* 应用列表 */}
        <div className={styles.appBox}>
          <div className={styles.appListBox}>
            <Checkbox.Group
              className={styles.checkbox}
              value={checkActive}
              onChange={this.onCheckboxGroupChange}
            >
              {checkData.map(item => {
                return (
                  <Checkbox key={item.value} value={item.value}>
                    {localeJson[item.value]}
                  </Checkbox>
                )
              })}
            </Checkbox.Group>
            {/* 应用列表 */}
            <div className={styles.appList}>
              {appData.map((item, i) => {
                let useNum =
                  item.useNum > 10000
                    ? localeJson.about +
                      Math.round(item.useNum / 10000) +
                      localeJson.tenThousand
                    : ~~item.useNum
                return (
                  <AppItem
                    id={i === 0 ? 'appCenter_app' : null}
                    data={item}
                    key={i}
                    isNew={isNew === '1'}
                    isRecommend={isRecommend === '1'}
                    hasCollect={true}
                    onCollect={this.handleCollect(item)}
                  >
                    <div
                      className="fl"
                      style={{ color: '#333', marginLeft: 78 }}
                    >
                      <Icon
                        type="smile"
                        style={{ color: 'rgb(204, 204, 204)', marginRight: 5 }}
                      />
                      {useNum + ' ' + localeJson.appUseCount}
                    </div>
                    <div
                      className={styles.appListBtnSc}
                      style={{ color: '#333' }}
                    >
                      <Icon
                        type="heart"
                        style={{ color: 'rgb(204, 204, 204)', marginRight: 5 }}
                      />
                      {~~item.storeNum + ' ' + localeJson.appMarkCount}
                    </div>
                  </AppItem>
                )
              })}
            </div>

            {!appData.length && (
              <div style={{ textAlign: 'center', paddingTop: 80 }}>
                <img src={require('assets/images/absent.png')} alt="" />
                <p>{localeJson.nodata}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    )
  }
}
