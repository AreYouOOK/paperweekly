// 字母
export const letterData = [
  'A',
  'B',
  'C',
  'D',
  'E',
  'F',
  'G',
  'H',
  'I',
  'J',
  'K',
  'L',
  'M',
  'N',
  'O',
  'P',
  'Q',
  'R',
  'S',
  'T',
  'U',
  'V',
  'W',
  'X',
  'Y',
  'Z'
];

// 搜索历史
export const searchHistory = [
  {
    title: '最近搜索',
    children: [
      {
        title: '办公自动化'
      },
      {
        title: '教务管理系统'
      },
      {
        title: '图书管理系统'
      },
      {
        title: '校历查询系统'
      }
    ]
  }
];

// 服务场景
export const sceneData = [
  {
    label: '全部',
    value: 0
  },
  {
    label: '行政办公',
    value: 1
  },
  {
    label: '教学研究',
    value: 2
  },
  {
    label: '生活服务',
    value: 3
  },
  {
    label: '资产收费',
    value: 4
  }
];

// 服务角色
export const roleData = [
  {
    label: '全部',
    value: 0
  },
  {
    label: '领导',
    value: 1
  },
  {
    label: '学生',
    value: 2
  },
  {
    label: '游客',
    value: 3
  }
];

// 服务部门
export const sectionData = [
  {
    label: '全部',
    value: 0
  },
  {
    label: '党政办',
    value: 1
  },
  {
    label: '学生处',
    value: 2
  },
  {
    label: '人事处',
    value: 3
  },
  {
    label: '教务处',
    value: 4
  },
  {
    label: '学工处',
    value: 5
  },
  {
    label: '后勤处',
    value: 6
  },
  {
    label: '就业处',
    value: 7
  }
];

// 多选筛选
export const checkData = [
  {
    label: '官方推荐',
    value: 'isRecommend'
  },
  {
    label: '最新',
    value: 'isNew'
  }
  // {
  //     label: "我的收藏",
  //     value: 'isStore'
  // },
  // {
  //     label: "自建服务",
  //     value: 'isPersonal'
  //}
];

// 应用数据
export const appData = [
  {
    key: '0',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 1,
    tag: '荐'
  },
  {
    key: '1',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 0,
    tag: ''
  },
  {
    key: '2',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 1,
    tag: ''
  },
  {
    key: '3',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 1,
    tag: '热'
  },
  {
    key: '4',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 1,
    tag: '荐'
  },
  {
    key: '5',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 0,
    tag: '新'
  },
  {
    key: '6',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 1,
    tag: '荐'
  },
  {
    key: '7',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 1,
    tag: '荐'
  },
  {
    key: '8',
    name: 'OA',
    title: '办公自动化',
    info: '办公自动化系统',
    use: 758,
    collect: 366,
    isCollect: 1,
    tag: '荐'
  }
];
