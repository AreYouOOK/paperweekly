import React from "react";
import AppCenter from "./appCenter"; // 应用中心

export default class Apply extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (
            <div>
                <AppCenter />
            </div>
        );
    }
}
