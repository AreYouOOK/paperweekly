/*
 * @Description: iframe嵌入页面
 * @Author: xuqiuting
 * @Date: 2019-07-01 14:47:07
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 14:52:52
 */
import React from 'react';
import { getSize } from 'utils/util';
import { connect } from 'react-redux'

@connect((state) => {
    return { ...state }
})
export default class NewIframe extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            iFrameHeight: '0px',
            height: getSize().windowH,
        }
    }

    render() {
        const { page } = this.props;
        const { system } = page;
        const { height } = this.state;
        let scrollHeight = height;
        // 如果有baner
        if (system && system.banner) {
            scrollHeight = height - 175;
        } else {
            scrollHeight = height - 86
        }
        
        return (
            <iframe
                style={{ width: '100%', height: scrollHeight, overflow: 'visible' }}
                ref="iframe"
                src={this.props.url}
                width="100%"
                height={scrollHeight}
                scrolling="no"
                frameBorder="0"
            />
        )
    }
}