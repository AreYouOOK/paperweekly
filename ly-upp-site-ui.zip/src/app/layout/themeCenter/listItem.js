import React, { Component } from "react";
import { Icon } from "antd";
import styles from "./index.less";

export default class ListItem extends Component {
    render() {
        const { data, extra, edit = false } = this.props;
        // edit 是否是可编辑状态

        return (
            <div className={styles.listItem}>
                <div className={styles.listItemCon}>
                    <div className={styles.listItemConC}>
                        <div className={styles.listItemImg}>
                            <img src={data.img} />
                        </div>
                    </div>
                    <div className={styles.listItemBtn}>
                        {edit && <Icon type="form" />}
                        <Icon type="eye" />
                        {edit && <Icon type="close" />}
                    </div>
                    {data.tag && (
                        <div className={styles.listItemTag}>
                            <div className={styles.text}>{data.tag}</div>
                        </div>
                    )}
                    <div className={styles.listItemMask} />
                </div>
                <div className={styles.listItemInfo}>
                    <div className={styles.listItemTitle}>
                        <div className={styles.listItemTitleL}>
                            {data.title}
                        </div>
                        <div className={styles.timeBox}>
                            <span>
                                <Icon type="fire" />
                                <span>{data.use}</span>
                            </span>
                            <span className="ml10">
                                <Icon type="environment" />
                                <span>{data.time}</span>
                            </span>
                        </div>
                    </div>
                    <div className={styles.describe}>{data.info}</div>
                    {extra}
                </div>
            </div>
        );
    }
}
