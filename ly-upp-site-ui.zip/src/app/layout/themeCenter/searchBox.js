import React, { Component } from "react";
import classNames from "classnames";
import { Button, Form, Input } from "antd";
import styles from "./index.less";

@Form.create()
export default class SearchBox extends Component {
    // 搜索
    handleSubmit = e => {
        const { onSearch } = this.props;
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            if (!err) {
                onSearch && onSearch(values);
            }
        });
    };

    // 重置
    onReset = () => {
        this.props.form.resetFields();
    };

    render() {
        const {
            form,
            typeList = [],
            typeActive,
            onTypeClick = Function.prototype
        } = this.props;
        const { getFieldDecorator } = form;

        return (
            <div className={styles.searchBox}>
                <Form layout="inline">
                    <Form.Item>
                        {getFieldDecorator("name")(
                            <Input
                                style={{ width: 200 }}
                                placeholder="请输入主题名称"
                            />
                        )}
                    </Form.Item>
                    <Form.Item>
                        <Button type="primary" onClick={this.handleSubmit}>
                            搜索
                        </Button>
                        <Button className="ml10" onClick={this.onReset}>
                            重置
                        </Button>
                    </Form.Item>
                </Form>
                {/* 类型筛选 */}
                {typeList[0] && (
                    <div className={styles.searchType}>
                        {typeList.map(item => {
                            return (
                                <div
                                    key={item.value}
                                    className={classNames(
                                        styles.searchTypeItem,
                                        {
                                            [styles.active]:
                                                typeActive === item.value
                                        }
                                    )}
                                    onClick={() => onTypeClick(item)}
                                >
                                    {item.label}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        );
    }
}
