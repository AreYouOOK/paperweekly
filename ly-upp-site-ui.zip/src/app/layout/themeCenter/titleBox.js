import React, { Component } from "react";
import { Button } from "antd";
import styles from "./index.less";

const TitleBox = props => {
    const { title } = props;
    return (
        <div className={styles.titleBox}>
            <div className={styles.titleL}>{title}</div>
            <div className={styles.titleR}>
                <Button type="primary">回到首页</Button>
            </div>
        </div>
    );
};
export default TitleBox;
