const imgUrl = require("assets/images/theme/theme1.jpg");
// 主题列表类型
export const typeList = [
    {
        label: "官方",
        value: 1
	},
	{
        label: "推荐",
        value: 2
	},
	{
        label: "最新",
        value: 3
	},
	{
        label: "热度",
        value: 4
    }
];

// 我的主题列表类型
export const myThemeTypeList = [
    {
        label: "全部",
        value: 0
	},
	{
        label: "审核通过",
        value: 1
	},
	{
        label: "审核不通过",
        value: 2
	},
];

// 主题列表
export const themeData = [
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "推荐",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。"
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "最新",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。"
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "最热",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。"
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。"
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。"
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。"
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。"
    }
];

// 我的主题
// state 0: 审核中 1: 审核通过 2: 审核不通过
export const myThemeData = [
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。",
        state: 1,
        share: 0
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。",
        state: 0,
        share: 0
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。",
        state: 2,
        share: 0
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。",
        state: 1,
        share: 1
    },
    {
        title: "办公老师专用主题",
        img: imgUrl,
        use: "120",
        time: "2019-03-25",
        tag: "",
        info: "适合与行政老师的日常办公，包含日程日历，代办事件。",
        state: 1,
        share: 0
    }
];
