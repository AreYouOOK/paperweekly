import React, { Component } from "react";
import { Icon } from "antd";
import TitleBox from "./titleBox"; // 标题
import SearchBox from "./searchBox"; // 搜索
import ListItem from "./listItem"; // 搜索
import AddModal from "./addModal";
import { myThemeData, myThemeTypeList } from "./data";
import styles from "./index.less";

export default class MyTheme extends Component {
    constructor(props) {
        super(props);
        this.state = {
            addVisible: false, // 弹窗
            addLoading: false, // 弹窗-loading
            typeActive: "" // 类型筛选
        };
    }

    // 类型选择
    onTypeClick = data => {
        this.setState({
            typeActive: data.value
        });
    };

    // 搜索
    onSearch = value => {
        console.log(value);
    };

    // 弹窗确认
    handleOk = () => {
        this.setState({
            addLoading: true
        });
        setTimeout(() => {
            this.setState({
                addVisible: false,
                addLoading: false
            });
        }, 2000);
    };

    // 打开弹窗
    showModal = () => {
        this.setState({
            addVisible: true
        });
    };

    // 关闭弹窗
    handleCancel = () => {
        this.setState({
            addVisible: false
        });
    };

    render() {
        const { addVisible, addLoading, typeActive } = this.state;

        const extra = data => {
            return (
                <div className={styles.extra}>
                    <div className={styles.extraL}>
                        {data.state == 0 && (
                            <span className="text-danger">审核中</span>
                        )}
                        {data.state == 2 && (
                            <span className="text-danger">审核失败</span>
                        )}
                        {data.state == 1 && data.share == 1 && (
                            <span className="text-success">已分享</span>
                        )}
                    </div>
                    {data.state != 0 && (
                        <div className={styles.extraR}>
                            <span
                                className={styles.extraBtn}
                                onClick={this.showModal}
                            >
                                <Icon type="edit" />
                                <span>
                                    {data.state == 2 ? "重新编辑" : "编辑"}
                                </span>
                            </span>
                            {data.state == 1 && (
                                <span className={styles.extraBtn}>
                                    <Icon type="share-alt" />
                                    <span>分享</span>
                                </span>
                            )}
                        </div>
                    )}
                </div>
            );
        };

        return (
            <div>
                <TitleBox title="我的主题" />
                <SearchBox
                    onSearch={this.onSearch}
                    typeActive={typeActive}
                    typeList={myThemeTypeList}
                    onTypeClick={this.onTypeClick}
                />
                <div className={styles.listBox}>
                    {myThemeData.map((item, i) => {
                        return (
                            <ListItem
                                edit
                                key={i}
                                data={item}
                                extra={extra(item)}
                            />
                        );
                    })}
                </div>
                {/* 添加 */}
                <AddModal
                    visible={addVisible}
                    loading={addLoading}
                    handleOk={this.handleOk}
                    handleCancel={this.handleCancel}
                />
            </div>
        );
    }
}
