import React, { Component } from "react";
import TitleBox from "./titleBox"; // 标题
import SearchBox from "./searchBox"; // 搜索
import ListItem from "./listItem"; // 搜索
import { themeData, typeList } from "./data";
import styles from "./index.less";

export default class Center extends Component {
    constructor(props) {
        super(props);
        this.state = {
            typeActive: "" // 类型筛选
        };
    }

    // 类型选择
    onTypeClick = data => {
        this.setState({
            typeActive: data.value
        });
    };

    // 搜索
    onSearch = value => {
        console.log(value);
    };

    render() {
        const { typeActive } = this.state;

        return (
            <div>
                <TitleBox title="主题中心" />
                <SearchBox
                    onSearch={this.onSearch}
                    typeActive={typeActive}
                    typeList={typeList}
                    onTypeClick={this.onTypeClick}
                />
                <div className={styles.listBox}>
                    {themeData.map((item, i) => {
                        return <ListItem key={i} data={item} />;
                    })}
                </div>
            </div>
        );
    }
}
