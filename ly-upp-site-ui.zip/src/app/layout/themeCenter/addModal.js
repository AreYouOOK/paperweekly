import React, { Component } from "react";
import { Modal, Form, Input, Upload, Icon, message } from "antd";
import { getBase64 } from "utils/util";
import styles from "./index.less";

const { TextArea } = Input;

@Form.create()
export default class AddModal extends Component {
    state = {
        loading: false,
        imageUrl: ""
    };

    handleOk = () => {
        const { handleOk } = this.props;
        this.props.form.validateFields((err, values) => {
            if (!err) {
                console.log("Received values of form: ", values);
                handleOk && handleOk(values);
            }
        });
    };

    handleChange = info => {
        if (info.file.status === "uploading") {
            this.setState({ loading: true });
            return;
        }
        if (info.file.status === "done") {
            // Get this url from response in real world.
            getBase64(info.file.originFileObj, imageUrl =>
                this.setState({
                    imageUrl,
                    loading: false
                })
            );
        }
    };

    render() {
        const {
            visible,
            loading,
            handleOk,
            handleCancel,
            form,
            ...restProps
        } = this.props;

        const { getFieldDecorator } = form;
        const { imageUrl } = this.state;

        const formItemLayout = {
            labelCol: {
                span: 6
            },
            wrapperCol: {
                span: 16
            }
        };

        const beforeUpload = file => {
            const isIPGPNG =
                file.type === "image/jpeg" || file.type === "image/png";
            if (!isIPGPNG) {
                message.error("You can only upload JPG file!");
            }
            const isLt2M = file.size / 1024 / 1024 < 2;
            if (!isLt2M) {
                message.error("Image must smaller than 2MB!");
            }
            return isIPGPNG && isLt2M;
        };

        const uploadButton = (
            <div>
                <Icon type={this.state.loading ? "loading" : "plus"} />
                <div className="ant-upload-text">上传</div>
            </div>
        );

        return (
            <Modal
                visible={visible}
                onOk={this.handleOk}
                title={<div className={styles.addModalTitle}>主题信息</div>}
                wrapClassName={styles.addModalBox}
                confirmLoading={loading}
                onCancel={handleCancel}
                {...restProps}
            >
                <Form {...formItemLayout}>
                    <Form.Item label="主题名称">
                        {getFieldDecorator("name", {
                            rules: [
                                {
                                    required: true,
                                    message: "请输入主题名称"
                                }
                            ]
                        })(<Input placeholder="请输入" />)}
                    </Form.Item>
                    <Form.Item label="主题描述">
                        {getFieldDecorator("info")(
                            <TextArea
                                autosize={{ minRows: 4, maxRows: 4 }}
                                placeholder="请输入"
                            />
                        )}
                    </Form.Item>
                    <Form.Item label="缩略图">
                        {getFieldDecorator("icon", {
                            rules: [
                                {
                                    required: true,
                                    message: "请上传缩略图"
                                }
                            ]
                        })(
                            <Upload
                                name="icon"
                                listType="picture-card"
                                className="icon-uploader"
                                showUploadList={false}
                                action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                                beforeUpload={beforeUpload}
                                onChange={this.handleChange}
                            >
                                {imageUrl ? (
                                    <img src={imageUrl} alt="icon" />
                                ) : (
                                    uploadButton
                                )}
                            </Upload>
                        )}
                    </Form.Item>
                </Form>
            </Modal>
        );
    }
}
