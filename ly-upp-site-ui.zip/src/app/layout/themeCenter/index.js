import React from "react";
import { Layout, Menu, Button, Icon } from "antd";
import Center from "./center"; // 主题中心
import MyTheme from "./myTheme"; // 我的主题
import styles from "./index.less";

const { Content, Sider } = Layout;

export default class ThemeCenter extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedKeys: "theme" // 菜单激活的key
        };
    }

    handleClick = e => {
        this.setState({
            selectedKeys: e.key
        });
    };

    onSearch = values => {
        console.log(values, "values");
    };

    render() {
        const { selectedKeys } = this.state;

        return (
            <Layout className={styles.box}>
                <Sider theme="light" className={styles.boxSider}>
                    <Menu
                        mode="inline"
                        selectedKeys={[selectedKeys]}
                        onClick={this.handleClick}
                    >
                        <Menu.Item key="theme">主题中心</Menu.Item>
                        <Menu.Item key="myTheme">我的主题</Menu.Item>
                    </Menu>
                </Sider>
                <Content className={styles.boxContent}>
                    {selectedKeys == "theme" && <Center />}
                    {selectedKeys == "myTheme" && <MyTheme />}
                </Content>
            </Layout>
        );
    }
}
