/*
 * @Description: 语言输入框
 * @Author: xuqiuting
 * @Date: 2019-08-21 09:37:54
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-11-04 09:43:13
 */
import React, { Fragment } from "react";
import { Input, Tooltip } from "antd";
import _ from "lodash";
import { connect } from "react-redux";

const { TextArea } = Input;

@connect(state => {
  return { ...state }
})
export default class LanguageInput extends React.Component {
  static defaultProps = {
    type: "name",
    inputType: "input"
  };
  constructor(props) {
    super(props);
    this.state = {
      // language: "zh_CN", // 名称的当前语言
      language: this.props.login.locale, // 名称的当前语言
      locale: {}
    };
  }

  // 根据props的值更新state
  static getDerivedStateFromProps(nextProps, prevState) {
    if ("value" in nextProps && !_.isEqual(nextProps.value, prevState.locale)) {
      return {
        value:
          nextProps.value && nextProps.value[prevState.language]
            ? nextProps.value[prevState.language][nextProps.type]
            : null,
        locale: nextProps.value ? nextProps.value : {}
      };
    }
    return null;
  }

  // 改变语言
  handleLanguage = type => {
    const { locale } = this.state;
    this.setState({
      language: type,
      value: locale[type] ? locale[type][this.props.type] : null
    });
  };

  //输入改变
  handleInputChange = e => {
    const { language } = this.state;
    let value = e.target.value;
    let locale = this.state.locale;
    locale[language] = locale[language] || {};
    locale[language][this.props.type] = value;
    this.setState({
      locale: locale,
      value: value
    });
    this.triggerChange(locale);
  };

  // 向外传递值
  triggerChange = changedValue => {
    const onChange = this.props.onChange;
    if (onChange) {
      onChange(changedValue);
    }
  };

  render() {
    const { languageList, localeJson, inputType, rows, maxLength } = this.props;
    const { language, value } = this.state;

    return (
      <Fragment>
        {inputType == "TextArea" ? (
          <TextArea
            rows={rows ? rows : 8}
            onChange={e => this.handleInputChange(e)}
            value={value}
            maxLength={maxLength ? maxLength : null}
          />
        ) : (
          <Input
            maxLength={maxLength ? maxLength : null}
            onChange={e => this.handleInputChange(e)}
            value={value}
          />
        )}

        <div style={{ lineHeight: "20px" }}>
          {languageList.map(res => {
            return (
              <Tooltip
                key={res.type}
                placement="topLeft"
                title={localeJson[res.tip]}
              >
                <div
                  className={"imgdiv"}
                  onClick={() => this.handleLanguage(res.type)}
                >
                  <img src={res.img} />
                  {language == res.type ? <div className={"circle"} /> : null}
                </div>
              </Tooltip>
            );
          })}
        </div>
      </Fragment>
    );
  }
}
