/*
 * @Description: 错误边界装饰器，捕捉页面js报错
 * @Author: xuqiuting
 * @Date: 2019-09-11 14:23:34
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-23 16:58:08
 */
import React from "react";
import { connect } from "react-redux";

@connect(state => {
  return { login: state.login };
})
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  componentDidCatch(error, info) {
    this.setState({ hasError: true });
  }

  render() {
    const { login } = this.props;
    if (this.state.hasError) {
      return (
        <h1>
          {login.locale == "zh_CN"
            ? "卡片显示异常,请检查卡片后台配置参数"
            : "Card Went Wrong,Please Check BackPatformItems"}
        </h1>
      );
    }
    return this.props.children;
  }
}

function errorCatch(Target) {
  class Wrap extends React.Component {
    render() {
      return (
        <ErrorBoundary>
          <Target {...this.props} />
        </ErrorBoundary>
      );
    }
  }
  return Wrap;
}

export default errorCatch;
