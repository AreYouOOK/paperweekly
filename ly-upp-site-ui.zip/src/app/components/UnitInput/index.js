/*
 * @Description: 单位输入框
 * @Author: qizc
 * @Date: 2019-06-18 09:37:54
 * @LastEditors: qizc
 * @LastEditTime: 2019-06-18 14:14:49
 */

import React from "react";
import { Input, Select } from "antd";
const { Option } = Select;

export default class UnitInput extends React.Component {
    static getDerivedStateFromProps(nextProps, prevState) {
        // Should be a controlled component.
        const oldValue = prevState.value || {};
        const newValue = nextProps.value || {};
        if (
            "value" in nextProps &&
            (newValue.number !== oldValue.number ||
                newValue.unit !== oldValue.unit)
        ) {
            return {
                ...(nextProps.value || {})
            };
        }
        return null;
    }

    constructor(props) {
        super(props);

        const value = props.value || {};
        this.state = {
            number: value.number || 0,
            unit: value.unit || ""
        };
    }

    // 数值改变
    handleNumberChange = e => {
        const number = e.target.value;
        if (!("value" in this.props)) {
            this.setState({ number });
        }
        this.triggerChange({ number });
    };

    // 单位改变
    handleUnitChange = unit => {
        if (!("value" in this.props)) {
            this.setState({ unit });
        }
        this.triggerChange({ unit });
    };

    // 向外传递值
    triggerChange = changedValue => {
        const onChange = this.props.onChange;
        if (onChange) {
            onChange(Object.assign({}, this.state, changedValue));
        }
    };

    render() {
        const { size, unitData = [] } = this.props;
        const state = this.state;

        return (
            <span>
                <Input
                    type="text"
                    size={size}
                    value={state.number}
                    onChange={this.handleNumberChange}
                    style={{ width: "65%", marginRight: "3%" }}
                />
                <Select
                    value={state.unit}
                    size={size}
                    style={{ width: "32%" }}
                    onChange={this.handleUnitChange}
                >
                    {unitData.map(item => {
                        return (
                            <Option key={item.value} value={item.value}>
                                {item.label}
                            </Option>
                        );
                    })}
                </Select>
            </span>
        );
    }
}
