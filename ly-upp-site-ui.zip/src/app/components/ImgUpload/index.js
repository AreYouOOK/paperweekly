/*
 * @Description: 图片上传组件
 * @Author: xuqiuting
 * @Date: 2019-08-28 09:37:54
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 14:46:34
 */

import React, { Fragment } from "react";
import { Upload, Modal, Icon, message } from "antd";
import { connect } from "react-redux";
import { reqDeleteAttachment, downloadApi, reqUploadImg } from "utils/api";
const { confirm } = Modal;

@connect(state => {
  return { login: state.login };
})
export default class ImgUpload extends React.Component {
  static defaultProps = {
    imgType: "1" //图片上传要传的类型字段
  };
  static getDerivedStateFromProps(nextProps, prevState) {
    if ("value" in nextProps && nextProps.value != prevState.value) {
      return {
        value: nextProps.value,
        fileList: nextProps.value
          ? [
              {
                id: nextProps.value,
                uid: nextProps.value,
                url: downloadApi + "?attachmentId=" + nextProps.value,
                thumbUrl: downloadApi + "?attachmentId=" + nextProps.value
              }
            ]
          : []
      };
    }
    return null;
  }

  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      fileList: []
    };
  }

  // 向外传递值
  triggerChange = changedValue => {
    const onChange = this.props.onChange;
    if (onChange) {
      onChange(changedValue);
    }
  };

  // 模态框取消
  handleCancel = () => {
    this.setState({
      visible: false
    });
  };

  // 预览
  handlePreview = file => {
    this.setState({
      image: file.url || file.thumbUrl,
      visible: true
    });
  };

  // 图片选择改变
  handleChange = file => {
    const { imgType, login } = this.props;
    let fileList = file.fileList;
    if (fileList.length > 0) {
      let params = {
        file: file.file,
        type: imgType
      };
      reqUploadImg(params).then(res => {
        const { data, meta } = res.data;
        if (meta.success) {
          fileList[0].id = data;
          this.triggerChange(data);
        } else {
          message.error(login.localeJson.app_icon_upload_error);
        }
      });
    } else {
      this.triggerChange(null);
    }
  };

  // 图片移除
  handleRemove = file => {
    const { localeJson } = this.props.login;
    let id;
    if (file.id || (file.response && file.response.data)) {
      id = file.id || file.response.data;
      file.name = file.name ? file.name : "";
      return new Promise((resolve, reject) => {
        confirm({
          title: `${localeJson.delete_the_img}`,
          onOk: () => {
            resolve(true);
          }
        });
      }).then(() => {
        if (id) {
          reqDeleteAttachment(id).then(res => {
            const { data, meta } = res.data;
            if (meta.success) {
              message.success(localeJson.api_delete_success);
            } else {
              message.error(meta.message);
            }
          });
        }
      });
    }
  };

  render() {
    const { localeJson } = this.props.login;
    const { fileList, visible, image } = this.state;
    const uploadButton = (
      <div>
        <Icon type="plus" />
        <div className="ant-upload-text">{localeJson.upload}</div>
      </div>
    );
    // console.log(fileList,"fileList")
    return (
      <Fragment>
        <Upload
        accept={".jpg,.png,.ico,.gif,.svg"}
          beforeUpload={file => {
            return false;
          }}
          listType="picture-card"
          fileList={fileList}
          onPreview={this.handlePreview}
          onChange={this.handleChange}
          onRemove={this.handleRemove}
        >
          {fileList.length < 1 ? uploadButton : null}
        </Upload>
        <Modal
          visible={visible}
          footer={null}
          onCancel={() => this.handleCancel()}
        >
          <img style={{ width: "100%" }} src={image} />
        </Modal>
      </Fragment>
    );
  }
}
