/*
 * @Description: css 代码编辑器
 * @Author: qizc
 * @Date: 2019-06-18 09:37:54
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-08-23 18:33:18
 */

import React from "react";
import classNames from "classnames";
require("codemirror/lib/codemirror.css");
require("codemirror/theme/idea.css");
require("codemirror/mode/css/css.js");
require("codemirror/keymap/sublime.js");
import { Controlled as CodeMirror } from "react-codemirror2";

export default class CssEditor extends React.Component {
  constructor(props) {
    super(props);
    const value = props.value || "";
    this.state = {
      beforeValue: value
    };
  }

  // 根据props的值更新state
  static getDerivedStateFromProps(nextProps, prevState) {
    if ("value" in nextProps && nextProps.value != prevState.beforeValue) {
      return {
        beforeValue: nextProps.value
      };
    }
    return null;
  }

  // 向外传递值
  triggerChange = value => {
    const onChange = this.props.onChange;
    if (onChange) {
      onChange(value);
    }
  };

  // 值改变
  onChange = value => {
    this.setState({
      beforeValue: value
    });
    this.triggerChange(value);
  };

  render() {
    const { className, options = {} } = this.props;
    const { beforeValue } = this.state;

    return (
      <div className={classNames(className, "css-editor")}>
        <CodeMirror
          value={beforeValue}
          options={{
            mode: "css",
            theme: "idea",
            lineNumbers: true,
            keyMap: "sublime",
            ...options
          }}
          onBeforeChange={(editor, data, value) => {
            this.onChange(value)
          }}
        />
      </div>
    );
  }
}
