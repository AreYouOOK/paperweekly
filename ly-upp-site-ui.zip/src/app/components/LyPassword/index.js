import React from 'react'
import PropTypes from 'prop-types'
import { Input, Icon } from 'antd'

export default class LyPassword extends React.Component {
  static defaultProps = {
    encryptMark: '*' //用作加密的符号
  }

  static propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    encryptMark: PropTypes.string
  }

  constructor(props) {
    super(props)
    // 初始化
    const { newValue, newEncrypt } = this.getEncrypt(
      props.value || props.defaultValue || '',
      ''
    )
    this.state = {
      value: newValue,
      encrypt: newEncrypt
    }
  }

  // 改变
  onChange = e => {
    const { onChange } = this.props
    const { value } = this.state
    // console.log('old', value)
    // console.log('now', e.target.value)
    const { newValue, newEncrypt } = this.getEncrypt(e.target.value, value)
    this.setState(
      {
        value: newValue,
        encrypt: newEncrypt
      },
      () => onChange && onChange(newValue)
    )
  }

  // 获取加密的值和原始值 nowValue:input框当前的值 value:原来未加密的值
  getEncrypt = (nowValue = '', value = '') => {
    const { encryptMark } = this.props
    const lastEncryptMarkIndex = nowValue.lastIndexOf(encryptMark)
    // 改变的部分
    const changeText = nowValue.slice(lastEncryptMarkIndex + 1)
    // 未改变的部分
    const retainText = value.slice(0, lastEncryptMarkIndex + 1)
    const newValue = retainText + changeText
    const newEncrypt = encryptMark.repeat(nowValue.length)
    // console.log('haha', newValue, newEncrypt)
    return {
      newValue,
      newEncrypt
    }
  }

  render() {
    const { onChange, encryptMark, value, ...restProps } = this.props
    const { encrypt } = this.state

    return (
      <Input
        {...restProps}
        value={encrypt}
        onChange={this.onChange}
        autoComplete="off"
        size="large"
        // type="password"
        prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
      />
    )
  }
}
