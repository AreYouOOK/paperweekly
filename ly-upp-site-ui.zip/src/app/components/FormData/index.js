/*
 * @Description: 卡片弹窗配置
 * @Author: xuqiuting
 * @Date: 2019-08-21 09:37:54
 * @LastEditors: liyaochuan
 * @LastEditTime: 2019-11-20 15:50:08
 */
import React, { Fragment } from 'react'
import { Form, Input, Select, Switch, DatePicker, InputNumber } from 'antd'
import { ColorBtn, LanguageInput, CssEditor } from 'components'
import _ from 'lodash'

const FormItem = Form.Item
const Option = Select.Option
const { TextArea } = Input

export default class FormData extends React.Component {
  static defaultProps = {
    languageList: window.locale ? window.locale.list : [], // 语言列表
    localeJson: window.locale['zh_CN'] ? window.locale['zh_CN'] : {}, //当前系统语言配置
    language: 'zh_CN', //当前系统语言
    config: {}, // 初始化值
    dataSouce: [] // 表单项
  }
  constructor(props) {
    super(props)
    this.state = {}
  }

  componentDidMount() {
    this.handleInit(this.props)
  }

  componentWillReceiveProps(nextprops) {
    if (!_.isEqual(nextprops.config, this.props.config)) {
      this.handleInit(nextprops)
    }
  }

  // 初始化
  handleInit = props => {
    this.setState({
      ...props.config
    })
  }

  // Switch展示
  handleSwitch = (value, name) => {
    this.setState({
      [name]: value
    })
  }

  // 根据类型生成对应的组件
  generateFormFields = formList => {
    let allComponent = []
    const { localeJson, languageList, language } = this.props
    // 表单遍历
    formList.map(item => {
      let component = null
      if (!item.type) {
        return
      }
      switch (item.type) {
        case 'Input':
          component = (
            <Input
              style={{ width: item.width ? item.width : '100%' }}
              maxLength={item.maxlength ? item.maxlength : null}
              placeholder={item.placeholder ? item.placeholder : ''}
            />
          )
          break
        case 'InputNumber':
          component = (
            <InputNumber
              style={{ width: item.width ? item.width : '100%' }}
              placeholder={item.placeholder ? item.placeholder : ''}
              min={item.min}
              max={item.max}
            />
          )
          break
        case 'TextArea':
          component = (
            <TextArea
              rows={item.rows || 2}
              style={{ width: item.width ? item.width : '100%' }}
              placeholder={item.placeholder ? item.placeholder : ''}
            />
          )
          break
        case 'Switch':
          component = (
            <Switch
              checked={this.state[item.name] ? this.state[item.name] : false}
              onChange={e => this.handleSwitch(e, item.name)}
            />
          )
          break
        case 'ColorBtn':
          component = <ColorBtn colorType={item.colorType} />
          break
        case 'LanguageInput':
          component = (
            <LanguageInput
              languageList={languageList}
              maxLength={item.maxlength ? item.maxlength : null}
              localeJson={localeJson}
              language={language}
            />
          )
          break
        case 'Select':
          component = (
            <Select
              style={{ width: item.width ? item.width : '100%' }}
              placeholder={item.placeholder ? item.placeholder : '请选择'}
              mode={item.mode ? item.mode : ''}
              allowClear
              onChange={value => {
                item.onChange && item.onChange(value)
              }}
            >
              {item.items &&
                item.items.map(({ label, value }, index) => (
                  <Option key={value + '_' + index} value={value.toString()}>
                    {item.hideLanguage ? label : localeJson[label]}
                  </Option>
                ))}
            </Select>
          )
          break
        case 'RangePicker':
          component = (
            <DatePicker.RangePicker
              style={{ width: item.width ? item.width : '100%' }}
              showTime={item.showTime ? item.showTime : false}
              format={item.format ? item.format : 'YYYY-MM-DD HH:mm'}
            />
          )
          break
        case 'DatePicker':
          component = (
            <DatePicker
              style={{ width: item.width ? item.width : '100%' }}
              showTime={item.showTime ? item.showTime : false}
              format={item.format ? item.format : 'YYYY-MM-DD'}
              allowClear={!!item.allowClear ? true : item.allowClear}
            />
          )
          break
        case 'CssEditor':
          component = <CssEditor />
          break
      }
      component = this.generateFormItem({
        component,
        ...item
      })
      allComponent.push(component)
    })
    return allComponent
  }

  // 生成表单项
  generateFormItem = ({ label, name, options, component, extra, show }) => {
    const { getFieldDecorator } = this.props.form
    const { localeJson } = this.props
    const formItemLayout = {
      labelCol: { span: 5 },
      wrapperCol: { span: 15 }
    }
    let style = {}

    // 控制显示
    if (typeof show != 'boolean') {
      style = {
        display: this.state[show.label] == show.value ? 'block' : 'none'
      }
    }

    return (
      <FormItem
        {...formItemLayout}
        key={name}
        label={localeJson[label]}
        extra={localeJson[extra]}
        style={style}
      >
        {getFieldDecorator(
          name,
          {
            initialValue: this.state[name]
          },
          options
        )(component)}
      </FormItem>
    )
  }

  render() {
    const { dataSouce } = this.props
    return <Fragment>{this.generateFormFields(dataSouce)}</Fragment>
  }
}
