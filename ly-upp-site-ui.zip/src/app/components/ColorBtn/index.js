/*
 * @Description: 颜色选择框
 * @Author: qizc
 * @Date: 2019-06-18 09:37:54
 * @LastEditors: qizc
 * @LastEditTime: 2019-06-18 15:13:59
 */

import React from "react";
import { Popover } from "antd";
import PropTypes from "prop-types";
import { colorConfig } from "src/app/config/global";
import { getColor } from "utils/util";
import { SketchPicker } from "react-color";

export default class ColorBtn extends React.Component {
    static propTypes = {
        small: PropTypes.bool,
        colorType: PropTypes.oneOf(["rgb", "hex", "hsl", "hsv"]),
        pickerOptions: PropTypes.object
    };
    static defaultProps = {
        small: true, // 按钮大小
        colorType: "rgb", // 按钮大小
        pickerOptions: {
            // picker 属性
            type: "sketch", // 类型
            presetColors: colorConfig.presetColors // 颜色
        }
    };

    // 根据props的值更新state
    static getDerivedStateFromProps(nextProps, prevState) {
        if ("value" in nextProps && nextProps.value !== prevState.value) {
            return {
                value: nextProps.value
            };
        }
        return null;
    }

    constructor(props) {
        super(props);

        const value = props.value;
        this.state = {
            value: value,
            visible: false
        };
    }

    // 向外传递值
    triggerChange = changedValue => {
        const onChange = this.props.onChange;
        if (onChange) {
            onChange(changedValue);
        }
    };

    handleClick = () => {
        this.setState({ visible: !this.state.visible });
    };

    // 改变
    handleChange = color => {
        const { colorType } = this.props;
        if (!("value" in this.props)) {
            this.setState({ value: color[colorType] });
        }
        this.triggerChange(color[colorType]);
    };

    handleVisibleChange = visible => {
        this.setState({ visible: visible });
    };

    render() {
        const { small, className, colorType, pickerOptions } = this.props;
        const { value } = this.state;

        // 获取可显示的颜色
        const backgroundColor = getColor(value, colorType);

        const styles = {
            color: {
                width: small ? "16px" : "120px",
                height: small ? "16px" : "24px",
                borderRadius: "2px",
                backgroundColor: backgroundColor
            },
            swatch: {
                padding: "5px",
                background: "#fff",
                borderRadius: "1px",
                boxShadow: "0 0 0 1px rgba(0,0,0,.1)",
                display: "inline-block",
                cursor: "pointer",
                verticalAlign: "middle"
            }
        };

        return (
            <div className={className}>
                <Popover
                    overlayClassName="colorPopover"
                    visible={this.state.visible}
                    content={
                        <SketchPicker
                            color={this.state.value}
                            onChange={this.handleChange}
                            {...pickerOptions}
                        />
                    }
                    trigger="click"
                    onVisibleChange={this.handleVisibleChange}
                >
                    <div style={styles.swatch} onClick={this.handleClick}>
                        <div style={styles.color} />
                    </div>
                </Popover>
            </div>
        );
    }
}
