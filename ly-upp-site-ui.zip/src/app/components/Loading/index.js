/*
 * @Description:Loading--页面加载loading
 * @Author: qizc
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 14:49:32
 */

"use strict";
import React from "react";
import { Spin } from "antd";

class _Loading extends React.Component {
  render() {
    const { children, pastDelay, error, isLoading } = this.props;

    if (error) {
      console.log(error);
      return (
        <div
          style={{
            height: "100%",
            width: "100%",
            position: "relative"
          }}
        >
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%"
            }}
          >
            Error!
          </div>
        </div>
      );
    } else if (pastDelay) {
      return (
        <div
          style={{
            height: "100%",
            width: "100%",
            position: "relative"
          }}
        >
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%"
            }}
          >
            <Spin />
          </div>
        </div>
      );
    }

    if (children && !isLoading) {
      return (
        <div
          key="page"
          style={{
            height: "100%",
            width: "100%"
          }}
        >
          {children}
        </div>
      );
    }
    return null;
  }
}

export default _Loading;
