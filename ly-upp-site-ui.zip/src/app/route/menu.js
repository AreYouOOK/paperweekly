/*
 * @Description:菜单
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-13 09:51:11
 */

// import asyncComponent from "utils/asyncComponent"; //按需加载组件
// /********** 应用中心 **********/
// const NewPage = asyncComponent({
//   loader: () => import("../layout/newPage/index")
// });
// // /********** 应用中心 **********/
// const Apply = asyncComponent({
//   loader: () => import("../layout/apply/index")
// });
// /********** 主题中心 **********/
// const ThemeCenter = asyncComponent({
//   loader: () => import("../layout/themeCenter/index")
// });
// /********** 卡片设置 **********/
// const CardSet = asyncComponent({
//   loader: () => import("../layout/cardSet/index")
// });

export const menuData = [
  // {
  //   pageId: "index",
  //   pageName: "首页",
  //   pagePath: "index",
  //   key: "index",
  //   isShow: "1",
  //   type: "index",
  //   component: NewPage
  // },
  // {
  //   pageId: "lyappCenter",
  //   pageName: "应用中心",
  //   pagePath: "apply",
  //   key: "apply",
  //   isShow: "0",
  //   type: "apply",
  //   locales: {
  //     en_US: {
  //       name: "ApplyCenter"
  //     },
  //     zh_CN: {
  //       name: "应用中心"
  //     }
  //   },
  //   component: Apply
  // },
  // {
  //   pageId: "ly_theme",
  //   pageName: "主题中心",
  //   pagePath: "theme",
  //   isShow: "0",
  //   key: "theme",
  //   type: "theme",
  //   component: ThemeCenter
  // },
  // {
  //   pageId: "ly_CardSet",
  //   pageName: "卡片设置",
  //   pagePath: "cardSet",
  //   key: "cardSet",
  //   isShow: "0",
  //   type: "cardSet",
  //   component: CardSet
  // }
];

// 日程菜单
export const scheduleMenus = [
  {
    pageId: "schedule",
    pageName: "日程管理",
    pagePath: "schedule",
    key: "schedule",
    isShow: "0",
    // type: "schedule",
    hidden: true,
    isBuiltIn: true // 特加字段，用于判断是否是前端代码里内置页面（类似于隐藏页面，不显示在菜单，区别于普通页面，作为一些功能性的页面展示）
  },
  {
    pageId: "schedulePublish",
    pageName: "日程发布",
    pagePath: "schedulePublish",
    key: "schedulePublish",
    isShow: "0",
    // type: "schedulePublish",
    hidden: true,
    isBuiltIn: true
  },
  {
    pageId: "scheduleDetail",
    pageName: "日程详情",
    pagePath: "scheduleDetail",
    key: "scheduleDetail",
    isShow: "0",
    // type: "scheduleDetail",
    hidden: true,
    isBuiltIn: true
  },
]

// 菜单处理，添加上/
export const formatter = (data, parentPath = "/") => {
  return data.map(item => {
    let { pagePath } = item;
    const reg = /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/g;
    if (!reg.test(pagePath)) {
      pagePath = parentPath + item.pagePath;
    }
    const result = {
      ...item,
      pagePath
    };

    if (item.children) {
      result.children = formatter(
        item.children,
        `${parentPath}${item.pagePath}/`
      );
    }
    return result;
  });
};
