/*
 * @Description: 全局配置信息
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-15 14:58:17
 */
export const config = {
    appId: "license",
    title: "联谊大学服务门户",
    english: "",
    version: "V2.0.20170512-31058"
};

// 颜色配置
export const colorConfig = {
    presetColors: [
        "#F5222D",
        "#FA541C",
        "#FA8C16",
        "#FAAD14",
        "#FADB14",
        "#A0D911",
        "#52C41A",
        "#13C2C2",
        "#1890FF",
        "#2F54EB",
        "#722ED1",
        "#EB2F96"
    ]
};

