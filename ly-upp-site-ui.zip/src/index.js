/*
 * @Description: 项目路口
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: xuqiuting
 * @LastEditTime: 2019-10-12 11:22:36
 */
import "babel-polyfill";
import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { AppContainer } from "react-hot-loader";
import { message } from "antd";

import "antd/dist/antd.min.css";
import "moment/locale/zh-cn";
import "../node_modules/slick-carousel/slick/slick.css";
import "../node_modules/slick-carousel/slick/slick-theme.css";
import "../node_modules/react-grid-layout/css/styles.css";
import "../node_modules/react-resizable/css/styles.css";
import "../assets/css/reset.less";
import "../assets/css/global.less";
import "../assets/css/guide.less";
import "../assets/theme/variables.less";
import "../assets/css/template.less";
import "../assets/theme/theme.less";
import "../assets/css/systemTheme.less";
import "lodash";
import GlobalRoute from "./plugins/globalRoute/index";
import store from "./redux/store/configureStore";

// ant-design信息弹出时间全局控制
message.config({
  duration: 1,
  maxCount: 3
});

//解决移动端300毫秒延迟
var FastClick = require("fastclick");
FastClick.attach(document.body);

const render = Component => {
  ReactDOM.render(
    <AppContainer>
      <Provider store={store}>
        <Component />
      </Provider>
    </AppContainer>,
    document.getElementById("root")
  );
};

render(GlobalRoute);

// 热更新
if (module.hot) {
  module.hot.accept("./plugins/globalRoute/index", () => {
    render(GlobalRoute);
  });
}
