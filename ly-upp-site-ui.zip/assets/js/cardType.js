/*
 * @Description: file conten
 * @Author: liyaochuan
 * @Date: 2019-11-13 15:03:53
 * @LastEditors  : chenzezhen
 * @LastEditTime : 2020-01-07 11:25:48
 */
window.cardType = [
  {
    id: '0-1',
    name: 'iframe',
    locale: {
      zh_CN: 'iframe',
      en_US: 'iframe'
    },
    component: 'IfameComponent',
    path: '/card/list/iframeEdit'
  },
  {
    id: '0-2',
    name: '选项卡',
    locale: {
      zh_CN: '选项卡',
      en_US: 'tab card'
    },
    component: 'SelectCard',
    path: '/card/list/setTab'
  },
  {
    id: '0-3',
    name: '应用展示',
    locale: {
      zh_CN: '应用展示',
      en_US: 'service display'
    },
    component: 'BuiltInAppTypeShow',
    path: '/card/list/ServiceTypeShowConfig'
  },
  {
    id: '1-1',
    name: '内容服务展示',
    locale: {
      zh_CN: '内容服务展示',
      en_US: 'content service display'
    },
    component: 'ServiceComponent',
    path: '/card/list/allocate'
  },
  {
    id: '1-2',
    name: '图表服务展示',
    locale: {
      zh_CN: '图表服务展示',
      en_US: 'charts service display'
    },
    component: 'BuiltInEcharts',
    path: '/card/list/chartConfigEdit'
  },
  {
    id: '2-1',
    name: '个人信息',
    locale: {
      zh_CN: '个人信息',
      en_US: 'user info'
    },
    component: 'ServiceComponent'
  },
  {
    id: '2-2',
    name: '课表',
    locale: {
      zh_CN: '课表',
      en_US: 'timetable'
    },
    component: 'TimetableCard',
    path: '/card/list/LessonsList'
  },
  {
    id: '2-3',
    name: '邮箱',
    locale: {
      zh_CN: '邮箱',
      en_US: 'mail'
    },
    component: 'Mailcard',
    path: '/card/list/setmail'
  },
  {
    id: '3-1',
    name: '一卡通',
    locale: {
      zh_CN: '一卡通',
      en_US: 'OneCard'
    },
    component: 'OneCard'
  },
  {
    id: '3-2',
    name: '工资信息',
    locale: {
      zh_CN: '工资信息',
      en_US: 'Salary'
    },
    component: 'Salary'
  },
  {
    id: '3-3',
    name: '图书展示',
    locale: {
      zh_CN: '图书展示',
      en_US: 'Book'
    },
    component: 'Booklending'
  },
  {
    id: '3-4',
    name: '图书展示(二)',
    locale: {
      zh_CN: '图书展示(二)',
      en_US: 'Book II'
    },
    component: 'Booklending2'
  },
  {
    id: '3-5',
    name: '一卡通(二)',
    locale: {
      zh_CN: '一卡通(二)',
      en_US: 'OneCard II'
    },
    component: 'OneCard2'
  }
]
