/*
 * @Description: postcss-loader config file
 * @Author: chenzezhen
 * @Date: 2019-12-16 14:08:13
 * @LastEditors: chenzezhen
 * @LastEditTime: 2019-12-16 14:41:41
 */
module.exports = {
  plugins: [
    require('autoprefixer')({
      browsers: [
        'last 10 Chrome versions',
        'last 5 Firefox versions',
        'Safari >= 6',
        'ie> 8'
      ] 
    })
  ]
}