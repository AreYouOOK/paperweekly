﻿/*
 * @Description: webpack配置
 * @Author: xuqiuting
 * @Date: 2019-06-05 10:15:12
 * @LastEditors: chenzezhen
 * @LastEditTime: 2020-02-27 15:55:22
 */
var os = require('os')
var path = require('path')
var webpack = require('webpack')
var ExtractTextPlugin = require('extract-text-webpack-plugin')
var LodashModuleReplacementPlugin = require('lodash-webpack-plugin')
var HTMLPlugin = require('html-webpack-plugin')
const TerserPlugin = require('terser-webpack-plugin-legacy')
// var BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin; //分析工具
// require("babel-polyfill");
const CopyWebpackPlugin = require('copy-webpack-plugin')
const CleanWebpackPlugin = require('clean-webpack-plugin') //打包前清除之前的文件
const AntDesignThemePlugin = require('antd-theme-webpack-plugin')
var argv = require('yargs').argv
var host = '0.0.0.0'
var port = 1111
//判断当前运行环境是开发模式还是生产模式
const nodeEnv = process.env.NODE_ENV || 'development'
const isPro = nodeEnv === 'production'

// 多线程
const HappyPack = require('happypack')
const threads = Math.max(1, os.cpus().length - 1) // 设置最大cpu数 - 1

// 抽离静态资源
const AutoDllPlugin = require('autodll-webpack-plugin')
const Dll = ['react', 'react-dom', 'moment', 'lodash', 'draft-js']

let dir = 'build'
if (isPro) {
  dir = 'dist'
}

console.log('当前运行环境：', isPro ? 'production' : 'development')

// 根据运行模式改变输出方式
const output = isPro
  ? {
      path: path.join(__dirname, dir),
      filename: 'assets/js/[name].[chunkhash:5].js',
      publicPath: './',
      chunkFilename: 'assets/js/chunk/[id].[chunkhash:5].js'
    }
  : { path: path.join(__dirname, dir), filename: 'assets/js/[name].js' }

const htmlPlugin = new HTMLPlugin({
  filename: path.resolve(dir, 'index.html'),
  template: 'index.html',
  inject: true,
  minify: {
    removeComments: true,
    collapseWhitespace: true,
    removeAttributeQuotes: true
    // more options:
    // https://github.com/kangax/html-minifier#options-quick-reference
  },
  // necessary to consistently work with multiple chunks via CommonsChunkPlugin
  chunksSortMode: 'dependency'
})

// 主题配置
const themeOptions = {
  antDir: path.join(__dirname, './node_modules/antd'),
  stylesDir: path.join(__dirname, './assets/theme'),
  varFile: path.join(__dirname, './assets/theme/variables.less'),
  mainLessFile: path.join(__dirname, './assets/theme/theme.less'),
  themeVariables: ['@primary-color'],
  publicPath: './',
  indexFileName: false,
  generateOnce: false
}

const themePlugin = new AntDesignThemePlugin(themeOptions)

var plugins = [
  new LodashModuleReplacementPlugin({
    paths: true
  }),
  new HappyPack({
    // 用唯一的标识符 id 来代表当前的 HappyPack 是用来处理一类特定的文件
    id: 'babel',
    threads: threads,
    // 如何处理 .js 文件，用法和 Loader 配置中一样
    loaders: ['babel-loader?cacheDirectory=true']
    // ... 其它配置项
  }),
  new ExtractTextPlugin({
    filename: 'assets/css/[name].[contenthash].css',
    allChunks: true
  }),
  new webpack.DefinePlugin({
    // 定义全局变量
    'process.env': {
      NODE_ENV: JSON.stringify(nodeEnv)
    }
  }),
  htmlPlugin,
  themePlugin,
  new AutoDllPlugin({
    context: path.join(__dirname, './'),
    inject: true, // will inject the DLL bundle to index.html
    debug: true,
    filename: '[name]_[hash:5].dll.js',
    path: './assets/js/dll',
    entry: {
      vendor: Dll
    },
    plugins: isPro
      ? [
          new webpack.DefinePlugin({
            // 定义全局变量
            'process.env': {
              NODE_ENV: JSON.stringify('production')
            }
          }),
          new TerserPlugin({
            cache: true,
            parallel: true,
            sourceMap: false,
            extractComments: false
          })
        ]
      : []
  }),
  new webpack.optimize.CommonsChunkPlugin({
    name: 'vendor',
    minChunks: function(module) {
      // 该配置假定你引入的 vendor 存在于 node_modules 目录中
      return module.context && module.context.indexOf('node_modules') !== -1
    }
  }),
  new CopyWebpackPlugin([
    {
      from: __dirname + '/assets/images',
      to: __dirname + '/' + dir + '/assets/images'
    },
    { from: __dirname + '/assets/js', to: __dirname + '/' + dir + '/assets/js' }
  ]),
  // new BundleAnalyzerPlugin(),
  // 只加载locale zh-cn文件
  new webpack.ContextReplacementPlugin(/moment[\/\\]locale$/, /zh-cn/),
  new CleanWebpackPlugin()
]
var app = ['./index']
if (isPro) {
  plugins.push(
    new TerserPlugin({
      cache: true,
      parallel: true,
      sourceMap: false,
      extractComments: false,
      terserOptions: {
        warnings: false,
        compress: {
          drop_debugger: true,
          drop_console: true,
          pure_funcs: ['console.log']
        }
      }
    })
  )
} else {
  app.unshift(
    'react-hot-loader/patch',
    `webpack-dev-server/client?http://${host}:${port}`,
    'webpack/hot/only-dev-server'
  )
  plugins.push(
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NamedModulesPlugin(),
    new webpack.NoEmitOnErrorsPlugin()
  )
}
app.unshift('babel-polyfill')

module.exports = {
  context: path.resolve(__dirname, 'src'),
  devtool: isPro ? 'source-map' : 'inline-source-map',
  entry: {
    app: app
  },
  output: output,
  // BASE_URL是全局的api接口访问地址
  plugins,
  // alias是配置全局的路径入口名称，只要涉及到下面配置的文件路径，可以直接用定义的单个字母表示整个路径
  resolve: {
    extensions: ['.js', '.jsx', '.less', '.scss', '.css'],
    modules: [
      path.resolve(__dirname, 'node_modules'),
      path.join(__dirname, './src')
    ],
    alias: {
      assets: path.join(__dirname, '/assets'),
      src: path.join(__dirname, '/src'),
      components: path.join(__dirname, '/src/app/components'),
      utils: path.join(__dirname, '/src/utils'),
      plugins: path.join(__dirname, '/src/plugins'),
      comon: path.join(__dirname, '/src/comon'),
      '@redux': path.join(__dirname, '/src/redux')
    }
  },
  module: {
    rules: [
      {
        test: /\.js|.jsx$/,
        exclude: /(node_modules)/,
        use: ['happypack/loader?id=babel']
      },
      {
        test: /\.less$/,
        include: /src/,
        use: ExtractTextPlugin.extract({
          use: [
            {
              loader:
                'css-loader?modules&localIdentName=[path][name]-[local]-[hash:base64:5]'
            },
            {
              loader: 'postcss-loader'
            },
            {
              loader: 'less-loader'
            }
          ],
          publicPath: '../../'
        })
      },
      {
        test: /\.less$/,
        include: /(node_modules)|(assets)/,
        use: ExtractTextPlugin.extract({
          use: [
            {
              loader: 'css-loader' // translates CSS into CommonJS
            },
            {
              loader: 'postcss-loader'
            },
            {
              loader: 'less-loader' // compiles Less to CSS
            }
          ],
          publicPath: '../../'
        })
      },
      {
        test: /\.css$/,
        include: /(src)/,
        use: ExtractTextPlugin.extract({
          use: [
            {
              loader:
                'css-loader?modules&localIdentName=[path][name]-[local]-[hash:base64:5]'
            },
            {
              loader: 'postcss-loader'
            }
          ],
          publicPath: '../../'
        })
      },
      {
        test: /\.css$/,
        include: /(node_modules)|(assets)/,
        use: ExtractTextPlugin.extract({
          use: [
            {
              loader: 'css-loader'
            },
            {
              loader: 'postcss-loader'
            }
          ],
          publicPath: '../../'
        })
      },
      {
        test: /\.(png|jpg|gif|svg|eot|ttf|woff|woff2)$/,
        use: [
          'url-loader?limit=10000&name=assets/images/[md5:hash:base64:10].[ext]'
        ]
      }
    ]
  },
  devServer: {
    hot: true,
    compress: true,
    host,
    port,
    historyApiFallback: true,
    proxy: {
      '/weather': {
        //天气
        // target: 'http://192.168.35.105:1101',
        target: 'http://192.168.30.71:4106',
        secure: false,
        changeOrigin: true
      },
      '/login': {
        // target: 'http://192.168.35.105:1101',
        target: 'http://192.168.30.71:1101',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true
      },
      '/logout': {
        // target: 'http://192.168.35.105:1101',
        target: 'http://192.168.30.71:1101',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true
      },
      '/tryLoginUserInfo': {
        // target: 'http://192.168.35.105:1101',
        target: 'http://192.168.30.71:1101',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true
      },
      '/download': {
        // target: 'http://192.168.35.105:1430',
        target: 'http://192.168.30.71:1430',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true
      },
      '/api/uppexcard': {
        // target: 'http://192.168.35.105:4208',
        target: 'http://192.168.30.71:4208',
        changeOrigin: true,
        pathRewrite: {
          '^/api/uppexcard': ''
        }
      },
      '/zuul': {
        // target: 'http://192.168.35.105:1101',
        target: 'http://192.168.30.71:1101',
        changeOrigin: true
      },
      '/api/uppcard': {
        // target: 'http://192.168.35.105:4207',
        target: 'http://192.168.30.71:4207',
        changeOrigin: true,
        pathRewrite: {
          '^/api/uppcard': ''
        }
      },
      '/api/upp': {
        target: 'http://192.168.30.71:4205', //共
        changeOrigin: true,
        pathRewrite: {
          '^/api/upp': ''
        }
      },
      '/api/schedule': {
        // target: 'http://192.168.35.105:5102',
        target: 'http://192.168.30.71:5102',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true,
        pathRewrite: {
          '/api/schedule': ''
        }
      },
      '/api/authc': {
        // target: 'http://192.168.35.105:1400',
        target: 'http://192.168.30.71:1400',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true,
        pathRewrite: {
          '/api/authc': ''
        }
      },
      '/api/oa_pub_info': {
        target: 'http://192.168.35.27:1101/',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true
      },
      '/shiro-cas': {
        // target: 'http://192.168.35.105:1101',
        target: 'http://192.168.30.71:1101',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true
      },
      '/auth': {
        // target: 'http://192.168.35.105:1101',
        target: 'http://192.168.30.71:1101',
        secure: false, // 接受 运行在 https 上的服务
        changeOrigin: true
      }
    },
    stats: {
      modules: false,
      chunks: false
    }
  }
}
