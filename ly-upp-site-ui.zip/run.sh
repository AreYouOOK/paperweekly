#!/bin/bash
#Date:nginx-1.12.1.tar.gz nginx-1.12.1.tar.gz 9:13 2017-9-18
#Author:nginx-1.12.1.tar.gz Create By Lingyuwang
#Mail:nginx-1.12.1.tar.gz nginx-1.12.1.tar.gz lingyuwang@ly-sky.com
#Function:nginx-1.12.1.tar.gz start nginx
#Version:nginx-1.12.1.tar.gz 1.0

###############################
#########CAS 激活状态配置##########
###############################
casEnable=false

if   [ $Cas_Enable ]; 
then 
    casEnable=$Cas_Enable 
fi

echo "casEnable=$casEnable"

sed -i 's/_casStatus/'"$casEnable"'/g' /usr/share/nginx/html/index.html

###############################
#########CAS 登出地址配置##########
###############################
casLogoutUrl=""

if   [ $Cas_LogoutURL ]; 
then 
    casLogoutUrl=$Cas_LogoutURL 
fi

echo "casLogoutUrl=$casLogoutUrl"

sed -i 's|_casLogoutUrl|'"$casLogoutUrl"'|g' /usr/share/nginx/html/index.html



nginx -g  "daemon off;"
